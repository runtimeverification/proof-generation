$c #Substitution #SetVariable #ElementVariable #Symbol ) #Variable #Pattern \kore-sort-SortBlock ( $.
$v ph0 xX xX0 ptn0 ph1 $.
ph0-is-pattern $f #Pattern ph0 $.
ph1-is-pattern $f #Pattern ph1 $.
xX-is-var $f #Variable xX $.
${ $d xX ph0 $.
   substitution-disjoint $a #Substitution ph0 ph0 ph1 xX $. $}
xX0-variable $f #Variable xX0 $.
ptn0-pattern $f #Pattern ptn0 $.
IMP-sort-18-is-pattern $a #Pattern \kore-sort-SortBlock $.
${ IMP-sort-18-substitution $p #Substitution \kore-sort-SortBlock \kore-sort-SortBlock ptn0 xX0 $= ( IMP-sort-18-is-pattern substitution-disjoint ) CBAD $. $}
