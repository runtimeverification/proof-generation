$c #Notation \kore-symbol-LblisGeneratedCounterCell-symbol #SetVariable #ElementVariable #Symbol #Variable #Pattern #ApplicationContext \kore-symbol-LblisGeneratedCounterCell \app ) ( $.
$v ph0 xX xX0 sg0 ptn0 ph1 $.
ph0-is-pattern $f #Pattern ph0 $.
ph1-is-pattern $f #Pattern ph1 $.
xX-is-var $f #Variable xX $.
sg0-is-symbol $f #Symbol sg0 $.
symbol-is-pattern $a #Pattern sg0 $.
app-is-pattern $a #Pattern ( \app ph0 ph1 ) $.
${ $d xX ph0 $.
   application-context-app-right.0 $e #ApplicationContext xX ph1 $.
   application-context-app-right $a #ApplicationContext xX ( \app ph0 ph1 ) $. $}
${ notation-application-context.0 $e #ApplicationContext xX ph0 $.
   notation-application-context.1 $e #Notation ph1 ph0 $.
   notation-application-context $a #ApplicationContext xX ph1 $. $}
xX0-variable $f #Variable xX0 $.
ptn0-pattern $f #Pattern ptn0 $.
IMP-symbol-255-is-symbol $a #Symbol \kore-symbol-LblisGeneratedCounterCell-symbol $.
IMP-symbol-255-is-pattern $a #Pattern ( \kore-symbol-LblisGeneratedCounterCell ptn0 ) $.
notation-cache-502 $a #Notation ( \kore-symbol-LblisGeneratedCounterCell ptn0 ) ( \app \kore-symbol-LblisGeneratedCounterCell-symbol ptn0 ) $.
${ IMP-symbol-255-application-context-0.0 $e #ApplicationContext xX0 ptn0 $.
   IMP-symbol-255-application-context-0 $p #ApplicationContext xX0 ( \kore-symbol-LblisGeneratedCounterCell ptn0 ) $= ( IMP-symbol-255-is-symbol symbol-is-pattern app-is-pattern IMP-symbol-255-is-pattern application-context-app-right notation-cache-502 notation-application-context ) DEBFBGADEBACHBIJ $. $}
