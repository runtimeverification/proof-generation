$c #Notation \kore-symbol-LblList'Coln'get #SetVariable #ElementVariable #Symbol #Variable #Pattern #ApplicationContext \app \kore-symbol-LblList'Coln'get-symbol ) ( $.
$v ph0 xX xX0 sg0 ptn1 ptn0 ph1 $.
ph0-is-pattern $f #Pattern ph0 $.
ph1-is-pattern $f #Pattern ph1 $.
xX-is-var $f #Variable xX $.
sg0-is-symbol $f #Symbol sg0 $.
symbol-is-pattern $a #Pattern sg0 $.
app-is-pattern $a #Pattern ( \app ph0 ph1 ) $.
${ $d xX ph0 $.
   application-context-app-right.0 $e #ApplicationContext xX ph1 $.
   application-context-app-right $a #ApplicationContext xX ( \app ph0 ph1 ) $. $}
${ notation-application-context.0 $e #ApplicationContext xX ph0 $.
   notation-application-context.1 $e #Notation ph1 ph0 $.
   notation-application-context $a #ApplicationContext xX ph1 $. $}
xX0-variable $f #Variable xX0 $.
ptn0-pattern $f #Pattern ptn0 $.
ptn1-pattern $f #Pattern ptn1 $.
IMP-symbol-139-is-symbol $a #Symbol \kore-symbol-LblList'Coln'get-symbol $.
IMP-symbol-139-is-pattern $a #Pattern ( \kore-symbol-LblList'Coln'get ptn0 ptn1 ) $.
notation-cache-188 $a #Notation ( \kore-symbol-LblList'Coln'get ptn0 ptn1 ) ( \app ( \app \kore-symbol-LblList'Coln'get-symbol ptn0 ) ptn1 ) $.
${ $d xX0 ptn0 $.
   IMP-symbol-139-application-context-1.0 $e #ApplicationContext xX0 ptn1 $.
   IMP-symbol-139-application-context-1 $p #ApplicationContext xX0 ( \kore-symbol-LblList'Coln'get ptn0 ptn1 ) $= ( app-is-pattern IMP-symbol-139-is-symbol symbol-is-pattern IMP-symbol-139-is-pattern application-context-app-right notation-cache-188 notation-application-context ) FGBECEBCHAFGBECADIBCJK $. $}
