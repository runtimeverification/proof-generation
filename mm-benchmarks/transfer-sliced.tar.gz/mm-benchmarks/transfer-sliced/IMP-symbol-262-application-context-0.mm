$c #Notation #SetVariable #ElementVariable \kore-symbol-LblisIOString #Symbol #Variable #Pattern #ApplicationContext \kore-symbol-LblisIOString-symbol \app ) ( $.
$v ph0 xX xX0 sg0 ptn0 ph1 $.
ph0-is-pattern $f #Pattern ph0 $.
ph1-is-pattern $f #Pattern ph1 $.
xX-is-var $f #Variable xX $.
sg0-is-symbol $f #Symbol sg0 $.
symbol-is-pattern $a #Pattern sg0 $.
app-is-pattern $a #Pattern ( \app ph0 ph1 ) $.
${ $d xX ph0 $.
   application-context-app-right.0 $e #ApplicationContext xX ph1 $.
   application-context-app-right $a #ApplicationContext xX ( \app ph0 ph1 ) $. $}
${ notation-application-context.0 $e #ApplicationContext xX ph0 $.
   notation-application-context.1 $e #Notation ph1 ph0 $.
   notation-application-context $a #ApplicationContext xX ph1 $. $}
xX0-variable $f #Variable xX0 $.
ptn0-pattern $f #Pattern ptn0 $.
IMP-symbol-262-is-symbol $a #Symbol \kore-symbol-LblisIOString-symbol $.
IMP-symbol-262-is-pattern $a #Pattern ( \kore-symbol-LblisIOString ptn0 ) $.
notation-cache-523 $a #Notation ( \kore-symbol-LblisIOString ptn0 ) ( \app \kore-symbol-LblisIOString-symbol ptn0 ) $.
${ IMP-symbol-262-application-context-0.0 $e #ApplicationContext xX0 ptn0 $.
   IMP-symbol-262-application-context-0 $p #ApplicationContext xX0 ( \kore-symbol-LblisIOString ptn0 ) $= ( IMP-symbol-262-is-symbol symbol-is-pattern app-is-pattern IMP-symbol-262-is-pattern application-context-app-right notation-cache-523 notation-application-context ) DEBFBGADEBACHBIJ $. $}
