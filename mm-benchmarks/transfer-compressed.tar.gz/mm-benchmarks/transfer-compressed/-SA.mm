$c #Symbol #Variable SwE #SetVariable ) 4w YQk JAQ #ElementVariable IQE #Pattern ( $.
$v 7Ag 2gg CQ Bw $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
4g $a #Pattern ( 4w Bw CQ ) $.
IAE $a #Pattern IQE $.
SgE $a #Pattern ( SwE Bw CQ ) $.
IwQ $a #Pattern ( JAQ Bw ) $.
2Qg $f #ElementVariable 2gg $.
6wg $f #ElementVariable 7Ag $.
YAk $a #Pattern YQk $.
Wh8 $a #Pattern 2gg $.
-CA $a #Pattern 7Ag $.
${ -SA $p #Pattern ( 4w ( JAQ 2gg ) ( 4w ( SwE 7Ag YQk ) IQE ) ) $=
  ( Wh8 IwQ -CA YAk SgE IAE 4g ) ACDBEFGHII $. $}
