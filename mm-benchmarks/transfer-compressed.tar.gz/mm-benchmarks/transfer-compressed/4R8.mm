$c #SetVariable iA ) #ElementVariable #Symbol #Variable #Pattern ( $.
$v 7Rw Ow CQ xX Bw Kw ph0 0R8 6xw $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Kg $f #ElementVariable Kw $.
Og $f #Variable Ow $.
SA $a #Variable Kw $.
${ $d xX ph0 $.
   IQI $a iA Bw Bw CQ Ow $. $}
6hw $f #ElementVariable 6xw $.
7Bw $f #ElementVariable 7Rw $.
0B8 $f #ElementVariable 0R8 $.
1B8 $a #Pattern 7Rw $.
1h8 $a #Pattern 0R8 $.
${ 4R8 $p iA 7Rw 7Rw 0R8 6xw $=
  ( 1B8 1h8 SA IQI ) BDCEAFG $. $}
