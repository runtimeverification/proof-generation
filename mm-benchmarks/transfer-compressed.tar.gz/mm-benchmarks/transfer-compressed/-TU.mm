$c 4B4 Ngk Lwk #Symbol 7h4 8Q4 zw xwM pgg #Pattern 0Q4 rwg Ex0 xB4 tQM Wgk 0h4 #Variable SwE PQk #SetVariable vR4 4w #ElementVariable IQE 8hw xQg cBQ lSA 2R4 XBI RAk Tw 1CA wQM -g4 rgk ( twM LAQ ewk yx4 IAQ 9R4 Hg8 Kw8 8wk 7Ak 7BI ) $.
$v oAg Cw GQ CQ qwg Bw $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Cg $f #Pattern Cw $.
GA $f #Pattern GQ $.
4g $a #Pattern ( 4w Bw CQ ) $.
IAE $a #Pattern IQE $.
SgE $a #Pattern ( SwE Bw CQ ) $.
${ lgE $e zw ( Tw Bw CQ ) $.
   lwE $e zw ( Tw CQ Cw ) $.
   mAE $a zw ( Tw Bw Cw ) $. $}
${ wAE $e zw ( Tw Bw CQ ) $.
   wQE $e zw ( Tw Bw Cw ) $.
   wgE $a zw ( Tw Bw ( 4w CQ Cw ) ) $. $}
uwM $a #Pattern ( twM Bw ) $.
wAM $a #Pattern ( wQM Bw CQ Cw ) $.
HwQ $a #Pattern ( IAQ Bw CQ ) $.
KwQ $a #Pattern ( LAQ Bw CQ Cw ) $.
JwU $a zw ( Tw ( 4w ( SwE CQ Bw ) ( SwE Cw Bw ) ) ( SwE ( wQM Bw CQ Cw ) Bw ) ) $.
${ sgU $e zw ( Tw GQ ( SwE CQ Bw ) ) $.
   swU $a zw ( Tw GQ ( tQM Bw ( xwM Bw CQ CQ ) ) ) $. $}
nwg $f #Pattern oAg $.
pQg $a #Pattern pgg $.
qgg $f #Pattern qwg $.
rgg $a #Pattern ( rwg oAg qwg ) $.
xAg $a #Pattern xQg $.
Lgk $a #Pattern Lwk $.
NQk $a #Pattern Ngk $.
PAk $a #Pattern PQk $.
Qwk $a #Pattern RAk $.
WQk $a #Pattern Wgk $.
egk $a #Pattern ewk $.
rQk $a #Pattern rgk $.
6wk $a #Pattern 7Ak $.
8gk $a #Pattern 8wk $.
0A4 $a #Pattern ( 0Q4 oAg qwg ) $.
3Q4 $a zw ( Tw ( 4w ( SwE oAg Lwk ) ( SwE qwg PQk ) ) ( SwE ( 0Q4 oAg qwg ) 7Ak ) ) $.
8A4 $a #Pattern ( 8Q4 oAg ) $.
-Q4 $a #Pattern ( -g4 oAg qwg ) $.
Cg8 $a zw ( Tw ( 4w ( SwE oAg 7Ak ) ( SwE qwg RAk ) ) ( SwE ( -g4 oAg qwg ) Ngk ) ) $.
HQ8 $a #Pattern ( Hg8 oAg ) $.
Kg8 $a #Pattern ( Kw8 oAg ) $.
WxI $a #Pattern ( XBI oAg qwg ) $.
6xI $a #Pattern ( 7BI oAg qwg ) $.
bxQ $a #Pattern ( cBQ oAg qwg ) $.
8Rw $a #Pattern 8hw $.
Eh0 $a #Pattern Ex0 $.
vB4 $a #Pattern vR4 $.
wx4 $a #Pattern xB4 $.
yh4 $a #Pattern yx4 $.
0R4 $a #Pattern 0h4 $.
2B4 $a #Pattern 2R4 $.
3x4 $a #Pattern 4B4 $.
7R4 $a #Pattern 7h4 $.
9B4 $a #Pattern 9R4 $.
.R4 $a zw ( Tw IQE ( SwE ( twM Ngk ) Ngk ) ) $.
Kx8 $a zw ( Tw IQE ( SwE ( 8Q4 ( IAQ rgk 8hw ) ) RAk ) ) $.
lCA $a #Pattern lSA $.
qSA $a zw ( Tw IQE ( SwE ( Kw8 ( 7BI ( cBQ ( LAQ ewk pgg ( IAQ ewk xB4 ) ) ( LAQ rgk pgg ( IAQ rgk 8hw ) ) ) ( 7BI ( cBQ ( LAQ ewk pgg ( IAQ ewk vR4 ) ) ( LAQ rgk pgg ( IAQ rgk lSA ) ) ) ( 7BI ( cBQ ( LAQ ewk pgg ( IAQ ewk 9R4 ) ) ( LAQ rgk pgg ( IAQ rgk yx4 ) ) ) ( 7BI ( cBQ ( LAQ ewk pgg ( IAQ ewk 7h4 ) ) ( LAQ rgk pgg ( IAQ rgk 4B4 ) ) ) ( cBQ ( LAQ ewk pgg ( IAQ ewk 2R4 ) ) ( LAQ rgk pgg ( IAQ rgk 0h4 ) ) ) ) ) ) ) ) PQk ) ) $.
0yA $a #Pattern 1CA $.
3yA $a zw ( Tw IQE ( SwE ( Hg8 ( rwg ( LAQ 8wk pgg ( XBI ( IAQ ewk 7h4 ) ( LAQ rgk Wgk ( IAQ rgk 1CA ) ) ) ) ( rwg ( LAQ 8wk pgg ( XBI ( IAQ ewk xB4 ) ( LAQ rgk Wgk ( IAQ rgk Ex0 ) ) ) ) xQg ) ) ) Lwk ) ) $.
${ -TU $p zw ( Tw IQE ( tQM Ngk ( xwM Ngk ( wQM Ngk ( wQM Ngk ( twM Ngk ) ( twM Ngk ) ) ( -g4 ( 0Q4 ( Hg8 ( rwg ( LAQ 8wk pgg ( XBI ( IAQ ewk 7h4 ) ( LAQ rgk Wgk ( IAQ rgk 1CA ) ) ) ) ( rwg ( LAQ 8wk pgg ( XBI ( IAQ ewk xB4 ) ( LAQ rgk Wgk ( IAQ rgk Ex0 ) ) ) ) xQg ) ) ) ( Kw8 ( 7BI ( cBQ ( LAQ ewk pgg ( IAQ ewk xB4 ) ) ( LAQ rgk pgg ( IAQ rgk 8hw ) ) ) ( 7BI ( cBQ ( LAQ ewk pgg ( IAQ ewk vR4 ) ) ( LAQ rgk pgg ( IAQ rgk lSA ) ) ) ( 7BI ( cBQ ( LAQ ewk pgg ( IAQ ewk 9R4 ) ) ( LAQ rgk pgg ( IAQ rgk yx4 ) ) ) ( 7BI ( cBQ ( LAQ ewk pgg ( IAQ ewk 7h4 ) ) ( LAQ rgk pgg ( IAQ rgk 4B4 ) ) ) ( cBQ ( LAQ ewk pgg ( IAQ ewk 2R4 ) ) ( LAQ rgk pgg ( IAQ rgk 0h4 ) ) ) ) ) ) ) ) ) ( 8Q4 ( IAQ rgk 8hw ) ) ) ) ( wQM Ngk ( wQM Ngk ( twM Ngk ) ( twM Ngk ) ) ( -g4 ( 0Q4 ( Hg8 ( rwg ( LAQ 8wk pgg ( XBI ( IAQ ewk 7h4 ) ( LAQ rgk Wgk ( IAQ rgk 1CA ) ) ) ) ( rwg ( LAQ 8wk pgg ( XBI ( IAQ ewk xB4 ) ( LAQ rgk Wgk ( IAQ rgk Ex0 ) ) ) ) xQg ) ) ) ( Kw8 ( 7BI ( cBQ ( LAQ ewk pgg ( IAQ ewk xB4 ) ) ( LAQ rgk pgg ( IAQ rgk 8hw ) ) ) ( 7BI ( cBQ ( LAQ ewk pgg ( IAQ ewk vR4 ) ) ( LAQ rgk pgg ( IAQ rgk lSA ) ) ) ( 7BI ( cBQ ( LAQ ewk pgg ( IAQ ewk 9R4 ) ) ( LAQ rgk pgg ( IAQ rgk yx4 ) ) ) ( 7BI ( cBQ ( LAQ ewk pgg ( IAQ ewk 7h4 ) ) ( LAQ rgk pgg ( IAQ rgk 4B4 ) ) ) ( cBQ ( LAQ ewk pgg ( IAQ ewk 2R4 ) ) ( LAQ rgk pgg ( IAQ rgk 0h4 ) ) ) ) ) ) ) ) ) ( 8Q4 ( IAQ rgk 8hw ) ) ) ) ) ) ) $=
  ( NQk wAM 8gk pQg egk HwQ rQk WQk KwQ WxI rgg bxQ 6xI IAE SgE .R4 wgE JwU mAE
  4g uwM 7R4 0yA wx4 Eh0 xAg HQ8 8Rw vB4 lCA 9B4 yh4 3x4 2B4 0R4 Kg8 0A4 8A4
  -Q4 6wk Qwk Lgk PAk 3yA qSA 3Q4 Kx8 Cg8 swU ) AAAAUAZVJBZCDEUBFZGHGUCFIJICDEU
  DFZGHGUEFIJIUFKKUGZEDVMIGDGUHFZILEDEUIFIGDGUJFILEDEUKFIGDGULFILEDVLIGDGUMFILE
  DEUNFIGDGUOFILMMMMUPZUQZVOURZUSZBZNNVKAOZVSAOZTVTAONWAWBNVJAOZWCTWANWCWCPPQAV
  JVJRSNVQUTOZVRVAOZTWBNWDWENVNVBOZVPVCOZTWDNWFWGVDVEQVNVPVFSVGQVQVRVHSQAVKVSRS
  VI $. $}
