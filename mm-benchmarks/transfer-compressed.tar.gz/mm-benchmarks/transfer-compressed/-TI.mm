$c Ngk RAk 7BA Tw #Symbol wQM -g4 DBE zw pgg rgk 0Q4 #Pattern ( rwg twM .gM LAQ tQM Wgk Hg8 #Variable SwE PQk #SetVariable 4w #ElementVariable IQE mwg ) $.
$v 4wg CQ qwg 3gg Bw oAg 5Qg Cw 3Ag 4Ag $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Cg $f #Pattern Cw $.
4g $a #Pattern ( 4w Bw CQ ) $.
IAE $a #Pattern IQE $.
SgE $a #Pattern ( SwE Bw CQ ) $.
lQE $a zw ( Tw Bw Bw ) $.
${ lgE $e zw ( Tw Bw CQ ) $.
   lwE $e zw ( Tw CQ Cw ) $.
   mAE $a zw ( Tw Bw Cw ) $. $}
ugE $a zw ( Tw ( 4w Bw CQ ) Bw ) $.
uwE $a zw ( Tw ( 4w Bw CQ ) CQ ) $.
${ wAE $e zw ( Tw Bw CQ ) $.
   wQE $e zw ( Tw Bw Cw ) $.
   wgE $a zw ( Tw Bw ( 4w CQ Cw ) ) $. $}
tAM $a #Pattern ( tQM Bw CQ ) $.
uwM $a #Pattern ( twM Bw ) $.
wAM $a #Pattern ( wQM Bw CQ Cw ) $.
.QM $a #Pattern ( .gM Bw CQ Cw ) $.
mgg $a #Pattern mwg $.
nwg $f #Pattern oAg $.
qgg $f #Pattern qwg $.
2wg $f #ElementVariable 3Ag $.
3Qg $f #ElementVariable 3gg $.
3wg $f #ElementVariable 4Ag $.
4gg $f #ElementVariable 4wg $.
5Ag $f #ElementVariable 5Qg $.
NQk $a #Pattern Ngk $.
Qwk $a #Pattern RAk $.
rQk $a #Pattern rgk $.
-Q4 $a #Pattern ( -g4 oAg qwg ) $.
TB0 $a zw ( Tw ( 4w ( SwE 3Ag RAk ) ( 4w ( SwE 4Ag rgk ) ( 4w ( SwE 3gg mwg ) ( 4w ( SwE 4wg PQk ) ( 4w ( SwE 5Qg rgk ) IQE ) ) ) ) ) ( tQM Ngk ( .gM Ngk ( wQM Ngk ( twM Ngk ) ( -g4 ( 0Q4 ( Hg8 ( rwg ( LAQ Wgk pgg ( DBE ( LAQ rgk Wgk 5Qg ) ( LAQ rgk Wgk 4Ag ) ) ) 3gg ) ) 4wg ) 3Ag ) ) ( wQM Ngk ( twM Ngk ) ( -g4 ( 0Q4 ( Hg8 ( rwg ( LAQ rgk pgg ( 7BA 5Qg 4Ag ) ) 3gg ) ) 4wg ) 3Ag ) ) ) ) ) $.
BCQ $a #Pattern 4Ag $.
ByQ $a #Pattern 3Ag $.
XiU $a #Pattern 3gg $.
NS8 $a #Pattern ( 4w ( SwE 4wg PQk ) ( 4w ( SwE 5Qg rgk ) IQE ) ) $.
Pi8 $a zw ( Tw ( 4w ( 4w ( SwE 4Ag rgk ) ( 4w ( SwE 3gg mwg ) ( 4w ( SwE 4wg PQk ) ( 4w ( SwE 5Qg rgk ) IQE ) ) ) ) ( 4w ( SwE 3Ag RAk ) IQE ) ) ( 4w ( SwE 4wg PQk ) ( 4w ( SwE 5Qg rgk ) IQE ) ) ) $.
.jI $a #Pattern ( -g4 ( 0Q4 ( Hg8 ( rwg ( LAQ Wgk pgg ( DBE ( LAQ rgk Wgk 5Qg ) ( LAQ rgk Wgk 4Ag ) ) ) 3gg ) ) 4wg ) 3Ag ) $.
-DI $a #Pattern ( 0Q4 ( Hg8 ( rwg ( LAQ rgk pgg ( 7BA 5Qg 4Ag ) ) 3gg ) ) 4wg ) $.
${ -TI $p zw ( Tw ( 4w ( 4w ( SwE 4Ag rgk ) ( 4w ( SwE 3gg mwg ) ( 4w ( SwE 4wg PQk ) ( 4w ( SwE 5Qg rgk ) IQE ) ) ) ) ( 4w ( SwE 3Ag RAk ) IQE ) ) ( tQM Ngk ( .gM Ngk ( wQM Ngk ( twM Ngk ) ( -g4 ( 0Q4 ( Hg8 ( rwg ( LAQ Wgk pgg ( DBE ( LAQ rgk Wgk 5Qg ) ( LAQ rgk Wgk 4Ag ) ) ) 3gg ) ) 4wg ) 3Ag ) ) ( wQM Ngk ( twM Ngk ) ( -g4 ( 0Q4 ( Hg8 ( rwg ( LAQ rgk pgg ( 7BA 5Qg 4Ag ) ) 3gg ) ) 4wg ) 3Ag ) ) ) ) ) $=
  ( BCQ rQk SgE XiU mgg NS8 4g IAE NQk wAM uwE ugE lQE mAE wgE ByQ Qwk uwM .jI
  -DI -Q4 .QM tAM Pi8 TB0 ) CFGHZBIJHZDEKZLZLZAUAZUBHZMLZLZUQUOLNNNNUCZABCDEUDO
  NUTBCDEUEUPUFOUGUHUSUQUOUSURUQUOURPURUQUQUQMQUQRSSUSUKUNUSUOUKUOURQZUOUKUKUKU
  NQUKRSSUSULUMUSUOULVAUOUNULUKUNPUNULULULUMQULRSSSABCDEUITTTABCDEUJS $. $}
