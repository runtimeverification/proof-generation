$c 0wM 1wk #Symbol #Variable #SetVariable GBY iA rwM #ElementVariable #Pattern ) ( $.
$v yhs Ow ph6 CQ xX DQ Ew XRw Kw Bw Cw 2gg nR4 EQ y -Rs Dw LQ $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Cg $f #Pattern Cw $.
DA $f #Pattern DQ $.
Dg $f #Pattern Dw $.
EA $f #Pattern EQ $.
Eg $f #Pattern Ew $.
Kg $f #ElementVariable Kw $.
LA $f #ElementVariable LQ $.
Og $f #Variable Ow $.
SA $a #Variable Kw $.
${ $d xX y $.
   $d y ph6 $.
   OAQ $e iA Bw DQ Ew Ow $.
   OQQ $e iA CQ Dw Ew Ow $.
   OgQ $e iA Cw EQ Ew Ow $.
   OwQ $a iA ( rwM Bw CQ LQ Cw ) ( rwM DQ Dw LQ EQ ) Ew Ow $. $}
2Qg $f #ElementVariable 2gg $.
1gk $a #Pattern 1wk $.
yRs $f #ElementVariable yhs $.
-Bs $f #ElementVariable -Rs $.
XBw $f #ElementVariable XRw $.
nB4 $f #ElementVariable nR4 $.
Wh8 $a #Pattern 2gg $.
6h8 $a #Pattern nR4 $.
UyE $a iA 2gg 2gg nR4 -Rs $.
9iE $a #Pattern ( 0wM 1wk 2gg yhs ( GBY -Rs XRw ) ) $.
.SE $a #Pattern ( 0wM 1wk 2gg yhs ( GBY nR4 XRw ) ) $.
-CE $a iA 1wk 1wk nR4 -Rs $.
-iE $a iA ( 0wM 1wk 2gg yhs ( GBY nR4 XRw ) ) ( 0wM 1wk 2gg yhs ( GBY -Rs XRw ) ) nR4 -Rs $.
${ -yE $p iA ( rwM 1wk 2gg yhs ( 0wM 1wk 2gg yhs ( GBY nR4 XRw ) ) ) ( rwM 1wk 2gg yhs ( 0wM 1wk 2gg yhs ( GBY -Rs XRw ) ) ) nR4 -Rs $=
  ( 1gk Wh8 .SE 9iE 6h8 SA -CE UyE -iE OwQ ) FAGZABDEHFPABCDIEJBCKCELACEMABCDEN
  O $. $}
