$c Ngk XBI RAk Tw #Symbol wQM -g4 zw YQk mwg rgk pgg #Pattern ( 0Q4 rwg twM .gM LAQ ewk tQM Wgk Hg8 #Variable SwE Kw8 #SetVariable 4w #ElementVariable IQE 8wk 7BI ) cBQ $.
$v 4wg CQ qwg 3gg -Bw Bw oAg 5Qg Cw 3Ag 4Ag $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Cg $f #Pattern Cw $.
4g $a #Pattern ( 4w Bw CQ ) $.
IAE $a #Pattern IQE $.
SgE $a #Pattern ( SwE Bw CQ ) $.
lQE $a zw ( Tw Bw Bw ) $.
${ lgE $e zw ( Tw Bw CQ ) $.
   lwE $e zw ( Tw CQ Cw ) $.
   mAE $a zw ( Tw Bw Cw ) $. $}
ugE $a zw ( Tw ( 4w Bw CQ ) Bw ) $.
uwE $a zw ( Tw ( 4w Bw CQ ) CQ ) $.
${ wAE $e zw ( Tw Bw CQ ) $.
   wQE $e zw ( Tw Bw Cw ) $.
   wgE $a zw ( Tw Bw ( 4w CQ Cw ) ) $. $}
tAM $a #Pattern ( tQM Bw CQ ) $.
uwM $a #Pattern ( twM Bw ) $.
wAM $a #Pattern ( wQM Bw CQ Cw ) $.
.QM $a #Pattern ( .gM Bw CQ Cw ) $.
KwQ $a #Pattern ( LAQ Bw CQ Cw ) $.
mgg $a #Pattern mwg $.
nwg $f #Pattern oAg $.
pQg $a #Pattern pgg $.
qgg $f #Pattern qwg $.
rgg $a #Pattern ( rwg oAg qwg ) $.
2wg $f #ElementVariable 3Ag $.
3Qg $f #ElementVariable 3gg $.
3wg $f #ElementVariable 4Ag $.
4gg $f #ElementVariable 4wg $.
5Ag $f #ElementVariable 5Qg $.
NQk $a #Pattern Ngk $.
Qwk $a #Pattern RAk $.
egk $a #Pattern ewk $.
rQk $a #Pattern rgk $.
8gk $a #Pattern 8wk $.
0A4 $a #Pattern ( 0Q4 oAg qwg ) $.
-Q4 $a #Pattern ( -g4 oAg qwg ) $.
HQ8 $a #Pattern ( Hg8 oAg ) $.
Kg8 $a #Pattern ( Kw8 oAg ) $.
6xI $a #Pattern ( 7BI oAg qwg ) $.
.xw $f #ElementVariable -Bw $.
Wh0 $a zw ( Tw ( 4w ( SwE 3Ag RAk ) ( 4w ( SwE 4Ag mwg ) ( 4w ( SwE 3gg rgk ) ( 4w ( SwE 4wg ewk ) ( 4w ( SwE 5Qg pgg ) ( 4w ( SwE -Bw YQk ) IQE ) ) ) ) ) ) ( tQM Ngk ( .gM Ngk ( wQM Ngk ( twM Ngk ) ( -g4 ( 0Q4 ( Hg8 ( rwg ( LAQ 8wk pgg ( XBI 4wg ( LAQ rgk Wgk 3gg ) ) ) 4Ag ) ) ( Kw8 ( 7BI ( cBQ ( LAQ ewk pgg 4wg ) 5Qg ) -Bw ) ) ) 3Ag ) ) ( wQM Ngk ( twM Ngk ) ( -g4 ( 0Q4 ( Hg8 4Ag ) ( Kw8 ( 7BI ( cBQ ( LAQ ewk pgg 4wg ) ( LAQ rgk pgg 3gg ) ) -Bw ) ) ) 3Ag ) ) ) ) ) $.
BCQ $a #Pattern 4Ag $.
ByQ $a #Pattern 3Ag $.
XiU $a #Pattern 3gg $.
XyU $a #Pattern 4wg $.
yyg $a #Pattern -Bw $.
zCg $a #Pattern ( 4w ( SwE 5Qg pgg ) ( 4w ( SwE -Bw YQk ) IQE ) ) $.
2Sg $a zw ( Tw ( 4w ( 4w ( SwE 4Ag mwg ) ( 4w ( SwE 3gg rgk ) ( 4w ( SwE 4wg ewk ) ( 4w ( SwE 5Qg pgg ) ( 4w ( SwE -Bw YQk ) IQE ) ) ) ) ) ( 4w ( SwE 3Ag RAk ) IQE ) ) ( 4w ( SwE 3gg rgk ) ( 4w ( SwE 4wg ewk ) ( 4w ( SwE 5Qg pgg ) ( 4w ( SwE -Bw YQk ) IQE ) ) ) ) ) $.
2ig $a #Pattern ( XBI 4wg ( LAQ rgk Wgk 3gg ) ) $.
2yg $a #Pattern ( cBQ ( LAQ ewk pgg 4wg ) 5Qg ) $.
3Cg $a #Pattern ( 7BI ( cBQ ( LAQ ewk pgg 4wg ) ( LAQ rgk pgg 3gg ) ) -Bw ) $.
${ 3Sg $p zw ( Tw ( 4w ( 4w ( SwE 4Ag mwg ) ( 4w ( SwE 3gg rgk ) ( 4w ( SwE 4wg ewk ) ( 4w ( SwE 5Qg pgg ) ( 4w ( SwE -Bw YQk ) IQE ) ) ) ) ) ( 4w ( SwE 3Ag RAk ) IQE ) ) ( tQM Ngk ( .gM Ngk ( wQM Ngk ( twM Ngk ) ( -g4 ( 0Q4 ( Hg8 ( rwg ( LAQ 8wk pgg ( XBI 4wg ( LAQ rgk Wgk 3gg ) ) ) 4Ag ) ) ( Kw8 ( 7BI ( cBQ ( LAQ ewk pgg 4wg ) 5Qg ) -Bw ) ) ) 3Ag ) ) ( wQM Ngk ( twM Ngk ) ( -g4 ( 0Q4 ( Hg8 4Ag ) ( Kw8 ( 7BI ( cBQ ( LAQ ewk pgg 4wg ) ( LAQ rgk pgg 3gg ) ) -Bw ) ) ) 3Ag ) ) ) ) ) $=
  ( BCQ SgE 4g IAE NQk HQ8 Kg8 0A4 -Q4 wAM ugE lQE mAE wgE mgg XiU rQk XyU egk
  zCg ByQ Qwk uwM 8gk pQg 2ig KwQ rgg 2yg yyg 6xI 3Cg .QM tAM uwE 2Sg Wh0 ) CGZ
  UAHZBUBUCHDUDUEHEFUFIIZIZAUGZUHHZJIZIZVIVGIKKKKUIZUJUKBDULUMVDUNLDEUOFUPUQMNV
  HOPKVLVDLBDFURMNVHOPUSUTVKVIVGVKVJVIVGVJVAVJVIVIVIJQVIRSSVKVEVFVKVGVEVGVJQVGV
  EVEVEVFQVERSSABCDEFVBTTABCDEFVCS $. $}
