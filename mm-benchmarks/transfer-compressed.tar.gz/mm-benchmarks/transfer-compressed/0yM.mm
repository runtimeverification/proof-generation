$c 1wk #Symbol #Variable SwE #SetVariable ) 4w JAQ #ElementVariable IQE #Pattern ( $.
$v 2gg CQ zBs Bw $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
4g $a #Pattern ( 4w Bw CQ ) $.
IAE $a #Pattern IQE $.
SgE $a #Pattern ( SwE Bw CQ ) $.
IwQ $a #Pattern ( JAQ Bw ) $.
2Qg $f #ElementVariable 2gg $.
1gk $a #Pattern 1wk $.
yxs $f #ElementVariable zBs $.
Wh8 $a #Pattern 2gg $.
JiE $a #Pattern zBs $.
${ 0yM $p #Pattern ( 4w ( JAQ 2gg ) ( 4w ( SwE zBs 1wk ) IQE ) ) $=
  ( Wh8 IwQ JiE 1gk SgE IAE 4g ) ACDBEFGHII $. $}
