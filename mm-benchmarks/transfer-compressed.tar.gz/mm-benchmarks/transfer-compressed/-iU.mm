$c 0wM ww4 #Symbol #Variable #SetVariable iA YQk #ElementVariable 7BI #Pattern ) ( $.
$v Fw Ow CQ FQ qwg qxw DQ Ew Bw Kw oAg Cw 2gg nR4 EQ Dw $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Cg $f #Pattern Cw $.
DA $f #Pattern DQ $.
Dg $f #Pattern Dw $.
EA $f #Pattern EQ $.
Eg $f #Pattern Ew $.
FA $f #Pattern FQ $.
Fg $f #Pattern Fw $.
Kg $f #ElementVariable Kw $.
Og $f #Variable Ow $.
SA $a #Variable Kw $.
jg $a iA Bw Ow Bw Ow $.
${ XgQ $e iA Bw Dw Fw Ow $.
   XwQ $e iA CQ EQ Fw Ow $.
   YAQ $e iA Cw Ew Fw Ow $.
   YQQ $e iA DQ FQ Fw Ow $.
   YgQ $a iA ( 0wM Bw CQ Cw DQ ) ( 0wM Dw EQ Ew FQ ) Fw Ow $. $}
nwg $f #Pattern oAg $.
qgg $f #Pattern qwg $.
2Qg $f #ElementVariable 2gg $.
YAk $a #Pattern YQk $.
wg4 $a #Pattern ww4 $.
6xI $a #Pattern ( 7BI oAg qwg ) $.
qhw $f #ElementVariable qxw $.
nB4 $f #ElementVariable nR4 $.
Wh8 $a #Pattern 2gg $.
6h8 $a #Pattern nR4 $.
7iU $a #Pattern qxw $.
9yU $a iA YQk YQk nR4 qxw $.
.yU $a iA 2gg 2gg nR4 qxw $.
-SU $a iA ( 7BI nR4 ww4 ) ( 7BI qxw ww4 ) nR4 qxw $.
${ -iU $p iA ( 0wM YQk 2gg ( 7BI nR4 ww4 ) nR4 ) ( 0wM YQk 2gg ( 7BI qxw ww4 ) qxw ) nR4 qxw $=
  ( YAk Wh8 6h8 wg4 6xI 7iU SA 9yU .yU -SU jg YgQ ) DAEZCFZGHQDPBIZGHRQBJZBCKAB
  CLBCMQSNO $. $}
