$c Uw PgE Tw #Symbol zw JAQ pwk .gk Px0 pgg #Pattern ( 0wM LAQ tQM IAQ #Variable SwE #SetVariable iA 4w #ElementVariable IQE ) $.
$v th1 7Rw Ow CQ Fw DQ Bw ph1 Cw 2gg EQ y th2 mh4 Dw HQ FQ z xX ph2 th0 Gw Hw Ew Kw ph0 GQ nR4 x Lw LQ $.
$d z y $.
$d z x $.
$d y x $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Cg $f #Pattern Cw $.
DA $f #Pattern DQ $.
Dg $f #Pattern Dw $.
EA $f #Pattern EQ $.
Eg $f #Pattern Ew $.
FA $f #Pattern FQ $.
Fg $f #Pattern Fw $.
GA $f #Pattern GQ $.
Gg $f #Pattern Gw $.
HA $f #Pattern HQ $.
Hg $f #Pattern Hw $.
Kg $f #ElementVariable Kw $.
LA $f #ElementVariable LQ $.
Lg $f #ElementVariable Lw $.
Og $f #Variable Ow $.
SA $a #Variable Kw $.
jg $a iA Bw Ow Bw Ow $.
${ kg $e iA CQ DQ Bw Ow $.
   kw $e iA Cw Dw Bw Ow $.
   lA $a iA ( Tw CQ Cw ) ( Tw DQ Dw ) Bw Ow $. $}
4g $a #Pattern ( 4w Bw CQ ) $.
IAE $a #Pattern IQE $.
SgE $a #Pattern ( SwE Bw CQ ) $.
${ lgE $e zw ( Tw Bw CQ ) $.
   lwE $e zw ( Tw CQ Cw ) $.
   mAE $a zw ( Tw Bw Cw ) $. $}
${ wAE $e zw ( Tw Bw CQ ) $.
   wQE $e zw ( Tw Bw Cw ) $.
   wgE $a zw ( Tw Bw ( 4w CQ Cw ) ) $. $}
${ $d xX ph0 $.
   IQI $a iA Bw Bw CQ Ow $. $}
${ KAI $e iA CQ DQ Bw Ow $.
   KQI $e iA Cw Dw Bw Ow $.
   KgI $a iA ( 4w CQ Cw ) ( 4w DQ Dw ) Bw Ow $. $}
${ OgI $e iA CQ DQ Bw Ow $.
   OwI $e iA Cw Dw Bw Ow $.
   PAI $a iA ( SwE CQ Cw ) ( SwE DQ Dw ) Bw Ow $. $}
tAM $a #Pattern ( tQM Bw CQ ) $.
0gM $a #Pattern ( 0wM Bw CQ Cw DQ ) $.
HwQ $a #Pattern ( IAQ Bw CQ ) $.
IwQ $a #Pattern ( JAQ Bw ) $.
KwQ $a #Pattern ( LAQ Bw CQ Cw ) $.
${ QAQ $e iA Bw Cw Dw Ow $.
   QQQ $e iA CQ DQ Dw Ow $.
   QgQ $a iA ( tQM Bw CQ ) ( tQM Cw DQ ) Dw Ow $. $}
${ XgQ $e iA Bw Dw Fw Ow $.
   XwQ $e iA CQ EQ Fw Ow $.
   YAQ $e iA Cw Ew Fw Ow $.
   YQQ $e iA DQ FQ Fw Ow $.
   YgQ $a iA ( 0wM Bw CQ Cw DQ ) ( 0wM Dw EQ Ew FQ ) Fw Ow $. $}
${ lAQ $e iA Bw DQ Ew Ow $.
   lQQ $e iA CQ Dw Ew Ow $.
   lgQ $e iA Cw EQ Ew Ow $.
   lwQ $a iA ( LAQ Bw CQ Cw ) ( LAQ DQ Dw EQ ) Ew Ow $. $}
${ $d z ph0 $.
   $d z ph1 $.
   $d z ph2 $.
   $d z y $.
   $d z x $.
   $d z th1 $.
   $d z th2 $.
   $d x ph0 $.
   $d y th0 $.
   lAY $e zw ( Tw GQ ( Uw Kw ( PgE Kw Bw ) ) ) $.
   lQY $e zw ( Tw ( 4w GQ Gw ) CQ ) $.
   lgY $e iA ( Tw HQ Cw ) ( Tw Gw CQ ) Bw LQ $.
   lwY $e iA ( Tw Hw DQ ) ( Tw Gw CQ ) Lw LQ $.
   mAY $a zw ( Tw ( 4w GQ HQ ) Cw ) $. $}
pQg $a #Pattern pgg $.
2Qg $f #ElementVariable 2gg $.
pgk $a #Pattern pwk $.
.Qk $a #Pattern .gk $.
7Bw $f #ElementVariable 7Rw $.
Ph0 $a #Pattern Px0 $.
mR4 $f #ElementVariable mh4 $.
nB4 $f #ElementVariable nR4 $.
Wh8 $a #Pattern 2gg $.
YR8 $a #Pattern mh4 $.
6h8 $a #Pattern nR4 $.
8B8 $a iA 2gg 2gg nR4 mh4 $.
8R8 $a iA pgg pgg nR4 mh4 $.
9h8 $a zw ( Tw ( 4w ( JAQ 2gg ) IQE ) ( 4w ( JAQ 2gg ) IQE ) ) $.
EDA $a zw ( Tw ( 4w ( JAQ 2gg ) IQE ) ( Uw 7Rw ( PgE 7Rw ( IAQ .gk Px0 ) ) ) ) $.
IjA $a zw ( Tw ( 4w ( JAQ 2gg ) IQE ) ( 4w ( SwE ( IAQ .gk Px0 ) .gk ) IQE ) ) $.
nDA $a #Pattern ( 4w ( JAQ 2gg ) ( 4w ( SwE mh4 .gk ) IQE ) ) $.
qjA $a zw ( Tw ( 4w ( 4w ( JAQ 2gg ) IQE ) ( 4w ( SwE mh4 .gk ) IQE ) ) ( 4w ( JAQ 2gg ) ( 4w ( SwE mh4 .gk ) IQE ) ) ) $.
qzA $a iA 2gg 2gg ( IAQ .gk Px0 ) mh4 $.
rjA $a iA ( 4w ( SwE nR4 .gk ) IQE ) ( 4w ( SwE mh4 .gk ) IQE ) nR4 mh4 $.
sTA $a iA ( LAQ .gk pgg nR4 ) ( LAQ .gk pgg mh4 ) nR4 mh4 $.
1jA $a zw ( Tw ( 4w ( JAQ 2gg ) ( 4w ( SwE mh4 .gk ) IQE ) ) ( tQM 2gg ( 0wM pgg 2gg ( LAQ pwk pgg ( LAQ .gk pwk mh4 ) ) ( LAQ .gk pgg mh4 ) ) ) ) $.
2TA $a iA ( LAQ pwk pgg ( LAQ .gk pwk nR4 ) ) ( LAQ pwk pgg ( LAQ .gk pwk mh4 ) ) nR4 mh4 $.
${ 2jA $p zw ( Tw ( 4w ( JAQ 2gg ) IQE ) ( tQM 2gg ( 0wM pgg 2gg ( LAQ pwk pgg ( LAQ .gk pwk ( IAQ .gk Px0 ) ) ) ( LAQ .gk pgg ( IAQ .gk Px0 ) ) ) ) ) $=
  ( mR4 nB4 7Bw Wh8 IAE 4g .Qk SgE pQg pgk KwQ 0gM tAM mAE IQI lwQ YgQ QgQ lA
  IwQ Ph0 HwQ 9h8 IjA wgE YR8 6h8 EDA nDA qjA 1jA SA jg PAI KgI qzA rjA 8B8 8R8
  2TA sTA mAY ) AEZUAFGZVEHUBUCZHIZFGZGVDJVDKJHKVFLZLZHJVFLZMZNZVEVEVHAUDAUEUFV
  FVDJVDKJHKBUGZLZLZHJVNLZMZNZVMVDJVDKJHKCUHZLLZHJVTLZMZNZVEVNHIZFGZVHVTHIFGZDB
  CADUIVEWFGABUJVSABUKABULOVFVHVMWFVSBUMZVFVGFWEFWHVFVFHVNHWHVFWHUNZHVFWHPZUOFV
  FWHPUPVDVLVDVRVFWHABUQZJVDVJVKJVDVPVQVFWHJVFWHPZWKKJVIKJVOVFWHKVFWHPZWLHKVFHK
  VNVFWHWJWMWIQQHJVFHJVNVFWHWJWLWIQRSTVTWGWDWFVSWHBCURVDWCVDVRVTWHABCUSZJVDWAWB
  JVDVPVQVTWHBCUTWNBCVABCVBRSTVCO $. $}
