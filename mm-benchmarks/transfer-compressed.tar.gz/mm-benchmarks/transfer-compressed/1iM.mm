$c 0wM LAQ 1wk #Symbol #Variable #SetVariable ) #ElementVariable pgg #Pattern ( $.
$v yhs CQ DQ Bw Cw 2gg nR4 $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Cg $f #Pattern Cw $.
DA $f #Pattern DQ $.
0gM $a #Pattern ( 0wM Bw CQ Cw DQ ) $.
KwQ $a #Pattern ( LAQ Bw CQ Cw ) $.
pQg $a #Pattern pgg $.
2Qg $f #ElementVariable 2gg $.
1gk $a #Pattern 1wk $.
yRs $f #ElementVariable yhs $.
nB4 $f #ElementVariable nR4 $.
Wh8 $a #Pattern 2gg $.
6h8 $a #Pattern nR4 $.
7SA $a #Pattern yhs $.
${ 1iM $p #Pattern ( 0wM pgg 2gg yhs ( LAQ 1wk pgg nR4 ) ) $=
  ( pQg Wh8 7SA 1gk 6h8 KwQ 0gM ) DAEBFGDCHIJ $. $}
