$c #SetVariable iA ) #ElementVariable #Symbol #Variable xQg #Pattern ( $.
$v Ow CQ xX Bw Kw ph0 2gg 6xw $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Kg $f #ElementVariable Kw $.
Og $f #Variable Ow $.
SA $a #Variable Kw $.
${ $d xX ph0 $.
   IQI $a iA Bw Bw CQ Ow $. $}
xAg $a #Pattern xQg $.
2Qg $f #ElementVariable 2gg $.
6hw $f #ElementVariable 6xw $.
dB8 $a #Pattern 6xw $.
${ 4CQ $p iA xQg xQg 6xw 2gg $=
  ( xAg dB8 SA IQI ) CBDAEF $. $}
