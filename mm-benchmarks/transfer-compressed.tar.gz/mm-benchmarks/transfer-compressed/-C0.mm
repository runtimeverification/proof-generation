$c #Symbol #Variable SwE #SetVariable iA 4w #ElementVariable IQE pgg #Pattern ) ( $.
$v Ow CQ -Bw DQ Bw Kw Cw nR4 Dw $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Cg $f #Pattern Cw $.
DA $f #Pattern DQ $.
Dg $f #Pattern Dw $.
Kg $f #ElementVariable Kw $.
Og $f #Variable Ow $.
SA $a #Variable Kw $.
IAE $a #Pattern IQE $.
SgE $a #Pattern ( SwE Bw CQ ) $.
${ KAI $e iA CQ DQ Bw Ow $.
   KQI $e iA Cw Dw Bw Ow $.
   KgI $a iA ( 4w CQ Cw ) ( 4w DQ Dw ) Bw Ow $. $}
pQg $a #Pattern pgg $.
.xw $f #ElementVariable -Bw $.
nB4 $f #ElementVariable nR4 $.
6h8 $a #Pattern nR4 $.
yyg $a #Pattern -Bw $.
USk $a iA IQE IQE nR4 -Bw $.
.y0 $a iA ( SwE nR4 pgg ) ( SwE -Bw pgg ) nR4 -Bw $.
${ -C0 $p iA ( 4w ( SwE nR4 pgg ) IQE ) ( 4w ( SwE -Bw pgg ) IQE ) nR4 -Bw $=
  ( 6h8 pQg SgE IAE yyg SA .y0 USk KgI ) BCZLDEFAGDEFAHABIABJK $. $}
