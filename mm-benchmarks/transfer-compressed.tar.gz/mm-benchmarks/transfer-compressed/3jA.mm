$c 4B4 Ngk Lwk #Symbol 7h4 DBE 8Q4 zw xwM pgg #Pattern 0Q4 rwg Ex0 0wM xB4 tQM Wgk 0h4 5xw #Variable SwE PQk #SetVariable iA vR4 4w #ElementVariable IQE qxs mwg 8hw xQg cBQ kBM 2R4 zBA XBI RAk Tw cwE wQM -g4 5x4 pwk .gk Px0 rgk ( RQ0 twM LAQ ewk yx4 IAQ 9R4 Hg8 Kw8 hgk 7Ak 7BI ) $.
$v Ow CQ qwg DQ Bw Cw EQ sgg Dw tAg ngg FQ xX Ew Kw ph0 oAg GQ nR4 tgg $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Cg $f #Pattern Cw $.
DA $f #Pattern DQ $.
Dg $f #Pattern Dw $.
EA $f #Pattern EQ $.
Eg $f #Pattern Ew $.
FA $f #Pattern FQ $.
GA $f #Pattern GQ $.
Kg $f #ElementVariable Kw $.
Og $f #Variable Ow $.
SA $a #Variable Kw $.
Tg $a #Pattern ( Tw Bw CQ ) $.
jg $a iA Bw Ow Bw Ow $.
4g $a #Pattern ( 4w Bw CQ ) $.
5Q $a zw ( Tw Bw ( Tw CQ Bw ) ) $.
${ 6A $e zw ( Tw Bw CQ ) $.
   6Q $e zw Bw $.
   6g $a zw CQ $. $}
IAE $a #Pattern IQE $.
SgE $a #Pattern ( SwE Bw CQ ) $.
${ lgE $e zw ( Tw Bw CQ ) $.
   lwE $e zw ( Tw CQ Cw ) $.
   mAE $a zw ( Tw Bw Cw ) $. $}
${ wAE $e zw ( Tw Bw CQ ) $.
   wQE $e zw ( Tw Bw Cw ) $.
   wgE $a zw ( Tw Bw ( 4w CQ Cw ) ) $. $}
${ $d xX ph0 $.
   IQI $a iA Bw Bw CQ Ow $. $}
${ NwM $e zw CQ $.
   OAM $a zw ( Tw Bw CQ ) $. $}
tAM $a #Pattern ( tQM Bw CQ ) $.
uwM $a #Pattern ( twM Bw ) $.
wAM $a #Pattern ( wQM Bw CQ Cw ) $.
xgM $a #Pattern ( xwM Bw CQ Cw ) $.
0gM $a #Pattern ( 0wM Bw CQ Cw DQ ) $.
HwQ $a #Pattern ( IAQ Bw CQ ) $.
KwQ $a #Pattern ( LAQ Bw CQ Cw ) $.
${ QAQ $e iA Bw Cw Dw Ow $.
   QQQ $e iA CQ DQ Dw Ow $.
   QgQ $a iA ( tQM Bw CQ ) ( tQM Cw DQ ) Dw Ow $. $}
${ SgQ $e iA Bw DQ Ew Ow $.
   SwQ $e iA CQ Dw Ew Ow $.
   TAQ $e iA Cw EQ Ew Ow $.
   TQQ $a iA ( wQM Bw CQ Cw ) ( wQM DQ Dw EQ ) Ew Ow $. $}
${ UgQ $e iA Bw DQ Ew Ow $.
   UwQ $e iA CQ Dw Ew Ow $.
   VAQ $e iA Cw EQ Ew Ow $.
   VQQ $a iA ( xwM Bw CQ Cw ) ( xwM DQ Dw EQ ) Ew Ow $. $}
JwU $a zw ( Tw ( 4w ( SwE CQ Bw ) ( SwE Cw Bw ) ) ( SwE ( wQM Bw CQ Cw ) Bw ) ) $.
LAU $a zw ( SwE ( 0wM Bw CQ Cw DQ ) CQ ) $.
${ VwU $e zw ( Tw GQ ( tQM Bw Cw ) ) $.
   WAU $a zw ( Tw GQ ( tQM Bw ( xwM Bw CQ Cw ) ) ) $. $}
${ sgU $e zw ( Tw GQ ( SwE CQ Bw ) ) $.
   swU $a zw ( Tw GQ ( tQM Bw ( xwM Bw CQ CQ ) ) ) $. $}
${ AgY $e zw ( Tw GQ ( SwE CQ Bw ) ) $.
   AwY $e zw ( Tw GQ ( SwE Cw Bw ) ) $.
   BAY $e zw ( Tw GQ ( SwE Dw Bw ) ) $.
   BQY $e zw ( Tw GQ ( tQM Bw ( xwM Bw CQ Cw ) ) ) $.
   BgY $e zw ( Tw GQ ( tQM Bw ( xwM Bw DQ ( wQM Bw CQ Dw ) ) ) ) $.
   BwY $a zw ( Tw GQ ( tQM Bw ( xwM Bw DQ ( wQM Bw Cw Dw ) ) ) ) $. $}
${ swY $e zw ( Tw GQ ( SwE CQ Bw ) ) $.
   tAY $e zw ( Tw GQ ( SwE Cw Bw ) ) $.
   tQY $e zw ( Tw GQ ( tQM cwE ( 0wM Bw cwE CQ Cw ) ) ) $.
   tgY $e zw ( Tw GQ ( tQM Ew DQ ) ) $.
   twY $e iA ( tQM Ew DQ ) Dw CQ Kw $.
   uAY $e iA ( tQM FQ EQ ) Dw Cw Kw $.
   uQY $a zw ( Tw GQ ( tQM FQ EQ ) ) $. $}
uwY $a zw ( tQM Bw ( 0wM CQ Bw Cw Cw ) ) $.
mgg $a #Pattern mwg $.
nQg $f #Variable ngg $.
nwg $f #Pattern oAg $.
pQg $a #Pattern pgg $.
qgg $f #Pattern qwg $.
rgg $a #Pattern ( rwg oAg qwg ) $.
sQg $f #Pattern sgg $.
swg $f #Pattern tAg $.
tQg $f #Pattern tgg $.
${ uQg $e iA qwg tAg oAg ngg $.
   ugg $e iA sgg tgg oAg ngg $.
   uwg $a iA ( rwg qwg sgg ) ( rwg tAg tgg ) oAg ngg $. $}
wQg $a zw ( Tw ( 4w ( SwE oAg pgg ) ( SwE qwg mwg ) ) ( SwE ( rwg oAg qwg ) mwg ) ) $.
xAg $a #Pattern xQg $.
Lgk $a #Pattern Lwk $.
NQk $a #Pattern Ngk $.
PAk $a #Pattern PQk $.
Qwk $a #Pattern RAk $.
WQk $a #Pattern Wgk $.
egk $a #Pattern ewk $.
hQk $a #Pattern hgk $.
pgk $a #Pattern pwk $.
rQk $a #Pattern rgk $.
6wk $a #Pattern 7Ak $.
.Qk $a #Pattern .gk $.
RA0 $a #Pattern ( RQ0 oAg qwg ) $.
UQ0 $a zw ( Tw ( 4w ( SwE oAg mwg ) ( SwE qwg mwg ) ) ( SwE ( RQ0 oAg qwg ) pgg ) ) $.
0A4 $a #Pattern ( 0Q4 oAg qwg ) $.
${ 1Q4 $e iA qwg tAg oAg ngg $.
   1g4 $e iA sgg tgg oAg ngg $.
   1w4 $a iA ( 0Q4 qwg sgg ) ( 0Q4 tAg tgg ) oAg ngg $. $}
3Q4 $a zw ( Tw ( 4w ( SwE oAg Lwk ) ( SwE qwg PQk ) ) ( SwE ( 0Q4 oAg qwg ) 7Ak ) ) $.
8A4 $a #Pattern ( 8Q4 oAg ) $.
-Q4 $a #Pattern ( -g4 oAg qwg ) $.
${ Ag8 $e iA qwg tAg oAg ngg $.
   Aw8 $e iA sgg tgg oAg ngg $.
   BA8 $a iA ( -g4 qwg sgg ) ( -g4 tAg tgg ) oAg ngg $. $}
Cg8 $a zw ( Tw ( 4w ( SwE oAg 7Ak ) ( SwE qwg RAk ) ) ( SwE ( -g4 oAg qwg ) Ngk ) ) $.
HQ8 $a #Pattern ( Hg8 oAg ) $.
${ Ig8 $e iA qwg sgg oAg ngg $.
   Iw8 $a iA ( Hg8 qwg ) ( Hg8 sgg ) oAg ngg $. $}
Jw8 $a zw ( Tw ( SwE oAg mwg ) ( SwE ( Hg8 oAg ) Lwk ) ) $.
Kg8 $a #Pattern ( Kw8 oAg ) $.
yxA $a #Pattern ( zBA oAg qwg ) $.
CxE $a #Pattern ( DBE oAg qwg ) $.
WxI $a #Pattern ( XBI oAg qwg ) $.
6xI $a #Pattern ( 7BI oAg qwg ) $.
jxM $a #Pattern ( kBM oAg qwg ) $.
bxQ $a #Pattern ( cBQ oAg qwg ) $.
qhs $a #Pattern ( qxs oAg ) $.
5hw $a #Pattern 5xw $.
8Rw $a #Pattern 8hw $.
Eh0 $a #Pattern Ex0 $.
Ph0 $a #Pattern Px0 $.
nB4 $f #ElementVariable nR4 $.
vB4 $a #Pattern vR4 $.
wx4 $a #Pattern xB4 $.
yh4 $a #Pattern yx4 $.
0R4 $a #Pattern 0h4 $.
2B4 $a #Pattern 2R4 $.
3x4 $a #Pattern 4B4 $.
5h4 $a #Pattern 5x4 $.
7R4 $a #Pattern 7h4 $.
9B4 $a #Pattern 9R4 $.
.R4 $a zw ( Tw IQE ( SwE ( twM Ngk ) Ngk ) ) $.
JB8 $a zw ( Tw IQE ( SwE xQg mwg ) ) $.
Kx8 $a zw ( Tw IQE ( SwE ( 8Q4 ( IAQ rgk 8hw ) ) RAk ) ) $.
VB8 $a zw ( Tw IQE ( SwE ( rwg ( LAQ hgk pgg ( qxs ( XBI ( IAQ ewk xB4 ) ( LAQ rgk Wgk ( IAQ rgk 8hw ) ) ) ) ) xQg ) mwg ) ) $.
VR8 $a zw ( Tw IQE ( SwE ( rwg ( LAQ hgk pgg ( qxs ( kBM ( kBM ( XBI ( IAQ ewk vR4 ) ( DBE ( LAQ ewk Wgk ( IAQ ewk vR4 ) ) ( LAQ ewk Wgk ( IAQ ewk 2R4 ) ) ) ) ( XBI ( IAQ ewk 7h4 ) ( zBA ( LAQ ewk Wgk ( IAQ ewk 7h4 ) ) ( LAQ ewk Wgk ( IAQ ewk 2R4 ) ) ) ) ) ( XBI ( IAQ ewk xB4 ) ( LAQ rgk Wgk ( IAQ rgk Ex0 ) ) ) ) ) ) xQg ) mwg ) ) $.
Vh8 $a zw ( Tw IQE ( SwE ( Kw8 ( 7BI ( cBQ ( LAQ ewk pgg ( IAQ ewk xB4 ) ) ( LAQ rgk pgg ( IAQ rgk 8hw ) ) ) ( 7BI ( cBQ ( LAQ ewk pgg ( IAQ ewk vR4 ) ) ( LAQ rgk pgg ( IAQ rgk 5x4 ) ) ) ( 7BI ( cBQ ( LAQ ewk pgg ( IAQ ewk 9R4 ) ) ( LAQ rgk pgg ( IAQ rgk yx4 ) ) ) ( 7BI ( cBQ ( LAQ ewk pgg ( IAQ ewk 7h4 ) ) ( LAQ rgk pgg ( IAQ rgk 4B4 ) ) ) ( cBQ ( LAQ ewk pgg ( IAQ ewk 2R4 ) ) ( LAQ rgk pgg ( IAQ rgk 0h4 ) ) ) ) ) ) ) ) PQk ) ) $.
6h8 $a #Pattern nR4 $.
pi8 $a zw ( Tw IQE ( SwE ( LAQ .gk pgg ( IAQ .gk Px0 ) ) pgg ) ) $.
yTA $a zw ( Tw IQE ( tQM cwE ( 0wM pgg cwE ( LAQ .gk pgg ( IAQ .gk Px0 ) ) ( wQM pgg ( LAQ .gk pgg ( IAQ .gk Px0 ) ) ( LAQ .gk pgg ( IAQ .gk Px0 ) ) ) ) ) ) $.
3DA $a zw ( Tw IQE ( tQM cwE ( 0wM pgg cwE ( LAQ .gk pgg ( IAQ .gk Px0 ) ) ( LAQ pwk pgg ( LAQ .gk pwk ( IAQ .gk Px0 ) ) ) ) ) ) $.
3TA $a zw ( Tw IQE ( SwE ( LAQ pwk pgg ( LAQ .gk pwk ( IAQ .gk Px0 ) ) ) pgg ) ) $.
${ 3jA $p zw ( Tw IQE ( tQM Ngk ( xwM Ngk ( wQM Ngk ( wQM Ngk ( twM Ngk ) ( twM Ngk ) ) ( -g4 ( 0Q4 ( Hg8 ( rwg ( LAQ .gk pgg ( IAQ .gk Px0 ) ) ( rwg ( RQ0 ( rwg ( LAQ hgk pgg ( qxs ( XBI ( IAQ ewk xB4 ) ( LAQ rgk Wgk ( IAQ rgk 8hw ) ) ) ) ) xQg ) ( rwg ( LAQ hgk pgg ( qxs ( kBM ( kBM ( XBI ( IAQ ewk vR4 ) ( DBE ( LAQ ewk Wgk ( IAQ ewk vR4 ) ) ( LAQ ewk Wgk ( IAQ ewk 2R4 ) ) ) ) ( XBI ( IAQ ewk 7h4 ) ( zBA ( LAQ ewk Wgk ( IAQ ewk 7h4 ) ) ( LAQ ewk Wgk ( IAQ ewk 2R4 ) ) ) ) ) ( XBI ( IAQ ewk xB4 ) ( LAQ rgk Wgk ( IAQ rgk Ex0 ) ) ) ) ) ) xQg ) ) xQg ) ) ) ( Kw8 ( 7BI ( cBQ ( LAQ ewk pgg ( IAQ ewk xB4 ) ) ( LAQ rgk pgg ( IAQ rgk 8hw ) ) ) ( 7BI ( cBQ ( LAQ ewk pgg ( IAQ ewk vR4 ) ) ( LAQ rgk pgg ( IAQ rgk 5x4 ) ) ) ( 7BI ( cBQ ( LAQ ewk pgg ( IAQ ewk 9R4 ) ) ( LAQ rgk pgg ( IAQ rgk yx4 ) ) ) ( 7BI ( cBQ ( LAQ ewk pgg ( IAQ ewk 7h4 ) ) ( LAQ rgk pgg ( IAQ rgk 4B4 ) ) ) ( cBQ ( LAQ ewk pgg ( IAQ ewk 2R4 ) ) ( LAQ rgk pgg ( IAQ rgk 0h4 ) ) ) ) ) ) ) ) ) ( 8Q4 ( IAQ rgk 8hw ) ) ) ) ( wQM Ngk ( 0wM .gk Ngk ( IAQ .gk 5xw ) ( IAQ .gk 5xw ) ) ( -g4 ( 0Q4 ( Hg8 ( rwg ( wQM pgg ( LAQ pwk pgg ( LAQ .gk pwk ( IAQ .gk Px0 ) ) ) ( LAQ .gk pgg ( IAQ .gk Px0 ) ) ) ( rwg ( RQ0 ( rwg ( LAQ hgk pgg ( qxs ( XBI ( IAQ ewk xB4 ) ( LAQ rgk Wgk ( IAQ rgk 8hw ) ) ) ) ) xQg ) ( rwg ( LAQ hgk pgg ( qxs ( kBM ( kBM ( XBI ( IAQ ewk vR4 ) ( DBE ( LAQ ewk Wgk ( IAQ ewk vR4 ) ) ( LAQ ewk Wgk ( IAQ ewk 2R4 ) ) ) ) ( XBI ( IAQ ewk 7h4 ) ( zBA ( LAQ ewk Wgk ( IAQ ewk 7h4 ) ) ( LAQ ewk Wgk ( IAQ ewk 2R4 ) ) ) ) ) ( XBI ( IAQ ewk xB4 ) ( LAQ rgk Wgk ( IAQ rgk Ex0 ) ) ) ) ) ) xQg ) ) xQg ) ) ) ( Kw8 ( 7BI ( cBQ ( LAQ ewk pgg ( IAQ ewk xB4 ) ) ( LAQ rgk pgg ( IAQ rgk 8hw ) ) ) ( 7BI ( cBQ ( LAQ ewk pgg ( IAQ ewk vR4 ) ) ( LAQ rgk pgg ( IAQ rgk 5x4 ) ) ) ( 7BI ( cBQ ( LAQ ewk pgg ( IAQ ewk 9R4 ) ) ( LAQ rgk pgg ( IAQ rgk yx4 ) ) ) ( 7BI ( cBQ ( LAQ ewk pgg ( IAQ ewk 7h4 ) ) ( LAQ rgk pgg ( IAQ rgk 4B4 ) ) ) ( cBQ ( LAQ ewk pgg ( IAQ ewk 2R4 ) ) ( LAQ rgk pgg ( IAQ rgk 0h4 ) ) ) ) ) ) ) ) ) ( 8Q4 ( IAQ rgk 8hw ) ) ) ) ) ) ) $=
  ( NQk wAM .Qk HwQ pQg KwQ egk rQk WQk xAg rgg IAE SgE wgE mAE mgg pi8 IQI TQQ
  4g nB4 uwM 5hw 0gM Ph0 hQk wx4 8Rw WxI qhs vB4 2B4 CxE 7R4 yxA jxM Eh0 RA0 Tg
  HQ8 bxQ 5h4 9B4 yh4 3x4 0R4 6xI Kg8 0A4 8A4 -Q4 pgk .R4 JwU 5Q LAU 6g 6wk Qwk
  Lgk PAk 3TA VB8 VR8 UQ0 JB8 wQg Jw8 Vh8 3Q4 Kx8 Cg8 tAM uwY OAM WAU xgM SA jg
  6h8 3DA yTA swU uwg Iw8 1w4 BA8 VQQ QgQ uQY BwY ) AAAUBZXLBZCACUCDZXNUDZAXMCE
  CUEDZFZUFEGUGDZHIHUHDZFUIUJFJKZUFEGUKDZGIYAFGIGULDZFZUMUIGUNDZGIYDFYCUOUIUPXR
  HIHUQDFUIUPUJFJKZURZJKZKZUTZGEXRFHEXSFVAGEYAFHEHVBDFVAGEGVCDFHEHVDDFVAGEYDFHE
  HVEDFVAGEYBFHEHVFDFVAVGVGVGVGVHZVIZXSVJZVKZBZEVLECVLXPFFZXQBZYGKZUTZYJVIZYLVK
  ZLLXLAMZUUATXMAMZLUUAUUAVMVMNAXLXLVNOZXOAMZLUUDUSUUDLVOCAXNXNVPVQLYSVRMZYLVSM
  ZTYTAMLUUEUUFLYRVTMZYJWAMZTUUELUUGUUHLYQPMZUUGLYPEMZYGPMZTUUILUUJUUKLYOEMZXQE
  MZTUUJLUULUUMWBQNEYOXQVNOLYFEMZJPMZTUUKLUUNUUOLXTPMZYEPMZTUUNLUUPUUQWCWDNXTYE
  WEOWFNYFJWGOZNYPYGWGOYQWHOWINYRYJWJOWKNYSYLWLOAXMXOLLAXOWMACXNWNWOWPEXQYOAYNA
  XMEXQXQBZYGKZUTZYJVIZYLVKZBZWQZAAYNAXMEUAWTZXQBZYGKZUTZYJVIZYLVKZBZWQZWMAYNAX
  MYTBZWQZAALUAQWBXAEXQUUSAYNYNWQZAAYNAXMUVFYGKZUTZYJVIZYLVKZBZWQZWMUVEAALUAQLU
  UMUUMTUUSEMLUUMUUMQQNEXQXQVNOXBAYNLLUUBYMAMZTYNAMLUUBUWCUUCLYKVRMZUUFTUWCLUWD
  UUFLYIVTMZUUHTUWDLUWEUUHLYHPMZUWELUUMUUKTUWFLUUMUUKQUURNXQYGWGOYHWHOWINYIYJWJ
  OWKNYKYLWLONAXMYMVNOXCAUVPAUWBXQUAWRZAXQUWGRZAYNYNAYNUWAXQUWGUWHYNXQUWGRZAXMY
  MAXMUVTXQUWGUWHXMXQUWGRZUWGXQYKYLUVSYLUWGXQYIYJUVRYJUWGXQYHUVQUWGXQXQYGUVFYGX
  QUWGWSZYGXQUWGRZXDXEYJXQUWGRZXFYLXQUWGRZXGSXHXIAUVEAUWBUUSUWGAUUSUWGRZAYNUVDA
  YNUWAUUSUWGUWOYNUUSUWGRAXMUVCAXMUVTUUSUWGUWOXMUUSUWGRUWGUUSUVBYLUVSYLUWGUUSUV
  AYJUVRYJUWGUUSUUTUVQUWGUUSUUSYGUVFYGUUSUWGWSYGUUSUWGRXDXEYJUUSUWGRXFYLUUSUWGR
  XGSXHXIXJAUVEAUVMXQUWGUWHAYNUVDAYNUVLXQUWGUWHUWIAXMUVCAXMUVKXQUWGUWHUWJUWGXQU
  VBYLUVJYLUWGXQUVAYJUVIYJUWGXQUUTUVHUWGXQUUSYGUVGYGEXQXQEUVFXQXQUWGEXQUWGRUWKX
  QXQUWGRSUWLXDXEUWMXFUWNXGSXHXIAUVOAUVMYOUWGAYOUWGRZAYNUVNAYNUVLYOUWGUWPYNYOUW
  GRAXMYTAXMUVKYOUWGUWPXMYOUWGRUWGYOYSYLUVJYLUWGYOYRYJUVIYJUWGYOYQUVHUWGYOYPYGU
  VGYGEYOXQEUVFXQYOUWGEYOUWGRYOUWGWSXQYOUWGRSYGYOUWGRXDXEYJYOUWGRXFYLYOUWGRXGSX
  HXIXJXK $. $}
