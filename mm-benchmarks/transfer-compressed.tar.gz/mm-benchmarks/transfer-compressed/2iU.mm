$c ewk IAQ Wgk Tw #Symbol #Variable 7h4 SwE -gg #SetVariable zw 4w JAQ #ElementVariable IQE #Pattern ) ( $.
$v 5Qg Cw CQ Bw $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Cg $f #Pattern Cw $.
4g $a #Pattern ( 4w Bw CQ ) $.
IAE $a #Pattern IQE $.
SgE $a #Pattern ( SwE Bw CQ ) $.
${ wAE $e zw ( Tw Bw CQ ) $.
   wQE $e zw ( Tw Bw Cw ) $.
   wgE $a zw ( Tw Bw ( 4w CQ Cw ) ) $. $}
HwQ $a #Pattern ( IAQ Bw CQ ) $.
IwQ $a #Pattern ( JAQ Bw ) $.
5Ag $f #ElementVariable 5Qg $.
-Qg $a #Pattern -gg $.
WQk $a #Pattern Wgk $.
egk $a #Pattern ewk $.
7R4 $a #Pattern 7h4 $.
YCU $a #Pattern 5Qg $.
xSU $a zw ( Tw ( 4w ( SwE 5Qg -gg ) IQE ) ( SwE ( IAQ ewk 7h4 ) ewk ) ) $.
zCU $a zw ( Tw ( 4w ( SwE 5Qg -gg ) IQE ) ( 4w ( JAQ ewk ) ( JAQ Wgk ) ) ) $.
${ 2iU $p zw ( Tw ( 4w ( SwE 5Qg -gg ) IQE ) ( 4w ( 4w ( JAQ ewk ) ( JAQ Wgk ) ) ( SwE ( IAQ ewk 7h4 ) ewk ) ) ) $=
  ( YCU -Qg SgE IAE 4g egk IwQ WQk 7R4 HwQ zCU xSU wgE ) ABCDEFGHIHFGJKGDALAMN
  $. $}
