$c XBI Lwk Tw #Symbol zw pgg rgk #Pattern ( rwg Ex0 LAQ ewk xB4 IAQ Wgk Hg8 #Variable SwE #SetVariable #ElementVariable IQE 8wk mwg xQg ) $.
$v oAg Cw CQ qwg Bw $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Cg $f #Pattern Cw $.
IAE $a #Pattern IQE $.
SgE $a #Pattern ( SwE Bw CQ ) $.
${ lgE $e zw ( Tw Bw CQ ) $.
   lwE $e zw ( Tw CQ Cw ) $.
   mAE $a zw ( Tw Bw Cw ) $. $}
HwQ $a #Pattern ( IAQ Bw CQ ) $.
KwQ $a #Pattern ( LAQ Bw CQ Cw ) $.
mgg $a #Pattern mwg $.
nwg $f #Pattern oAg $.
pQg $a #Pattern pgg $.
qgg $f #Pattern qwg $.
rgg $a #Pattern ( rwg oAg qwg ) $.
xAg $a #Pattern xQg $.
Lgk $a #Pattern Lwk $.
WQk $a #Pattern Wgk $.
egk $a #Pattern ewk $.
rQk $a #Pattern rgk $.
8gk $a #Pattern 8wk $.
HQ8 $a #Pattern ( Hg8 oAg ) $.
Jw8 $a zw ( Tw ( SwE oAg mwg ) ( SwE ( Hg8 oAg ) Lwk ) ) $.
WxI $a #Pattern ( XBI oAg qwg ) $.
Eh0 $a #Pattern Ex0 $.
wx4 $a #Pattern xB4 $.
dCA $a zw ( Tw IQE ( SwE ( rwg ( LAQ 8wk pgg ( XBI ( IAQ ewk xB4 ) ( LAQ rgk Wgk ( IAQ rgk Ex0 ) ) ) ) xQg ) mwg ) ) $.
${ 4CA $p zw ( Tw IQE ( SwE ( Hg8 ( rwg ( LAQ 8wk pgg ( XBI ( IAQ ewk xB4 ) ( LAQ rgk Wgk ( IAQ rgk Ex0 ) ) ) ) xQg ) ) Lwk ) ) $=
  ( IAE 8gk pQg egk wx4 HwQ rQk WQk Eh0 KwQ WxI xAg rgg mgg SgE HQ8 Lgk dCA Jw8
  mAE ) ABCDEFGHGIFJKJLMZNOUAPQORUAST $. $}
