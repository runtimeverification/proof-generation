$c Wgk #Symbol #Variable SwE #SetVariable ) 4w JAQ #ElementVariable IQE #Pattern ( $.
$v 2gg CQ -Rs Bw XRw $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
4g $a #Pattern ( 4w Bw CQ ) $.
IAE $a #Pattern IQE $.
SgE $a #Pattern ( SwE Bw CQ ) $.
IwQ $a #Pattern ( JAQ Bw ) $.
2Qg $f #ElementVariable 2gg $.
WQk $a #Pattern Wgk $.
-Bs $f #ElementVariable -Rs $.
XBw $f #ElementVariable XRw $.
Wh8 $a #Pattern 2gg $.
QCE $a #Pattern XRw $.
QyE $a #Pattern -Rs $.
${ 2yI $p #Pattern ( 4w ( JAQ 2gg ) ( 4w ( SwE -Rs Wgk ) ( 4w ( SwE XRw Wgk ) IQE ) ) ) $=
  ( Wh8 IwQ QyE WQk SgE QCE IAE 4g ) ADEBFGHCIGHJKKK $. $}
