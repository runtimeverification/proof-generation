$c Uw PgE Tw #Symbol zw JAQ pgg #Pattern ( rwg 0wM LAQ ewk tQM IAQ #Variable SwE #SetVariable iA vR4 4w rwM #ElementVariable IQE mwg xQg ) $.
$v th1 CQ Bw Cw 2gg z ph2 Ew ph0 x Lw LQ 7Ag Ow ph6 qwg DQ ph1 EQ y th2 Dw HQ xX Gw th0 Hw Kw oAg 6Ag GQ nR4 $.
$d z y $.
$d z x $.
$d y x $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Cg $f #Pattern Cw $.
DA $f #Pattern DQ $.
Dg $f #Pattern Dw $.
EA $f #Pattern EQ $.
Eg $f #Pattern Ew $.
GA $f #Pattern GQ $.
Gg $f #Pattern Gw $.
HA $f #Pattern HQ $.
Hg $f #Pattern Hw $.
Kg $f #ElementVariable Kw $.
LA $f #ElementVariable LQ $.
Lg $f #ElementVariable Lw $.
Og $f #Variable Ow $.
SA $a #Variable Kw $.
${ kg $e iA CQ DQ Bw Ow $.
   kw $e iA Cw Dw Bw Ow $.
   lA $a iA ( Tw CQ Cw ) ( Tw DQ Dw ) Bw Ow $. $}
4g $a #Pattern ( 4w Bw CQ ) $.
IAE $a #Pattern IQE $.
SgE $a #Pattern ( SwE Bw CQ ) $.
${ lgE $e zw ( Tw Bw CQ ) $.
   lwE $e zw ( Tw CQ Cw ) $.
   mAE $a zw ( Tw Bw Cw ) $. $}
${ wAE $e zw ( Tw Bw CQ ) $.
   wQE $e zw ( Tw Bw Cw ) $.
   wgE $a zw ( Tw Bw ( 4w CQ Cw ) ) $. $}
${ $d xX ph0 $.
   IQI $a iA Bw Bw CQ Ow $. $}
rgM $a #Pattern ( rwM Bw CQ Kw Cw ) $.
tAM $a #Pattern ( tQM Bw CQ ) $.
0gM $a #Pattern ( 0wM Bw CQ Cw DQ ) $.
HwQ $a #Pattern ( IAQ Bw CQ ) $.
IwQ $a #Pattern ( JAQ Bw ) $.
KwQ $a #Pattern ( LAQ Bw CQ Cw ) $.
${ $d xX y $.
   $d y ph6 $.
   OAQ $e iA Bw DQ Ew Ow $.
   OQQ $e iA CQ Dw Ew Ow $.
   OgQ $e iA Cw EQ Ew Ow $.
   OwQ $a iA ( rwM Bw CQ LQ Cw ) ( rwM DQ Dw LQ EQ ) Ew Ow $. $}
${ QAQ $e iA Bw Cw Dw Ow $.
   QQQ $e iA CQ DQ Dw Ow $.
   QgQ $a iA ( tQM Bw CQ ) ( tQM Cw DQ ) Dw Ow $. $}
${ $d z ph0 $.
   $d z ph1 $.
   $d z ph2 $.
   $d z y $.
   $d z x $.
   $d z th1 $.
   $d z th2 $.
   $d x ph0 $.
   $d y th0 $.
   lAY $e zw ( Tw GQ ( Uw Kw ( PgE Kw Bw ) ) ) $.
   lQY $e zw ( Tw ( 4w GQ Gw ) CQ ) $.
   lgY $e iA ( Tw HQ Cw ) ( Tw Gw CQ ) Bw LQ $.
   lwY $e iA ( Tw Hw DQ ) ( Tw Gw CQ ) Lw LQ $.
   mAY $a zw ( Tw ( 4w GQ HQ ) Cw ) $. $}
mgg $a #Pattern mwg $.
nwg $f #Pattern oAg $.
pQg $a #Pattern pgg $.
qgg $f #Pattern qwg $.
rgg $a #Pattern ( rwg oAg qwg ) $.
xAg $a #Pattern xQg $.
2Qg $f #ElementVariable 2gg $.
5wg $f #ElementVariable 6Ag $.
6wg $f #ElementVariable 7Ag $.
egk $a #Pattern ewk $.
nB4 $f #ElementVariable nR4 $.
vB4 $a #Pattern vR4 $.
Wh8 $a #Pattern 2gg $.
6h8 $a #Pattern nR4 $.
9h8 $a zw ( Tw ( 4w ( JAQ 2gg ) IQE ) ( 4w ( JAQ 2gg ) IQE ) ) $.
-CA $a #Pattern 7Ag $.
BCE $a #Pattern 6Ag $.
9yM $a iA 2gg 2gg nR4 7Ag $.
pyQ $a #Pattern ( 4w ( JAQ 2gg ) ( 4w ( SwE 7Ag mwg ) IQE ) ) $.
5CQ $a zw ( Tw ( 4w ( JAQ 2gg ) IQE ) ( Uw 6Ag ( PgE 6Ag xQg ) ) ) $.
5yQ $a zw ( Tw ( 4w ( 4w ( JAQ 2gg ) IQE ) ( 4w ( SwE 7Ag mwg ) IQE ) ) ( 4w ( JAQ 2gg ) ( 4w ( SwE 7Ag mwg ) IQE ) ) ) $.
6CQ $a iA ( 4w ( SwE xQg mwg ) IQE ) ( 4w ( SwE 7Ag mwg ) IQE ) xQg 7Ag $.
6SQ $a iA 2gg 2gg xQg 7Ag $.
6yQ $a iA mwg mwg nR4 7Ag $.
7SQ $a iA ( 4w ( SwE nR4 mwg ) IQE ) ( 4w ( SwE 7Ag mwg ) IQE ) nR4 7Ag $.
7yQ $a zw ( Tw ( 4w ( JAQ 2gg ) IQE ) ( 4w ( SwE xQg mwg ) IQE ) ) $.
9yw $a #Pattern ( 0wM mwg 2gg 6Ag ( rwg ( LAQ ewk pgg ( IAQ ewk vR4 ) ) 7Ag ) ) $.
.iw $a zw ( Tw ( 4w ( JAQ 2gg ) ( 4w ( SwE 7Ag mwg ) IQE ) ) ( tQM 2gg ( rwM mwg 2gg 6Ag ( 0wM mwg 2gg 6Ag ( rwg ( LAQ ewk pgg ( IAQ ewk vR4 ) ) 7Ag ) ) ) ) ) $.
.yw $a #Pattern ( 0wM mwg 2gg 6Ag ( rwg ( LAQ ewk pgg ( IAQ ewk vR4 ) ) nR4 ) ) $.
-Cw $a iA ( 0wM mwg 2gg 6Ag ( rwg ( LAQ ewk pgg ( IAQ ewk vR4 ) ) xQg ) ) ( 0wM mwg 2gg 6Ag ( rwg ( LAQ ewk pgg ( IAQ ewk vR4 ) ) 7Ag ) ) xQg 7Ag $.
-Sw $a iA ( 0wM mwg 2gg 6Ag ( rwg ( LAQ ewk pgg ( IAQ ewk vR4 ) ) nR4 ) ) ( 0wM mwg 2gg 6Ag ( rwg ( LAQ ewk pgg ( IAQ ewk vR4 ) ) 7Ag ) ) nR4 7Ag $.
${ -iw $p zw ( Tw ( 4w ( JAQ 2gg ) IQE ) ( tQM 2gg ( rwM mwg 2gg 6Ag ( 0wM mwg 2gg 6Ag ( rwg ( LAQ ewk pgg ( IAQ ewk vR4 ) ) xQg ) ) ) ) ) $=
  ( 6wg nB4 Wh8 IwQ IAE 4g xAg mgg SgE BCE egk pQg rgM tAM mAE OwQ QgQ lA vB4
  HwQ KwQ rgg 0gM 9h8 7yQ wgE 9yw .yw -CA 6h8 5CQ pyQ 5yQ .iw 6CQ 6SQ IQI -Cw
  SA 7SQ 9yM 6yQ -Sw mAY ) AEZFGHZVHIJKGHZHVGJVGJVGBLMNMUAUBUCIUDUEZBOZPZVHVHVI
  AUFAUGUHIVGJVGABCUIZBOZPZVLVGJVGABDUJZBOZPZVHCUKJKGHZVIDULZJKGHZBCDABUMVHVSHA
  CUNVOACUOABCUPQIVIVLVSVOCVAZCUQVGVKVGVNIWBACURZJVGVJJVGVMIBWBJIWBUSWCABCUTRST
  VTWAVRVSVOWBCDVBVGVQVGVNVTWBACDVCZJVGVPJVGVMVTBWBCDVDWDABCDVERSTVFQ $. $}
