$c 4B4 Tw #Symbol ZAE zw JAQ rgk pgg #Pattern ( rwg LAQ tQM IAQ 1gM #Variable SwE #SetVariable 4w #ElementVariable IQE mwg xQg ) $.
$v CQ qwg DQ Bw ph0 oAg Cw 2gg GQ x $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Cg $f #Pattern Cw $.
DA $f #Pattern DQ $.
GA $f #Pattern GQ $.
4g $a #Pattern ( 4w Bw CQ ) $.
IAE $a #Pattern IQE $.
${ lgE $e zw ( Tw Bw CQ ) $.
   lwE $e zw ( Tw CQ Cw ) $.
   mAE $a zw ( Tw Bw Cw ) $. $}
nAE $a zw IQE $.
${ wAE $e zw ( Tw Bw CQ ) $.
   wQE $e zw ( Tw Bw Cw ) $.
   wgE $a zw ( Tw Bw ( 4w CQ Cw ) ) $. $}
${ NwM $e zw CQ $.
   OAM $a zw ( Tw Bw CQ ) $. $}
tAM $a #Pattern ( tQM Bw CQ ) $.
1QM $a #Pattern ( 1gM Bw CQ Cw DQ ) $.
HwQ $a #Pattern ( IAQ Bw CQ ) $.
IwQ $a #Pattern ( JAQ Bw ) $.
KwQ $a #Pattern ( LAQ Bw CQ Cw ) $.
${ EwU $e zw ( ZAE Bw ) $.
   FAU $e zw ( ZAE CQ ) $.
   FQU $a zw ( ZAE ( 4w Bw CQ ) ) $. $}
FgU $a zw ( ZAE IQE ) $.
${ $d x ph0 $.
   NAY $a zw ( ZAE ( JAQ Bw ) ) $. $}
${ dwY $e zw ( ZAE GQ ) $.
   eAY $e zw ( Tw GQ ( SwE Cw Bw ) ) $.
   eQY $a zw ( Tw GQ ( tQM CQ ( 1gM Bw CQ Cw Cw ) ) ) $. $}
mgg $a #Pattern mwg $.
nwg $f #Pattern oAg $.
pQg $a #Pattern pgg $.
qgg $f #Pattern qwg $.
rgg $a #Pattern ( rwg oAg qwg ) $.
xAg $a #Pattern xQg $.
2Qg $f #ElementVariable 2gg $.
rQk $a #Pattern rgk $.
3x4 $a #Pattern 4B4 $.
Wh8 $a #Pattern 2gg $.
9h8 $a zw ( Tw ( 4w ( JAQ 2gg ) IQE ) ( 4w ( JAQ 2gg ) IQE ) ) $.
2DQ $a zw ( Tw ( 4w ( 4w ( JAQ 2gg ) IQE ) IQE ) ( SwE ( rwg ( LAQ rgk pgg ( IAQ rgk 4B4 ) ) xQg ) mwg ) ) $.
${ 2TQ $p zw ( Tw ( 4w ( JAQ 2gg ) IQE ) ( tQM 2gg ( 1gM mwg 2gg ( rwg ( LAQ rgk pgg ( IAQ rgk 4B4 ) ) xQg ) ( rwg ( LAQ rgk pgg ( IAQ rgk 4B4 ) ) xQg ) ) ) ) $=
  ( Wh8 IwQ IAE 4g mgg rQk pQg 3x4 HwQ KwQ xAg rgg 1QM tAM 9h8 nAE OAM FgU FQU
  wgE NAY 2DQ eQY mAE ) ABZCZDEZUHDEZUFFUFGHGIJKLMZUJNOUHUHDAPUHDQRUAFUFUJUIUHD
  UGDUFUBSTSTAUCUDUE $. $}
