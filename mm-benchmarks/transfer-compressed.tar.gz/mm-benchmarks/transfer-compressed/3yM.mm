$c Uw 4B4 #Symbol 7h4 DBE GBY zw pgg vA4 #Pattern Ex0 0wM xB4 tQM Wgk 0h4 #Variable SwE 0hU #SetVariable iA vR4 4w rwM #ElementVariable IQE qxs 8hw 2R4 PgE kBM XBI zBA 1wk Tw cwE -gg zBI 5x4 JAQ pwk rgk ( LAQ ewk yx4 IAQ 9R4 3BA hgk 8wk ) $.
$v th1 yhs Fw CQ Bw Cw 2gg sgg Pw FQ z ph2 Ew ph0 x Lw 6xw LQ Ow ph6 qwg DQ ph1 EQ y th2 Dw HQ xX Gw th0 Hw Kw oAg GQ $.
$d z y $.
$d z x $.
$d y x $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Cg $f #Pattern Cw $.
DA $f #Pattern DQ $.
Dg $f #Pattern Dw $.
EA $f #Pattern EQ $.
Eg $f #Pattern Ew $.
FA $f #Pattern FQ $.
Fg $f #Pattern Fw $.
GA $f #Pattern GQ $.
Gg $f #Pattern Gw $.
HA $f #Pattern HQ $.
Hg $f #Pattern Hw $.
Kg $f #ElementVariable Kw $.
LA $f #ElementVariable LQ $.
Lg $f #ElementVariable Lw $.
Og $f #Variable Ow $.
Pg $f #Symbol Pw $.
SA $a #Variable Kw $.
Sw $a #Pattern Pw $.
Ug $a #Pattern ( Uw Kw Bw ) $.
jg $a iA Bw Ow Bw Ow $.
${ kg $e iA CQ DQ Bw Ow $.
   kw $e iA Cw Dw Bw Ow $.
   lA $a iA ( Tw CQ Cw ) ( Tw DQ Dw ) Bw Ow $. $}
4g $a #Pattern ( 4w Bw CQ ) $.
IAE $a #Pattern IQE $.
PQE $a #Pattern ( PgE Bw CQ ) $.
SgE $a #Pattern ( SwE Bw CQ ) $.
cgE $a #Symbol cwE $.
${ lgE $e zw ( Tw Bw CQ ) $.
   lwE $e zw ( Tw CQ Cw ) $.
   mAE $a zw ( Tw Bw Cw ) $. $}
nAE $a zw IQE $.
${ wAE $e zw ( Tw Bw CQ ) $.
   wQE $e zw ( Tw Bw Cw ) $.
   wgE $a zw ( Tw Bw ( 4w CQ Cw ) ) $. $}
${ $d xX ph0 $.
   IQI $a iA Bw Bw CQ Ow $. $}
${ NwM $e zw CQ $.
   OAM $a zw ( Tw Bw CQ ) $. $}
rgM $a #Pattern ( rwM Bw CQ Kw Cw ) $.
tAM $a #Pattern ( tQM Bw CQ ) $.
0gM $a #Pattern ( 0wM Bw CQ Cw DQ ) $.
HwQ $a #Pattern ( IAQ Bw CQ ) $.
IwQ $a #Pattern ( JAQ Bw ) $.
KwQ $a #Pattern ( LAQ Bw CQ Cw ) $.
${ $d xX y $.
   $d y ph6 $.
   OAQ $e iA Bw DQ Ew Ow $.
   OQQ $e iA CQ Dw Ew Ow $.
   OgQ $e iA Cw EQ Ew Ow $.
   OwQ $a iA ( rwM Bw CQ LQ Cw ) ( rwM DQ Dw LQ EQ ) Ew Ow $. $}
${ QAQ $e iA Bw Cw Dw Ow $.
   QQQ $e iA CQ DQ Dw Ow $.
   QgQ $a iA ( tQM Bw CQ ) ( tQM Cw DQ ) Dw Ow $. $}
${ XgQ $e iA Bw Dw Fw Ow $.
   XwQ $e iA CQ EQ Fw Ow $.
   YAQ $e iA Cw Ew Fw Ow $.
   YQQ $e iA DQ FQ Fw Ow $.
   YgQ $a iA ( 0wM Bw CQ Cw DQ ) ( 0wM Dw EQ Ew FQ ) Fw Ow $. $}
iwY $a zw ( Uw Kw ( PgE Kw cwE ) ) $.
${ $d z ph0 $.
   $d z ph1 $.
   $d z ph2 $.
   $d z y $.
   $d z x $.
   $d z th1 $.
   $d z th2 $.
   $d x ph0 $.
   $d y th0 $.
   lAY $e zw ( Tw GQ ( Uw Kw ( PgE Kw Bw ) ) ) $.
   lQY $e zw ( Tw ( 4w GQ Gw ) CQ ) $.
   lgY $e iA ( Tw HQ Cw ) ( Tw Gw CQ ) Bw LQ $.
   lwY $e iA ( Tw Hw DQ ) ( Tw Gw CQ ) Lw LQ $.
   mAY $a zw ( Tw ( 4w GQ HQ ) Cw ) $. $}
${ $d x ph0 $.
   $d x ph1 $.
   vwY $e zw ( Tw GQ ( SwE CQ Bw ) ) $.
   wAY $e zw ( Tw GQ ( tQM cwE ( rwM Bw cwE Kw ( 0wM Bw cwE Kw CQ ) ) ) ) $.
   wQY $a zw ( Tw GQ ( Uw Kw ( PgE Kw CQ ) ) ) $. $}
nwg $f #Pattern oAg $.
pQg $a #Pattern pgg $.
qgg $f #Pattern qwg $.
sQg $f #Pattern sgg $.
2Qg $f #ElementVariable 2gg $.
.gg $a zw ( Tw ( 4w ( 4w ( JAQ oAg ) ( JAQ qwg ) ) ( SwE sgg oAg ) ) ( SwE ( LAQ oAg qwg sgg ) qwg ) ) $.
-Qg $a #Pattern -gg $.
WQk $a #Pattern Wgk $.
egk $a #Pattern ewk $.
hQk $a #Pattern hgk $.
pgk $a #Pattern pwk $.
rQk $a #Pattern rgk $.
1gk $a #Pattern 1wk $.
8gk $a #Pattern 8wk $.
uw4 $a #Pattern vA4 $.
yxA $a #Pattern ( zBA oAg qwg ) $.
2xA $a #Pattern ( 3BA oAg qwg ) $.
CxE $a #Pattern ( DBE oAg qwg ) $.
WxI $a #Pattern ( XBI oAg qwg ) $.
yxI $a #Pattern ( zBI oAg qwg ) $.
jxM $a #Pattern ( kBM oAg qwg ) $.
nBM $a zw ( Tw ( 4w ( SwE oAg 8wk ) ( SwE qwg 8wk ) ) ( SwE ( kBM oAg qwg ) 8wk ) ) $.
0RU $a #Pattern ( 0hU oAg qwg sgg ) $.
3xU $a zw ( Tw ( 4w ( 4w ( SwE oAg pwk ) ( SwE qwg hgk ) ) ( SwE sgg hgk ) ) ( SwE ( 0hU oAg qwg sgg ) 8wk ) ) $.
FxY $a #Pattern ( GBY oAg qwg ) $.
JBY $a zw ( Tw ( 4w ( SwE oAg -gg ) ( SwE qwg 8wk ) ) ( SwE ( GBY oAg qwg ) 1wk ) ) $.
qhs $a #Pattern ( qxs oAg ) $.
tBs $a zw ( Tw ( SwE oAg 8wk ) ( SwE ( qxs oAg ) hgk ) ) $.
yRs $f #ElementVariable yhs $.
6hw $f #ElementVariable 6xw $.
8Rw $a #Pattern 8hw $.
Eh0 $a #Pattern Ex0 $.
vB4 $a #Pattern vR4 $.
wx4 $a #Pattern xB4 $.
yh4 $a #Pattern yx4 $.
0R4 $a #Pattern 0h4 $.
2B4 $a #Pattern 2R4 $.
3x4 $a #Pattern 4B4 $.
5h4 $a #Pattern 5x4 $.
7R4 $a #Pattern 7h4 $.
9B4 $a #Pattern 9R4 $.
.h4 $a zw ( Tw IQE ( JAQ 1wk ) ) $.
.x4 $a zw ( Tw IQE ( JAQ pgg ) ) $.
Dh8 $a zw ( Tw IQE ( SwE ( kBM ( XBI ( IAQ ewk 9R4 ) ( LAQ rgk Wgk ( IAQ rgk yx4 ) ) ) ( XBI ( IAQ ewk 2R4 ) ( LAQ rgk Wgk ( IAQ rgk 0h4 ) ) ) ) 8wk ) ) $.
ER8 $a zw ( Tw IQE ( SwE ( XBI ( IAQ ewk vR4 ) ( LAQ rgk Wgk ( IAQ rgk 5x4 ) ) ) 8wk ) ) $.
FB8 $a zw ( Tw IQE ( SwE ( XBI ( IAQ ewk 7h4 ) ( LAQ rgk Wgk ( IAQ rgk 4B4 ) ) ) 8wk ) ) $.
GB8 $a zw ( Tw IQE ( SwE ( zBI ( LAQ ewk Wgk ( IAQ ewk 2R4 ) ) ( LAQ ewk Wgk ( IAQ ewk vR4 ) ) ) pwk ) ) $.
HB8 $a zw ( Tw IQE ( SwE ( qxs ( XBI ( IAQ ewk xB4 ) ( LAQ rgk Wgk ( IAQ rgk 8hw ) ) ) ) hgk ) ) $.
IB8 $a zw ( Tw IQE ( SwE ( kBM ( XBI ( IAQ ewk vR4 ) ( DBE ( LAQ ewk Wgk ( IAQ ewk vR4 ) ) ( LAQ ewk Wgk ( IAQ ewk 2R4 ) ) ) ) ( XBI ( IAQ ewk 7h4 ) ( zBA ( LAQ ewk Wgk ( IAQ ewk 7h4 ) ) ( LAQ ewk Wgk ( IAQ ewk 2R4 ) ) ) ) ) 8wk ) ) $.
Ix8 $a zw ( Tw IQE ( SwE ( XBI ( IAQ ewk xB4 ) ( LAQ rgk Wgk ( IAQ rgk Ex0 ) ) ) 8wk ) ) $.
Wh8 $a #Pattern 2gg $.
dB8 $a #Pattern 6xw $.
0h8 $a #Pattern ( PgE Kw cwE ) $.
5B8 $a zw ( Tw IQE ( 4w ( JAQ cwE ) IQE ) ) $.
.h8 $a zw ( Tw ( 4w IQE ( 4w ( JAQ 2gg ) IQE ) ) ( JAQ 2gg ) ) $.
-R8 $a iA ( 4w ( JAQ cwE ) IQE ) ( 4w ( JAQ 2gg ) IQE ) cwE 2gg $.
-h8 $a iA pgg pgg cwE 2gg $.
ASA $a iA ( 4w ( JAQ 6xw ) IQE ) ( 4w ( JAQ 2gg ) IQE ) 6xw 2gg $.
AiA $a iA pgg pgg 6xw 2gg $.
6yA $a zw ( Tw IQE ( SwE ( 3BA ( IAQ ewk 9R4 ) ( 3BA ( IAQ ewk 2R4 ) ( 3BA ( IAQ ewk vR4 ) ( 3BA ( IAQ ewk 7h4 ) ( 3BA ( IAQ ewk xB4 ) vA4 ) ) ) ) ) -gg ) ) $.
7SA $a #Pattern yhs $.
8yA $a iA yhs yhs cwE 2gg $.
9yA $a iA yhs yhs 6xw 2gg $.
3iM $a zw ( Tw ( 4w ( JAQ 2gg ) IQE ) ( tQM 2gg ( rwM pgg 2gg yhs ( 0wM pgg 2gg yhs ( LAQ 1wk pgg ( GBY ( 3BA ( IAQ ewk 9R4 ) ( 3BA ( IAQ ewk 2R4 ) ( 3BA ( IAQ ewk vR4 ) ( 3BA ( IAQ ewk 7h4 ) ( 3BA ( IAQ ewk xB4 ) vA4 ) ) ) ) ) ( kBM ( kBM ( kBM ( kBM ( XBI ( IAQ ewk 9R4 ) ( LAQ rgk Wgk ( IAQ rgk yx4 ) ) ) ( XBI ( IAQ ewk 2R4 ) ( LAQ rgk Wgk ( IAQ rgk 0h4 ) ) ) ) ( XBI ( IAQ ewk vR4 ) ( LAQ rgk Wgk ( IAQ rgk 5x4 ) ) ) ) ( XBI ( IAQ ewk 7h4 ) ( LAQ rgk Wgk ( IAQ rgk 4B4 ) ) ) ) ( 0hU ( zBI ( LAQ ewk Wgk ( IAQ ewk 2R4 ) ) ( LAQ ewk Wgk ( IAQ ewk vR4 ) ) ) ( qxs ( XBI ( IAQ ewk xB4 ) ( LAQ rgk Wgk ( IAQ rgk 8hw ) ) ) ) ( qxs ( kBM ( kBM ( XBI ( IAQ ewk vR4 ) ( DBE ( LAQ ewk Wgk ( IAQ ewk vR4 ) ) ( LAQ ewk Wgk ( IAQ ewk 2R4 ) ) ) ) ( XBI ( IAQ ewk 7h4 ) ( zBA ( LAQ ewk Wgk ( IAQ ewk 7h4 ) ) ( LAQ ewk Wgk ( IAQ ewk 2R4 ) ) ) ) ) ( XBI ( IAQ ewk xB4 ) ( LAQ rgk Wgk ( IAQ rgk Ex0 ) ) ) ) ) ) ) ) ) ) ) ) ) $.
${ 3yM $p zw ( Tw ( 4w ( JAQ 2gg ) IQE ) ( Uw yhs ( PgE yhs ( LAQ 1wk pgg ( GBY ( 3BA ( IAQ ewk 9R4 ) ( 3BA ( IAQ ewk 2R4 ) ( 3BA ( IAQ ewk vR4 ) ( 3BA ( IAQ ewk 7h4 ) ( 3BA ( IAQ ewk xB4 ) vA4 ) ) ) ) ) ( kBM ( kBM ( kBM ( kBM ( XBI ( IAQ ewk 9R4 ) ( LAQ rgk Wgk ( IAQ rgk yx4 ) ) ) ( XBI ( IAQ ewk 2R4 ) ( LAQ rgk Wgk ( IAQ rgk 0h4 ) ) ) ) ( XBI ( IAQ ewk vR4 ) ( LAQ rgk Wgk ( IAQ rgk 5x4 ) ) ) ) ( XBI ( IAQ ewk 7h4 ) ( LAQ rgk Wgk ( IAQ rgk 4B4 ) ) ) ) ( 0hU ( zBI ( LAQ ewk Wgk ( IAQ ewk 2R4 ) ) ( LAQ ewk Wgk ( IAQ ewk vR4 ) ) ) ( qxs ( XBI ( IAQ ewk xB4 ) ( LAQ rgk Wgk ( IAQ rgk 8hw ) ) ) ) ( qxs ( kBM ( kBM ( XBI ( IAQ ewk vR4 ) ( DBE ( LAQ ewk Wgk ( IAQ ewk vR4 ) ) ( LAQ ewk Wgk ( IAQ ewk 2R4 ) ) ) ) ( XBI ( IAQ ewk 7h4 ) ( zBA ( LAQ ewk Wgk ( IAQ ewk 7h4 ) ) ( LAQ ewk Wgk ( IAQ ewk 2R4 ) ) ) ) ) ( XBI ( IAQ ewk xB4 ) ( LAQ rgk Wgk ( IAQ rgk Ex0 ) ) ) ) ) ) ) ) ) ) ) ) $=
  ( 6hw Kg IwQ IAE 4g pQg egk HwQ 2xA rQk WQk KwQ WxI jxM SgE wgE 8gk mAE Ug Sw
  Wh8 7SA 1gk 9B4 2B4 vB4 7R4 wx4 uw4 yh4 0R4 5h4 3x4 yxI 8Rw qhs CxE yxA SA jg
  Eh0 0RU FxY PQE nAE OAM .h4 .x4 -Qg 6yA Dh8 ER8 nBM FB8 pgk hQk GB8 HB8 IB8
  Ix8 tBs 3xU JBY .gg cgE 0gM rgM tAM 5B8 dB8 0h8 iwY .h8 3iM -R8 -h8 8yA IQI
  YgQ OwQ QgQ lA ASA AiA 9yA mAY wQY ) AUCZEZFGZFBUDZUEHIUFJZIUGJZIUHJZIUIJZIUJ
  JZUKKKKKKZXNLMLULJNOXOLMLUMJNOPZXPLMLUNJNOZPZXQLMLUOJNOZPZIMXONZIMXPNZUPZXRLM
  LUQJNOURZXPYFYEUSOXQIMXQNYEUTOPZXRLMLVCJNOZPZURZVDZPZVEZNZVFBUAXLFVGVHHYPFBFU
  EEZHEZGZYOUEQZGYPHQFYSYTFYQYRVIVJRFXSVKQZYNSQZGYTFUUAUUBVLFYDSQZYMSQZGUUBFUUC
  UUDFYBSQZYCSQZGUUCFUUEUUFFXTSQZYASQZGUUEFUUGUUHVMVNRXTYAVOTVPRYBYCVOTFYGVQQZY
  HVRQZGZYLVRQZGUUDFUUKUULFUUIUUJVSVTRFYKSQZUULFYISQZYJSQZGUUMFUUNUUOWAWBRYIYJV
  OTYKWCTRYGYHYLWDTRYDYMVOTRXSYNWETRUEHYOWFTFFWGUBZEFGZGUUPHUUPHUUPXMYPWHZBWIZW
  JZFFUUQFFVGVHWKRUUPXJHXJHXJXMYPWHZBWIZWJZUUTCWLZHUVDHUVDXMYPWHZBWIZWJZFXLUUQU
  VDEFGZDACFDWMDUADWNVHFXLGZXLUVCUVIXKFAWOUVIFVGVHRABWPTUUPUUQUUTXLUVCAVAZAWQUU
  PUUSXJUVBUUPUVJUUPUVJVBZHUUPUURHXJUVAUUPBUVJAWRZUVKHUUPXMYPHXJXMYPUUPUVJUVLUV
  KABWSYPUUPUVJWTXAXBXCXDUVDUVHUVGXLUVCUVJACXEUVDUVFXJUVBUVDUVJUVDUVJVBZHUVDUVE
  HXJUVAUVDBUVJACXFZUVMHUVDXMYPHXJXMYPUVDUVJUVNUVMABCXGYPUVDUVJWTXAXBXCXDXHTXIT
  $. $}
