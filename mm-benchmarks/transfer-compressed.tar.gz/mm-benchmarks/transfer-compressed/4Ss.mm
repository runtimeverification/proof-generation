$c Uw PgE RAk Tw #Symbol cwE 8Q4 zw rgk #Pattern ( 0wM tQM IAQ Wgk #Variable SwE PQk #SetVariable 4w rwM #ElementVariable IQE mwg 8hw ) $.
$v yhs 4wg CQ 3gg Bw Kw ph1 oAg 5Qg ph0 GQ Cw x 4Ag $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Cg $f #Pattern Cw $.
GA $f #Pattern GQ $.
Kg $f #ElementVariable Kw $.
Ug $a #Pattern ( Uw Kw Bw ) $.
4g $a #Pattern ( 4w Bw CQ ) $.
IAE $a #Pattern IQE $.
PQE $a #Pattern ( PgE Bw CQ ) $.
SgE $a #Pattern ( SwE Bw CQ ) $.
${ lgE $e zw ( Tw Bw CQ ) $.
   lwE $e zw ( Tw CQ Cw ) $.
   mAE $a zw ( Tw Bw Cw ) $. $}
nAE $a zw IQE $.
${ NwM $e zw CQ $.
   OAM $a zw ( Tw Bw CQ ) $. $}
HwQ $a #Pattern ( IAQ Bw CQ ) $.
${ $d x ph0 $.
   $d x ph1 $.
   vwY $e zw ( Tw GQ ( SwE CQ Bw ) ) $.
   wAY $e zw ( Tw GQ ( tQM cwE ( rwM Bw cwE Kw ( 0wM Bw cwE Kw CQ ) ) ) ) $.
   wQY $a zw ( Tw GQ ( Uw Kw ( PgE Kw CQ ) ) ) $. $}
mgg $a #Pattern mwg $.
nwg $f #Pattern oAg $.
3Qg $f #ElementVariable 3gg $.
3wg $f #ElementVariable 4Ag $.
4gg $f #ElementVariable 4wg $.
5Ag $f #ElementVariable 5Qg $.
Qwk $a #Pattern RAk $.
WQk $a #Pattern Wgk $.
rQk $a #Pattern rgk $.
8A4 $a #Pattern ( 8Q4 oAg ) $.
yRs $f #ElementVariable yhs $.
8Rw $a #Pattern 8hw $.
Kx8 $a zw ( Tw IQE ( SwE ( 8Q4 ( IAQ rgk 8hw ) ) RAk ) ) $.
7SA $a #Pattern yhs $.
BCQ $a #Pattern 4Ag $.
XSU $a zw ( Tw IQE ( tQM cwE ( rwM RAk cwE yhs ( 0wM RAk cwE yhs ( 8Q4 ( IAQ rgk 8hw ) ) ) ) ) ) $.
XiU $a #Pattern 3gg $.
4Cs $a #Pattern ( 4w ( SwE 4wg PQk ) ( 4w ( SwE 5Qg Wgk ) IQE ) ) $.
${ 4Ss $p zw ( Tw ( 4w ( SwE 4Ag Wgk ) ( 4w ( SwE 3gg mwg ) ( 4w ( SwE 4wg PQk ) ( 4w ( SwE 5Qg Wgk ) IQE ) ) ) ) ( Uw yhs ( PgE yhs ( 8Q4 ( IAQ rgk 8hw ) ) ) ) ) $=
  ( BCQ WQk SgE XiU mgg 4Cs 4g IAE 7SA rQk 8Rw HwQ 8A4 PQE Ug nAE OAM Qwk Kx8
  XSU wQY mAE ) BFGHAIJHCDKLLZMENOPQRZSETUHMUAUBUCUIMEUDEUEUFUG $. $}
