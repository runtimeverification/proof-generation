$c ww4 2R4 Tw #Symbol zw YQk pgg rgk #Pattern ( LAQ ewk IAQ 9R4 #Variable SwE #SetVariable 4w #ElementVariable IQE 7BI 8hw ) cBQ $.
$v oAg Cw CQ qwg Bw $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Cg $f #Pattern Cw $.
4g $a #Pattern ( 4w Bw CQ ) $.
IAE $a #Pattern IQE $.
SgE $a #Pattern ( SwE Bw CQ ) $.
${ lgE $e zw ( Tw Bw CQ ) $.
   lwE $e zw ( Tw CQ Cw ) $.
   mAE $a zw ( Tw Bw Cw ) $. $}
${ wAE $e zw ( Tw Bw CQ ) $.
   wQE $e zw ( Tw Bw Cw ) $.
   wgE $a zw ( Tw Bw ( 4w CQ Cw ) ) $. $}
HwQ $a #Pattern ( IAQ Bw CQ ) $.
KwQ $a #Pattern ( LAQ Bw CQ Cw ) $.
nwg $f #Pattern oAg $.
pQg $a #Pattern pgg $.
qgg $f #Pattern qwg $.
YAk $a #Pattern YQk $.
egk $a #Pattern ewk $.
rQk $a #Pattern rgk $.
wg4 $a #Pattern ww4 $.
6xI $a #Pattern ( 7BI oAg qwg ) $.
.BI $a zw ( Tw ( 4w ( SwE oAg YQk ) ( SwE qwg YQk ) ) ( SwE ( 7BI oAg qwg ) YQk ) ) $.
bxQ $a #Pattern ( cBQ oAg qwg ) $.
8Rw $a #Pattern 8hw $.
2B4 $a #Pattern 2R4 $.
9B4 $a #Pattern 9R4 $.
JR8 $a zw ( Tw IQE ( SwE ww4 YQk ) ) $.
KB8 $a zw ( Tw IQE ( SwE ( cBQ ( LAQ ewk pgg ( IAQ ewk 9R4 ) ) ( LAQ rgk pgg ( IAQ rgk 8hw ) ) ) YQk ) ) $.
Lh8 $a zw ( Tw IQE ( SwE ( cBQ ( LAQ ewk pgg ( IAQ ewk 2R4 ) ) ( LAQ rgk pgg ( IAQ rgk 8hw ) ) ) YQk ) ) $.
${ 3yY $p zw ( Tw IQE ( SwE ( 7BI ( 7BI ( cBQ ( LAQ ewk pgg ( IAQ ewk 9R4 ) ) ( LAQ rgk pgg ( IAQ rgk 8hw ) ) ) ( cBQ ( LAQ ewk pgg ( IAQ ewk 2R4 ) ) ( LAQ rgk pgg ( IAQ rgk 8hw ) ) ) ) ww4 ) YQk ) ) $=
  ( IAE egk pQg 9B4 HwQ KwQ rQk 8Rw bxQ 2B4 6xI YAk SgE wg4 KB8 Lh8 wgE .BI mAE
  4g JR8 ) ABCBDEFGCGHEFZIZBCBJEFUBIZKZLMZNLMZTUENKLMAUFUGAUCLMZUDLMZTUFAUHUIOP
  QUCUDRSUAQUENRS $. $}
