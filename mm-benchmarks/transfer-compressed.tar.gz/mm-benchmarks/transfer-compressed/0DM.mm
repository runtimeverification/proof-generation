$c lSA ewk IAQ Tw #Symbol #Variable SwE #SetVariable zw 4w #ElementVariable IQE rgk #Pattern ) ( $.
$v 5Qg CQ Bw $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Tg $a #Pattern ( Tw Bw CQ ) $.
4g $a #Pattern ( 4w Bw CQ ) $.
5Q $a zw ( Tw Bw ( Tw CQ Bw ) ) $.
${ 6A $e zw ( Tw Bw CQ ) $.
   6Q $e zw Bw $.
   6g $a zw CQ $. $}
IAE $a #Pattern IQE $.
SgE $a #Pattern ( SwE Bw CQ ) $.
HwQ $a #Pattern ( IAQ Bw CQ ) $.
IgQ $a zw ( SwE ( IAQ Bw CQ ) Bw ) $.
5Ag $f #ElementVariable 5Qg $.
egk $a #Pattern ewk $.
rQk $a #Pattern rgk $.
lCA $a #Pattern lSA $.
YCU $a #Pattern 5Qg $.
${ 0DM $p zw ( Tw ( 4w ( SwE 5Qg ewk ) IQE ) ( SwE ( IAQ rgk lSA ) rgk ) ) $=
  ( rQk lCA HwQ SgE YCU egk IAE 4g Tg 5Q IgQ 6g ) BCDBEZAFGEHIZNJNOKBCLM $. $}
