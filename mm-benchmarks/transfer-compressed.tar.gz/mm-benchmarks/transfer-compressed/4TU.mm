$c IAQ #Symbol 1CA #Variable #SetVariable iA #ElementVariable rgk #Pattern ) ( $.
$v Ow CQ xX Bw Kw ph0 2gg mh4 $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Kg $f #ElementVariable Kw $.
Og $f #Variable Ow $.
SA $a #Variable Kw $.
${ $d xX ph0 $.
   IQI $a iA Bw Bw CQ Ow $. $}
HwQ $a #Pattern ( IAQ Bw CQ ) $.
2Qg $f #ElementVariable 2gg $.
rQk $a #Pattern rgk $.
mR4 $f #ElementVariable mh4 $.
Wh8 $a #Pattern 2gg $.
0yA $a #Pattern 1CA $.
${ 4TU $p iA 2gg 2gg ( IAQ rgk 1CA ) mh4 $=
  ( Wh8 rQk 0yA HwQ SA IQI ) ACDEFBGH $. $}
