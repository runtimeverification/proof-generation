$c 4B4 Ngk Lwk #Symbol 7h4 8Q4 BA0 zw xwM pgg #Pattern 0Q4 rwg Ex0 0wM xB4 tQM Wgk 0h4 5xw #Variable SwE PQk #SetVariable iA vR4 4w #ElementVariable IQE 8hw xQg cBQ lSA 2R4 XBI RAk Tw 1CA wQM cwE -g4 .gk rgk ( twM LAQ ewk yx4 IAQ 9R4 Hg8 Kw8 8wk 7Ak 7BI ) $.
$v Ow CQ qwg DQ Bw Cw EQ sgg Dw tAg ngg FQ xX Ew Kw ph0 oAg GQ nR4 tgg $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Cg $f #Pattern Cw $.
DA $f #Pattern DQ $.
Dg $f #Pattern Dw $.
EA $f #Pattern EQ $.
Eg $f #Pattern Ew $.
FA $f #Pattern FQ $.
GA $f #Pattern GQ $.
Kg $f #ElementVariable Kw $.
Og $f #Variable Ow $.
SA $a #Variable Kw $.
Tg $a #Pattern ( Tw Bw CQ ) $.
jg $a iA Bw Ow Bw Ow $.
4g $a #Pattern ( 4w Bw CQ ) $.
5Q $a zw ( Tw Bw ( Tw CQ Bw ) ) $.
${ 6A $e zw ( Tw Bw CQ ) $.
   6Q $e zw Bw $.
   6g $a zw CQ $. $}
IAE $a #Pattern IQE $.
SgE $a #Pattern ( SwE Bw CQ ) $.
${ lgE $e zw ( Tw Bw CQ ) $.
   lwE $e zw ( Tw CQ Cw ) $.
   mAE $a zw ( Tw Bw Cw ) $. $}
${ wAE $e zw ( Tw Bw CQ ) $.
   wQE $e zw ( Tw Bw Cw ) $.
   wgE $a zw ( Tw Bw ( 4w CQ Cw ) ) $. $}
${ $d xX ph0 $.
   IQI $a iA Bw Bw CQ Ow $. $}
${ NwM $e zw CQ $.
   OAM $a zw ( Tw Bw CQ ) $. $}
tAM $a #Pattern ( tQM Bw CQ ) $.
uwM $a #Pattern ( twM Bw ) $.
wAM $a #Pattern ( wQM Bw CQ Cw ) $.
xgM $a #Pattern ( xwM Bw CQ Cw ) $.
0gM $a #Pattern ( 0wM Bw CQ Cw DQ ) $.
HwQ $a #Pattern ( IAQ Bw CQ ) $.
KwQ $a #Pattern ( LAQ Bw CQ Cw ) $.
${ QAQ $e iA Bw Cw Dw Ow $.
   QQQ $e iA CQ DQ Dw Ow $.
   QgQ $a iA ( tQM Bw CQ ) ( tQM Cw DQ ) Dw Ow $. $}
${ SgQ $e iA Bw DQ Ew Ow $.
   SwQ $e iA CQ Dw Ew Ow $.
   TAQ $e iA Cw EQ Ew Ow $.
   TQQ $a iA ( wQM Bw CQ Cw ) ( wQM DQ Dw EQ ) Ew Ow $. $}
${ UgQ $e iA Bw DQ Ew Ow $.
   UwQ $e iA CQ Dw Ew Ow $.
   VAQ $e iA Cw EQ Ew Ow $.
   VQQ $a iA ( xwM Bw CQ Cw ) ( xwM DQ Dw EQ ) Ew Ow $. $}
JwU $a zw ( Tw ( 4w ( SwE CQ Bw ) ( SwE Cw Bw ) ) ( SwE ( wQM Bw CQ Cw ) Bw ) ) $.
LAU $a zw ( SwE ( 0wM Bw CQ Cw DQ ) CQ ) $.
${ VwU $e zw ( Tw GQ ( tQM Bw Cw ) ) $.
   WAU $a zw ( Tw GQ ( tQM Bw ( xwM Bw CQ Cw ) ) ) $. $}
${ sgU $e zw ( Tw GQ ( SwE CQ Bw ) ) $.
   swU $a zw ( Tw GQ ( tQM Bw ( xwM Bw CQ CQ ) ) ) $. $}
${ AgY $e zw ( Tw GQ ( SwE CQ Bw ) ) $.
   AwY $e zw ( Tw GQ ( SwE Cw Bw ) ) $.
   BAY $e zw ( Tw GQ ( SwE Dw Bw ) ) $.
   BQY $e zw ( Tw GQ ( tQM Bw ( xwM Bw CQ Cw ) ) ) $.
   BgY $e zw ( Tw GQ ( tQM Bw ( xwM Bw DQ ( wQM Bw CQ Dw ) ) ) ) $.
   BwY $a zw ( Tw GQ ( tQM Bw ( xwM Bw DQ ( wQM Bw Cw Dw ) ) ) ) $. $}
${ swY $e zw ( Tw GQ ( SwE CQ Bw ) ) $.
   tAY $e zw ( Tw GQ ( SwE Cw Bw ) ) $.
   tQY $e zw ( Tw GQ ( tQM cwE ( 0wM Bw cwE CQ Cw ) ) ) $.
   tgY $e zw ( Tw GQ ( tQM Ew DQ ) ) $.
   twY $e iA ( tQM Ew DQ ) Dw CQ Kw $.
   uAY $e iA ( tQM FQ EQ ) Dw Cw Kw $.
   uQY $a zw ( Tw GQ ( tQM FQ EQ ) ) $. $}
uwY $a zw ( tQM Bw ( 0wM CQ Bw Cw Cw ) ) $.
nQg $f #Variable ngg $.
nwg $f #Pattern oAg $.
pQg $a #Pattern pgg $.
qgg $f #Pattern qwg $.
rgg $a #Pattern ( rwg oAg qwg ) $.
sQg $f #Pattern sgg $.
swg $f #Pattern tAg $.
tQg $f #Pattern tgg $.
${ uQg $e iA qwg tAg oAg ngg $.
   ugg $e iA sgg tgg oAg ngg $.
   uwg $a iA ( rwg qwg sgg ) ( rwg tAg tgg ) oAg ngg $. $}
xAg $a #Pattern xQg $.
Lgk $a #Pattern Lwk $.
NQk $a #Pattern Ngk $.
PAk $a #Pattern PQk $.
Qwk $a #Pattern RAk $.
WQk $a #Pattern Wgk $.
egk $a #Pattern ewk $.
rQk $a #Pattern rgk $.
6wk $a #Pattern 7Ak $.
8gk $a #Pattern 8wk $.
.Qk $a #Pattern .gk $.
Aw0 $a #Pattern ( BA0 oAg ) $.
0A4 $a #Pattern ( 0Q4 oAg qwg ) $.
${ 1Q4 $e iA qwg tAg oAg ngg $.
   1g4 $e iA sgg tgg oAg ngg $.
   1w4 $a iA ( 0Q4 qwg sgg ) ( 0Q4 tAg tgg ) oAg ngg $. $}
3Q4 $a zw ( Tw ( 4w ( SwE oAg Lwk ) ( SwE qwg PQk ) ) ( SwE ( 0Q4 oAg qwg ) 7Ak ) ) $.
8A4 $a #Pattern ( 8Q4 oAg ) $.
-Q4 $a #Pattern ( -g4 oAg qwg ) $.
${ Ag8 $e iA qwg tAg oAg ngg $.
   Aw8 $e iA sgg tgg oAg ngg $.
   BA8 $a iA ( -g4 qwg sgg ) ( -g4 tAg tgg ) oAg ngg $. $}
Cg8 $a zw ( Tw ( 4w ( SwE oAg 7Ak ) ( SwE qwg RAk ) ) ( SwE ( -g4 oAg qwg ) Ngk ) ) $.
HQ8 $a #Pattern ( Hg8 oAg ) $.
${ Ig8 $e iA qwg sgg oAg ngg $.
   Iw8 $a iA ( Hg8 qwg ) ( Hg8 sgg ) oAg ngg $. $}
Kg8 $a #Pattern ( Kw8 oAg ) $.
WxI $a #Pattern ( XBI oAg qwg ) $.
6xI $a #Pattern ( 7BI oAg qwg ) $.
bxQ $a #Pattern ( cBQ oAg qwg ) $.
5hw $a #Pattern 5xw $.
8Rw $a #Pattern 8hw $.
Eh0 $a #Pattern Ex0 $.
nB4 $f #ElementVariable nR4 $.
vB4 $a #Pattern vR4 $.
wx4 $a #Pattern xB4 $.
yh4 $a #Pattern yx4 $.
0R4 $a #Pattern 0h4 $.
2B4 $a #Pattern 2R4 $.
3x4 $a #Pattern 4B4 $.
7R4 $a #Pattern 7h4 $.
9B4 $a #Pattern 9R4 $.
.R4 $a zw ( Tw IQE ( SwE ( twM Ngk ) Ngk ) ) $.
Kx8 $a zw ( Tw IQE ( SwE ( 8Q4 ( IAQ rgk 8hw ) ) RAk ) ) $.
6h8 $a #Pattern nR4 $.
lCA $a #Pattern lSA $.
qSA $a zw ( Tw IQE ( SwE ( Kw8 ( 7BI ( cBQ ( LAQ ewk pgg ( IAQ ewk xB4 ) ) ( LAQ rgk pgg ( IAQ rgk 8hw ) ) ) ( 7BI ( cBQ ( LAQ ewk pgg ( IAQ ewk vR4 ) ) ( LAQ rgk pgg ( IAQ rgk lSA ) ) ) ( 7BI ( cBQ ( LAQ ewk pgg ( IAQ ewk 9R4 ) ) ( LAQ rgk pgg ( IAQ rgk yx4 ) ) ) ( 7BI ( cBQ ( LAQ ewk pgg ( IAQ ewk 7h4 ) ) ( LAQ rgk pgg ( IAQ rgk 4B4 ) ) ) ( cBQ ( LAQ ewk pgg ( IAQ ewk 2R4 ) ) ( LAQ rgk pgg ( IAQ rgk 0h4 ) ) ) ) ) ) ) ) PQk ) ) $.
0yA $a #Pattern 1CA $.
4SA $a zw ( Tw IQE ( SwE ( LAQ rgk pgg ( IAQ rgk 1CA ) ) pgg ) ) $.
njU $a zw ( Tw IQE ( SwE ( Hg8 ( rwg ( LAQ rgk pgg ( IAQ rgk 1CA ) ) ( rwg ( BA0 ( rwg ( LAQ ewk pgg ( IAQ ewk 7h4 ) ) xQg ) ) ( rwg ( LAQ 8wk pgg ( XBI ( IAQ ewk xB4 ) ( LAQ rgk Wgk ( IAQ rgk Ex0 ) ) ) ) xQg ) ) ) ) Lwk ) ) $.
9jU $a zw ( Tw IQE ( tQM cwE ( 0wM pgg cwE ( LAQ rgk pgg ( IAQ rgk 1CA ) ) ( wQM pgg ( LAQ rgk pgg ( IAQ rgk 1CA ) ) ( LAQ rgk pgg ( IAQ rgk 1CA ) ) ) ) ) ) $.
.TU $a zw ( Tw IQE ( tQM cwE ( 0wM pgg cwE ( LAQ rgk pgg ( IAQ rgk 1CA ) ) ( LAQ Wgk pgg ( LAQ rgk Wgk ( IAQ rgk 1CA ) ) ) ) ) ) $.
.jU $a zw ( Tw IQE ( SwE ( LAQ Wgk pgg ( LAQ rgk Wgk ( IAQ rgk 1CA ) ) ) pgg ) ) $.
.zU $a zw ( Tw IQE ( SwE ( Hg8 ( rwg ( wQM pgg ( LAQ Wgk pgg ( LAQ rgk Wgk ( IAQ rgk 1CA ) ) ) ( LAQ rgk pgg ( IAQ rgk 1CA ) ) ) ( rwg ( BA0 ( rwg ( LAQ ewk pgg ( IAQ ewk 7h4 ) ) xQg ) ) ( rwg ( LAQ 8wk pgg ( XBI ( IAQ ewk xB4 ) ( LAQ rgk Wgk ( IAQ rgk Ex0 ) ) ) ) xQg ) ) ) ) Lwk ) ) $.
${ -DU $p zw ( Tw IQE ( tQM Ngk ( xwM Ngk ( wQM Ngk ( wQM Ngk ( twM Ngk ) ( twM Ngk ) ) ( -g4 ( 0Q4 ( Hg8 ( rwg ( LAQ rgk pgg ( IAQ rgk 1CA ) ) ( rwg ( BA0 ( rwg ( LAQ ewk pgg ( IAQ ewk 7h4 ) ) xQg ) ) ( rwg ( LAQ 8wk pgg ( XBI ( IAQ ewk xB4 ) ( LAQ rgk Wgk ( IAQ rgk Ex0 ) ) ) ) xQg ) ) ) ) ( Kw8 ( 7BI ( cBQ ( LAQ ewk pgg ( IAQ ewk xB4 ) ) ( LAQ rgk pgg ( IAQ rgk 8hw ) ) ) ( 7BI ( cBQ ( LAQ ewk pgg ( IAQ ewk vR4 ) ) ( LAQ rgk pgg ( IAQ rgk lSA ) ) ) ( 7BI ( cBQ ( LAQ ewk pgg ( IAQ ewk 9R4 ) ) ( LAQ rgk pgg ( IAQ rgk yx4 ) ) ) ( 7BI ( cBQ ( LAQ ewk pgg ( IAQ ewk 7h4 ) ) ( LAQ rgk pgg ( IAQ rgk 4B4 ) ) ) ( cBQ ( LAQ ewk pgg ( IAQ ewk 2R4 ) ) ( LAQ rgk pgg ( IAQ rgk 0h4 ) ) ) ) ) ) ) ) ) ( 8Q4 ( IAQ rgk 8hw ) ) ) ) ( wQM Ngk ( 0wM .gk Ngk ( IAQ .gk 5xw ) ( IAQ .gk 5xw ) ) ( -g4 ( 0Q4 ( Hg8 ( rwg ( wQM pgg ( LAQ Wgk pgg ( LAQ rgk Wgk ( IAQ rgk 1CA ) ) ) ( LAQ rgk pgg ( IAQ rgk 1CA ) ) ) ( rwg ( BA0 ( rwg ( LAQ ewk pgg ( IAQ ewk 7h4 ) ) xQg ) ) ( rwg ( LAQ 8wk pgg ( XBI ( IAQ ewk xB4 ) ( LAQ rgk Wgk ( IAQ rgk Ex0 ) ) ) ) xQg ) ) ) ) ( Kw8 ( 7BI ( cBQ ( LAQ ewk pgg ( IAQ ewk xB4 ) ) ( LAQ rgk pgg ( IAQ rgk 8hw ) ) ) ( 7BI ( cBQ ( LAQ ewk pgg ( IAQ ewk vR4 ) ) ( LAQ rgk pgg ( IAQ rgk lSA ) ) ) ( 7BI ( cBQ ( LAQ ewk pgg ( IAQ ewk 9R4 ) ) ( LAQ rgk pgg ( IAQ rgk yx4 ) ) ) ( 7BI ( cBQ ( LAQ ewk pgg ( IAQ ewk 7h4 ) ) ( LAQ rgk pgg ( IAQ rgk 4B4 ) ) ) ( cBQ ( LAQ ewk pgg ( IAQ ewk 2R4 ) ) ( LAQ rgk pgg ( IAQ rgk 0h4 ) ) ) ) ) ) ) ) ) ( 8Q4 ( IAQ rgk 8hw ) ) ) ) ) ) ) $=
  ( NQk wAM HwQ rQk pQg KwQ egk rgg HQ8 bxQ 0A4 -Q4 IAE SgE wgE mAE xgM IQI TQQ
  4g nB4 uwM .Qk 5hw 0gM 0yA 7R4 xAg Aw0 8gk wx4 WQk Eh0 WxI 8Rw vB4 lCA 9B4 Tg
  yh4 3x4 2B4 0R4 6xI Kg8 8A4 .R4 JwU 5Q LAU 6g 6wk Qwk Lgk PAk .zU qSA 3Q4 Kx8
  Cg8 tAM uwY OAM WAU 6h8 4SA .jU .TU 9jU njU swU SA jg uwg Iw8 1w4 BA8 VQQ QgQ
  uQY BwY ) AAAUBZXBBZUCAUCUDCZXDUEZAXCDEDUFCZFZGEGUGCFZUHHUIUJEGUKCZDULDUMCFUN
  FUHHHZHZIZGEXIFDEDUOCZFJGEGUPCFDEDUQCFJGEGURCFDEDUTCFJXHDEDVACFJGEGVBCFDEDVCC
  FJVDVDVDVDVEZKZXMVFZLZBZEULEDULXFFFZXGBZXJHZIZXNKZXPLZMMXBANZYETXCANZMYEYEVGV
  GOAXBXBVHPZXEANZMYHUSYHMVIUCAXDXDVJVKMYCVLNZXPVMNZTYDANMYIYJMYBVNNZXNVONZTYIM
  YKYLVPVQOYBXNVRPVSOYCXPVTPAXCXEMMAXEWAAUCXDWBWCWDEXGXSAXRAXCEXGXGBZXJHZIZXNKZ
  XPLZBZQZAAXRAXCEUAWEZXGBZXJHZIZXNKZXPLZBZQZWAAXRAXCYDBZQZAAMUAWFWGWHEXGYMAXRX
  RQZAAXRAXCYTXJHZIZXNKZXPLZBZQZWAYSAAMUAWFMXGENZUUQTYMENMUUQUUQWFWFOEXGXGVHPWI
  AXRMMYFXQANZTXRANMYFUURYGMXOVLNZYJTUURMUUSYJMXLVNNZYLTUUSMUUTYLWJVQOXLXNVRPVS
  OXOXPVTPOAXCXQVHPWKAUUJAUUPXGUAWLZAXGUVARZAXRXRAXRUUOXGUVAUVBXRXGUVARZAXCXQAX
  CUUNXGUVAUVBXCXGUVARZUVAXGXOXPUUMXPUVAXGXLXNUULXNUVAXGXKUUKUVAXGXGXJYTXJXGUVA
  WMZXJXGUVARZWNWOXNXGUVARZWPXPXGUVARZWQSWRWSAYSAUUPYMUVAAYMUVARZAXRYRAXRUUOYMU
  VAUVIXRYMUVARAXCYQAXCUUNYMUVAUVIXCYMUVARUVAYMYPXPUUMXPUVAYMYOXNUULXNUVAYMYNUU
  KUVAYMYMXJYTXJYMUVAWMXJYMUVARWNWOXNYMUVARWPXPYMUVARWQSWRWSWTAYSAUUGXGUVAUVBAX
  RYRAXRUUFXGUVAUVBUVCAXCYQAXCUUEXGUVAUVBUVDUVAXGYPXPUUDXPUVAXGYOXNUUCXNUVAXGYN
  UUBUVAXGYMXJUUAXJEXGXGEYTXGXGUVAEXGUVARUVEXGXGUVARSUVFWNWOUVGWPUVHWQSWRWSAUUI
  AUUGXSUVAAXSUVARZAXRUUHAXRUUFXSUVAUVJXRXSUVARAXCYDAXCUUEXSUVAUVJXCXSUVARUVAXS
  YCXPUUDXPUVAXSYBXNUUCXNUVAXSYAUUBUVAXSXTXJUUAXJEXSXGEYTXGXSUVAEXSUVARXSUVAWMX
  GXSUVARSXJXSUVARWNWOXNXSUVARWPXPXSUVARWQSWRWSWTXA $. $}
