$c #SetVariable iA ) ewk #ElementVariable #Symbol #Variable #Pattern ( $.
$v Ow CQ xX Bw Kw ph0 0R8 6xw $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Kg $f #ElementVariable Kw $.
Og $f #Variable Ow $.
SA $a #Variable Kw $.
${ $d xX ph0 $.
   IQI $a iA Bw Bw CQ Ow $. $}
egk $a #Pattern ewk $.
6hw $f #ElementVariable 6xw $.
0B8 $f #ElementVariable 0R8 $.
1h8 $a #Pattern 0R8 $.
${ 4B8 $p iA ewk ewk 0R8 6xw $=
  ( egk 1h8 SA IQI ) CBDAEF $. $}
