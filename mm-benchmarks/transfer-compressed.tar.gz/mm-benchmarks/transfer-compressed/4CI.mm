$c #SetVariable zBI ) #ElementVariable #Symbol #Variable #Pattern ( $.
$v oAg nR4 XRw qwg $.
nwg $f #Pattern oAg $.
qgg $f #Pattern qwg $.
yxI $a #Pattern ( zBI oAg qwg ) $.
XBw $f #ElementVariable XRw $.
nB4 $f #ElementVariable nR4 $.
6h8 $a #Pattern nR4 $.
QCE $a #Pattern XRw $.
${ 4CI $p #Pattern ( zBI nR4 XRw ) $=
  ( 6h8 QCE yxI ) BCADE $. $}
