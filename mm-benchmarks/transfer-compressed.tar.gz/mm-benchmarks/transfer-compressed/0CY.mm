$c LAQ IAQ Tw #Symbol #Variable SwE pgg #SetVariable zw 4w YQk JAQ #ElementVariable IQE rgk #Pattern 8hw ) ( $.
$v CQ qwg sgg Bw oAg Cw 2gg pxw $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Cg $f #Pattern Cw $.
Tg $a #Pattern ( Tw Bw CQ ) $.
4g $a #Pattern ( 4w Bw CQ ) $.
5Q $a zw ( Tw Bw ( Tw CQ Bw ) ) $.
${ 6A $e zw ( Tw Bw CQ ) $.
   6Q $e zw Bw $.
   6g $a zw CQ $. $}
SgE $a #Pattern ( SwE Bw CQ ) $.
${ lgE $e zw ( Tw Bw CQ ) $.
   lwE $e zw ( Tw CQ Cw ) $.
   mAE $a zw ( Tw Bw Cw ) $. $}
${ wAE $e zw ( Tw Bw CQ ) $.
   wQE $e zw ( Tw Bw Cw ) $.
   wgE $a zw ( Tw Bw ( 4w CQ Cw ) ) $. $}
HwQ $a #Pattern ( IAQ Bw CQ ) $.
IgQ $a zw ( SwE ( IAQ Bw CQ ) Bw ) $.
IwQ $a #Pattern ( JAQ Bw ) $.
KwQ $a #Pattern ( LAQ Bw CQ Cw ) $.
nwg $f #Pattern oAg $.
pQg $a #Pattern pgg $.
qgg $f #Pattern qwg $.
sQg $f #Pattern sgg $.
2Qg $f #ElementVariable 2gg $.
.gg $a zw ( Tw ( 4w ( 4w ( JAQ oAg ) ( JAQ qwg ) ) ( SwE sgg oAg ) ) ( SwE ( LAQ oAg qwg sgg ) qwg ) ) $.
rQk $a #Pattern rgk $.
phw $f #ElementVariable pxw $.
8Rw $a #Pattern 8hw $.
xSY $a #Pattern ( 4w ( JAQ 2gg ) ( 4w ( SwE pxw YQk ) IQE ) ) $.
zyY $a zw ( Tw ( 4w ( JAQ 2gg ) ( 4w ( SwE pxw YQk ) IQE ) ) ( 4w ( JAQ rgk ) ( JAQ pgg ) ) ) $.
${ 0CY $p zw ( Tw ( 4w ( JAQ 2gg ) ( 4w ( SwE pxw YQk ) IQE ) ) ( SwE ( LAQ rgk pgg ( IAQ rgk 8hw ) ) pgg ) ) $=
  ( xSY rQk IwQ pQg 4g 8Rw HwQ SgE KwQ zyY Tg 5Q IgQ 6g wgE .gg mAE ) ABCZDEFEG
  ZDHIZDJZGDFUBKFJTUAUCABLUCTUCMUCTNDHOPQDFUBRS $. $}
