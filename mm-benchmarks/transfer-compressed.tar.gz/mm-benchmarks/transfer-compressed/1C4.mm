$c Uw #Symbol 7h4 DBE zw pgg #Pattern rwg 0wM Ex0 xB4 tQM 0h4 Wgk #Variable SwE #SetVariable iA vR4 4w rwM #ElementVariable IQE qxs mwg xQg 8hw kBM 2R4 zBA XBI PgE Tw cwE JAQ rgk ( RQ0 LAQ ewk IAQ OA0 hgk ) $.
$v th1 Fw CQ Bw Cw 2gg sgg ngg FQ z ph2 Ew ph0 x Lw LQ 7Ag Ow ph6 qwg DQ ph1 EQ y th2 Dw tAg HQ xX Gw th0 Hw Kw oAg 6Ag GQ nR4 tgg $.
$d z y $.
$d z x $.
$d y x $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Cg $f #Pattern Cw $.
DA $f #Pattern DQ $.
Dg $f #Pattern Dw $.
EA $f #Pattern EQ $.
Eg $f #Pattern Ew $.
FA $f #Pattern FQ $.
Fg $f #Pattern Fw $.
GA $f #Pattern GQ $.
Gg $f #Pattern Gw $.
HA $f #Pattern HQ $.
Hg $f #Pattern Hw $.
Kg $f #ElementVariable Kw $.
LA $f #ElementVariable LQ $.
Lg $f #ElementVariable Lw $.
Og $f #Variable Ow $.
SA $a #Variable Kw $.
Ug $a #Pattern ( Uw Kw Bw ) $.
jg $a iA Bw Ow Bw Ow $.
${ kg $e iA CQ DQ Bw Ow $.
   kw $e iA Cw Dw Bw Ow $.
   lA $a iA ( Tw CQ Cw ) ( Tw DQ Dw ) Bw Ow $. $}
4g $a #Pattern ( 4w Bw CQ ) $.
IAE $a #Pattern IQE $.
PQE $a #Pattern ( PgE Bw CQ ) $.
SgE $a #Pattern ( SwE Bw CQ ) $.
${ lgE $e zw ( Tw Bw CQ ) $.
   lwE $e zw ( Tw CQ Cw ) $.
   mAE $a zw ( Tw Bw Cw ) $. $}
nAE $a zw IQE $.
${ wAE $e zw ( Tw Bw CQ ) $.
   wQE $e zw ( Tw Bw Cw ) $.
   wgE $a zw ( Tw Bw ( 4w CQ Cw ) ) $. $}
${ $d xX ph0 $.
   IQI $a iA Bw Bw CQ Ow $. $}
${ KAI $e iA CQ DQ Bw Ow $.
   KQI $e iA Cw Dw Bw Ow $.
   KgI $a iA ( 4w CQ Cw ) ( 4w DQ Dw ) Bw Ow $. $}
${ OgI $e iA CQ DQ Bw Ow $.
   OwI $e iA Cw Dw Bw Ow $.
   PAI $a iA ( SwE CQ Cw ) ( SwE DQ Dw ) Bw Ow $. $}
${ NwM $e zw CQ $.
   OAM $a zw ( Tw Bw CQ ) $. $}
rgM $a #Pattern ( rwM Bw CQ Kw Cw ) $.
tAM $a #Pattern ( tQM Bw CQ ) $.
0gM $a #Pattern ( 0wM Bw CQ Cw DQ ) $.
HwQ $a #Pattern ( IAQ Bw CQ ) $.
IwQ $a #Pattern ( JAQ Bw ) $.
KwQ $a #Pattern ( LAQ Bw CQ Cw ) $.
${ $d xX y $.
   $d y ph6 $.
   OAQ $e iA Bw DQ Ew Ow $.
   OQQ $e iA CQ Dw Ew Ow $.
   OgQ $e iA Cw EQ Ew Ow $.
   OwQ $a iA ( rwM Bw CQ LQ Cw ) ( rwM DQ Dw LQ EQ ) Ew Ow $. $}
${ QAQ $e iA Bw Cw Dw Ow $.
   QQQ $e iA CQ DQ Dw Ow $.
   QgQ $a iA ( tQM Bw CQ ) ( tQM Cw DQ ) Dw Ow $. $}
${ XgQ $e iA Bw Dw Fw Ow $.
   XwQ $e iA CQ EQ Fw Ow $.
   YAQ $e iA Cw Ew Fw Ow $.
   YQQ $e iA DQ FQ Fw Ow $.
   YgQ $a iA ( 0wM Bw CQ Cw DQ ) ( 0wM Dw EQ Ew FQ ) Fw Ow $. $}
${ $d z ph0 $.
   $d z ph1 $.
   $d z ph2 $.
   $d z y $.
   $d z x $.
   $d z th1 $.
   $d z th2 $.
   $d x ph0 $.
   $d y th0 $.
   lAY $e zw ( Tw GQ ( Uw Kw ( PgE Kw Bw ) ) ) $.
   lQY $e zw ( Tw ( 4w GQ Gw ) CQ ) $.
   lgY $e iA ( Tw HQ Cw ) ( Tw Gw CQ ) Bw LQ $.
   lwY $e iA ( Tw Hw DQ ) ( Tw Gw CQ ) Lw LQ $.
   mAY $a zw ( Tw ( 4w GQ HQ ) Cw ) $. $}
${ $d x ph0 $.
   $d x ph1 $.
   vwY $e zw ( Tw GQ ( SwE CQ Bw ) ) $.
   wAY $e zw ( Tw GQ ( tQM cwE ( rwM Bw cwE Kw ( 0wM Bw cwE Kw CQ ) ) ) ) $.
   wQY $a zw ( Tw GQ ( Uw Kw ( PgE Kw CQ ) ) ) $. $}
mgg $a #Pattern mwg $.
nQg $f #Variable ngg $.
nwg $f #Pattern oAg $.
pQg $a #Pattern pgg $.
qgg $f #Pattern qwg $.
rgg $a #Pattern ( rwg oAg qwg ) $.
sQg $f #Pattern sgg $.
swg $f #Pattern tAg $.
tQg $f #Pattern tgg $.
${ uQg $e iA qwg tAg oAg ngg $.
   ugg $e iA sgg tgg oAg ngg $.
   uwg $a iA ( rwg qwg sgg ) ( rwg tAg tgg ) oAg ngg $. $}
wQg $a zw ( Tw ( 4w ( SwE oAg pgg ) ( SwE qwg mwg ) ) ( SwE ( rwg oAg qwg ) mwg ) ) $.
xAg $a #Pattern xQg $.
2Qg $f #ElementVariable 2gg $.
5wg $f #ElementVariable 6Ag $.
6wg $f #ElementVariable 7Ag $.
WQk $a #Pattern Wgk $.
egk $a #Pattern ewk $.
hQk $a #Pattern hgk $.
rQk $a #Pattern rgk $.
Nw0 $a #Pattern ( OA0 oAg ) $.
RA0 $a #Pattern ( RQ0 oAg qwg ) $.
UQ0 $a zw ( Tw ( 4w ( SwE oAg mwg ) ( SwE qwg mwg ) ) ( SwE ( RQ0 oAg qwg ) pgg ) ) $.
yxA $a #Pattern ( zBA oAg qwg ) $.
CxE $a #Pattern ( DBE oAg qwg ) $.
WxI $a #Pattern ( XBI oAg qwg ) $.
jxM $a #Pattern ( kBM oAg qwg ) $.
qhs $a #Pattern ( qxs oAg ) $.
8Rw $a #Pattern 8hw $.
Eh0 $a #Pattern Ex0 $.
nB4 $f #ElementVariable nR4 $.
vB4 $a #Pattern vR4 $.
wx4 $a #Pattern xB4 $.
0R4 $a #Pattern 0h4 $.
2B4 $a #Pattern 2R4 $.
7R4 $a #Pattern 7h4 $.
JB8 $a zw ( Tw IQE ( SwE xQg mwg ) ) $.
VB8 $a zw ( Tw IQE ( SwE ( rwg ( LAQ hgk pgg ( qxs ( XBI ( IAQ ewk xB4 ) ( LAQ rgk Wgk ( IAQ rgk 8hw ) ) ) ) ) xQg ) mwg ) ) $.
VR8 $a zw ( Tw IQE ( SwE ( rwg ( LAQ hgk pgg ( qxs ( kBM ( kBM ( XBI ( IAQ ewk vR4 ) ( DBE ( LAQ ewk Wgk ( IAQ ewk vR4 ) ) ( LAQ ewk Wgk ( IAQ ewk 2R4 ) ) ) ) ( XBI ( IAQ ewk 7h4 ) ( zBA ( LAQ ewk Wgk ( IAQ ewk 7h4 ) ) ( LAQ ewk Wgk ( IAQ ewk 2R4 ) ) ) ) ) ( XBI ( IAQ ewk xB4 ) ( LAQ rgk Wgk ( IAQ rgk Ex0 ) ) ) ) ) ) xQg ) mwg ) ) $.
Wh8 $a #Pattern 2gg $.
6h8 $a #Pattern nR4 $.
9h8 $a zw ( Tw ( 4w ( JAQ 2gg ) IQE ) ( 4w ( JAQ 2gg ) IQE ) ) $.
-CA $a #Pattern 7Ag $.
BCE $a #Pattern 6Ag $.
9yM $a iA 2gg 2gg nR4 7Ag $.
pyQ $a #Pattern ( 4w ( JAQ 2gg ) ( 4w ( SwE 7Ag mwg ) IQE ) ) $.
5yQ $a zw ( Tw ( 4w ( 4w ( JAQ 2gg ) IQE ) ( 4w ( SwE 7Ag mwg ) IQE ) ) ( 4w ( JAQ 2gg ) ( 4w ( SwE 7Ag mwg ) IQE ) ) ) $.
6yQ $a iA mwg mwg nR4 7Ag $.
7SQ $a iA ( 4w ( SwE nR4 mwg ) IQE ) ( 4w ( SwE 7Ag mwg ) IQE ) nR4 7Ag $.
7iQ $a zw ( Tw ( 4w ( JAQ 2gg ) IQE ) ( SwE xQg mwg ) ) $.
VSw $a zw ( Tw ( 4w ( JAQ 2gg ) IQE ) ( SwE ( LAQ hgk pgg ( qxs ( kBM ( kBM ( XBI ( IAQ ewk vR4 ) ( DBE ( LAQ ewk Wgk ( IAQ ewk vR4 ) ) ( LAQ ewk Wgk ( IAQ ewk 2R4 ) ) ) ) ( XBI ( IAQ ewk 7h4 ) ( zBA ( LAQ ewk Wgk ( IAQ ewk 7h4 ) ) ( LAQ ewk Wgk ( IAQ ewk 2R4 ) ) ) ) ) ( XBI ( IAQ ewk xB4 ) ( LAQ rgk Wgk ( IAQ rgk Ex0 ) ) ) ) ) ) pgg ) ) $.
Wyw $a zw ( Tw IQE ( tQM cwE ( rwM mwg cwE 6Ag ( 0wM mwg cwE 6Ag ( rwg ( RQ0 ( rwg ( LAQ hgk pgg ( qxs ( XBI ( IAQ ewk xB4 ) ( LAQ rgk Wgk ( IAQ rgk 8hw ) ) ) ) ) xQg ) ( rwg ( LAQ hgk pgg ( qxs ( kBM ( kBM ( XBI ( IAQ ewk vR4 ) ( DBE ( LAQ ewk Wgk ( IAQ ewk vR4 ) ) ( LAQ ewk Wgk ( IAQ ewk 2R4 ) ) ) ) ( XBI ( IAQ ewk 7h4 ) ( zBA ( LAQ ewk Wgk ( IAQ ewk 7h4 ) ) ( LAQ ewk Wgk ( IAQ ewk 2R4 ) ) ) ) ) ( XBI ( IAQ ewk xB4 ) ( LAQ rgk Wgk ( IAQ rgk Ex0 ) ) ) ) ) ) xQg ) ) xQg ) ) ) ) ) $.
HC0 $a zw ( Tw ( 4w ( JAQ 2gg ) IQE ) ( SwE ( rwg ( LAQ hgk pgg ( qxs ( XBI ( IAQ ewk xB4 ) ( LAQ rgk Wgk ( IAQ rgk 8hw ) ) ) ) ) xQg ) mwg ) ) $.
zy4 $a #Pattern ( 0wM mwg 2gg 6Ag ( rwg ( OA0 ( rwg ( LAQ rgk pgg ( IAQ rgk 0h4 ) ) xQg ) ) 7Ag ) ) $.
0S4 $a zw ( Tw ( 4w ( JAQ 2gg ) ( 4w ( SwE 7Ag mwg ) IQE ) ) ( tQM 2gg ( rwM mwg 2gg 6Ag ( 0wM mwg 2gg 6Ag ( rwg ( OA0 ( rwg ( LAQ rgk pgg ( IAQ rgk 0h4 ) ) xQg ) ) 7Ag ) ) ) ) ) $.
0i4 $a #Pattern ( 0wM mwg 2gg 6Ag ( rwg ( OA0 ( rwg ( LAQ rgk pgg ( IAQ rgk 0h4 ) ) xQg ) ) nR4 ) ) $.
0y4 $a iA ( 0wM mwg 2gg 6Ag ( rwg ( OA0 ( rwg ( LAQ rgk pgg ( IAQ rgk 0h4 ) ) xQg ) ) nR4 ) ) ( 0wM mwg 2gg 6Ag ( rwg ( OA0 ( rwg ( LAQ rgk pgg ( IAQ rgk 0h4 ) ) xQg ) ) 7Ag ) ) nR4 7Ag $.
${ 1C4 $p zw ( Tw ( 4w ( JAQ 2gg ) IQE ) ( tQM 2gg ( rwM mwg 2gg 6Ag ( 0wM mwg 2gg 6Ag ( rwg ( OA0 ( rwg ( LAQ rgk pgg ( IAQ rgk 0h4 ) ) xQg ) ) ( rwg ( RQ0 ( rwg ( LAQ hgk pgg ( qxs ( XBI ( IAQ ewk xB4 ) ( LAQ rgk Wgk ( IAQ rgk 8hw ) ) ) ) ) xQg ) ( rwg ( LAQ hgk pgg ( qxs ( kBM ( kBM ( XBI ( IAQ ewk vR4 ) ( DBE ( LAQ ewk Wgk ( IAQ ewk vR4 ) ) ( LAQ ewk Wgk ( IAQ ewk 2R4 ) ) ) ) ( XBI ( IAQ ewk 7h4 ) ( zBA ( LAQ ewk Wgk ( IAQ ewk 7h4 ) ) ( LAQ ewk Wgk ( IAQ ewk 2R4 ) ) ) ) ) ( XBI ( IAQ ewk xB4 ) ( LAQ rgk Wgk ( IAQ rgk Ex0 ) ) ) ) ) ) xQg ) ) xQg ) ) ) ) ) ) $=
  ( 6wg nB4 IAE 4g pQg egk HwQ rQk WQk KwQ WxI xAg rgg mgg SgE wgE mAE IQI Wh8
  IwQ hQk wx4 8Rw qhs vB4 2B4 CxE 7R4 yxA jxM Eh0 RA0 BCE 0R4 Nw0 0gM rgM Ug SA
  tAM 9h8 HC0 VSw 7iQ wQg UQ0 nAE OAM zy4 0i4 -CA 6h8 PQE VB8 VR8 JB8 Wyw jg lA
  wQY pyQ 5yQ 0S4 PAI KgI uwg YgQ OwQ QgQ 7SQ 9yM 6yQ 0y4 mAY ) AUAZUBEFZWRUCGH
  UDIZJKJUEILMUFLNOZUCGHUGIZHKXALHKHUHILZUIMHUJIZHKXCLXBUKMULWSJKJUMILMULUFLZNO
  ZUNZNOZPQZEFZFWQPWQPWQBUOZJGJUPILNOUQZXGOZURZBUSZVBZWRWRXIAVCWRXHEWRXFGQZNPQZ
  FZXHWRXPXQWRWTPQZXEPQZFZXPWRXSXTAVDWRXDGQZXQFXTWRYBXQAVEAVFZRXDNVGSRWTXEVHZSY
  CRXFNVGZSWREVIVJZRRXGWQPWQABCVKZBUSZVBZXOWQPWQABDVLZBUSZVBZWRCVMZPQZEFZXIDVNZ
  PQEFZBCDWREXJXGVOBUTYFPXGEBEXRXHEXPXQEYAXPEXSXTVPVQRYDSVRRYESBVSWBSWRYOFACWCY
  IACWDABCWESXGXIXOYOYICVAZXGXHEYNEYRXGXGPYMPYRXGYRVTZPXGYRTZWFEXGYRTWGWQXNWQYH
  XGYRWQXGYRTZPWQXMPWQYGXGBYRYTUUAPWQXJXLPWQXJXKYMOXGYRYTUUAXJXGYRTYRXGXKXGXKYM
  XKXGYRTYSWHWIWJWKWAYPYQYLYOYIYRCDWLWQYKWQYHYPYRACDWMZPWQYJPWQYGYPBYRCDWNUUBAB
  CDWOWJWKWAWPS $. $}
