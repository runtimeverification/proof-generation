$c #SetVariable iA ) pwk #ElementVariable #Symbol #Variable #Pattern ( $.
$v Ow CQ xX Bw Kw ph0 5Qg nR4 $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Kg $f #ElementVariable Kw $.
Og $f #Variable Ow $.
SA $a #Variable Kw $.
${ $d xX ph0 $.
   IQI $a iA Bw Bw CQ Ow $. $}
5Ag $f #ElementVariable 5Qg $.
pgk $a #Pattern pwk $.
nB4 $f #ElementVariable nR4 $.
6h8 $a #Pattern nR4 $.
${ -io $p iA pwk pwk nR4 5Qg $=
  ( pgk 6h8 SA IQI ) CBDAEF $. $}
