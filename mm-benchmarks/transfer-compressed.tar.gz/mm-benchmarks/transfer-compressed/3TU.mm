$c Uw PgE Tw #Symbol 1CA cwE zw JAQ rgk 3gk #Pattern ( 0wM LAQ tQM IAQ #Variable SwE #SetVariable 4w rwM #ElementVariable IQE ) $.
$v yhs CQ Bw Kw ph1 ph0 Cw 2gg GQ x $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Cg $f #Pattern Cw $.
GA $f #Pattern GQ $.
Kg $f #ElementVariable Kw $.
Ug $a #Pattern ( Uw Kw Bw ) $.
4g $a #Pattern ( 4w Bw CQ ) $.
IAE $a #Pattern IQE $.
PQE $a #Pattern ( PgE Bw CQ ) $.
${ lgE $e zw ( Tw Bw CQ ) $.
   lwE $e zw ( Tw CQ Cw ) $.
   mAE $a zw ( Tw Bw Cw ) $. $}
nAE $a zw IQE $.
${ NwM $e zw CQ $.
   OAM $a zw ( Tw Bw CQ ) $. $}
HwQ $a #Pattern ( IAQ Bw CQ ) $.
IwQ $a #Pattern ( JAQ Bw ) $.
KwQ $a #Pattern ( LAQ Bw CQ Cw ) $.
${ $d x ph0 $.
   $d x ph1 $.
   vwY $e zw ( Tw GQ ( SwE CQ Bw ) ) $.
   wAY $e zw ( Tw GQ ( tQM cwE ( rwM Bw cwE Kw ( 0wM Bw cwE Kw CQ ) ) ) ) $.
   wQY $a zw ( Tw GQ ( Uw Kw ( PgE Kw CQ ) ) ) $. $}
2Qg $f #ElementVariable 2gg $.
rQk $a #Pattern rgk $.
3Qk $a #Pattern 3gk $.
yRs $f #ElementVariable yhs $.
Wh8 $a #Pattern 2gg $.
0yA $a #Pattern 1CA $.
7SA $a #Pattern yhs $.
2zU $a zw ( Tw IQE ( tQM cwE ( rwM 3gk cwE yhs ( 0wM 3gk cwE yhs ( LAQ rgk 3gk ( IAQ rgk 1CA ) ) ) ) ) ) $.
3DU $a zw ( Tw IQE ( SwE ( LAQ rgk 3gk ( IAQ rgk 1CA ) ) 3gk ) ) $.
${ 3TU $p zw ( Tw ( 4w ( JAQ 2gg ) IQE ) ( Uw yhs ( PgE yhs ( LAQ rgk 3gk ( IAQ rgk 1CA ) ) ) ) ) $=
  ( Wh8 IwQ IAE 4g 7SA rQk 3Qk 0yA HwQ KwQ PQE Ug nAE OAM 3DU 2zU wQY mAE ) ACD
  EFZEBGHIHJKLZMBNUAEOPIUBEBQBRST $. $}
