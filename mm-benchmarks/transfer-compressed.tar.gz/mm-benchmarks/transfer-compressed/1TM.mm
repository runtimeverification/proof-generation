$c Uw zBA 2R4 PgE Tw #Symbol 7h4 zw JAQ pgg #Pattern ( 0wM LAQ ewk tQM IAQ Wgk #Variable SwE #SetVariable iA 4w rwM #ElementVariable IQE ) $.
$v th1 yhs Fw CQ Bw Cw 2gg FQ z ph2 Ew ph0 x Lw LQ Ow ph6 qwg DQ ph1 EQ y th2 Dw HQ xX Gw th0 zBs Hw Kw oAg GQ nR4 $.
$d z y $.
$d z x $.
$d y x $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Cg $f #Pattern Cw $.
DA $f #Pattern DQ $.
Dg $f #Pattern Dw $.
EA $f #Pattern EQ $.
Eg $f #Pattern Ew $.
FA $f #Pattern FQ $.
Fg $f #Pattern Fw $.
GA $f #Pattern GQ $.
Gg $f #Pattern Gw $.
HA $f #Pattern HQ $.
Hg $f #Pattern Hw $.
Kg $f #ElementVariable Kw $.
LA $f #ElementVariable LQ $.
Lg $f #ElementVariable Lw $.
Og $f #Variable Ow $.
SA $a #Variable Kw $.
jg $a iA Bw Ow Bw Ow $.
${ kg $e iA CQ DQ Bw Ow $.
   kw $e iA Cw Dw Bw Ow $.
   lA $a iA ( Tw CQ Cw ) ( Tw DQ Dw ) Bw Ow $. $}
4g $a #Pattern ( 4w Bw CQ ) $.
IAE $a #Pattern IQE $.
SgE $a #Pattern ( SwE Bw CQ ) $.
${ lgE $e zw ( Tw Bw CQ ) $.
   lwE $e zw ( Tw CQ Cw ) $.
   mAE $a zw ( Tw Bw Cw ) $. $}
nAE $a zw IQE $.
${ wAE $e zw ( Tw Bw CQ ) $.
   wQE $e zw ( Tw Bw Cw ) $.
   wgE $a zw ( Tw Bw ( 4w CQ Cw ) ) $. $}
${ $d xX ph0 $.
   IQI $a iA Bw Bw CQ Ow $. $}
${ KAI $e iA CQ DQ Bw Ow $.
   KQI $e iA Cw Dw Bw Ow $.
   KgI $a iA ( 4w CQ Cw ) ( 4w DQ Dw ) Bw Ow $. $}
${ OgI $e iA CQ DQ Bw Ow $.
   OwI $e iA Cw Dw Bw Ow $.
   PAI $a iA ( SwE CQ Cw ) ( SwE DQ Dw ) Bw Ow $. $}
${ NwM $e zw CQ $.
   OAM $a zw ( Tw Bw CQ ) $. $}
rgM $a #Pattern ( rwM Bw CQ Kw Cw ) $.
tAM $a #Pattern ( tQM Bw CQ ) $.
0gM $a #Pattern ( 0wM Bw CQ Cw DQ ) $.
HwQ $a #Pattern ( IAQ Bw CQ ) $.
IwQ $a #Pattern ( JAQ Bw ) $.
KwQ $a #Pattern ( LAQ Bw CQ Cw ) $.
${ $d xX y $.
   $d y ph6 $.
   OAQ $e iA Bw DQ Ew Ow $.
   OQQ $e iA CQ Dw Ew Ow $.
   OgQ $e iA Cw EQ Ew Ow $.
   OwQ $a iA ( rwM Bw CQ LQ Cw ) ( rwM DQ Dw LQ EQ ) Ew Ow $. $}
${ QAQ $e iA Bw Cw Dw Ow $.
   QQQ $e iA CQ DQ Dw Ow $.
   QgQ $a iA ( tQM Bw CQ ) ( tQM Cw DQ ) Dw Ow $. $}
${ XgQ $e iA Bw Dw Fw Ow $.
   XwQ $e iA CQ EQ Fw Ow $.
   YAQ $e iA Cw Ew Fw Ow $.
   YQQ $e iA DQ FQ Fw Ow $.
   YgQ $a iA ( 0wM Bw CQ Cw DQ ) ( 0wM Dw EQ Ew FQ ) Fw Ow $. $}
${ lAQ $e iA Bw DQ Ew Ow $.
   lQQ $e iA CQ Dw Ew Ow $.
   lgQ $e iA Cw EQ Ew Ow $.
   lwQ $a iA ( LAQ Bw CQ Cw ) ( LAQ DQ Dw EQ ) Ew Ow $. $}
${ $d z ph0 $.
   $d z ph1 $.
   $d z ph2 $.
   $d z y $.
   $d z x $.
   $d z th1 $.
   $d z th2 $.
   $d x ph0 $.
   $d y th0 $.
   lAY $e zw ( Tw GQ ( Uw Kw ( PgE Kw Bw ) ) ) $.
   lQY $e zw ( Tw ( 4w GQ Gw ) CQ ) $.
   lgY $e iA ( Tw HQ Cw ) ( Tw Gw CQ ) Bw LQ $.
   lwY $e iA ( Tw Hw DQ ) ( Tw Gw CQ ) Lw LQ $.
   mAY $a zw ( Tw ( 4w GQ HQ ) Cw ) $. $}
nwg $f #Pattern oAg $.
pQg $a #Pattern pgg $.
qgg $f #Pattern qwg $.
2Qg $f #ElementVariable 2gg $.
WQk $a #Pattern Wgk $.
egk $a #Pattern ewk $.
yxA $a #Pattern ( zBA oAg qwg ) $.
yRs $f #ElementVariable yhs $.
yxs $f #ElementVariable zBs $.
nB4 $f #ElementVariable nR4 $.
2B4 $a #Pattern 2R4 $.
7R4 $a #Pattern 7h4 $.
Wh8 $a #Pattern 2gg $.
6h8 $a #Pattern nR4 $.
9h8 $a zw ( Tw ( 4w ( JAQ 2gg ) IQE ) ( 4w ( JAQ 2gg ) IQE ) ) $.
7SA $a #Pattern yhs $.
JiE $a #Pattern zBs $.
NSE $a iA 2gg 2gg nR4 zBs $.
jiM $a zw ( Tw ( 4w ( JAQ 2gg ) IQE ) ( Uw yhs ( PgE yhs ( zBA ( LAQ ewk Wgk ( IAQ ewk 7h4 ) ) ( LAQ ewk Wgk ( IAQ ewk 2R4 ) ) ) ) ) ) $.
kSM $a zw ( Tw ( 4w ( JAQ 2gg ) IQE ) ( SwE ( zBA ( LAQ ewk Wgk ( IAQ ewk 7h4 ) ) ( LAQ ewk Wgk ( IAQ ewk 2R4 ) ) ) Wgk ) ) $.
CTI $a #Pattern ( 0wM pgg 2gg yhs ( LAQ Wgk pgg zBs ) ) $.
CjI $a zw ( Tw ( 4w ( 4w ( JAQ 2gg ) IQE ) ( 4w ( SwE zBs Wgk ) IQE ) ) ( tQM 2gg ( rwM pgg 2gg yhs ( 0wM pgg 2gg yhs ( LAQ Wgk pgg zBs ) ) ) ) ) $.
CzI $a #Pattern ( 0wM pgg 2gg yhs ( LAQ Wgk pgg nR4 ) ) $.
DTI $a iA ( 4w ( SwE nR4 Wgk ) IQE ) ( 4w ( SwE zBs Wgk ) IQE ) nR4 zBs $.
EDI $a iA ( rwM pgg 2gg yhs ( 0wM pgg 2gg yhs ( LAQ Wgk pgg nR4 ) ) ) ( rwM pgg 2gg yhs ( 0wM pgg 2gg yhs ( LAQ Wgk pgg zBs ) ) ) nR4 zBs $.
${ 1TM $p zw ( Tw ( 4w ( JAQ 2gg ) IQE ) ( tQM 2gg ( rwM pgg 2gg yhs ( 0wM pgg 2gg yhs ( LAQ Wgk pgg ( zBA ( LAQ ewk Wgk ( IAQ ewk 7h4 ) ) ( LAQ ewk Wgk ( IAQ ewk 2R4 ) ) ) ) ) ) ) ) $=
  ( yxs nB4 Wh8 IwQ IAE 4g egk WQk HwQ KwQ SgE pQg rgM tAM wgE IQI QgQ lA SA jg
  7R4 2B4 yxA 7SA 0gM 9h8 kSM nAE OAM CTI CzI JiE 6h8 jiM CjI PAI KgI lwQ YgQ
  OwQ DTI NSE EDI mAY mAE ) AEZFGHZVIIJIUCKLIJIUDKLUEZJMZGHZHVHNVHNVHBUFZJNVJLZ
  UGZBOZPZVIVIVLAUHVIVKGAUIVIGUJUKQQVJVHNVHABCULZBOZPZVQVHNVHABDUMBOZPZVICUNZJM
  ZGHZVLDUOZJMGHZBCDABUPABCUQVJVLVQWEVTCUAZVJVKGWDGWHVJVJJWCJWHVJWHUBZJVJWHRZUR
  GVJWHRUSVHVPVHVSVJWHVHVJWHRZNVHVONVHVRVJBWHNVJWHRZWKNVHVMVNNVHVMJNWCLVJWHWLWK
  VMVJWHRJNVJJNWCVJWHWJWLWIUTVAVBSTWFWGWBWEVTWHCDVCVHWAVHVSWFWHACDVDABCDVESTVFV
  G $. $}
