$c Wgk #Symbol #Variable SwE #SetVariable iA 4w #ElementVariable IQE #Pattern ) ( $.
$v Ow CQ 3gg DQ Bw Kw Cw nR4 Dw $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Cg $f #Pattern Cw $.
DA $f #Pattern DQ $.
Dg $f #Pattern Dw $.
Kg $f #ElementVariable Kw $.
Og $f #Variable Ow $.
SA $a #Variable Kw $.
IAE $a #Pattern IQE $.
SgE $a #Pattern ( SwE Bw CQ ) $.
${ KAI $e iA CQ DQ Bw Ow $.
   KQI $e iA Cw Dw Bw Ow $.
   KgI $a iA ( 4w CQ Cw ) ( 4w DQ Dw ) Bw Ow $. $}
3Qg $f #ElementVariable 3gg $.
WQk $a #Pattern Wgk $.
nB4 $f #ElementVariable nR4 $.
6h8 $a #Pattern nR4 $.
XiU $a #Pattern 3gg $.
jyU $a iA IQE IQE nR4 3gg $.
zzE $a iA ( SwE nR4 Wgk ) ( SwE 3gg Wgk ) nR4 3gg $.
${ 0DE $p iA ( 4w ( SwE nR4 Wgk ) IQE ) ( 4w ( SwE 3gg Wgk ) IQE ) nR4 3gg $=
  ( 6h8 WQk SgE IAE XiU SA zzE jyU KgI ) BCZLDEFAGDEFAHABIABJK $. $}
