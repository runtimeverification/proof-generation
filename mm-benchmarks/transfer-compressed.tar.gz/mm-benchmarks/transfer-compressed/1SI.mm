$c 0wM LAQ ewk Wgk #Symbol #Variable #SetVariable iA rwM #ElementVariable #Pattern ) ( $.
$v yhs Ow ph6 CQ xX zBs DQ Ew Bw Kw Cw 2gg nR4 EQ y Dw LQ $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Cg $f #Pattern Cw $.
DA $f #Pattern DQ $.
Dg $f #Pattern Dw $.
EA $f #Pattern EQ $.
Eg $f #Pattern Ew $.
Kg $f #ElementVariable Kw $.
LA $f #ElementVariable LQ $.
Og $f #Variable Ow $.
SA $a #Variable Kw $.
${ $d xX y $.
   $d y ph6 $.
   OAQ $e iA Bw DQ Ew Ow $.
   OQQ $e iA CQ Dw Ew Ow $.
   OgQ $e iA Cw EQ Ew Ow $.
   OwQ $a iA ( rwM Bw CQ LQ Cw ) ( rwM DQ Dw LQ EQ ) Ew Ow $. $}
2Qg $f #ElementVariable 2gg $.
WQk $a #Pattern Wgk $.
yRs $f #ElementVariable yhs $.
yxs $f #ElementVariable zBs $.
nB4 $f #ElementVariable nR4 $.
Wh8 $a #Pattern 2gg $.
6h8 $a #Pattern nR4 $.
NSE $a iA 2gg 2gg nR4 zBs $.
MCI $a iA Wgk Wgk nR4 zBs $.
yiI $a #Pattern ( 0wM Wgk 2gg yhs ( LAQ ewk Wgk zBs ) ) $.
zCI $a #Pattern ( 0wM Wgk 2gg yhs ( LAQ ewk Wgk nR4 ) ) $.
1CI $a iA ( 0wM Wgk 2gg yhs ( LAQ ewk Wgk nR4 ) ) ( 0wM Wgk 2gg yhs ( LAQ ewk Wgk zBs ) ) nR4 zBs $.
${ 1SI $p iA ( rwM Wgk 2gg yhs ( 0wM Wgk 2gg yhs ( LAQ ewk Wgk nR4 ) ) ) ( rwM Wgk 2gg yhs ( 0wM Wgk 2gg yhs ( LAQ ewk Wgk zBs ) ) ) nR4 zBs $=
  ( WQk Wh8 zCI yiI 6h8 SA MCI NSE 1CI OwQ ) EAFZABDGEOABCHDIBCJCDKACDLABCDMN
  $. $}
