$c LAQ #Symbol #Variable #SetVariable iA pwk #ElementVariable .gk pgg #Pattern ) ( $.
$v Ow CQ DQ Ew Bw Kw Cw nR4 EQ mh4 Dw $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Cg $f #Pattern Cw $.
DA $f #Pattern DQ $.
Dg $f #Pattern Dw $.
EA $f #Pattern EQ $.
Eg $f #Pattern Ew $.
Kg $f #ElementVariable Kw $.
Og $f #Variable Ow $.
SA $a #Variable Kw $.
KwQ $a #Pattern ( LAQ Bw CQ Cw ) $.
${ lAQ $e iA Bw DQ Ew Ow $.
   lQQ $e iA CQ Dw Ew Ow $.
   lgQ $e iA Cw EQ Ew Ow $.
   lwQ $a iA ( LAQ Bw CQ Cw ) ( LAQ DQ Dw EQ ) Ew Ow $. $}
pQg $a #Pattern pgg $.
pgk $a #Pattern pwk $.
.Qk $a #Pattern .gk $.
mR4 $f #ElementVariable mh4 $.
nB4 $f #ElementVariable nR4 $.
YR8 $a #Pattern mh4 $.
6h8 $a #Pattern nR4 $.
8R8 $a iA pgg pgg nR4 mh4 $.
1zA $a iA pwk pwk nR4 mh4 $.
2DA $a iA ( LAQ .gk pwk nR4 ) ( LAQ .gk pwk mh4 ) nR4 mh4 $.
${ 2TA $p iA ( LAQ pwk pgg ( LAQ .gk pwk nR4 ) ) ( LAQ pwk pgg ( LAQ .gk pwk mh4 ) ) nR4 mh4 $=
  ( pgk pQg .Qk 6h8 KwQ YR8 SA 1zA 8R8 2DA lwQ ) CDECBFZGCDECAHGNAIABJABKABLM
  $. $}
