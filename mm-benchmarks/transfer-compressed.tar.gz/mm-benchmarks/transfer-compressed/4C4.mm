$c ewk IAQ Tw #Symbol #Variable SwE #SetVariable zw vR4 4w YQk #ElementVariable IQE #Pattern ) ( $.
$v Cw CQ -Bw Bw $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Cg $f #Pattern Cw $.
4g $a #Pattern ( 4w Bw CQ ) $.
IAE $a #Pattern IQE $.
SgE $a #Pattern ( SwE Bw CQ ) $.
nAE $a zw IQE $.
${ wAE $e zw ( Tw Bw CQ ) $.
   wQE $e zw ( Tw Bw Cw ) $.
   wgE $a zw ( Tw Bw ( 4w CQ Cw ) ) $. $}
${ NwM $e zw CQ $.
   OAM $a zw ( Tw Bw CQ ) $. $}
HwQ $a #Pattern ( IAQ Bw CQ ) $.
YAk $a #Pattern YQk $.
egk $a #Pattern ewk $.
.xw $f #ElementVariable -Bw $.
vB4 $a #Pattern vR4 $.
yyg $a #Pattern -Bw $.
3y4 $a zw ( Tw ( 4w ( SwE -Bw YQk ) IQE ) ( SwE ( IAQ ewk vR4 ) ewk ) ) $.
${ 4C4 $p zw ( Tw ( 4w ( SwE -Bw YQk ) IQE ) ( 4w ( SwE ( IAQ ewk vR4 ) ewk ) IQE ) ) $=
  ( yyg YAk SgE IAE 4g egk vB4 HwQ 3y4 nAE OAM wgE ) ABCDEFZGHIGDEAJNEKLM $. $}
