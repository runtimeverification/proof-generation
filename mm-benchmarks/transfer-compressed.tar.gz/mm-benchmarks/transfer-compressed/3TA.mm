$c LAQ IAQ Tw #Symbol #Variable SwE #SetVariable zw 4w pwk JAQ #ElementVariable IQE .gk Px0 pgg #Pattern ) ( $.
$v CQ qwg Bw oAg Cw sgg $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Cg $f #Pattern Cw $.
4g $a #Pattern ( 4w Bw CQ ) $.
IAE $a #Pattern IQE $.
SgE $a #Pattern ( SwE Bw CQ ) $.
${ lgE $e zw ( Tw Bw CQ ) $.
   lwE $e zw ( Tw CQ Cw ) $.
   mAE $a zw ( Tw Bw Cw ) $. $}
${ wAE $e zw ( Tw Bw CQ ) $.
   wQE $e zw ( Tw Bw Cw ) $.
   wgE $a zw ( Tw Bw ( 4w CQ Cw ) ) $. $}
HwQ $a #Pattern ( IAQ Bw CQ ) $.
IwQ $a #Pattern ( JAQ Bw ) $.
KwQ $a #Pattern ( LAQ Bw CQ Cw ) $.
nwg $f #Pattern oAg $.
pQg $a #Pattern pgg $.
qgg $f #Pattern qwg $.
sQg $f #Pattern sgg $.
.gg $a zw ( Tw ( 4w ( 4w ( JAQ oAg ) ( JAQ qwg ) ) ( SwE sgg oAg ) ) ( SwE ( LAQ oAg qwg sgg ) qwg ) ) $.
pgk $a #Pattern pwk $.
.Qk $a #Pattern .gk $.
Ph0 $a #Pattern Px0 $.
.x4 $a zw ( Tw IQE ( JAQ pgg ) ) $.
UB8 $a zw ( Tw IQE ( JAQ pwk ) ) $.
cCA $a zw ( Tw IQE ( SwE ( LAQ .gk pwk ( IAQ .gk Px0 ) ) pwk ) ) $.
${ 3TA $p zw ( Tw IQE ( SwE ( LAQ pwk pgg ( LAQ .gk pwk ( IAQ .gk Px0 ) ) ) pgg ) ) $=
  ( IAE pgk IwQ pQg 4g .Qk Ph0 HwQ KwQ SgE UB8 .x4 wgE cCA .gg mAE ) ABCZDCZEZF
  BFGHIZBJZEBDTIDJASUAAQRKLMNMBDTOP $. $}
