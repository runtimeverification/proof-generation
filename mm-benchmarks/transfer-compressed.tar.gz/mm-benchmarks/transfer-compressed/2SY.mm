$c #Symbol #Variable SwE #SetVariable iA YQk #ElementVariable #Pattern ) ( $.
$v Ow CQ DQ Bw Kw Cw nR4 pxw Dw $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Cg $f #Pattern Cw $.
DA $f #Pattern DQ $.
Dg $f #Pattern Dw $.
Kg $f #ElementVariable Kw $.
Og $f #Variable Ow $.
SA $a #Variable Kw $.
jg $a iA Bw Ow Bw Ow $.
${ OgI $e iA CQ DQ Bw Ow $.
   OwI $e iA Cw Dw Bw Ow $.
   PAI $a iA ( SwE CQ Cw ) ( SwE DQ Dw ) Bw Ow $. $}
YAk $a #Pattern YQk $.
phw $f #ElementVariable pxw $.
nB4 $f #ElementVariable nR4 $.
6h8 $a #Pattern nR4 $.
sCY $a #Pattern pxw $.
2CY $a iA YQk YQk nR4 pxw $.
${ 2SY $p iA ( SwE nR4 YQk ) ( SwE pxw YQk ) nR4 pxw $=
  ( 6h8 YAk sCY SA jg 2CY PAI ) BCZJDAEDAFZJKGABHI $. $}
