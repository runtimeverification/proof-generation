$c 4B4 Tw #Symbol zw .gk pgg rgk #Pattern ( rwg LAQ IAQ #Variable SwE #SetVariable #ElementVariable IQE mwg xQg ) Vhc $.
$v oAg Cw CQ qwg Bw $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Cg $f #Pattern Cw $.
IAE $a #Pattern IQE $.
SgE $a #Pattern ( SwE Bw CQ ) $.
${ lgE $e zw ( Tw Bw CQ ) $.
   lwE $e zw ( Tw CQ Cw ) $.
   mAE $a zw ( Tw Bw Cw ) $. $}
HwQ $a #Pattern ( IAQ Bw CQ ) $.
KwQ $a #Pattern ( LAQ Bw CQ Cw ) $.
mgg $a #Pattern mwg $.
nwg $f #Pattern oAg $.
pQg $a #Pattern pgg $.
qgg $f #Pattern qwg $.
rgg $a #Pattern ( rwg oAg qwg ) $.
xAg $a #Pattern xQg $.
rQk $a #Pattern rgk $.
.Qk $a #Pattern .gk $.
VRc $a #Pattern ( Vhc oAg ) $.
Xxc $a zw ( Tw ( SwE oAg mwg ) ( SwE ( Vhc oAg ) .gk ) ) $.
3x4 $a #Pattern 4B4 $.
yCA $a zw ( Tw IQE ( SwE ( rwg ( LAQ rgk pgg ( IAQ rgk 4B4 ) ) xQg ) mwg ) ) $.
${ 4DQ $p zw ( Tw IQE ( SwE ( Vhc ( rwg ( LAQ rgk pgg ( IAQ rgk 4B4 ) ) xQg ) ) .gk ) ) $=
  ( IAE rQk pQg 3x4 HwQ KwQ xAg rgg mgg SgE VRc .Qk yCA Xxc mAE ) ABCBDEFGHZIJP
  KLJMPNO $. $}
