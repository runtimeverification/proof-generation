$c #SetVariable iA ) XBI #ElementVariable #Symbol #Variable #Pattern ( $.
$v ngg Ow qwg 3gg Bw Kw oAg 5Qg nR4 sgg tAg tgg $.
Bg $f #Pattern Bw $.
Kg $f #ElementVariable Kw $.
Og $f #Variable Ow $.
SA $a #Variable Kw $.
jg $a iA Bw Ow Bw Ow $.
nQg $f #Variable ngg $.
nwg $f #Pattern oAg $.
qgg $f #Pattern qwg $.
sQg $f #Pattern sgg $.
swg $f #Pattern tAg $.
tQg $f #Pattern tgg $.
3Qg $f #ElementVariable 3gg $.
5Ag $f #ElementVariable 5Qg $.
${ YBI $e iA qwg tAg oAg ngg $.
   YRI $e iA sgg tgg oAg ngg $.
   YhI $a iA ( XBI qwg sgg ) ( XBI tAg tgg ) oAg ngg $. $}
nB4 $f #ElementVariable nR4 $.
6h8 $a #Pattern nR4 $.
XiU $a #Pattern 3gg $.
YCU $a #Pattern 5Qg $.
lCU $a iA 5Qg 5Qg nR4 3gg $.
${ 1TE $p iA ( XBI 5Qg nR4 ) ( XBI 5Qg 3gg ) nR4 3gg $=
  ( SA 6h8 YCU XiU lCU jg YhI ) ADZCEZBFZLMAGABCHLKIJ $. $}
