$c vA4 ewk xB4 IAQ Tw #Symbol #Variable SwE -gg #SetVariable zw 4w JAQ #ElementVariable IQE #Pattern ) ( $.
$v Cw 2gg CQ Bw $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Cg $f #Pattern Cw $.
4g $a #Pattern ( 4w Bw CQ ) $.
IAE $a #Pattern IQE $.
SgE $a #Pattern ( SwE Bw CQ ) $.
${ wAE $e zw ( Tw Bw CQ ) $.
   wQE $e zw ( Tw Bw Cw ) $.
   wgE $a zw ( Tw Bw ( 4w CQ Cw ) ) $. $}
HwQ $a #Pattern ( IAQ Bw CQ ) $.
IwQ $a #Pattern ( JAQ Bw ) $.
2Qg $f #ElementVariable 2gg $.
-Qg $a #Pattern -gg $.
egk $a #Pattern ewk $.
uw4 $a #Pattern vA4 $.
wx4 $a #Pattern xB4 $.
Wh8 $a #Pattern 2gg $.
wSE $a zw ( Tw ( 4w ( JAQ 2gg ) IQE ) ( SwE vA4 -gg ) ) $.
zyE $a zw ( Tw ( 4w ( JAQ 2gg ) IQE ) ( SwE ( IAQ ewk xB4 ) ewk ) ) $.
${ 0CE $p zw ( Tw ( 4w ( JAQ 2gg ) IQE ) ( 4w ( SwE ( IAQ ewk xB4 ) ewk ) ( SwE vA4 -gg ) ) ) $=
  ( Wh8 IwQ IAE 4g egk wx4 HwQ SgE uw4 -Qg zyE wSE wgE ) ABCDEFGHFIJKIALAMN $. $}
