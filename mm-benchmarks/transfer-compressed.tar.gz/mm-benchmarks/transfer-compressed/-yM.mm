$c IAQ Tw #Symbol #Variable DR4 SwE #SetVariable zw 4w JAQ lAk #ElementVariable IQE pgg #Pattern ) ( $.
$v Cw 2gg CQ Bw $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Cg $f #Pattern Cw $.
4g $a #Pattern ( 4w Bw CQ ) $.
IAE $a #Pattern IQE $.
SgE $a #Pattern ( SwE Bw CQ ) $.
${ wAE $e zw ( Tw Bw CQ ) $.
   wQE $e zw ( Tw Bw Cw ) $.
   wgE $a zw ( Tw Bw ( 4w CQ Cw ) ) $. $}
HwQ $a #Pattern ( IAQ Bw CQ ) $.
IwQ $a #Pattern ( JAQ Bw ) $.
pQg $a #Pattern pgg $.
2Qg $f #ElementVariable 2gg $.
kwk $a #Pattern lAk $.
DB4 $a #Pattern DR4 $.
Wh8 $a #Pattern 2gg $.
OyE $a zw ( Tw ( 4w ( JAQ 2gg ) IQE ) ( SwE ( IAQ lAk DR4 ) lAk ) ) $.
-iM $a zw ( Tw ( 4w ( JAQ 2gg ) IQE ) ( 4w ( JAQ lAk ) ( JAQ pgg ) ) ) $.
${ -yM $p zw ( Tw ( 4w ( JAQ 2gg ) IQE ) ( 4w ( 4w ( JAQ lAk ) ( JAQ pgg ) ) ( SwE ( IAQ lAk DR4 ) lAk ) ) ) $=
  ( Wh8 IwQ IAE 4g kwk pQg DB4 HwQ SgE -iM OyE wgE ) ABCDEFCGCEFHIFJAKALM $. $}
