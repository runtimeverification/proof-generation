$c ewk #Symbol Tw #Variable SwE PQk #SetVariable zw 4w #ElementVariable IQE #Pattern ) ( $.
$v 5Qg 4wg Cw CQ Bw $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Cg $f #Pattern Cw $.
4g $a #Pattern ( 4w Bw CQ ) $.
IAE $a #Pattern IQE $.
SgE $a #Pattern ( SwE Bw CQ ) $.
lQE $a zw ( Tw Bw Bw ) $.
${ lgE $e zw ( Tw Bw CQ ) $.
   lwE $e zw ( Tw CQ Cw ) $.
   mAE $a zw ( Tw Bw Cw ) $. $}
ugE $a zw ( Tw ( 4w Bw CQ ) Bw ) $.
4gg $f #ElementVariable 4wg $.
5Ag $f #ElementVariable 5Qg $.
PAk $a #Pattern PQk $.
egk $a #Pattern ewk $.
XyU $a #Pattern 4wg $.
YCU $a #Pattern 5Qg $.
${ 3TE $p zw ( Tw ( 4w ( 4w ( SwE 5Qg ewk ) IQE ) ( 4w ( SwE 4wg PQk ) IQE ) ) ( SwE 5Qg ewk ) ) $=
  ( YCU egk SgE IAE 4g XyU PAk ugE lQE mAE ) BCDEZFGZAHIEFGZGNMNOJNMMMFJMKLL $. $}
