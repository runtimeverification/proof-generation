$c Uw PgE 4B4 Tw #Symbol zw JAQ rgk pgg 3gk #Pattern ( 0wM LAQ tQM IAQ #Variable SwE #SetVariable iA 4w #ElementVariable IQE ) $.
$v th1 7Rw Ow CQ Fw DQ Bw ph1 Cw 2gg EQ y th2 mh4 Dw HQ FQ z xX ph2 th0 Gw Hw Ew Kw ph0 GQ nR4 x Lw LQ $.
$d z y $.
$d z x $.
$d y x $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Cg $f #Pattern Cw $.
DA $f #Pattern DQ $.
Dg $f #Pattern Dw $.
EA $f #Pattern EQ $.
Eg $f #Pattern Ew $.
FA $f #Pattern FQ $.
Fg $f #Pattern Fw $.
GA $f #Pattern GQ $.
Gg $f #Pattern Gw $.
HA $f #Pattern HQ $.
Hg $f #Pattern Hw $.
Kg $f #ElementVariable Kw $.
LA $f #ElementVariable LQ $.
Lg $f #ElementVariable Lw $.
Og $f #Variable Ow $.
SA $a #Variable Kw $.
jg $a iA Bw Ow Bw Ow $.
${ kg $e iA CQ DQ Bw Ow $.
   kw $e iA Cw Dw Bw Ow $.
   lA $a iA ( Tw CQ Cw ) ( Tw DQ Dw ) Bw Ow $. $}
4g $a #Pattern ( 4w Bw CQ ) $.
IAE $a #Pattern IQE $.
SgE $a #Pattern ( SwE Bw CQ ) $.
${ lgE $e zw ( Tw Bw CQ ) $.
   lwE $e zw ( Tw CQ Cw ) $.
   mAE $a zw ( Tw Bw Cw ) $. $}
${ wAE $e zw ( Tw Bw CQ ) $.
   wQE $e zw ( Tw Bw Cw ) $.
   wgE $a zw ( Tw Bw ( 4w CQ Cw ) ) $. $}
${ $d xX ph0 $.
   IQI $a iA Bw Bw CQ Ow $. $}
${ KAI $e iA CQ DQ Bw Ow $.
   KQI $e iA Cw Dw Bw Ow $.
   KgI $a iA ( 4w CQ Cw ) ( 4w DQ Dw ) Bw Ow $. $}
${ OgI $e iA CQ DQ Bw Ow $.
   OwI $e iA Cw Dw Bw Ow $.
   PAI $a iA ( SwE CQ Cw ) ( SwE DQ Dw ) Bw Ow $. $}
tAM $a #Pattern ( tQM Bw CQ ) $.
0gM $a #Pattern ( 0wM Bw CQ Cw DQ ) $.
HwQ $a #Pattern ( IAQ Bw CQ ) $.
IwQ $a #Pattern ( JAQ Bw ) $.
KwQ $a #Pattern ( LAQ Bw CQ Cw ) $.
${ QAQ $e iA Bw Cw Dw Ow $.
   QQQ $e iA CQ DQ Dw Ow $.
   QgQ $a iA ( tQM Bw CQ ) ( tQM Cw DQ ) Dw Ow $. $}
${ XgQ $e iA Bw Dw Fw Ow $.
   XwQ $e iA CQ EQ Fw Ow $.
   YAQ $e iA Cw Ew Fw Ow $.
   YQQ $e iA DQ FQ Fw Ow $.
   YgQ $a iA ( 0wM Bw CQ Cw DQ ) ( 0wM Dw EQ Ew FQ ) Fw Ow $. $}
${ lAQ $e iA Bw DQ Ew Ow $.
   lQQ $e iA CQ Dw Ew Ow $.
   lgQ $e iA Cw EQ Ew Ow $.
   lwQ $a iA ( LAQ Bw CQ Cw ) ( LAQ DQ Dw EQ ) Ew Ow $. $}
${ $d z ph0 $.
   $d z ph1 $.
   $d z ph2 $.
   $d z y $.
   $d z x $.
   $d z th1 $.
   $d z th2 $.
   $d x ph0 $.
   $d y th0 $.
   lAY $e zw ( Tw GQ ( Uw Kw ( PgE Kw Bw ) ) ) $.
   lQY $e zw ( Tw ( 4w GQ Gw ) CQ ) $.
   lgY $e iA ( Tw HQ Cw ) ( Tw Gw CQ ) Bw LQ $.
   lwY $e iA ( Tw Hw DQ ) ( Tw Gw CQ ) Lw LQ $.
   mAY $a zw ( Tw ( 4w GQ HQ ) Cw ) $. $}
pQg $a #Pattern pgg $.
2Qg $f #ElementVariable 2gg $.
rQk $a #Pattern rgk $.
3Qk $a #Pattern 3gk $.
7Bw $f #ElementVariable 7Rw $.
mR4 $f #ElementVariable mh4 $.
nB4 $f #ElementVariable nR4 $.
3x4 $a #Pattern 4B4 $.
Wh8 $a #Pattern 2gg $.
YR8 $a #Pattern mh4 $.
6h8 $a #Pattern nR4 $.
8B8 $a iA 2gg 2gg nR4 mh4 $.
8R8 $a iA pgg pgg nR4 mh4 $.
9h8 $a zw ( Tw ( 4w ( JAQ 2gg ) IQE ) ( 4w ( JAQ 2gg ) IQE ) ) $.
QSA $a #Pattern ( 4w ( JAQ 2gg ) ( 4w ( SwE mh4 rgk ) IQE ) ) $.
ViA $a zw ( Tw ( 4w ( 4w ( JAQ 2gg ) IQE ) ( 4w ( SwE mh4 rgk ) IQE ) ) ( 4w ( JAQ 2gg ) ( 4w ( SwE mh4 rgk ) IQE ) ) ) $.
WiA $a iA ( 4w ( SwE nR4 rgk ) IQE ) ( 4w ( SwE mh4 rgk ) IQE ) nR4 mh4 $.
XSA $a iA ( LAQ rgk pgg nR4 ) ( LAQ rgk pgg mh4 ) nR4 mh4 $.
wiA $a zw ( Tw ( 4w ( JAQ 2gg ) IQE ) ( Uw 7Rw ( PgE 7Rw ( IAQ rgk 4B4 ) ) ) ) $.
wyA $a iA 2gg 2gg ( IAQ rgk 4B4 ) mh4 $.
xSA $a zw ( Tw ( 4w ( JAQ 2gg ) IQE ) ( 4w ( SwE ( IAQ rgk 4B4 ) rgk ) IQE ) ) $.
Ri4 $a zw ( Tw ( 4w ( JAQ 2gg ) ( 4w ( SwE mh4 rgk ) IQE ) ) ( tQM 2gg ( 0wM pgg 2gg ( LAQ 3gk pgg ( LAQ rgk 3gk mh4 ) ) ( LAQ rgk pgg mh4 ) ) ) ) $.
SS4 $a iA ( LAQ 3gk pgg ( LAQ rgk 3gk nR4 ) ) ( LAQ 3gk pgg ( LAQ rgk 3gk mh4 ) ) nR4 mh4 $.
${ 0TQ $p zw ( Tw ( 4w ( JAQ 2gg ) IQE ) ( tQM 2gg ( 0wM pgg 2gg ( LAQ 3gk pgg ( LAQ rgk 3gk ( IAQ rgk 4B4 ) ) ) ( LAQ rgk pgg ( IAQ rgk 4B4 ) ) ) ) ) $=
  ( mR4 nB4 7Bw Wh8 IAE 4g rQk SgE pQg 3Qk KwQ 0gM tAM mAE IQI lwQ YgQ QgQ lA
  IwQ 3x4 HwQ 9h8 xSA wgE YR8 6h8 wiA QSA ViA Ri4 SA jg PAI KgI wyA WiA 8B8 8R8
  SS4 XSA mAY ) AEZUAFGZVEHUBUCZHIZFGZGVDJVDKJHKVFLZLZHJVFLZMZNZVEVEVHAUDAUEUFV
  FVDJVDKJHKBUGZLZLZHJVNLZMZNZVMVDJVDKJHKCUHZLLZHJVTLZMZNZVEVNHIZFGZVHVTHIFGZDB
  CADUIVEWFGABUJVSABUKABULOVFVHVMWFVSBUMZVFVGFWEFWHVFVFHVNHWHVFWHUNZHVFWHPZUOFV
  FWHPUPVDVLVDVRVFWHABUQZJVDVJVKJVDVPVQVFWHJVFWHPZWKKJVIKJVOVFWHKVFWHPZWLHKVFHK
  VNVFWHWJWMWIQQHJVFHJVNVFWHWJWLWIQRSTVTWGWDWFVSWHBCURVDWCVDVRVTWHABCUSZJVDWAWB
  JVDVPVQVTWHBCUTWNBCVABCVBRSTVCO $. $}
