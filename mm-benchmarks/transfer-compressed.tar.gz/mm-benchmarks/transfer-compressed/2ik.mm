$c Uw 2R4 PgE Tw #Symbol cwE zw YQk JAQ rgk pgg #Pattern ( 0wM LAQ ewk tQM IAQ 0h4 #Variable SwE #SetVariable 4w rwM #ElementVariable IQE ) cBQ $.
$v yhs CQ qwg Bw Kw ph1 oAg Cw 2gg ph0 GQ x $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Cg $f #Pattern Cw $.
GA $f #Pattern GQ $.
Kg $f #ElementVariable Kw $.
Ug $a #Pattern ( Uw Kw Bw ) $.
4g $a #Pattern ( 4w Bw CQ ) $.
IAE $a #Pattern IQE $.
PQE $a #Pattern ( PgE Bw CQ ) $.
${ lgE $e zw ( Tw Bw CQ ) $.
   lwE $e zw ( Tw CQ Cw ) $.
   mAE $a zw ( Tw Bw Cw ) $. $}
nAE $a zw IQE $.
${ NwM $e zw CQ $.
   OAM $a zw ( Tw Bw CQ ) $. $}
HwQ $a #Pattern ( IAQ Bw CQ ) $.
IwQ $a #Pattern ( JAQ Bw ) $.
KwQ $a #Pattern ( LAQ Bw CQ Cw ) $.
${ $d x ph0 $.
   $d x ph1 $.
   vwY $e zw ( Tw GQ ( SwE CQ Bw ) ) $.
   wAY $e zw ( Tw GQ ( tQM cwE ( rwM Bw cwE Kw ( 0wM Bw cwE Kw CQ ) ) ) ) $.
   wQY $a zw ( Tw GQ ( Uw Kw ( PgE Kw CQ ) ) ) $. $}
nwg $f #Pattern oAg $.
pQg $a #Pattern pgg $.
qgg $f #Pattern qwg $.
2Qg $f #ElementVariable 2gg $.
YAk $a #Pattern YQk $.
egk $a #Pattern ewk $.
rQk $a #Pattern rgk $.
bxQ $a #Pattern ( cBQ oAg qwg ) $.
yRs $f #ElementVariable yhs $.
0R4 $a #Pattern 0h4 $.
2B4 $a #Pattern 2R4 $.
Rx8 $a zw ( Tw IQE ( SwE ( cBQ ( LAQ ewk pgg ( IAQ ewk 2R4 ) ) ( LAQ rgk pgg ( IAQ rgk 0h4 ) ) ) YQk ) ) $.
Wh8 $a #Pattern 2gg $.
7SA $a #Pattern yhs $.
2Sk $a zw ( Tw IQE ( tQM cwE ( rwM YQk cwE yhs ( 0wM YQk cwE yhs ( cBQ ( LAQ ewk pgg ( IAQ ewk 2R4 ) ) ( LAQ rgk pgg ( IAQ rgk 0h4 ) ) ) ) ) ) ) $.
${ 2ik $p zw ( Tw ( 4w ( JAQ 2gg ) IQE ) ( Uw yhs ( PgE yhs ( cBQ ( LAQ ewk pgg ( IAQ ewk 2R4 ) ) ( LAQ rgk pgg ( IAQ rgk 0h4 ) ) ) ) ) ) $=
  ( Wh8 IwQ IAE 4g 7SA egk pQg 2B4 HwQ KwQ rQk 0R4 bxQ PQE Ug nAE OAM YAk Rx8
  2Sk wQY mAE ) ACDEFZEBGHIHJKLMIMNKLOZPBQUEERSTUFEBUABUBUCUD $. $}
