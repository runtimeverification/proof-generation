$c #Symbol Tw #Variable SwE #SetVariable zw 4w YQk JAQ #ElementVariable IQE #Pattern ) ( $.
$v Cw 2gg CQ pxw Bw $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Cg $f #Pattern Cw $.
4g $a #Pattern ( 4w Bw CQ ) $.
IAE $a #Pattern IQE $.
SgE $a #Pattern ( SwE Bw CQ ) $.
lQE $a zw ( Tw Bw Bw ) $.
${ lgE $e zw ( Tw Bw CQ ) $.
   lwE $e zw ( Tw CQ Cw ) $.
   mAE $a zw ( Tw Bw Cw ) $. $}
ugE $a zw ( Tw ( 4w Bw CQ ) Bw ) $.
uwE $a zw ( Tw ( 4w Bw CQ ) CQ ) $.
IwQ $a #Pattern ( JAQ Bw ) $.
2Qg $f #ElementVariable 2gg $.
YAk $a #Pattern YQk $.
phw $f #ElementVariable pxw $.
Wh8 $a #Pattern 2gg $.
sCY $a #Pattern pxw $.
${ 1CY $p zw ( Tw ( 4w ( 4w ( JAQ 2gg ) IQE ) ( 4w ( SwE pxw YQk ) IQE ) ) ( SwE pxw YQk ) ) $=
  ( Wh8 IwQ IAE 4g sCY YAk SgE uwE ugE lQE mAE ) ACDEFZBGHIZEFZFPONPJPOOOEKOLMM
  $. $}
