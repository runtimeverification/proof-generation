$c 0wM LAQ IAQ #Symbol #Variable 1CA #SetVariable iA ) #ElementVariable rgk #Pattern 3gk ( $.
$v yhs Fw Ow CQ DQ Bw Cw 2gg EQ Dw FQ xX zBs Ew Kw ph0 $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Cg $f #Pattern Cw $.
DA $f #Pattern DQ $.
Dg $f #Pattern Dw $.
EA $f #Pattern EQ $.
Eg $f #Pattern Ew $.
FA $f #Pattern FQ $.
Fg $f #Pattern Fw $.
Kg $f #ElementVariable Kw $.
Og $f #Variable Ow $.
SA $a #Variable Kw $.
jg $a iA Bw Ow Bw Ow $.
${ $d xX ph0 $.
   IQI $a iA Bw Bw CQ Ow $. $}
HwQ $a #Pattern ( IAQ Bw CQ ) $.
KwQ $a #Pattern ( LAQ Bw CQ Cw ) $.
${ XgQ $e iA Bw Dw Fw Ow $.
   XwQ $e iA CQ EQ Fw Ow $.
   YAQ $e iA Cw Ew Fw Ow $.
   YQQ $e iA DQ FQ Fw Ow $.
   YgQ $a iA ( 0wM Bw CQ Cw DQ ) ( 0wM Dw EQ Ew FQ ) Fw Ow $. $}
${ lAQ $e iA Bw DQ Ew Ow $.
   lQQ $e iA CQ Dw Ew Ow $.
   lgQ $e iA Cw EQ Ew Ow $.
   lwQ $a iA ( LAQ Bw CQ Cw ) ( LAQ DQ Dw EQ ) Ew Ow $. $}
2Qg $f #ElementVariable 2gg $.
rQk $a #Pattern rgk $.
3Qk $a #Pattern 3gk $.
yRs $f #ElementVariable yhs $.
yxs $f #ElementVariable zBs $.
Wh8 $a #Pattern 2gg $.
0yA $a #Pattern 1CA $.
7SA $a #Pattern yhs $.
JiE $a #Pattern zBs $.
tjU $a iA 2gg 2gg ( IAQ rgk 1CA ) zBs $.
tzU $a iA yhs yhs ( IAQ rgk 1CA ) zBs $.
${ 2DU $p iA ( 0wM 3gk 2gg yhs ( LAQ rgk 3gk ( IAQ rgk 1CA ) ) ) ( 0wM 3gk 2gg yhs ( LAQ rgk 3gk zBs ) ) ( IAQ rgk 1CA ) zBs $=
  ( 3Qk Wh8 7SA rQk 0yA HwQ KwQ JiE SA IQI tjU tzU jg lwQ YgQ ) DAEZBFZGDGHIZJD
  STGDCKZJUACLZDUAUCMZACNBCOGDUAGDUBUAUCGUAUCMUDUAUCPQR $. $}
