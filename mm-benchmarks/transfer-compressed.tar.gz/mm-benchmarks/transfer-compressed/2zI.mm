$c rwg 0wM LAQ IAQ #Symbol #Variable #SetVariable 5x4 ) jww #ElementVariable mwg rgk pgg xQg #Pattern ( $.
$v CQ qwg DQ Bw oAg Cw 6Ag 2gg nR4 $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Cg $f #Pattern Cw $.
DA $f #Pattern DQ $.
0gM $a #Pattern ( 0wM Bw CQ Cw DQ ) $.
HwQ $a #Pattern ( IAQ Bw CQ ) $.
KwQ $a #Pattern ( LAQ Bw CQ Cw ) $.
mgg $a #Pattern mwg $.
nwg $f #Pattern oAg $.
pQg $a #Pattern pgg $.
qgg $f #Pattern qwg $.
rgg $a #Pattern ( rwg oAg qwg ) $.
xAg $a #Pattern xQg $.
2Qg $f #ElementVariable 2gg $.
5wg $f #ElementVariable 6Ag $.
rQk $a #Pattern rgk $.
jgw $a #Pattern ( jww oAg ) $.
nB4 $f #ElementVariable nR4 $.
5h4 $a #Pattern 5x4 $.
Wh8 $a #Pattern 2gg $.
6h8 $a #Pattern nR4 $.
BCE $a #Pattern 6Ag $.
${ 2zI $p #Pattern ( 0wM mwg 2gg 6Ag ( rwg ( jww ( rwg ( LAQ rgk pgg ( IAQ rgk 5x4 ) ) xQg ) ) nR4 ) ) $=
  ( mgg Wh8 BCE rQk pQg 5h4 HwQ KwQ xAg rgg jgw 6h8 0gM ) DAEBFGHGIJKLMNCOMP $. $}
