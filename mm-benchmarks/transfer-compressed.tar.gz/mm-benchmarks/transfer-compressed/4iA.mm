$c LAQ ewk cBQ IAQ Tw #Symbol #Variable 7h4 1CA SwE pgg #SetVariable zw 4w YQk #ElementVariable IQE rgk #Pattern ) ( $.
$v oAg Cw CQ qwg Bw $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Cg $f #Pattern Cw $.
4g $a #Pattern ( 4w Bw CQ ) $.
IAE $a #Pattern IQE $.
SgE $a #Pattern ( SwE Bw CQ ) $.
${ lgE $e zw ( Tw Bw CQ ) $.
   lwE $e zw ( Tw CQ Cw ) $.
   mAE $a zw ( Tw Bw Cw ) $. $}
${ wAE $e zw ( Tw Bw CQ ) $.
   wQE $e zw ( Tw Bw Cw ) $.
   wgE $a zw ( Tw Bw ( 4w CQ Cw ) ) $. $}
HwQ $a #Pattern ( IAQ Bw CQ ) $.
KwQ $a #Pattern ( LAQ Bw CQ Cw ) $.
nwg $f #Pattern oAg $.
pQg $a #Pattern pgg $.
qgg $f #Pattern qwg $.
YAk $a #Pattern YQk $.
egk $a #Pattern ewk $.
rQk $a #Pattern rgk $.
bxQ $a #Pattern ( cBQ oAg qwg ) $.
fBQ $a zw ( Tw ( 4w ( SwE oAg pgg ) ( SwE qwg pgg ) ) ( SwE ( cBQ oAg qwg ) YQk ) ) $.
7R4 $a #Pattern 7h4 $.
Mx8 $a zw ( Tw IQE ( SwE ( LAQ ewk pgg ( IAQ ewk 7h4 ) ) pgg ) ) $.
0yA $a #Pattern 1CA $.
4SA $a zw ( Tw IQE ( SwE ( LAQ rgk pgg ( IAQ rgk 1CA ) ) pgg ) ) $.
${ 4iA $p zw ( Tw IQE ( SwE ( cBQ ( LAQ ewk pgg ( IAQ ewk 7h4 ) ) ( LAQ rgk pgg ( IAQ rgk 1CA ) ) ) YQk ) ) $=
  ( IAE egk pQg 7R4 HwQ KwQ SgE rQk 0yA 4g bxQ YAk Mx8 4SA wgE fBQ mAE ) ABCBDE
  FZCGZHCHIEFZCGZJRTKLGASUAMNORTPQ $. $}
