$c XBI Tw #Symbol -gg zw rgk #Pattern ( Ex0 LAQ ewk xB4 IAQ Wgk #Variable SwE #SetVariable 4w #ElementVariable IQE 8wk ) $.
$v CQ qwg Bw oAg 5Qg Cw $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Cg $f #Pattern Cw $.
4g $a #Pattern ( 4w Bw CQ ) $.
IAE $a #Pattern IQE $.
SgE $a #Pattern ( SwE Bw CQ ) $.
${ lgE $e zw ( Tw Bw CQ ) $.
   lwE $e zw ( Tw CQ Cw ) $.
   mAE $a zw ( Tw Bw Cw ) $. $}
${ wAE $e zw ( Tw Bw CQ ) $.
   wQE $e zw ( Tw Bw Cw ) $.
   wgE $a zw ( Tw Bw ( 4w CQ Cw ) ) $. $}
HwQ $a #Pattern ( IAQ Bw CQ ) $.
KwQ $a #Pattern ( LAQ Bw CQ Cw ) $.
nwg $f #Pattern oAg $.
qgg $f #Pattern qwg $.
5Ag $f #ElementVariable 5Qg $.
-Qg $a #Pattern -gg $.
WQk $a #Pattern Wgk $.
egk $a #Pattern ewk $.
rQk $a #Pattern rgk $.
8gk $a #Pattern 8wk $.
WxI $a #Pattern ( XBI oAg qwg ) $.
aBI $a zw ( Tw ( 4w ( SwE oAg ewk ) ( SwE qwg Wgk ) ) ( SwE ( XBI oAg qwg ) 8wk ) ) $.
Eh0 $a #Pattern Ex0 $.
wx4 $a #Pattern xB4 $.
YCU $a #Pattern 5Qg $.
0iU $a zw ( Tw ( 4w ( SwE 5Qg -gg ) IQE ) ( SwE ( IAQ ewk xB4 ) ewk ) ) $.
4CU $a zw ( Tw ( 4w ( SwE 5Qg -gg ) IQE ) ( SwE ( LAQ rgk Wgk ( IAQ rgk Ex0 ) ) Wgk ) ) $.
${ 4SU $p zw ( Tw ( 4w ( SwE 5Qg -gg ) IQE ) ( SwE ( XBI ( IAQ ewk xB4 ) ( LAQ rgk Wgk ( IAQ rgk Ex0 ) ) ) 8wk ) ) $=
  ( YCU -Qg SgE IAE 4g egk wx4 HwQ rQk WQk Eh0 KwQ WxI 8gk 0iU 4CU wgE aBI mAE
  ) ABCDEFZGHIZGDZJKJLIMZKDZFUBUDNODUAUCUEAPAQRUBUDST $. $}
