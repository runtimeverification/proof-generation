$c Tw #Symbol zBI zw JAQ pwk #Pattern ( 0wM tQM Wgk #Variable SwE #SetVariable 4w rwM #ElementVariable IQE ) $.
$v yhs CQ Bw XRw Kw Cw 2gg -Rs $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Cg $f #Pattern Cw $.
Kg $f #ElementVariable Kw $.
4g $a #Pattern ( 4w Bw CQ ) $.
IAE $a #Pattern IQE $.
SgE $a #Pattern ( SwE Bw CQ ) $.
${ lgE $e zw ( Tw Bw CQ ) $.
   lwE $e zw ( Tw CQ Cw ) $.
   mAE $a zw ( Tw Bw Cw ) $. $}
ugE $a zw ( Tw ( 4w Bw CQ ) Bw ) $.
${ wAE $e zw ( Tw Bw CQ ) $.
   wQE $e zw ( Tw Bw Cw ) $.
   wgE $a zw ( Tw Bw ( 4w CQ Cw ) ) $. $}
rgM $a #Pattern ( rwM Bw CQ Kw Cw ) $.
tAM $a #Pattern ( tQM Bw CQ ) $.
IwQ $a #Pattern ( JAQ Bw ) $.
2Qg $f #ElementVariable 2gg $.
WQk $a #Pattern Wgk $.
pgk $a #Pattern pwk $.
yRs $f #ElementVariable yhs $.
-Bs $f #ElementVariable -Rs $.
XBw $f #ElementVariable XRw $.
pBw $a zw ( Tw ( 4w ( JAQ 2gg ) ( 4w ( SwE -Rs Wgk ) ( 4w ( SwE XRw Wgk ) IQE ) ) ) ( tQM 2gg ( rwM pwk 2gg yhs ( 0wM pwk 2gg yhs ( zBI -Rs XRw ) ) ) ) ) $.
Wh8 $a #Pattern 2gg $.
QCE $a #Pattern XRw $.
QyE $a #Pattern -Rs $.
CCI $a #Pattern ( 4w ( JAQ 2gg ) ( 4w ( SwE XRw Wgk ) IQE ) ) $.
CiI $a zw ( Tw ( 4w ( JAQ 2gg ) ( 4w ( SwE XRw Wgk ) IQE ) ) ( JAQ 2gg ) ) $.
2iI $a zw ( Tw ( 4w ( 4w ( JAQ 2gg ) ( 4w ( SwE XRw Wgk ) IQE ) ) ( 4w ( SwE -Rs Wgk ) IQE ) ) ( 4w ( SwE -Rs Wgk ) ( 4w ( SwE XRw Wgk ) IQE ) ) ) $.
2yI $a #Pattern ( 4w ( JAQ 2gg ) ( 4w ( SwE -Rs Wgk ) ( 4w ( SwE XRw Wgk ) IQE ) ) ) $.
3SI $a #Pattern ( 0wM pwk 2gg yhs ( zBI -Rs XRw ) ) $.
${ 3iI $p zw ( Tw ( 4w ( 4w ( JAQ 2gg ) ( 4w ( SwE XRw Wgk ) IQE ) ) ( 4w ( SwE -Rs Wgk ) IQE ) ) ( tQM 2gg ( rwM pwk 2gg yhs ( 0wM pwk 2gg yhs ( zBI -Rs XRw ) ) ) ) ) $=
  ( CCI QyE WQk SgE IAE 4g 2yI Wh8 pgk 3SI rgM tAM IwQ QCE ugE mAE CiI 2iI wgE
  pBw ) ADEZCFGHZIJZJZACDKALZMUIABCDNBOPUHUIQZUFDRGHIJJUHUEUJUEUGSADUATACDUBUCA
  BCDUDT $. $}
