$c ewk xB4 IAQ #Symbol #Variable #SetVariable iA #ElementVariable #Pattern ) ( $.
$v yhs Ow CQ xX zBs Bw Kw ph0 $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Kg $f #ElementVariable Kw $.
Og $f #Variable Ow $.
SA $a #Variable Kw $.
${ $d xX ph0 $.
   IQI $a iA Bw Bw CQ Ow $. $}
HwQ $a #Pattern ( IAQ Bw CQ ) $.
egk $a #Pattern ewk $.
yRs $f #ElementVariable yhs $.
yxs $f #ElementVariable zBs $.
wx4 $a #Pattern xB4 $.
7SA $a #Pattern yhs $.
${ 0Sc $p iA yhs yhs ( IAQ ewk xB4 ) zBs $=
  ( 7SA egk wx4 HwQ SA IQI ) ACDEFBGH $. $}
