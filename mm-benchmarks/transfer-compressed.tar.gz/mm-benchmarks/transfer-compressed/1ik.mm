$c LAQ IAQ 0h4 Tw #Symbol #Variable SwE pgg #SetVariable zw 4w JAQ #ElementVariable IQE rgk #Pattern ) ( $.
$v CQ qwg Bw oAg Cw 2gg sgg $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Cg $f #Pattern Cw $.
4g $a #Pattern ( 4w Bw CQ ) $.
IAE $a #Pattern IQE $.
SgE $a #Pattern ( SwE Bw CQ ) $.
${ lgE $e zw ( Tw Bw CQ ) $.
   lwE $e zw ( Tw CQ Cw ) $.
   mAE $a zw ( Tw Bw Cw ) $. $}
HwQ $a #Pattern ( IAQ Bw CQ ) $.
IwQ $a #Pattern ( JAQ Bw ) $.
KwQ $a #Pattern ( LAQ Bw CQ Cw ) $.
nwg $f #Pattern oAg $.
pQg $a #Pattern pgg $.
qgg $f #Pattern qwg $.
sQg $f #Pattern sgg $.
2Qg $f #ElementVariable 2gg $.
.gg $a zw ( Tw ( 4w ( 4w ( JAQ oAg ) ( JAQ qwg ) ) ( SwE sgg oAg ) ) ( SwE ( LAQ oAg qwg sgg ) qwg ) ) $.
rQk $a #Pattern rgk $.
0R4 $a #Pattern 0h4 $.
Wh8 $a #Pattern 2gg $.
1Sk $a zw ( Tw ( 4w ( JAQ 2gg ) IQE ) ( 4w ( 4w ( JAQ rgk ) ( JAQ pgg ) ) ( SwE ( IAQ rgk 0h4 ) rgk ) ) ) $.
${ 1ik $p zw ( Tw ( 4w ( JAQ 2gg ) IQE ) ( SwE ( LAQ rgk pgg ( IAQ rgk 0h4 ) ) pgg ) ) $=
  ( Wh8 IwQ IAE 4g rQk pQg 0R4 HwQ SgE KwQ 1Sk .gg mAE ) ABCDEFCGCEFHIZFJEFGOKG
  JALFGOMN $. $}
