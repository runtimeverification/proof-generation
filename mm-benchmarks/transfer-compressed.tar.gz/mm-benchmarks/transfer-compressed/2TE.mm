$c 2R4 ewk IAQ Wgk Tw #Symbol #Variable SwE PQk #SetVariable zw 4w JAQ #ElementVariable IQE #Pattern ) ( $.
$v 4wg 5Qg Cw CQ Bw $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Cg $f #Pattern Cw $.
Tg $a #Pattern ( Tw Bw CQ ) $.
4g $a #Pattern ( 4w Bw CQ ) $.
5Q $a zw ( Tw Bw ( Tw CQ Bw ) ) $.
${ 6A $e zw ( Tw Bw CQ ) $.
   6Q $e zw Bw $.
   6g $a zw CQ $. $}
SgE $a #Pattern ( SwE Bw CQ ) $.
${ wAE $e zw ( Tw Bw CQ ) $.
   wQE $e zw ( Tw Bw Cw ) $.
   wgE $a zw ( Tw Bw ( 4w CQ Cw ) ) $. $}
HwQ $a #Pattern ( IAQ Bw CQ ) $.
IgQ $a zw ( SwE ( IAQ Bw CQ ) Bw ) $.
IwQ $a #Pattern ( JAQ Bw ) $.
4gg $f #ElementVariable 4wg $.
5Ag $f #ElementVariable 5Qg $.
WQk $a #Pattern Wgk $.
XQk $a zw ( JAQ Wgk ) $.
egk $a #Pattern ewk $.
fgk $a zw ( JAQ ewk ) $.
2B4 $a #Pattern 2R4 $.
ljE $a #Pattern ( 4w ( SwE 4wg PQk ) ( 4w ( SwE 5Qg ewk ) IQE ) ) $.
${ 2TE $p zw ( Tw ( 4w ( SwE 4wg PQk ) ( 4w ( SwE 5Qg ewk ) IQE ) ) ( 4w ( 4w ( JAQ ewk ) ( JAQ Wgk ) ) ( SwE ( IAQ ewk 2R4 ) ewk ) ) ) $=
  ( ljE egk IwQ WQk 4g 2B4 HwQ SgE Tg 5Q fgk 6g XQk wgE IgQ ) ABCZDEZFEZGDHIDJZ
  RSTSRSKSRLMNTRTKTRLONPUARUAKUARLDHQNP $. $}
