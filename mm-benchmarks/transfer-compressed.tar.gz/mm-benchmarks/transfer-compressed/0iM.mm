$c 1wk #Symbol Tw #Variable SwE #SetVariable zw 4w JAQ #ElementVariable IQE #Pattern ) ( $.
$v Cw 2gg CQ zBs Bw $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Cg $f #Pattern Cw $.
4g $a #Pattern ( 4w Bw CQ ) $.
IAE $a #Pattern IQE $.
SgE $a #Pattern ( SwE Bw CQ ) $.
nAE $a zw IQE $.
${ wAE $e zw ( Tw Bw CQ ) $.
   wQE $e zw ( Tw Bw Cw ) $.
   wgE $a zw ( Tw Bw ( 4w CQ Cw ) ) $. $}
${ NwM $e zw CQ $.
   OAM $a zw ( Tw Bw CQ ) $. $}
IwQ $a #Pattern ( JAQ Bw ) $.
2Qg $f #ElementVariable 2gg $.
1gk $a #Pattern 1wk $.
yxs $f #ElementVariable zBs $.
Wh8 $a #Pattern 2gg $.
JiE $a #Pattern zBs $.
0CM $a zw ( Tw ( 4w ( 4w ( JAQ 2gg ) IQE ) ( 4w ( SwE zBs 1wk ) IQE ) ) ( JAQ 2gg ) ) $.
0SM $a zw ( Tw ( 4w ( 4w ( JAQ 2gg ) IQE ) ( 4w ( SwE zBs 1wk ) IQE ) ) ( SwE zBs 1wk ) ) $.
${ 0iM $p zw ( Tw ( 4w ( 4w ( JAQ 2gg ) IQE ) ( 4w ( SwE zBs 1wk ) IQE ) ) ( 4w ( JAQ 2gg ) ( 4w ( SwE zBs 1wk ) IQE ) ) ) $=
  ( Wh8 IwQ IAE 4g JiE 1gk SgE 0CM 0SM nAE OAM wgE ) ACDZEFBGHIZEFZFZOQABJRPEAB
  KRELMNN $. $}
