$c ww4 #Symbol #Variable #SetVariable iA #ElementVariable 7BI #Pattern ) ( $.
$v ngg Ow qwg qxw Bw Kw oAg nR4 sgg tAg tgg $.
Bg $f #Pattern Bw $.
Kg $f #ElementVariable Kw $.
Og $f #Variable Ow $.
SA $a #Variable Kw $.
jg $a iA Bw Ow Bw Ow $.
nQg $f #Variable ngg $.
nwg $f #Pattern oAg $.
qgg $f #Pattern qwg $.
sQg $f #Pattern sgg $.
swg $f #Pattern tAg $.
tQg $f #Pattern tgg $.
wg4 $a #Pattern ww4 $.
${ 8BI $e iA qwg tAg oAg ngg $.
   8RI $e iA sgg tgg oAg ngg $.
   8hI $a iA ( 7BI qwg sgg ) ( 7BI tAg tgg ) oAg ngg $. $}
qhw $f #ElementVariable qxw $.
nB4 $f #ElementVariable nR4 $.
6h8 $a #Pattern nR4 $.
7iU $a #Pattern qxw $.
-CU $a iA ww4 ww4 nR4 qxw $.
${ -SU $p iA ( 7BI nR4 ww4 ) ( 7BI qxw ww4 ) nR4 qxw $=
  ( SA 6h8 wg4 7iU jg -CU 8hI ) ACZBDZKEAFEKJGABHI $. $}
