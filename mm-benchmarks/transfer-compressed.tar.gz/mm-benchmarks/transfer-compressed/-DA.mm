$c rwg LAQ Hg8 #Symbol #Variable #SetVariable iA hgk #ElementVariable pgg #Pattern xQg ) ( $.
$v Ow CQ qwg Bw Cw sgg tAg ngg xX 3gg Kw ph0 oAg tgg 4Ag $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Cg $f #Pattern Cw $.
Kg $f #ElementVariable Kw $.
Og $f #Variable Ow $.
SA $a #Variable Kw $.
jg $a iA Bw Ow Bw Ow $.
${ $d xX ph0 $.
   IQI $a iA Bw Bw CQ Ow $. $}
KwQ $a #Pattern ( LAQ Bw CQ Cw ) $.
nQg $f #Variable ngg $.
nwg $f #Pattern oAg $.
pQg $a #Pattern pgg $.
qgg $f #Pattern qwg $.
rgg $a #Pattern ( rwg oAg qwg ) $.
sQg $f #Pattern sgg $.
swg $f #Pattern tAg $.
tQg $f #Pattern tgg $.
${ uQg $e iA qwg tAg oAg ngg $.
   ugg $e iA sgg tgg oAg ngg $.
   uwg $a iA ( rwg qwg sgg ) ( rwg tAg tgg ) oAg ngg $. $}
xAg $a #Pattern xQg $.
3Qg $f #ElementVariable 3gg $.
3wg $f #ElementVariable 4Ag $.
hQk $a #Pattern hgk $.
${ Ig8 $e iA qwg sgg oAg ngg $.
   Iw8 $a iA ( Hg8 qwg ) ( Hg8 sgg ) oAg ngg $. $}
BCQ $a #Pattern 4Ag $.
XiU $a #Pattern 3gg $.
7TA $a #Pattern ( rwg ( LAQ hgk pgg 3gg ) 4Ag ) $.
${ -DA $p iA ( Hg8 ( rwg ( LAQ hgk pgg 3gg ) xQg ) ) ( Hg8 ( rwg ( LAQ hgk pgg 3gg ) 4Ag ) ) xQg 4Ag $=
  ( SA xAg hQk pQg XiU KwQ rgg 7TA BCQ IQI jg uwg Iw8 ) BCZDEFAGHZDIABJPDQDQBKQ
  DPLDPMNO $. $}
