$c ewk IAQ Tw #Symbol #Variable SwE #SetVariable zw vR4 4w YQk #ElementVariable IQE #Pattern ) ( $.
$v CQ -Bw Bw $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Tg $a #Pattern ( Tw Bw CQ ) $.
4g $a #Pattern ( 4w Bw CQ ) $.
5Q $a zw ( Tw Bw ( Tw CQ Bw ) ) $.
${ 6A $e zw ( Tw Bw CQ ) $.
   6Q $e zw Bw $.
   6g $a zw CQ $. $}
IAE $a #Pattern IQE $.
SgE $a #Pattern ( SwE Bw CQ ) $.
HwQ $a #Pattern ( IAQ Bw CQ ) $.
IgQ $a zw ( SwE ( IAQ Bw CQ ) Bw ) $.
YAk $a #Pattern YQk $.
egk $a #Pattern ewk $.
.xw $f #ElementVariable -Bw $.
vB4 $a #Pattern vR4 $.
yyg $a #Pattern -Bw $.
${ 3y4 $p zw ( Tw ( 4w ( SwE -Bw YQk ) IQE ) ( SwE ( IAQ ewk vR4 ) ewk ) ) $=
  ( egk vB4 HwQ SgE yyg YAk IAE 4g Tg 5Q IgQ 6g ) BCDBEZAFGEHIZNJNOKBCLM $. $}
