$c Uw 4B4 #Symbol 7h4 DBE GBY zw pgg vA4 #Pattern Ex0 0wM xB4 tQM Wgk 0h4 #Variable SwE 0hU #SetVariable iA vR4 4w rwM #ElementVariable IQE qxs 8hw 2R4 kBM zBA XBI PgE 1wk Tw -gg zBI 5x4 JAQ pwk rgk ( LAQ ewk yx4 IAQ 9R4 3BA hgk 8wk ) $.
$v th1 yhs Fw CQ Bw Cw 2gg sgg FQ z ph2 Ew ph0 x Lw LQ Ow ph6 qwg DQ ph1 EQ y th2 Dw HQ xX Gw th0 zBs Hw Kw oAg GQ nR4 $.
$d z y $.
$d z x $.
$d y x $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Cg $f #Pattern Cw $.
DA $f #Pattern DQ $.
Dg $f #Pattern Dw $.
EA $f #Pattern EQ $.
Eg $f #Pattern Ew $.
FA $f #Pattern FQ $.
Fg $f #Pattern Fw $.
GA $f #Pattern GQ $.
Gg $f #Pattern Gw $.
HA $f #Pattern HQ $.
Hg $f #Pattern Hw $.
Kg $f #ElementVariable Kw $.
LA $f #ElementVariable LQ $.
Lg $f #ElementVariable Lw $.
Og $f #Variable Ow $.
SA $a #Variable Kw $.
jg $a iA Bw Ow Bw Ow $.
${ kg $e iA CQ DQ Bw Ow $.
   kw $e iA Cw Dw Bw Ow $.
   lA $a iA ( Tw CQ Cw ) ( Tw DQ Dw ) Bw Ow $. $}
4g $a #Pattern ( 4w Bw CQ ) $.
IAE $a #Pattern IQE $.
SgE $a #Pattern ( SwE Bw CQ ) $.
${ lgE $e zw ( Tw Bw CQ ) $.
   lwE $e zw ( Tw CQ Cw ) $.
   mAE $a zw ( Tw Bw Cw ) $. $}
nAE $a zw IQE $.
${ wAE $e zw ( Tw Bw CQ ) $.
   wQE $e zw ( Tw Bw Cw ) $.
   wgE $a zw ( Tw Bw ( 4w CQ Cw ) ) $. $}
${ $d xX ph0 $.
   IQI $a iA Bw Bw CQ Ow $. $}
${ KAI $e iA CQ DQ Bw Ow $.
   KQI $e iA Cw Dw Bw Ow $.
   KgI $a iA ( 4w CQ Cw ) ( 4w DQ Dw ) Bw Ow $. $}
${ OgI $e iA CQ DQ Bw Ow $.
   OwI $e iA Cw Dw Bw Ow $.
   PAI $a iA ( SwE CQ Cw ) ( SwE DQ Dw ) Bw Ow $. $}
${ NwM $e zw CQ $.
   OAM $a zw ( Tw Bw CQ ) $. $}
rgM $a #Pattern ( rwM Bw CQ Kw Cw ) $.
tAM $a #Pattern ( tQM Bw CQ ) $.
0gM $a #Pattern ( 0wM Bw CQ Cw DQ ) $.
HwQ $a #Pattern ( IAQ Bw CQ ) $.
IwQ $a #Pattern ( JAQ Bw ) $.
KwQ $a #Pattern ( LAQ Bw CQ Cw ) $.
${ $d xX y $.
   $d y ph6 $.
   OAQ $e iA Bw DQ Ew Ow $.
   OQQ $e iA CQ Dw Ew Ow $.
   OgQ $e iA Cw EQ Ew Ow $.
   OwQ $a iA ( rwM Bw CQ LQ Cw ) ( rwM DQ Dw LQ EQ ) Ew Ow $. $}
${ QAQ $e iA Bw Cw Dw Ow $.
   QQQ $e iA CQ DQ Dw Ow $.
   QgQ $a iA ( tQM Bw CQ ) ( tQM Cw DQ ) Dw Ow $. $}
${ XgQ $e iA Bw Dw Fw Ow $.
   XwQ $e iA CQ EQ Fw Ow $.
   YAQ $e iA Cw Ew Fw Ow $.
   YQQ $e iA DQ FQ Fw Ow $.
   YgQ $a iA ( 0wM Bw CQ Cw DQ ) ( 0wM Dw EQ Ew FQ ) Fw Ow $. $}
${ lAQ $e iA Bw DQ Ew Ow $.
   lQQ $e iA CQ Dw Ew Ow $.
   lgQ $e iA Cw EQ Ew Ow $.
   lwQ $a iA ( LAQ Bw CQ Cw ) ( LAQ DQ Dw EQ ) Ew Ow $. $}
${ $d z ph0 $.
   $d z ph1 $.
   $d z ph2 $.
   $d z y $.
   $d z x $.
   $d z th1 $.
   $d z th2 $.
   $d x ph0 $.
   $d y th0 $.
   lAY $e zw ( Tw GQ ( Uw Kw ( PgE Kw Bw ) ) ) $.
   lQY $e zw ( Tw ( 4w GQ Gw ) CQ ) $.
   lgY $e iA ( Tw HQ Cw ) ( Tw Gw CQ ) Bw LQ $.
   lwY $e iA ( Tw Hw DQ ) ( Tw Gw CQ ) Lw LQ $.
   mAY $a zw ( Tw ( 4w GQ HQ ) Cw ) $. $}
nwg $f #Pattern oAg $.
pQg $a #Pattern pgg $.
qgg $f #Pattern qwg $.
sQg $f #Pattern sgg $.
2Qg $f #ElementVariable 2gg $.
-Qg $a #Pattern -gg $.
WQk $a #Pattern Wgk $.
egk $a #Pattern ewk $.
hQk $a #Pattern hgk $.
pgk $a #Pattern pwk $.
rQk $a #Pattern rgk $.
1gk $a #Pattern 1wk $.
8gk $a #Pattern 8wk $.
uw4 $a #Pattern vA4 $.
yxA $a #Pattern ( zBA oAg qwg ) $.
2xA $a #Pattern ( 3BA oAg qwg ) $.
CxE $a #Pattern ( DBE oAg qwg ) $.
WxI $a #Pattern ( XBI oAg qwg ) $.
yxI $a #Pattern ( zBI oAg qwg ) $.
jxM $a #Pattern ( kBM oAg qwg ) $.
nBM $a zw ( Tw ( 4w ( SwE oAg 8wk ) ( SwE qwg 8wk ) ) ( SwE ( kBM oAg qwg ) 8wk ) ) $.
0RU $a #Pattern ( 0hU oAg qwg sgg ) $.
3xU $a zw ( Tw ( 4w ( 4w ( SwE oAg pwk ) ( SwE qwg hgk ) ) ( SwE sgg hgk ) ) ( SwE ( 0hU oAg qwg sgg ) 8wk ) ) $.
FxY $a #Pattern ( GBY oAg qwg ) $.
JBY $a zw ( Tw ( 4w ( SwE oAg -gg ) ( SwE qwg 8wk ) ) ( SwE ( GBY oAg qwg ) 1wk ) ) $.
qhs $a #Pattern ( qxs oAg ) $.
tBs $a zw ( Tw ( SwE oAg 8wk ) ( SwE ( qxs oAg ) hgk ) ) $.
yRs $f #ElementVariable yhs $.
yxs $f #ElementVariable zBs $.
8Rw $a #Pattern 8hw $.
Eh0 $a #Pattern Ex0 $.
nB4 $f #ElementVariable nR4 $.
vB4 $a #Pattern vR4 $.
wx4 $a #Pattern xB4 $.
yh4 $a #Pattern yx4 $.
0R4 $a #Pattern 0h4 $.
2B4 $a #Pattern 2R4 $.
3x4 $a #Pattern 4B4 $.
5h4 $a #Pattern 5x4 $.
7R4 $a #Pattern 7h4 $.
9B4 $a #Pattern 9R4 $.
Wh8 $a #Pattern 2gg $.
6h8 $a #Pattern nR4 $.
9h8 $a zw ( Tw ( 4w ( JAQ 2gg ) IQE ) ( 4w ( JAQ 2gg ) IQE ) ) $.
7SA $a #Pattern yhs $.
JiE $a #Pattern zBs $.
NSE $a iA 2gg 2gg nR4 zBs $.
lSM $a zw ( Tw ( 4w ( JAQ 2gg ) IQE ) ( SwE ( XBI ( IAQ ewk 7h4 ) ( zBA ( LAQ ewk Wgk ( IAQ ewk 7h4 ) ) ( LAQ ewk Wgk ( IAQ ewk 2R4 ) ) ) ) 8wk ) ) $.
ryM $a zw ( Tw ( 4w ( JAQ 2gg ) IQE ) ( SwE ( XBI ( IAQ ewk xB4 ) ( LAQ rgk Wgk ( IAQ rgk Ex0 ) ) ) 8wk ) ) $.
syM $a zw ( Tw ( 4w ( JAQ 2gg ) IQE ) ( SwE ( XBI ( IAQ ewk vR4 ) ( DBE ( LAQ ewk Wgk ( IAQ ewk vR4 ) ) ( LAQ ewk Wgk ( IAQ ewk 2R4 ) ) ) ) 8wk ) ) $.
wiM $a zw ( Tw ( 4w ( JAQ 2gg ) IQE ) ( SwE ( zBI ( LAQ ewk Wgk ( IAQ ewk 2R4 ) ) ( LAQ ewk Wgk ( IAQ ewk vR4 ) ) ) pwk ) ) $.
wyM $a zw ( Tw ( 4w ( JAQ 2gg ) IQE ) ( SwE ( qxs ( XBI ( IAQ ewk xB4 ) ( LAQ rgk Wgk ( IAQ rgk 8hw ) ) ) ) hgk ) ) $.
yyM $a zw ( Tw ( 4w ( JAQ 2gg ) IQE ) ( SwE ( kBM ( kBM ( kBM ( XBI ( IAQ ewk 9R4 ) ( LAQ rgk Wgk ( IAQ rgk yx4 ) ) ) ( XBI ( IAQ ewk 2R4 ) ( LAQ rgk Wgk ( IAQ rgk 0h4 ) ) ) ) ( XBI ( IAQ ewk vR4 ) ( LAQ rgk Wgk ( IAQ rgk 5x4 ) ) ) ) ( XBI ( IAQ ewk 7h4 ) ( LAQ rgk Wgk ( IAQ rgk 4B4 ) ) ) ) 8wk ) ) $.
zyM $a zw ( Tw ( 4w ( JAQ 2gg ) IQE ) ( Uw yhs ( PgE yhs ( GBY ( 3BA ( IAQ ewk 9R4 ) ( 3BA ( IAQ ewk 2R4 ) ( 3BA ( IAQ ewk vR4 ) ( 3BA ( IAQ ewk 7h4 ) ( 3BA ( IAQ ewk xB4 ) vA4 ) ) ) ) ) ( kBM ( kBM ( kBM ( kBM ( XBI ( IAQ ewk 9R4 ) ( LAQ rgk Wgk ( IAQ rgk yx4 ) ) ) ( XBI ( IAQ ewk 2R4 ) ( LAQ rgk Wgk ( IAQ rgk 0h4 ) ) ) ) ( XBI ( IAQ ewk vR4 ) ( LAQ rgk Wgk ( IAQ rgk 5x4 ) ) ) ) ( XBI ( IAQ ewk 7h4 ) ( LAQ rgk Wgk ( IAQ rgk 4B4 ) ) ) ) ( 0hU ( zBI ( LAQ ewk Wgk ( IAQ ewk 2R4 ) ) ( LAQ ewk Wgk ( IAQ ewk vR4 ) ) ) ( qxs ( XBI ( IAQ ewk xB4 ) ( LAQ rgk Wgk ( IAQ rgk 8hw ) ) ) ) ( qxs ( kBM ( kBM ( XBI ( IAQ ewk vR4 ) ( DBE ( LAQ ewk Wgk ( IAQ ewk vR4 ) ) ( LAQ ewk Wgk ( IAQ ewk 2R4 ) ) ) ) ( XBI ( IAQ ewk 7h4 ) ( zBA ( LAQ ewk Wgk ( IAQ ewk 7h4 ) ) ( LAQ ewk Wgk ( IAQ ewk 2R4 ) ) ) ) ) ( XBI ( IAQ ewk xB4 ) ( LAQ rgk Wgk ( IAQ rgk Ex0 ) ) ) ) ) ) ) ) ) ) ) $.
1CM $a #Pattern ( 0wM pgg 2gg yhs ( LAQ 1wk pgg zBs ) ) $.
1SM $a zw ( Tw ( 4w ( 4w ( JAQ 2gg ) IQE ) ( 4w ( SwE zBs 1wk ) IQE ) ) ( tQM 2gg ( rwM pgg 2gg yhs ( 0wM pgg 2gg yhs ( LAQ 1wk pgg zBs ) ) ) ) ) $.
1iM $a #Pattern ( 0wM pgg 2gg yhs ( LAQ 1wk pgg nR4 ) ) $.
2SM $a iA ( 4w ( SwE nR4 1wk ) IQE ) ( 4w ( SwE zBs 1wk ) IQE ) nR4 zBs $.
3CM $a iA ( rwM pgg 2gg yhs ( 0wM pgg 2gg yhs ( LAQ 1wk pgg nR4 ) ) ) ( rwM pgg 2gg yhs ( 0wM pgg 2gg yhs ( LAQ 1wk pgg zBs ) ) ) nR4 zBs $.
3SM $a zw ( Tw ( 4w ( JAQ 2gg ) IQE ) ( SwE ( 3BA ( IAQ ewk 9R4 ) ( 3BA ( IAQ ewk 2R4 ) ( 3BA ( IAQ ewk vR4 ) ( 3BA ( IAQ ewk 7h4 ) ( 3BA ( IAQ ewk xB4 ) vA4 ) ) ) ) ) -gg ) ) $.
${ 3iM $p zw ( Tw ( 4w ( JAQ 2gg ) IQE ) ( tQM 2gg ( rwM pgg 2gg yhs ( 0wM pgg 2gg yhs ( LAQ 1wk pgg ( GBY ( 3BA ( IAQ ewk 9R4 ) ( 3BA ( IAQ ewk 2R4 ) ( 3BA ( IAQ ewk vR4 ) ( 3BA ( IAQ ewk 7h4 ) ( 3BA ( IAQ ewk xB4 ) vA4 ) ) ) ) ) ( kBM ( kBM ( kBM ( kBM ( XBI ( IAQ ewk 9R4 ) ( LAQ rgk Wgk ( IAQ rgk yx4 ) ) ) ( XBI ( IAQ ewk 2R4 ) ( LAQ rgk Wgk ( IAQ rgk 0h4 ) ) ) ) ( XBI ( IAQ ewk vR4 ) ( LAQ rgk Wgk ( IAQ rgk 5x4 ) ) ) ) ( XBI ( IAQ ewk 7h4 ) ( LAQ rgk Wgk ( IAQ rgk 4B4 ) ) ) ) ( 0hU ( zBI ( LAQ ewk Wgk ( IAQ ewk 2R4 ) ) ( LAQ ewk Wgk ( IAQ ewk vR4 ) ) ) ( qxs ( XBI ( IAQ ewk xB4 ) ( LAQ rgk Wgk ( IAQ rgk 8hw ) ) ) ) ( qxs ( kBM ( kBM ( XBI ( IAQ ewk vR4 ) ( DBE ( LAQ ewk Wgk ( IAQ ewk vR4 ) ) ( LAQ ewk Wgk ( IAQ ewk 2R4 ) ) ) ) ( XBI ( IAQ ewk 7h4 ) ( zBA ( LAQ ewk Wgk ( IAQ ewk 7h4 ) ) ( LAQ ewk Wgk ( IAQ ewk 2R4 ) ) ) ) ) ( XBI ( IAQ ewk xB4 ) ( LAQ rgk Wgk ( IAQ rgk Ex0 ) ) ) ) ) ) ) ) ) ) ) ) ) $=
  ( yxs nB4 IAE 4g egk HwQ 2xA rQk WQk KwQ WxI jxM 1gk SgE pQg 8gk wgE mAE Wh8
  IwQ 9B4 2B4 vB4 7R4 wx4 uw4 yh4 0R4 5h4 3x4 yxI 8Rw qhs CxE yxA Eh0 0RU SA jg
  FxY 7SA 0gM rgM tAM 9h8 -Qg 3SM yyM pgk hQk wiM wyM syM lSM nBM ryM tBs 3xU
  JBY nAE OAM 1CM 1iM JiE 6h8 zyM 1SM IQI PAI KgI lwQ YgQ OwQ QgQ 2SM NSE 3CM
  lA mAY ) AUAZUBEFZXCGUCHZGUDHZGUEHZGUFHZGUGHZUHIIIIIZXDJKJUIHLMXEJKJUJHLMNXFJ
  KJUKHLMNXGJKJULHLMNZGKXELZGKXFLZUMZXHJKJUNHLMUOZXFXLXKUPMZXGGKXGLXKUQMZNZXHJK
  JURHLMZNZUOZUSZNZVBZOPZEFZFXBQXBQXBBVCZOQYCLZVDZBVEZVFZXCXCYEAVGXCYDEXCXIVHPZ
  YBRPZFYDXCYKYLAVIXCXJRPZYARPZFYLXCYMYNAVJXCXMVKPZXNVLPZFZXTVLPZFYNXCYQYRXCYOY
  PAVMAVNSXCXSRPZYRXCXQRPZXRRPZFYSXCYTUUAXCXORPZXPRPZFYTXCUUBUUCAVOAVPSXOXPVQTA
  VRSXQXRVQTXSVSTSXMXNXTVTTSXJYAVQTSXIYBWATXCEWBWCSSYCXBQXBABCWDZBVEZVFZYJXBQXB
  ABDWEBVEZVFZXCCWFZOPZEFZYEDWGZOPEFZBCDABWHABCWIYCYEYJUUKUUFCUTZYCYDEUUJEUUNYC
  YCOUUIOUUNYCUUNVAZOYCUUNWJZWKEYCUUNWJWLXBYIXBUUEYCUUNXBYCUUNWJZQXBYHQXBUUDYCB
  UUNQYCUUNWJZUUQQXBYFYGQXBYFOQUUILYCUUNUURUUQYFYCUUNWJOQYCOQUUIYCUUNUUPUURUUOW
  MWNWOWPWTUULUUMUUHUUKUUFUUNCDWQXBUUGXBUUEUULUUNACDWRABCDWSWPWTXAT $. $}
