$c Uw Ngk #Symbol 7h4 DBE 8Q4 zw YQk pgg #Pattern 0Q4 rwg Ex0 0wM xB4 tQM 0h4 Wgk #Variable SwE PQk #SetVariable iA vR4 4w rwM #ElementVariable IQE qxs mwg xQg 8hw cBQ kBM 2R4 zBA XBI PgE Tw cwE wQM -g4 rgk ( RQ0 twM .gM LAQ ewk IAQ Hg8 Kw8 OA0 hgk 7BI ) $.
$v th1 CQ -Bw Bw Cw sgg ngg z ph2 3gg Ew ph0 5Qg x Lw LQ Ow qwg DQ ph1 EQ y th2 tAg Dw HQ 4wg xX Gw th0 Hw Kw oAg 6Ag GQ nR4 tgg 4Ag $.
$d z y $.
$d z x $.
$d y x $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Cg $f #Pattern Cw $.
DA $f #Pattern DQ $.
Dg $f #Pattern Dw $.
EA $f #Pattern EQ $.
Eg $f #Pattern Ew $.
GA $f #Pattern GQ $.
Gg $f #Pattern Gw $.
HA $f #Pattern HQ $.
Hg $f #Pattern Hw $.
Kg $f #ElementVariable Kw $.
LA $f #ElementVariable LQ $.
Lg $f #ElementVariable Lw $.
Og $f #Variable Ow $.
SA $a #Variable Kw $.
Tg $a #Pattern ( Tw Bw CQ ) $.
Ug $a #Pattern ( Uw Kw Bw ) $.
jg $a iA Bw Ow Bw Ow $.
${ kg $e iA CQ DQ Bw Ow $.
   kw $e iA Cw Dw Bw Ow $.
   lA $a iA ( Tw CQ Cw ) ( Tw DQ Dw ) Bw Ow $. $}
4g $a #Pattern ( 4w Bw CQ ) $.
5Q $a zw ( Tw Bw ( Tw CQ Bw ) ) $.
${ 6A $e zw ( Tw Bw CQ ) $.
   6Q $e zw Bw $.
   6g $a zw CQ $. $}
IAE $a #Pattern IQE $.
PQE $a #Pattern ( PgE Bw CQ ) $.
SgE $a #Pattern ( SwE Bw CQ ) $.
lQE $a zw ( Tw Bw Bw ) $.
${ lgE $e zw ( Tw Bw CQ ) $.
   lwE $e zw ( Tw CQ Cw ) $.
   mAE $a zw ( Tw Bw Cw ) $. $}
nAE $a zw IQE $.
ugE $a zw ( Tw ( 4w Bw CQ ) Bw ) $.
uwE $a zw ( Tw ( 4w Bw CQ ) CQ ) $.
${ wAE $e zw ( Tw Bw CQ ) $.
   wQE $e zw ( Tw Bw Cw ) $.
   wgE $a zw ( Tw Bw ( 4w CQ Cw ) ) $. $}
${ $d xX ph0 $.
   IQI $a iA Bw Bw CQ Ow $. $}
${ KAI $e iA CQ DQ Bw Ow $.
   KQI $e iA Cw Dw Bw Ow $.
   KgI $a iA ( 4w CQ Cw ) ( 4w DQ Dw ) Bw Ow $. $}
${ OgI $e iA CQ DQ Bw Ow $.
   OwI $e iA Cw Dw Bw Ow $.
   PAI $a iA ( SwE CQ Cw ) ( SwE DQ Dw ) Bw Ow $. $}
${ NwM $e zw CQ $.
   OAM $a zw ( Tw Bw CQ ) $. $}
tAM $a #Pattern ( tQM Bw CQ ) $.
uwM $a #Pattern ( twM Bw ) $.
wAM $a #Pattern ( wQM Bw CQ Cw ) $.
.QM $a #Pattern ( .gM Bw CQ Cw ) $.
HwQ $a #Pattern ( IAQ Bw CQ ) $.
KwQ $a #Pattern ( LAQ Bw CQ Cw ) $.
${ QAQ $e iA Bw Cw Dw Ow $.
   QQQ $e iA CQ DQ Dw Ow $.
   QgQ $a iA ( tQM Bw CQ ) ( tQM Cw DQ ) Dw Ow $. $}
${ SgQ $e iA Bw DQ Ew Ow $.
   SwQ $e iA CQ Dw Ew Ow $.
   TAQ $e iA Cw EQ Ew Ow $.
   TQQ $a iA ( wQM Bw CQ Cw ) ( wQM DQ Dw EQ ) Ew Ow $. $}
${ awQ $e iA Bw DQ Ew Ow $.
   bAQ $e iA CQ Dw Ew Ow $.
   bQQ $e iA Cw EQ Ew Ow $.
   bgQ $a iA ( .gM Bw CQ Cw ) ( .gM DQ Dw EQ ) Ew Ow $. $}
${ $d z ph0 $.
   $d z ph1 $.
   $d z ph2 $.
   $d z y $.
   $d z x $.
   $d z th1 $.
   $d z th2 $.
   $d x ph0 $.
   $d y th0 $.
   lAY $e zw ( Tw GQ ( Uw Kw ( PgE Kw Bw ) ) ) $.
   lQY $e zw ( Tw ( 4w GQ Gw ) CQ ) $.
   lgY $e iA ( Tw HQ Cw ) ( Tw Gw CQ ) Bw LQ $.
   lwY $e iA ( Tw Hw DQ ) ( Tw Gw CQ ) Lw LQ $.
   mAY $a zw ( Tw ( 4w GQ HQ ) Cw ) $. $}
${ $d x ph0 $.
   $d x ph1 $.
   vwY $e zw ( Tw GQ ( SwE CQ Bw ) ) $.
   wAY $e zw ( Tw GQ ( tQM cwE ( rwM Bw cwE Kw ( 0wM Bw cwE Kw CQ ) ) ) ) $.
   wQY $a zw ( Tw GQ ( Uw Kw ( PgE Kw CQ ) ) ) $. $}
mgg $a #Pattern mwg $.
nQg $f #Variable ngg $.
nwg $f #Pattern oAg $.
pQg $a #Pattern pgg $.
qgg $f #Pattern qwg $.
rgg $a #Pattern ( rwg oAg qwg ) $.
sQg $f #Pattern sgg $.
swg $f #Pattern tAg $.
tQg $f #Pattern tgg $.
${ uQg $e iA qwg tAg oAg ngg $.
   ugg $e iA sgg tgg oAg ngg $.
   uwg $a iA ( rwg qwg sgg ) ( rwg tAg tgg ) oAg ngg $. $}
wQg $a zw ( Tw ( 4w ( SwE oAg pgg ) ( SwE qwg mwg ) ) ( SwE ( rwg oAg qwg ) mwg ) ) $.
xAg $a #Pattern xQg $.
yAg $a zw ( SwE xQg mwg ) $.
3Qg $f #ElementVariable 3gg $.
3wg $f #ElementVariable 4Ag $.
4gg $f #ElementVariable 4wg $.
5Ag $f #ElementVariable 5Qg $.
5wg $f #ElementVariable 6Ag $.
NQk $a #Pattern Ngk $.
PAk $a #Pattern PQk $.
WQk $a #Pattern Wgk $.
egk $a #Pattern ewk $.
hQk $a #Pattern hgk $.
rQk $a #Pattern rgk $.
Nw0 $a #Pattern ( OA0 oAg ) $.
QQ0 $a zw ( Tw ( SwE oAg mwg ) ( SwE ( OA0 oAg ) pgg ) ) $.
RA0 $a #Pattern ( RQ0 oAg qwg ) $.
UQ0 $a zw ( Tw ( 4w ( SwE oAg mwg ) ( SwE qwg mwg ) ) ( SwE ( RQ0 oAg qwg ) pgg ) ) $.
0A4 $a #Pattern ( 0Q4 oAg qwg ) $.
${ 1Q4 $e iA qwg tAg oAg ngg $.
   1g4 $e iA sgg tgg oAg ngg $.
   1w4 $a iA ( 0Q4 qwg sgg ) ( 0Q4 tAg tgg ) oAg ngg $. $}
8A4 $a #Pattern ( 8Q4 oAg ) $.
-Q4 $a #Pattern ( -g4 oAg qwg ) $.
${ Ag8 $e iA qwg tAg oAg ngg $.
   Aw8 $e iA sgg tgg oAg ngg $.
   BA8 $a iA ( -g4 qwg sgg ) ( -g4 tAg tgg ) oAg ngg $. $}
HQ8 $a #Pattern ( Hg8 oAg ) $.
${ Ig8 $e iA qwg sgg oAg ngg $.
   Iw8 $a iA ( Hg8 qwg ) ( Hg8 sgg ) oAg ngg $. $}
Kg8 $a #Pattern ( Kw8 oAg ) $.
yxA $a #Pattern ( zBA oAg qwg ) $.
CxE $a #Pattern ( DBE oAg qwg ) $.
WxI $a #Pattern ( XBI oAg qwg ) $.
6xI $a #Pattern ( 7BI oAg qwg ) $.
jxM $a #Pattern ( kBM oAg qwg ) $.
qhs $a #Pattern ( qxs oAg ) $.
8Rw $a #Pattern 8hw $.
.xw $f #ElementVariable -Bw $.
Eh0 $a #Pattern Ex0 $.
nB4 $f #ElementVariable nR4 $.
vB4 $a #Pattern vR4 $.
wx4 $a #Pattern xB4 $.
0R4 $a #Pattern 0h4 $.
2B4 $a #Pattern 2R4 $.
7R4 $a #Pattern 7h4 $.
JB8 $a zw ( Tw IQE ( SwE xQg mwg ) ) $.
VB8 $a zw ( Tw IQE ( SwE ( rwg ( LAQ hgk pgg ( qxs ( XBI ( IAQ ewk xB4 ) ( LAQ rgk Wgk ( IAQ rgk 8hw ) ) ) ) ) xQg ) mwg ) ) $.
VR8 $a zw ( Tw IQE ( SwE ( rwg ( LAQ hgk pgg ( qxs ( kBM ( kBM ( XBI ( IAQ ewk vR4 ) ( DBE ( LAQ ewk Wgk ( IAQ ewk vR4 ) ) ( LAQ ewk Wgk ( IAQ ewk 2R4 ) ) ) ) ( XBI ( IAQ ewk 7h4 ) ( zBA ( LAQ ewk Wgk ( IAQ ewk 7h4 ) ) ( LAQ ewk Wgk ( IAQ ewk 2R4 ) ) ) ) ) ( XBI ( IAQ ewk xB4 ) ( LAQ rgk Wgk ( IAQ rgk Ex0 ) ) ) ) ) ) xQg ) mwg ) ) $.
6h8 $a #Pattern nR4 $.
YyA $a zw ( Tw IQE ( SwE ( OA0 ( rwg ( LAQ rgk pgg ( IAQ rgk 0h4 ) ) xQg ) ) pgg ) ) $.
BCE $a #Pattern 6Ag $.
BCQ $a #Pattern 4Ag $.
RyQ $a iA Ngk Ngk nR4 4Ag $.
XiU $a #Pattern 3gg $.
XyU $a #Pattern 4wg $.
YCU $a #Pattern 5Qg $.
iCc $a iA ( 4w ( SwE nR4 mwg ) IQE ) ( 4w ( SwE 4Ag mwg ) IQE ) nR4 4Ag $.
yyg $a #Pattern -Bw $.
2yw $a #Pattern ( 4w ( SwE 5Qg ewk ) ( 4w ( SwE -Bw YQk ) IQE ) ) $.
6Sw $a #Pattern ( rwg ( LAQ ewk pgg 5Qg ) 4Ag ) $.
6iw $a #Pattern ( cBQ ( LAQ ewk pgg 5Qg ) 4wg ) $.
6yw $a #Pattern ( rwg 4wg 4Ag ) $.
Iy0 $a zw ( Tw ( 4w ( 4w ( SwE 3gg PQk ) ( 4w ( SwE 4wg pgg ) ( 4w ( SwE 5Qg ewk ) ( 4w ( SwE -Bw YQk ) IQE ) ) ) ) ( 4w ( SwE 4Ag mwg ) IQE ) ) ( tQM Ngk ( .gM Ngk ( wQM Ngk ( twM Ngk ) ( -g4 ( 0Q4 ( Hg8 ( rwg ( LAQ ewk pgg 5Qg ) 4Ag ) ) ( wQM PQk ( Kw8 ( 7BI ( cBQ ( LAQ ewk pgg 5Qg ) 4wg ) -Bw ) ) 3gg ) ) ( 8Q4 ( IAQ rgk 8hw ) ) ) ) ( wQM Ngk ( twM Ngk ) ( -g4 ( 0Q4 ( Hg8 ( rwg 4wg 4Ag ) ) 3gg ) ( 8Q4 ( IAQ rgk 8hw ) ) ) ) ) ) ) $.
JC0 $a #Pattern ( rwg ( LAQ ewk pgg 5Qg ) nR4 ) $.
JS0 $a #Pattern ( rwg 4wg nR4 ) $.
Ji0 $a iA ( Hg8 ( rwg ( LAQ ewk pgg 5Qg ) nR4 ) ) ( Hg8 ( rwg ( LAQ ewk pgg 5Qg ) 4Ag ) ) nR4 4Ag $.
Ky0 $a iA ( wQM Ngk ( twM Ngk ) ( -g4 ( 0Q4 ( Hg8 ( rwg 4wg nR4 ) ) 3gg ) ( 8Q4 ( IAQ rgk 8hw ) ) ) ) ( wQM Ngk ( twM Ngk ) ( -g4 ( 0Q4 ( Hg8 ( rwg 4wg 4Ag ) ) 3gg ) ( 8Q4 ( IAQ rgk 8hw ) ) ) ) nR4 4Ag $.
LS0 $a zw ( Tw ( 4w ( SwE 3gg PQk ) ( 4w ( SwE 4wg pgg ) ( 4w ( SwE 5Qg ewk ) ( 4w ( SwE -Bw YQk ) IQE ) ) ) ) ( 4w ( SwE 5Qg ewk ) ( 4w ( SwE -Bw YQk ) IQE ) ) ) $.
SS0 $a zw ( Tw ( 4w ( SwE 3gg PQk ) ( 4w ( SwE 4wg pgg ) ( 4w ( SwE 5Qg ewk ) ( 4w ( SwE -Bw YQk ) IQE ) ) ) ) ( SwE ( RQ0 ( rwg ( LAQ hgk pgg ( qxs ( XBI ( IAQ ewk xB4 ) ( LAQ rgk Wgk ( IAQ rgk 8hw ) ) ) ) ) xQg ) ( rwg ( LAQ hgk pgg ( qxs ( kBM ( kBM ( XBI ( IAQ ewk vR4 ) ( DBE ( LAQ ewk Wgk ( IAQ ewk vR4 ) ) ( LAQ ewk Wgk ( IAQ ewk 2R4 ) ) ) ) ( XBI ( IAQ ewk 7h4 ) ( zBA ( LAQ ewk Wgk ( IAQ ewk 7h4 ) ) ( LAQ ewk Wgk ( IAQ ewk 2R4 ) ) ) ) ) ( XBI ( IAQ ewk xB4 ) ( LAQ rgk Wgk ( IAQ rgk Ex0 ) ) ) ) ) ) xQg ) ) pgg ) ) $.
1S4 $a zw ( Tw IQE ( tQM cwE ( rwM mwg cwE 6Ag ( 0wM mwg cwE 6Ag ( rwg ( OA0 ( rwg ( LAQ rgk pgg ( IAQ rgk 0h4 ) ) xQg ) ) ( rwg ( RQ0 ( rwg ( LAQ hgk pgg ( qxs ( XBI ( IAQ ewk xB4 ) ( LAQ rgk Wgk ( IAQ rgk 8hw ) ) ) ) ) xQg ) ( rwg ( LAQ hgk pgg ( qxs ( kBM ( kBM ( XBI ( IAQ ewk vR4 ) ( DBE ( LAQ ewk Wgk ( IAQ ewk vR4 ) ) ( LAQ ewk Wgk ( IAQ ewk 2R4 ) ) ) ) ( XBI ( IAQ ewk 7h4 ) ( zBA ( LAQ ewk Wgk ( IAQ ewk 7h4 ) ) ( LAQ ewk Wgk ( IAQ ewk 2R4 ) ) ) ) ) ( XBI ( IAQ ewk xB4 ) ( LAQ rgk Wgk ( IAQ rgk Ex0 ) ) ) ) ) ) xQg ) ) xQg ) ) ) ) ) ) $.
2C4 $a zw ( Tw ( 4w ( SwE 3gg PQk ) ( 4w ( SwE 4wg pgg ) ( 4w ( SwE 5Qg ewk ) ( 4w ( SwE -Bw YQk ) IQE ) ) ) ) ( SwE ( rwg ( LAQ rgk pgg ( IAQ rgk 0h4 ) ) xQg ) mwg ) ) $.
${ 2S4 $p zw ( Tw ( 4w ( SwE 3gg PQk ) ( 4w ( SwE 4wg pgg ) ( 4w ( SwE 5Qg ewk ) ( 4w ( SwE -Bw YQk ) IQE ) ) ) ) ( tQM Ngk ( .gM Ngk ( wQM Ngk ( twM Ngk ) ( -g4 ( 0Q4 ( Hg8 ( rwg ( LAQ ewk pgg 5Qg ) ( rwg ( OA0 ( rwg ( LAQ rgk pgg ( IAQ rgk 0h4 ) ) xQg ) ) ( rwg ( RQ0 ( rwg ( LAQ hgk pgg ( qxs ( XBI ( IAQ ewk xB4 ) ( LAQ rgk Wgk ( IAQ rgk 8hw ) ) ) ) ) xQg ) ( rwg ( LAQ hgk pgg ( qxs ( kBM ( kBM ( XBI ( IAQ ewk vR4 ) ( DBE ( LAQ ewk Wgk ( IAQ ewk vR4 ) ) ( LAQ ewk Wgk ( IAQ ewk 2R4 ) ) ) ) ( XBI ( IAQ ewk 7h4 ) ( zBA ( LAQ ewk Wgk ( IAQ ewk 7h4 ) ) ( LAQ ewk Wgk ( IAQ ewk 2R4 ) ) ) ) ) ( XBI ( IAQ ewk xB4 ) ( LAQ rgk Wgk ( IAQ rgk Ex0 ) ) ) ) ) ) xQg ) ) xQg ) ) ) ) ( wQM PQk ( Kw8 ( 7BI ( cBQ ( LAQ ewk pgg 5Qg ) 4wg ) -Bw ) ) 3gg ) ) ( 8Q4 ( IAQ rgk 8hw ) ) ) ) ( wQM Ngk ( twM Ngk ) ( -g4 ( 0Q4 ( Hg8 ( rwg 4wg ( rwg ( OA0 ( rwg ( LAQ rgk pgg ( IAQ rgk 0h4 ) ) xQg ) ) ( rwg ( RQ0 ( rwg ( LAQ hgk pgg ( qxs ( XBI ( IAQ ewk xB4 ) ( LAQ rgk Wgk ( IAQ rgk 8hw ) ) ) ) ) xQg ) ( rwg ( LAQ hgk pgg ( qxs ( kBM ( kBM ( XBI ( IAQ ewk vR4 ) ( DBE ( LAQ ewk Wgk ( IAQ ewk vR4 ) ) ( LAQ ewk Wgk ( IAQ ewk 2R4 ) ) ) ) ( XBI ( IAQ ewk 7h4 ) ( zBA ( LAQ ewk Wgk ( IAQ ewk 7h4 ) ) ( LAQ ewk Wgk ( IAQ ewk 2R4 ) ) ) ) ) ( XBI ( IAQ ewk xB4 ) ( LAQ rgk Wgk ( IAQ rgk Ex0 ) ) ) ) ) ) xQg ) ) xQg ) ) ) ) 3gg ) ( 8Q4 ( IAQ rgk 8hw ) ) ) ) ) ) ) $=
  ( 3wg nB4 SgE pQg 4g HwQ KwQ rgg egk mgg IAE NQk wAM mAE wgE IQI 5wg Tg 5Q 6g
  XiU PAk XyU 2yw rQk 0R4 xAg Nw0 hQk wx4 WQk 8Rw WxI qhs vB4 2B4 CxE 7R4 Ug SA
  yxA jxM Eh0 RA0 uwM YCU HQ8 6iw yyg 6xI Kg8 0A4 8A4 -Q4 .QM tAM ugE lQE jg lA
  uwE LS0 2C4 QQ0 SS0 yAg wQg nAE OAM 6Sw 6yw JC0 JS0 BCQ 6h8 BCE PQE YyA VB8
  VR8 UQ0 JB8 1S4 wQY Iy0 PAI KgI uwg Iw8 1w4 BA8 TQQ bgQ QgQ iCc RyQ Ji0 Ky0
  mAY ) AUEZUFGZBUGZHGZCDUHZIZIZYJUIHUIUJJKUKLZULZUMHMUNJZUIUOUIUPJZKUQURKUKLZU
  MHMUSJZMUOYPKMUOMUTJKZVAUQMVBJZMUOYRKYQVEUQVFYMUIUOUIVGJKUQVFURKUKLZVHZUKLZLZ
  NGZOIZIPPPPVIZMHCVJKZUUBLZVKZUFBCVLDVMVNVOYDQZVPZYNVQZVRZQZPUUEYFUUBLZVKZYDVP
  ZUUKVRZQZVSZVTZYJYJUUDYJYEYIYJYEYEYEYIWAYEWBRYJYGYHYJYIYGYEYIWEYIYGYGYGYHWAYG
  WBRRABCDWFSSYJUUCOYJYLHGZUUANGZIZUUCYJUVAUVBYJYKNGUVAABCDWGYKWHRYJYTHGZUKNGZI
  ZUVBYJUVDUVEABCDWIUVEYJUVEUBUVEYJUCWJUDSYTUKWKZRSYLUUAWKZRYJOWLWMZSSUUBPPPUUE
  ECWNZVKZUUIVPZUUKVRZQZPUUEEBWOZVKZYDVPZUUKVRZQZVSZVTZUUTPPPUUECFWPVKZUUIVPZUU
  KVRZQZPUUEBFWQVKYDVPUUKVRQZVSZVTZYJEWRZNGZOIZUUDFWSZNGOIZUAEFYJOUAWTUUBXAUAVC
  UVINUUBOUAOUVCUUCOUVAUVBXBOUVFUVBOUVDUVEOYONGZYSNGZIUVDOUWNUWOXCXDSYOYSXERXFS
  UVGRSUVHRUAXGXHRAEBCDXIUUBUUDUUTUWKUWAEVDZUUBUUCOUWJOUWPUUBUUBNUWINUWPUUBUWPW
  CZNUUBUWPTXJOUUBUWPTXKPUUSPUVTUUBUWPPUUBUWPTZPUUMUURPUVNUVSUUBUWPUWRPUUEUULPU
  UEUVMUUBUWPUWRUUEUUBUWPTZUWPUUBUUJUUKUVLUUKUWPUUBUUHUUIUVKUUIUWPUUBUUGUVJUWPU
  UBUUFUUBUUFUWIUUFUUBUWPTUWQXLXMUUIUUBUWPTXNUUKUUBUWPTZXOXPPUUEUUQPUUEUVRUUBUW
  PUWRUWSUWPUUBUUPUUKUVQUUKUWPUUBUUOYDUVPYDUWPUUBUUNUVOUWPUUBYFUUBYFUWIYFUUBUWP
  TUWQXLXMYDUUBUWPTXNUWTXOXPXQXRWDUWLUWMUWHUWKUWAUWPEFXSPUWGPUVTUWLUWPEFXTZPUWE
  UWFPUVNUVSUWLUWPUXAPUUEUWDPUUEUVMUWLUWPUXAUUEUWLUWPTUWPUWLUWCUUKUVLUUKUWPUWLU
  WBUUIUVKUUIECFYAUUIUWLUWPTXNUUKUWLUWPTXOXPAEBFYBXQXRWDYCR $. $}
