$c #SetVariable cwE iA ) #ElementVariable IQE #Symbol #Variable #Pattern ( $.
$v Ow CQ xX Bw Kw ph0 2gg Pw $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Kg $f #ElementVariable Kw $.
Og $f #Variable Ow $.
Pg $f #Symbol Pw $.
SA $a #Variable Kw $.
Sw $a #Pattern Pw $.
IAE $a #Pattern IQE $.
cgE $a #Symbol cwE $.
${ $d xX ph0 $.
   IQI $a iA Bw Bw CQ Ow $. $}
2Qg $f #ElementVariable 2gg $.
${ -B8 $p iA IQE IQE cwE 2gg $=
  ( IAE cgE Sw SA IQI ) BCDAEF $. $}
