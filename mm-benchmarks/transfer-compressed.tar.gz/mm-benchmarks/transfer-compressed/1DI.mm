$c Uw PgE Tw #Symbol 5x4 zw jww JAQ pgg rgk #Pattern ( rwg 0wM LAQ tQM IAQ #Variable SwE #SetVariable iA 4w rwM #ElementVariable IQE mwg xQg ) $.
$v th1 yhs Fw CQ Bw Cw 2gg sgg ngg FQ z ph2 Ew ph0 x Lw LQ Ow ph6 qwg DQ ph1 EQ y th2 -Rs Dw HQ xX Gw th0 Hw Kw oAg 6Ag GQ nR4 $.
$d z y $.
$d z x $.
$d y x $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Cg $f #Pattern Cw $.
DA $f #Pattern DQ $.
Dg $f #Pattern Dw $.
EA $f #Pattern EQ $.
Eg $f #Pattern Ew $.
FA $f #Pattern FQ $.
Fg $f #Pattern Fw $.
GA $f #Pattern GQ $.
Gg $f #Pattern Gw $.
HA $f #Pattern HQ $.
Hg $f #Pattern Hw $.
Kg $f #ElementVariable Kw $.
LA $f #ElementVariable LQ $.
Lg $f #ElementVariable Lw $.
Og $f #Variable Ow $.
SA $a #Variable Kw $.
jg $a iA Bw Ow Bw Ow $.
${ kg $e iA CQ DQ Bw Ow $.
   kw $e iA Cw Dw Bw Ow $.
   lA $a iA ( Tw CQ Cw ) ( Tw DQ Dw ) Bw Ow $. $}
4g $a #Pattern ( 4w Bw CQ ) $.
IAE $a #Pattern IQE $.
SgE $a #Pattern ( SwE Bw CQ ) $.
${ lgE $e zw ( Tw Bw CQ ) $.
   lwE $e zw ( Tw CQ Cw ) $.
   mAE $a zw ( Tw Bw Cw ) $. $}
${ wAE $e zw ( Tw Bw CQ ) $.
   wQE $e zw ( Tw Bw Cw ) $.
   wgE $a zw ( Tw Bw ( 4w CQ Cw ) ) $. $}
${ $d xX ph0 $.
   IQI $a iA Bw Bw CQ Ow $. $}
${ KAI $e iA CQ DQ Bw Ow $.
   KQI $e iA Cw Dw Bw Ow $.
   KgI $a iA ( 4w CQ Cw ) ( 4w DQ Dw ) Bw Ow $. $}
${ OgI $e iA CQ DQ Bw Ow $.
   OwI $e iA Cw Dw Bw Ow $.
   PAI $a iA ( SwE CQ Cw ) ( SwE DQ Dw ) Bw Ow $. $}
rgM $a #Pattern ( rwM Bw CQ Kw Cw ) $.
tAM $a #Pattern ( tQM Bw CQ ) $.
0gM $a #Pattern ( 0wM Bw CQ Cw DQ ) $.
HwQ $a #Pattern ( IAQ Bw CQ ) $.
IwQ $a #Pattern ( JAQ Bw ) $.
KwQ $a #Pattern ( LAQ Bw CQ Cw ) $.
${ $d xX y $.
   $d y ph6 $.
   OAQ $e iA Bw DQ Ew Ow $.
   OQQ $e iA CQ Dw Ew Ow $.
   OgQ $e iA Cw EQ Ew Ow $.
   OwQ $a iA ( rwM Bw CQ LQ Cw ) ( rwM DQ Dw LQ EQ ) Ew Ow $. $}
${ QAQ $e iA Bw Cw Dw Ow $.
   QQQ $e iA CQ DQ Dw Ow $.
   QgQ $a iA ( tQM Bw CQ ) ( tQM Cw DQ ) Dw Ow $. $}
${ XgQ $e iA Bw Dw Fw Ow $.
   XwQ $e iA CQ EQ Fw Ow $.
   YAQ $e iA Cw Ew Fw Ow $.
   YQQ $e iA DQ FQ Fw Ow $.
   YgQ $a iA ( 0wM Bw CQ Cw DQ ) ( 0wM Dw EQ Ew FQ ) Fw Ow $. $}
${ $d z ph0 $.
   $d z ph1 $.
   $d z ph2 $.
   $d z y $.
   $d z x $.
   $d z th1 $.
   $d z th2 $.
   $d x ph0 $.
   $d y th0 $.
   lAY $e zw ( Tw GQ ( Uw Kw ( PgE Kw Bw ) ) ) $.
   lQY $e zw ( Tw ( 4w GQ Gw ) CQ ) $.
   lgY $e iA ( Tw HQ Cw ) ( Tw Gw CQ ) Bw LQ $.
   lwY $e iA ( Tw Hw DQ ) ( Tw Gw CQ ) Lw LQ $.
   mAY $a zw ( Tw ( 4w GQ HQ ) Cw ) $. $}
mgg $a #Pattern mwg $.
nQg $f #Variable ngg $.
nwg $f #Pattern oAg $.
pQg $a #Pattern pgg $.
qgg $f #Pattern qwg $.
rgg $a #Pattern ( rwg oAg qwg ) $.
sQg $f #Pattern sgg $.
xAg $a #Pattern xQg $.
2Qg $f #ElementVariable 2gg $.
5wg $f #ElementVariable 6Ag $.
rQk $a #Pattern rgk $.
jgw $a #Pattern ( jww oAg ) $.
${ kww $e iA qwg sgg oAg ngg $.
   lAw $a iA ( jww qwg ) ( jww sgg ) oAg ngg $. $}
yRs $f #ElementVariable yhs $.
-Bs $f #ElementVariable -Rs $.
nB4 $f #ElementVariable nR4 $.
5h4 $a #Pattern 5x4 $.
Wh8 $a #Pattern 2gg $.
6h8 $a #Pattern nR4 $.
9h8 $a zw ( Tw ( 4w ( JAQ 2gg ) IQE ) ( 4w ( JAQ 2gg ) IQE ) ) $.
7SA $a #Pattern yhs $.
QyE $a #Pattern -Rs $.
Nyw $a iA ( 4w ( SwE nR4 mwg ) IQE ) ( 4w ( SwE -Rs mwg ) IQE ) nR4 -Rs $.
yTI $a zw ( Tw ( 4w ( JAQ 2gg ) IQE ) ( Uw 6Ag ( PgE 6Ag ( rwg ( LAQ rgk pgg ( IAQ rgk 5x4 ) ) xQg ) ) ) ) $.
yjI $a #Pattern ( 0wM pgg 2gg yhs ( jww -Rs ) ) $.
yzI $a zw ( Tw ( 4w ( 4w ( JAQ 2gg ) IQE ) ( 4w ( SwE -Rs mwg ) IQE ) ) ( tQM 2gg ( rwM pgg 2gg yhs ( 0wM pgg 2gg yhs ( jww -Rs ) ) ) ) ) $.
zDI $a #Pattern ( 0wM pgg 2gg yhs ( jww nR4 ) ) $.
0DI $a iA ( tQM 2gg ( rwM pgg 2gg yhs ( 0wM pgg 2gg yhs ( jww nR4 ) ) ) ) ( tQM 2gg ( rwM pgg 2gg yhs ( 0wM pgg 2gg yhs ( jww -Rs ) ) ) ) nR4 -Rs $.
0zI $a zw ( Tw ( 4w ( JAQ 2gg ) IQE ) ( 4w ( SwE ( rwg ( LAQ rgk pgg ( IAQ rgk 5x4 ) ) xQg ) mwg ) IQE ) ) $.
${ 1DI $p zw ( Tw ( 4w ( JAQ 2gg ) IQE ) ( tQM 2gg ( rwM pgg 2gg yhs ( 0wM pgg 2gg yhs ( jww ( rwg ( LAQ rgk pgg ( IAQ rgk 5x4 ) ) xQg ) ) ) ) ) ) $=
  ( -Bs nB4 5wg Wh8 IwQ IAE 4g rQk pQg 5h4 HwQ mgg SgE jgw rgM tAM IQI lA SA jg
  KwQ xAg rgg 7SA 0gM 9h8 0zI wgE yjI zDI QyE 6h8 yTI yzI PAI KgI lAw YgQ OwQ
  QgQ Nyw 0DI mAY mAE ) AFZGHIZVHJKJLMUCUDUEZNOZHIZIVGKVGKVGBUFZVIPZUGZBQZRZVHV
  HVKAUHAUIUJVIVGKVGABCUKZBQZRZVPVGKVGABDULBQRZVHCUMZNOZHIZVKDUNZNOHIZECDAEUOAB
  CUPVIVKVPWCVSCUAZVIVJHWBHWFVIVINWANWFVIWFUBZNVIWFSUQHVIWFSURVGVOVGVRVIWFVGVIW
  FSZKVGVNKVGVQVIBWFKVIWFSZWHKVGVLVMKVGVLWAPVIWFWIWHVLVIWFSWFVIVIWAWGUSUTVAVBTW
  DWEVTWCVSWFCDVCABCDVDTVEVF $. $}
