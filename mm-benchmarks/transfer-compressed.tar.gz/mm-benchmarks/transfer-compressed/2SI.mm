$c Uw 2R4 PgE Tw #Symbol cwE zw JAQ #Pattern ( 0wM LAQ ewk tQM IAQ Wgk #Variable SwE #SetVariable 4w rwM #ElementVariable IQE ) $.
$v yhs CQ Bw XRw Kw ph1 Cw 2gg ph0 GQ x $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Cg $f #Pattern Cw $.
GA $f #Pattern GQ $.
Kg $f #ElementVariable Kw $.
Ug $a #Pattern ( Uw Kw Bw ) $.
IAE $a #Pattern IQE $.
PQE $a #Pattern ( PgE Bw CQ ) $.
${ lgE $e zw ( Tw Bw CQ ) $.
   lwE $e zw ( Tw CQ Cw ) $.
   mAE $a zw ( Tw Bw Cw ) $. $}
nAE $a zw IQE $.
${ NwM $e zw CQ $.
   OAM $a zw ( Tw Bw CQ ) $. $}
HwQ $a #Pattern ( IAQ Bw CQ ) $.
KwQ $a #Pattern ( LAQ Bw CQ Cw ) $.
${ $d x ph0 $.
   $d x ph1 $.
   vwY $e zw ( Tw GQ ( SwE CQ Bw ) ) $.
   wAY $e zw ( Tw GQ ( tQM cwE ( rwM Bw cwE Kw ( 0wM Bw cwE Kw CQ ) ) ) ) $.
   wQY $a zw ( Tw GQ ( Uw Kw ( PgE Kw CQ ) ) ) $. $}
2Qg $f #ElementVariable 2gg $.
WQk $a #Pattern Wgk $.
egk $a #Pattern ewk $.
yRs $f #ElementVariable yhs $.
XBw $f #ElementVariable XRw $.
2B4 $a #Pattern 2R4 $.
Fh8 $a zw ( Tw IQE ( SwE ( LAQ ewk Wgk ( IAQ ewk 2R4 ) ) Wgk ) ) $.
7SA $a #Pattern yhs $.
CCI $a #Pattern ( 4w ( JAQ 2gg ) ( 4w ( SwE XRw Wgk ) IQE ) ) $.
2CI $a zw ( Tw IQE ( tQM cwE ( rwM Wgk cwE yhs ( 0wM Wgk cwE yhs ( LAQ ewk Wgk ( IAQ ewk 2R4 ) ) ) ) ) ) $.
${ 2SI $p zw ( Tw ( 4w ( JAQ 2gg ) ( 4w ( SwE XRw Wgk ) IQE ) ) ( Uw yhs ( PgE yhs ( LAQ ewk Wgk ( IAQ ewk 2R4 ) ) ) ) ) $=
  ( CCI IAE 7SA egk WQk 2B4 HwQ KwQ PQE Ug nAE OAM Fh8 2CI wQY mAE ) ACDZEBFGHG
  IJKZLBMTENOHUAEBPBQRS $. $}
