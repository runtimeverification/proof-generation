$c ww4 #Symbol #Variable SwE #SetVariable iA 4w YQk #ElementVariable IQE #Pattern ) ( $.
$v Ow CQ xX DQ Bw Kw ph0 Cw pxw Dw $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Cg $f #Pattern Cw $.
DA $f #Pattern DQ $.
Dg $f #Pattern Dw $.
Kg $f #ElementVariable Kw $.
Og $f #Variable Ow $.
SA $a #Variable Kw $.
jg $a iA Bw Ow Bw Ow $.
IAE $a #Pattern IQE $.
SgE $a #Pattern ( SwE Bw CQ ) $.
${ $d xX ph0 $.
   IQI $a iA Bw Bw CQ Ow $. $}
${ KAI $e iA CQ DQ Bw Ow $.
   KQI $e iA Cw Dw Bw Ow $.
   KgI $a iA ( 4w CQ Cw ) ( 4w DQ Dw ) Bw Ow $. $}
${ OgI $e iA CQ DQ Bw Ow $.
   OwI $e iA Cw Dw Bw Ow $.
   PAI $a iA ( SwE CQ Cw ) ( SwE DQ Dw ) Bw Ow $. $}
YAk $a #Pattern YQk $.
wg4 $a #Pattern ww4 $.
phw $f #ElementVariable pxw $.
sCY $a #Pattern pxw $.
${ 1iY $p iA ( 4w ( SwE ww4 YQk ) IQE ) ( 4w ( SwE pxw YQk ) IQE ) ww4 pxw $=
  ( wg4 YAk SgE IAE sCY SA jg IQI PAI KgI ) BBCDEAFZCDEAGZBBCLCMBMHCBMIJEBMIK
  $. $}
