$c ewk IAQ 3BA 7h4 #Symbol #Variable #SetVariable GBY ) #ElementVariable #Pattern ( $.
$v oAg 5Qg 4wg CQ qwg Bw $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
HwQ $a #Pattern ( IAQ Bw CQ ) $.
nwg $f #Pattern oAg $.
qgg $f #Pattern qwg $.
4gg $f #ElementVariable 4wg $.
5Ag $f #ElementVariable 5Qg $.
egk $a #Pattern ewk $.
2xA $a #Pattern ( 3BA oAg qwg ) $.
FxY $a #Pattern ( GBY oAg qwg ) $.
7R4 $a #Pattern 7h4 $.
XyU $a #Pattern 4wg $.
YCU $a #Pattern 5Qg $.
${ -iY $p #Pattern ( GBY ( 3BA ( IAQ ewk 7h4 ) 5Qg ) 4wg ) $=
  ( egk 7R4 HwQ YCU 2xA XyU FxY ) CDEBFGAHI $. $}
