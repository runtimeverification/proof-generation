$c ewk #Symbol Tw #Variable SwE #SetVariable zw 4w JAQ #ElementVariable IQE pgg #Pattern ) ( $.
$v 5Qg Cw CQ Bw $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Cg $f #Pattern Cw $.
4g $a #Pattern ( 4w Bw CQ ) $.
IAE $a #Pattern IQE $.
SgE $a #Pattern ( SwE Bw CQ ) $.
${ wAE $e zw ( Tw Bw CQ ) $.
   wQE $e zw ( Tw Bw Cw ) $.
   wgE $a zw ( Tw Bw ( 4w CQ Cw ) ) $. $}
IwQ $a #Pattern ( JAQ Bw ) $.
pQg $a #Pattern pgg $.
5Ag $f #ElementVariable 5Qg $.
egk $a #Pattern ewk $.
YCU $a #Pattern 5Qg $.
3jE $a zw ( Tw ( 4w ( SwE 5Qg ewk ) IQE ) ( JAQ ewk ) ) $.
3zE $a zw ( Tw ( 4w ( SwE 5Qg ewk ) IQE ) ( JAQ pgg ) ) $.
${ 4DE $p zw ( Tw ( 4w ( SwE 5Qg ewk ) IQE ) ( 4w ( JAQ ewk ) ( JAQ pgg ) ) ) $=
  ( YCU egk SgE IAE 4g IwQ pQg 3jE 3zE wgE ) ABCDEFCGHGAIAJK $. $}
