$c #SetVariable ) #ElementVariable #Symbol #Variable #Pattern ( $.
$v Ow 0R8 Kw $.
Kg $f #ElementVariable Kw $.
Og $f #Variable Ow $.
SA $a #Variable Kw $.
Sg $a #Pattern Ow $.
0B8 $f #ElementVariable 0R8 $.
${ 1h8 $p #Pattern 0R8 $=
  ( SA Sg ) ABC $. $}
