$c 2R4 Tw #Symbol zw JAQ .gk Px0 pgg #Pattern ( rwg 0wM LAQ ewk tQM IAQ #Variable #SetVariable 4w #ElementVariable IQE xQg ) Vhc $.
$v CQ qwg DQ Bw oAg Cw 2gg $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Cg $f #Pattern Cw $.
DA $f #Pattern DQ $.
4g $a #Pattern ( 4w Bw CQ ) $.
IAE $a #Pattern IQE $.
${ lgE $e zw ( Tw Bw CQ ) $.
   lwE $e zw ( Tw CQ Cw ) $.
   mAE $a zw ( Tw Bw Cw ) $. $}
nAE $a zw IQE $.
${ wAE $e zw ( Tw Bw CQ ) $.
   wQE $e zw ( Tw Bw Cw ) $.
   wgE $a zw ( Tw Bw ( 4w CQ Cw ) ) $. $}
${ NwM $e zw CQ $.
   OAM $a zw ( Tw Bw CQ ) $. $}
tAM $a #Pattern ( tQM Bw CQ ) $.
0gM $a #Pattern ( 0wM Bw CQ Cw DQ ) $.
HwQ $a #Pattern ( IAQ Bw CQ ) $.
IwQ $a #Pattern ( JAQ Bw ) $.
KwQ $a #Pattern ( LAQ Bw CQ Cw ) $.
nwg $f #Pattern oAg $.
pQg $a #Pattern pgg $.
qgg $f #Pattern qwg $.
rgg $a #Pattern ( rwg oAg qwg ) $.
xAg $a #Pattern xQg $.
2Qg $f #ElementVariable 2gg $.
egk $a #Pattern ewk $.
.Qk $a #Pattern .gk $.
VRc $a #Pattern ( Vhc oAg ) $.
Ph0 $a #Pattern Px0 $.
2B4 $a #Pattern 2R4 $.
Wh8 $a #Pattern 2gg $.
.h8 $a zw ( Tw ( 4w IQE ( 4w ( JAQ 2gg ) IQE ) ) ( JAQ 2gg ) ) $.
0Cw $a zw ( Tw ( 4w ( JAQ 2gg ) IQE ) ( tQM 2gg ( 0wM .gk 2gg ( Vhc ( rwg ( LAQ ewk pgg ( IAQ ewk 2R4 ) ) xQg ) ) ( IAQ .gk Px0 ) ) ) ) $.
${ 0Sw $p zw ( Tw ( 4w IQE ( 4w ( JAQ 2gg ) IQE ) ) ( tQM 2gg ( 0wM .gk 2gg ( Vhc ( rwg ( LAQ ewk pgg ( IAQ ewk 2R4 ) ) xQg ) ) ( IAQ .gk Px0 ) ) ) ) $=
  ( IAE Wh8 IwQ 4g .Qk egk pQg 2B4 HwQ KwQ xAg rgg VRc Ph0 0gM tAM .h8 nAE OAM
  wgE 0Cw mAE ) BACZDZBEZEZUFUDFUDGHGIJKLMNFOJPQUGUEBARUGBSTUAAUBUC $. $}
