$c ewk #Symbol Tw #Variable SwE #SetVariable zw 4w JAQ #ElementVariable IQE #Pattern ) ( $.
$v 5Qg CQ Bw $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Tg $a #Pattern ( Tw Bw CQ ) $.
4g $a #Pattern ( 4w Bw CQ ) $.
5Q $a zw ( Tw Bw ( Tw CQ Bw ) ) $.
${ 6A $e zw ( Tw Bw CQ ) $.
   6Q $e zw Bw $.
   6g $a zw CQ $. $}
IAE $a #Pattern IQE $.
SgE $a #Pattern ( SwE Bw CQ ) $.
IwQ $a #Pattern ( JAQ Bw ) $.
5Ag $f #ElementVariable 5Qg $.
egk $a #Pattern ewk $.
fgk $a zw ( JAQ ewk ) $.
YCU $a #Pattern 5Qg $.
${ 3jE $p zw ( Tw ( 4w ( SwE 5Qg ewk ) IQE ) ( JAQ ewk ) ) $=
  ( egk IwQ YCU SgE IAE 4g Tg 5Q fgk 6g ) BCZADBEFGZLHLMIJK $. $}
