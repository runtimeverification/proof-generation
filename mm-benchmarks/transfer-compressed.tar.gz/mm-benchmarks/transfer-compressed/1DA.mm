$c #SetVariable iA ) pwk #ElementVariable #Symbol #Variable #Pattern ( $.
$v Ow CQ xX lB4 Kw Bw ph0 6xw $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Kg $f #ElementVariable Kw $.
Og $f #Variable Ow $.
SA $a #Variable Kw $.
${ $d xX ph0 $.
   IQI $a iA Bw Bw CQ Ow $. $}
pgk $a #Pattern pwk $.
6hw $f #ElementVariable 6xw $.
kx4 $f #ElementVariable lB4 $.
dB8 $a #Pattern 6xw $.
${ 1DA $p iA pwk pwk 6xw lB4 $=
  ( pgk dB8 SA IQI ) CADBEF $. $}
