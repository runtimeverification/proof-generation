$c #SetVariable iA ) #ElementVariable .gk #Symbol #Variable #Pattern ( $.
$v Ow CQ xX -Bw Bw Kw ph0 nR4 $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Kg $f #ElementVariable Kw $.
Og $f #Variable Ow $.
SA $a #Variable Kw $.
${ $d xX ph0 $.
   IQI $a iA Bw Bw CQ Ow $. $}
.Qk $a #Pattern .gk $.
.xw $f #ElementVariable -Bw $.
nB4 $f #ElementVariable nR4 $.
6h8 $a #Pattern nR4 $.
${ -S0 $p iA .gk .gk nR4 -Bw $=
  ( .Qk 6h8 SA IQI ) CBDAEF $. $}
