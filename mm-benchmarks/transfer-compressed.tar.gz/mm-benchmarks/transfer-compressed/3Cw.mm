$c Uw PgE RAk Tw #Symbol cwE 8Q4 zw YQk rgk pgg #Pattern ( 0wM ewk tQM IAQ #Variable SwE PQk #SetVariable 4w rwM #ElementVariable IQE mwg 8hw ) $.
$v yhs 4wg CQ 3gg -Bw Bw Kw ph1 oAg 5Qg ph0 GQ Cw x 4Ag $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Cg $f #Pattern Cw $.
GA $f #Pattern GQ $.
Kg $f #ElementVariable Kw $.
Ug $a #Pattern ( Uw Kw Bw ) $.
4g $a #Pattern ( 4w Bw CQ ) $.
IAE $a #Pattern IQE $.
PQE $a #Pattern ( PgE Bw CQ ) $.
SgE $a #Pattern ( SwE Bw CQ ) $.
${ lgE $e zw ( Tw Bw CQ ) $.
   lwE $e zw ( Tw CQ Cw ) $.
   mAE $a zw ( Tw Bw Cw ) $. $}
nAE $a zw IQE $.
${ NwM $e zw CQ $.
   OAM $a zw ( Tw Bw CQ ) $. $}
HwQ $a #Pattern ( IAQ Bw CQ ) $.
${ $d x ph0 $.
   $d x ph1 $.
   vwY $e zw ( Tw GQ ( SwE CQ Bw ) ) $.
   wAY $e zw ( Tw GQ ( tQM cwE ( rwM Bw cwE Kw ( 0wM Bw cwE Kw CQ ) ) ) ) $.
   wQY $a zw ( Tw GQ ( Uw Kw ( PgE Kw CQ ) ) ) $. $}
mgg $a #Pattern mwg $.
nwg $f #Pattern oAg $.
pQg $a #Pattern pgg $.
3Qg $f #ElementVariable 3gg $.
3wg $f #ElementVariable 4Ag $.
4gg $f #ElementVariable 4wg $.
5Ag $f #ElementVariable 5Qg $.
PAk $a #Pattern PQk $.
Qwk $a #Pattern RAk $.
rQk $a #Pattern rgk $.
8A4 $a #Pattern ( 8Q4 oAg ) $.
yRs $f #ElementVariable yhs $.
8Rw $a #Pattern 8hw $.
.xw $f #ElementVariable -Bw $.
Kx8 $a zw ( Tw IQE ( SwE ( 8Q4 ( IAQ rgk 8hw ) ) RAk ) ) $.
7SA $a #Pattern yhs $.
BCQ $a #Pattern 4Ag $.
XSU $a zw ( Tw IQE ( tQM cwE ( rwM RAk cwE yhs ( 0wM RAk cwE yhs ( 8Q4 ( IAQ rgk 8hw ) ) ) ) ) ) $.
XiU $a #Pattern 3gg $.
XyU $a #Pattern 4wg $.
2yw $a #Pattern ( 4w ( SwE 5Qg ewk ) ( 4w ( SwE -Bw YQk ) IQE ) ) $.
${ 3Cw $p zw ( Tw ( 4w ( SwE 4Ag mwg ) ( 4w ( SwE 3gg PQk ) ( 4w ( SwE 4wg pgg ) ( 4w ( SwE 5Qg ewk ) ( 4w ( SwE -Bw YQk ) IQE ) ) ) ) ) ( Uw yhs ( PgE yhs ( 8Q4 ( IAQ rgk 8hw ) ) ) ) ) $=
  ( BCQ mgg SgE XiU PAk XyU pQg 2yw 4g IAE 7SA rQk 8Rw HwQ 8A4 PQE nAE OAM Qwk
  Ug Kx8 XSU wQY mAE ) BGHIAJKICLMIDFNOOOZPEQRSTUAZUBEUFUKPUCUDUEULPEUGEUHUIUJ
  $. $}
