$c IAQ #Symbol Tw #Variable 1CA SwE #SetVariable ) zw #ElementVariable IQE rgk #Pattern ( $.
$v CQ Bw $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Tg $a #Pattern ( Tw Bw CQ ) $.
5Q $a zw ( Tw Bw ( Tw CQ Bw ) ) $.
${ 6A $e zw ( Tw Bw CQ ) $.
   6Q $e zw Bw $.
   6g $a zw CQ $. $}
IAE $a #Pattern IQE $.
SgE $a #Pattern ( SwE Bw CQ ) $.
HwQ $a #Pattern ( IAQ Bw CQ ) $.
IgQ $a zw ( SwE ( IAQ Bw CQ ) Bw ) $.
rQk $a #Pattern rgk $.
0yA $a #Pattern 1CA $.
${ 2yA $p zw ( Tw IQE ( SwE ( IAQ rgk 1CA ) rgk ) ) $=
  ( rQk 0yA HwQ SgE IAE Tg 5Q IgQ 6g ) ABCADZEJFJEGABHI $. $}
