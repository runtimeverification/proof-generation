$c 2R4 XBI Tw #Symbol DBE zw JAQ #Pattern ( LAQ ewk IAQ Wgk #Variable SwE #SetVariable vR4 4w #ElementVariable IQE 8wk mwg ) $.
$v 7Ag CQ qwg Bw oAg Cw 2gg $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Cg $f #Pattern Cw $.
Tg $a #Pattern ( Tw Bw CQ ) $.
4g $a #Pattern ( 4w Bw CQ ) $.
5Q $a zw ( Tw Bw ( Tw CQ Bw ) ) $.
${ 6A $e zw ( Tw Bw CQ ) $.
   6Q $e zw Bw $.
   6g $a zw CQ $. $}
SgE $a #Pattern ( SwE Bw CQ ) $.
${ lgE $e zw ( Tw Bw CQ ) $.
   lwE $e zw ( Tw CQ Cw ) $.
   mAE $a zw ( Tw Bw Cw ) $. $}
${ wAE $e zw ( Tw Bw CQ ) $.
   wQE $e zw ( Tw Bw Cw ) $.
   wgE $a zw ( Tw Bw ( 4w CQ Cw ) ) $. $}
HwQ $a #Pattern ( IAQ Bw CQ ) $.
IgQ $a zw ( SwE ( IAQ Bw CQ ) Bw ) $.
KwQ $a #Pattern ( LAQ Bw CQ Cw ) $.
nwg $f #Pattern oAg $.
qgg $f #Pattern qwg $.
2Qg $f #ElementVariable 2gg $.
6wg $f #ElementVariable 7Ag $.
WQk $a #Pattern Wgk $.
egk $a #Pattern ewk $.
8gk $a #Pattern 8wk $.
CxE $a #Pattern ( DBE oAg qwg ) $.
GBE $a zw ( Tw ( 4w ( SwE oAg Wgk ) ( SwE qwg Wgk ) ) ( SwE ( DBE oAg qwg ) Wgk ) ) $.
WxI $a #Pattern ( XBI oAg qwg ) $.
aBI $a zw ( Tw ( 4w ( SwE oAg ewk ) ( SwE qwg Wgk ) ) ( SwE ( XBI oAg qwg ) 8wk ) ) $.
vB4 $a #Pattern vR4 $.
2B4 $a #Pattern 2R4 $.
pyQ $a #Pattern ( 4w ( JAQ 2gg ) ( 4w ( SwE 7Ag mwg ) IQE ) ) $.
zSQ $a zw ( Tw ( 4w ( JAQ 2gg ) ( 4w ( SwE 7Ag mwg ) IQE ) ) ( SwE ( LAQ ewk Wgk ( IAQ ewk 2R4 ) ) Wgk ) ) $.
ziQ $a zw ( Tw ( 4w ( JAQ 2gg ) ( 4w ( SwE 7Ag mwg ) IQE ) ) ( SwE ( LAQ ewk Wgk ( IAQ ewk vR4 ) ) Wgk ) ) $.
${ 0iQ $p zw ( Tw ( 4w ( JAQ 2gg ) ( 4w ( SwE 7Ag mwg ) IQE ) ) ( SwE ( XBI ( IAQ ewk vR4 ) ( DBE ( LAQ ewk Wgk ( IAQ ewk vR4 ) ) ( LAQ ewk Wgk ( IAQ ewk 2R4 ) ) ) ) 8wk ) ) $=
  ( pyQ egk vB4 HwQ SgE WQk KwQ 2B4 CxE 4g WxI 8gk Tg 5Q IgQ 6g wgE mAE ziQ zSQ
  GBE aBI ) ABCZDEFZDGZDHUFIZDHDJFIZKZHGZLUFUJMNGUEUGUKUGUEUGOUGUEPDEQRUEUHHGZU
  IHGZLUKUEULUMABUAABUBSUHUIUCTSUFUJUDT $. $}
