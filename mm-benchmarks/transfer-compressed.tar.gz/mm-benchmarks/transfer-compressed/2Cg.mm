$c ewk RAk Tw #Symbol #Variable SwE pgg #SetVariable zw 4w YQk #ElementVariable IQE rgk mwg #Pattern ) ( $.
$v 4wg CQ 3gg -Bw Bw 5Qg Cw 3Ag 4Ag $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Cg $f #Pattern Cw $.
4g $a #Pattern ( 4w Bw CQ ) $.
IAE $a #Pattern IQE $.
SgE $a #Pattern ( SwE Bw CQ ) $.
${ wAE $e zw ( Tw Bw CQ ) $.
   wQE $e zw ( Tw Bw Cw ) $.
   wgE $a zw ( Tw Bw ( 4w CQ Cw ) ) $. $}
mgg $a #Pattern mwg $.
pQg $a #Pattern pgg $.
2wg $f #ElementVariable 3Ag $.
3Qg $f #ElementVariable 3gg $.
3wg $f #ElementVariable 4Ag $.
4gg $f #ElementVariable 4wg $.
5Ag $f #ElementVariable 5Qg $.
Qwk $a #Pattern RAk $.
YAk $a #Pattern YQk $.
egk $a #Pattern ewk $.
rQk $a #Pattern rgk $.
.xw $f #ElementVariable -Bw $.
BCQ $a #Pattern 4Ag $.
ByQ $a #Pattern 3Ag $.
XiU $a #Pattern 3gg $.
XyU $a #Pattern 4wg $.
YCU $a #Pattern 5Qg $.
yyg $a #Pattern -Bw $.
zCg $a #Pattern ( 4w ( SwE 5Qg pgg ) ( 4w ( SwE -Bw YQk ) IQE ) ) $.
0ig $a zw ( Tw ( 4w ( 4w ( SwE 4Ag mwg ) ( 4w ( SwE 3gg rgk ) ( 4w ( SwE 4wg ewk ) ( 4w ( SwE 5Qg pgg ) ( 4w ( SwE -Bw YQk ) IQE ) ) ) ) ) ( 4w ( SwE 3Ag RAk ) IQE ) ) ( SwE 5Qg pgg ) ) $.
1yg $a zw ( Tw ( 4w ( 4w ( SwE 4Ag mwg ) ( 4w ( SwE 3gg rgk ) ( 4w ( SwE 4wg ewk ) ( 4w ( SwE 5Qg pgg ) ( 4w ( SwE -Bw YQk ) IQE ) ) ) ) ) ( 4w ( SwE 3Ag RAk ) IQE ) ) ( 4w ( SwE -Bw YQk ) IQE ) ) $.
${ 2Cg $p zw ( Tw ( 4w ( 4w ( SwE 4Ag mwg ) ( 4w ( SwE 3gg rgk ) ( 4w ( SwE 4wg ewk ) ( 4w ( SwE 5Qg pgg ) ( 4w ( SwE -Bw YQk ) IQE ) ) ) ) ) ( 4w ( SwE 3Ag RAk ) IQE ) ) ( 4w ( SwE 5Qg pgg ) ( 4w ( SwE -Bw YQk ) IQE ) ) ) $=
  ( BCQ mgg SgE XiU rQk XyU egk zCg 4g ByQ Qwk IAE YCU pQg yyg YAk 0ig 1yg wgE
  ) CGHIBJKIDLMIEFNOOOAPQIROOESTIFUAUBIROABCDEFUCABCDEFUDUE $. $}
