$c 0wM #Symbol cwE #Variable #SetVariable iA #ElementVariable mwg #Pattern xQg ) ( $.
$v Fw Ow CQ DQ Bw Cw 2gg EQ Dw Pw FQ Ew Kw 6Ag $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Cg $f #Pattern Cw $.
DA $f #Pattern DQ $.
Dg $f #Pattern Dw $.
EA $f #Pattern EQ $.
Eg $f #Pattern Ew $.
FA $f #Pattern FQ $.
Fg $f #Pattern Fw $.
Kg $f #ElementVariable Kw $.
Og $f #Variable Ow $.
Pg $f #Symbol Pw $.
SA $a #Variable Kw $.
Sw $a #Pattern Pw $.
jg $a iA Bw Ow Bw Ow $.
cgE $a #Symbol cwE $.
${ XgQ $e iA Bw Dw Fw Ow $.
   XwQ $e iA CQ EQ Fw Ow $.
   YAQ $e iA Cw Ew Fw Ow $.
   YQQ $e iA DQ FQ Fw Ow $.
   YgQ $a iA ( 0wM Bw CQ Cw DQ ) ( 0wM Dw EQ Ew FQ ) Fw Ow $. $}
mgg $a #Pattern mwg $.
xAg $a #Pattern xQg $.
2Qg $f #ElementVariable 2gg $.
5wg $f #ElementVariable 6Ag $.
Wh8 $a #Pattern 2gg $.
BCE $a #Pattern 6Ag $.
AiQ $a iA 6Ag 6Ag cwE 2gg $.
3CQ $a iA mwg mwg cwE 2gg $.
3SQ $a iA xQg xQg cwE 2gg $.
${ 3iQ $p iA ( 0wM mwg cwE 6Ag xQg ) ( 0wM mwg 2gg 6Ag xQg ) cwE 2gg $=
  ( mgg cgE Sw BCE xAg Wh8 SA 3CQ jg AiQ 3SQ YgQ ) CDEZBFZGCAHPGOAIZAJOQKABLAMN
  $. $}
