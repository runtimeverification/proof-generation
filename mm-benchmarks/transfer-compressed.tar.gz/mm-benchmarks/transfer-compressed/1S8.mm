$c #SetVariable iA ) #ElementVariable #Symbol #Variable #Pattern ( $.
$v Ow CQ xX Bw Kw ph0 MB0 nR4 4Ag $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Kg $f #ElementVariable Kw $.
Og $f #Variable Ow $.
SA $a #Variable Kw $.
${ $d xX ph0 $.
   IQI $a iA Bw Bw CQ Ow $. $}
3wg $f #ElementVariable 4Ag $.
Lx0 $f #ElementVariable MB0 $.
nB4 $f #ElementVariable nR4 $.
6h8 $a #Pattern nR4 $.
qy8 $a #Pattern MB0 $.
${ 1S8 $p iA MB0 MB0 nR4 4Ag $=
  ( qy8 6h8 SA IQI ) BDCEAFG $. $}
