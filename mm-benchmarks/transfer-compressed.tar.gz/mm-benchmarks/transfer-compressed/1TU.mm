$c LAQ IAQ Tw #Symbol #Variable 1CA SwE pgg #SetVariable 3gk zw 4w JAQ #ElementVariable IQE rgk #Pattern ) ( $.
$v CQ qwg Bw oAg Cw 2gg sgg 4Ag $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Cg $f #Pattern Cw $.
Tg $a #Pattern ( Tw Bw CQ ) $.
4g $a #Pattern ( 4w Bw CQ ) $.
5Q $a zw ( Tw Bw ( Tw CQ Bw ) ) $.
${ 6A $e zw ( Tw Bw CQ ) $.
   6Q $e zw Bw $.
   6g $a zw CQ $. $}
SgE $a #Pattern ( SwE Bw CQ ) $.
${ lgE $e zw ( Tw Bw CQ ) $.
   lwE $e zw ( Tw CQ Cw ) $.
   mAE $a zw ( Tw Bw Cw ) $. $}
${ wAE $e zw ( Tw Bw CQ ) $.
   wQE $e zw ( Tw Bw Cw ) $.
   wgE $a zw ( Tw Bw ( 4w CQ Cw ) ) $. $}
HwQ $a #Pattern ( IAQ Bw CQ ) $.
IgQ $a zw ( SwE ( IAQ Bw CQ ) Bw ) $.
IwQ $a #Pattern ( JAQ Bw ) $.
KwQ $a #Pattern ( LAQ Bw CQ Cw ) $.
nwg $f #Pattern oAg $.
pQg $a #Pattern pgg $.
qgg $f #Pattern qwg $.
sQg $f #Pattern sgg $.
2Qg $f #ElementVariable 2gg $.
3wg $f #ElementVariable 4Ag $.
.gg $a zw ( Tw ( 4w ( 4w ( JAQ oAg ) ( JAQ qwg ) ) ( SwE sgg oAg ) ) ( SwE ( LAQ oAg qwg sgg ) qwg ) ) $.
rQk $a #Pattern rgk $.
0yA $a #Pattern 1CA $.
DC4 $a #Pattern ( 4w ( JAQ 2gg ) ( 4w ( SwE 4Ag 3gk ) IQE ) ) $.
GS4 $a zw ( Tw ( 4w ( JAQ 2gg ) ( 4w ( SwE 4Ag 3gk ) IQE ) ) ( 4w ( JAQ rgk ) ( JAQ pgg ) ) ) $.
${ 1TU $p zw ( Tw ( 4w ( JAQ 2gg ) ( 4w ( SwE 4Ag 3gk ) IQE ) ) ( SwE ( LAQ rgk pgg ( IAQ rgk 1CA ) ) pgg ) ) $=
  ( DC4 rQk IwQ pQg 4g 0yA HwQ SgE KwQ GS4 Tg 5Q IgQ 6g wgE .gg mAE ) ABCZDEFEG
  ZDHIZDJZGDFUBKFJTUAUCABLUCTUCMUCTNDHOPQDFUBRS $. $}
