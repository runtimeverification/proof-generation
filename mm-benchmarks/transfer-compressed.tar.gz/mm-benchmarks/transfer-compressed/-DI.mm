$c rwg LAQ 7BA Hg8 #Symbol #Variable pgg #SetVariable ) #ElementVariable rgk #Pattern 0Q4 ( $.
$v 4wg CQ qwg 3gg Bw oAg 5Qg Cw 4Ag $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Cg $f #Pattern Cw $.
KwQ $a #Pattern ( LAQ Bw CQ Cw ) $.
nwg $f #Pattern oAg $.
pQg $a #Pattern pgg $.
qgg $f #Pattern qwg $.
rgg $a #Pattern ( rwg oAg qwg ) $.
3Qg $f #ElementVariable 3gg $.
3wg $f #ElementVariable 4Ag $.
4gg $f #ElementVariable 4wg $.
5Ag $f #ElementVariable 5Qg $.
rQk $a #Pattern rgk $.
0A4 $a #Pattern ( 0Q4 oAg qwg ) $.
HQ8 $a #Pattern ( Hg8 oAg ) $.
XiU $a #Pattern 3gg $.
XyU $a #Pattern 4wg $.
.zI $a #Pattern ( 7BA 5Qg 4Ag ) $.
${ -DI $p #Pattern ( 0Q4 ( Hg8 ( rwg ( LAQ rgk pgg ( 7BA 5Qg 4Ag ) ) 3gg ) ) 4wg ) $=
  ( rQk pQg .zI KwQ XiU rgg HQ8 XyU 0A4 ) EFBDGHAIJKCLM $. $}
