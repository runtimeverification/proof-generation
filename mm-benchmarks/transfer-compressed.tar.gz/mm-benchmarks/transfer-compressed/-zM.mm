$c 4B4 Ngk Lwk #Symbol 7h4 ZAE 8Q4 BA0 zw xwM pgg #Pattern 0Q4 rwg Ex0 oBM 0wM xB4 tQM Wgk 0h4 MAQ 5xw #Variable SwE PQk #SetVariable iA vR4 4w #ElementVariable IQE mwg 8hw xQg Vhc cBQ zBA 2R4 lSA XBI RAk Tw cwE wQM -g4 .gk -QM Px0 rgk ( twM .gM LAQ ewk yx4 IAQ 9R4 Hg8 lhg Kw8 8wk 7Ak 7BI ) $.
$v Fw Ow CQ qwg DQ Bw Cw EQ sgg Dw tAg ngg FQ xX Ew Kw ph0 oAg GQ nR4 tgg $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Cg $f #Pattern Cw $.
DA $f #Pattern DQ $.
Dg $f #Pattern Dw $.
EA $f #Pattern EQ $.
Eg $f #Pattern Ew $.
FA $f #Pattern FQ $.
Fg $f #Pattern Fw $.
GA $f #Pattern GQ $.
Kg $f #ElementVariable Kw $.
Og $f #Variable Ow $.
SA $a #Variable Kw $.
jg $a iA Bw Ow Bw Ow $.
4g $a #Pattern ( 4w Bw CQ ) $.
${ 6A $e zw ( Tw Bw CQ ) $.
   6Q $e zw Bw $.
   6g $a zw CQ $. $}
IAE $a #Pattern IQE $.
SgE $a #Pattern ( SwE Bw CQ ) $.
${ lgE $e zw ( Tw Bw CQ ) $.
   lwE $e zw ( Tw CQ Cw ) $.
   mAE $a zw ( Tw Bw Cw ) $. $}
nAE $a zw IQE $.
${ wAE $e zw ( Tw Bw CQ ) $.
   wQE $e zw ( Tw Bw Cw ) $.
   wgE $a zw ( Tw Bw ( 4w CQ Cw ) ) $. $}
${ $d xX ph0 $.
   IQI $a iA Bw Bw CQ Ow $. $}
${ NwM $e zw CQ $.
   OAM $a zw ( Tw Bw CQ ) $. $}
tAM $a #Pattern ( tQM Bw CQ ) $.
uwM $a #Pattern ( twM Bw ) $.
wAM $a #Pattern ( wQM Bw CQ Cw ) $.
xgM $a #Pattern ( xwM Bw CQ Cw ) $.
0gM $a #Pattern ( 0wM Bw CQ Cw DQ ) $.
.QM $a #Pattern ( .gM Bw CQ Cw ) $.
HwQ $a #Pattern ( IAQ Bw CQ ) $.
KwQ $a #Pattern ( LAQ Bw CQ Cw ) $.
${ QAQ $e iA Bw Cw Dw Ow $.
   QQQ $e iA CQ DQ Dw Ow $.
   QgQ $a iA ( tQM Bw CQ ) ( tQM Cw DQ ) Dw Ow $. $}
${ SgQ $e iA Bw DQ Ew Ow $.
   SwQ $e iA CQ Dw Ew Ow $.
   TAQ $e iA Cw EQ Ew Ow $.
   TQQ $a iA ( wQM Bw CQ Cw ) ( wQM DQ Dw EQ ) Ew Ow $. $}
${ XgQ $e iA Bw Dw Fw Ow $.
   XwQ $e iA CQ EQ Fw Ow $.
   YAQ $e iA Cw Ew Fw Ow $.
   YQQ $e iA DQ FQ Fw Ow $.
   YgQ $a iA ( 0wM Bw CQ Cw DQ ) ( 0wM Dw EQ Ew FQ ) Fw Ow $. $}
${ awQ $e iA Bw DQ Ew Ow $.
   bAQ $e iA CQ Dw Ew Ow $.
   bQQ $e iA Cw EQ Ew Ow $.
   bgQ $a iA ( .gM Bw CQ Cw ) ( .gM DQ Dw EQ ) Ew Ow $. $}
FgU $a zw ( ZAE IQE ) $.
JwU $a zw ( Tw ( 4w ( SwE CQ Bw ) ( SwE Cw Bw ) ) ( SwE ( wQM Bw CQ Cw ) Bw ) ) $.
${ fQU $e zw ( Tw GQ ( SwE CQ Bw ) ) $.
   fgU $e zw ( Tw GQ ( SwE Cw Bw ) ) $.
   fwU $a zw ( Tw GQ ( tQM Bw ( xwM Bw ( wQM Bw CQ Cw ) Cw ) ) ) $. $}
${ nwU $e zw ( SwE CQ Bw ) $.
   oAU $a zw ( tQM Bw ( xwM Bw CQ CQ ) ) $. $}
${ sgU $e zw ( Tw GQ ( SwE CQ Bw ) ) $.
   swU $a zw ( Tw GQ ( tQM Bw ( xwM Bw CQ CQ ) ) ) $. $}
${ 2AU $e zw ( Tw GQ ( SwE CQ Bw ) ) $.
   2QU $e zw ( Tw GQ ( SwE Cw Bw ) ) $.
   2gU $e zw ( Tw GQ ( SwE DQ Bw ) ) $.
   2wU $e zw ( Tw GQ ( SwE Dw Bw ) ) $.
   3AU $e zw ( Tw GQ ( tQM Bw ( xwM Bw CQ Cw ) ) ) $.
   3QU $e zw ( Tw GQ ( tQM Bw ( xwM Bw DQ Dw ) ) ) $.
   3gU $a zw ( Tw GQ ( tQM Bw ( xwM Bw ( wQM Bw CQ DQ ) ( wQM Bw Cw Dw ) ) ) ) $. $}
${ MQY $e zw ( MAQ Bw CQ ) $.
   MgY $e zw ( MAQ Bw Cw ) $.
   MwY $a zw ( MAQ Bw ( wQM Bw CQ Cw ) ) $. $}
NQY $a zw ( MAQ Bw ( twM Bw ) ) $.
${ swY $e zw ( Tw GQ ( SwE CQ Bw ) ) $.
   tAY $e zw ( Tw GQ ( SwE Cw Bw ) ) $.
   tQY $e zw ( Tw GQ ( tQM cwE ( 0wM Bw cwE CQ Cw ) ) ) $.
   tgY $e zw ( Tw GQ ( tQM Ew DQ ) ) $.
   twY $e iA ( tQM Ew DQ ) Dw CQ Kw $.
   uAY $e iA ( tQM FQ EQ ) Dw Cw Kw $.
   uQY $a zw ( Tw GQ ( tQM FQ EQ ) ) $. $}
${ hAc $e zw ( Tw GQ ( tQM Bw ( xwM Bw CQ Cw ) ) ) $.
   hQc $e zw ( Tw GQ ( tQM Bw ( -QM Bw Cw DQ ) ) ) $.
   hgc $a zw ( Tw GQ ( tQM Bw ( -QM Bw CQ DQ ) ) ) $. $}
${ pgc $e zw ( Tw GQ ( tQM Bw ( xwM Bw CQ Cw ) ) ) $.
   pwc $e zw ( Tw GQ ( tQM Bw ( .gM Bw Cw DQ ) ) ) $.
   qAc $a zw ( Tw GQ ( tQM Bw ( .gM Bw CQ DQ ) ) ) $. $}
${ qQc $e zw ( ZAE GQ ) $.
   qgc $e zw ( Tw GQ ( SwE Cw Bw ) ) $.
   qwc $e zw ( Tw GQ ( SwE DQ Bw ) ) $.
   rAc $e zw ( Tw GQ ( tQM Bw ( .gM Bw CQ Cw ) ) ) $.
   rQc $e zw ( Tw GQ ( tQM Bw ( xwM Bw Cw DQ ) ) ) $.
   rgc $a zw ( Tw GQ ( tQM Bw ( .gM Bw CQ DQ ) ) ) $. $}
${ twc $e zw ( MAQ Bw CQ ) $.
   uAc $e zw ( Tw GQ ( SwE CQ Bw ) ) $.
   uQc $e zw ( Tw GQ ( SwE Cw Bw ) ) $.
   ugc $e zw ( Tw GQ ( SwE DQ Bw ) ) $.
   uwc $e zw ( Tw GQ ( tQM Bw ( .gM Bw ( wQM Bw CQ Cw ) DQ ) ) ) $.
   vAc $a zw ( Tw GQ ( tQM Bw ( .gM Bw ( wQM Bw CQ Cw ) ( wQM Bw CQ DQ ) ) ) ) $. $}
${ 0Qc $e zw ( Tw GQ ( SwE CQ Bw ) ) $.
   0gc $e zw ( Tw GQ ( SwE Cw Bw ) ) $.
   0wc $e zw ( Tw GQ ( tQM Bw ( .gM Bw CQ Cw ) ) ) $.
   1Ac $a zw ( Tw GQ ( tQM Bw ( -QM Bw CQ Cw ) ) ) $. $}
mgg $a #Pattern mwg $.
nQg $f #Variable ngg $.
nwg $f #Pattern oAg $.
pQg $a #Pattern pgg $.
qgg $f #Pattern qwg $.
rgg $a #Pattern ( rwg oAg qwg ) $.
sQg $f #Pattern sgg $.
swg $f #Pattern tAg $.
tQg $f #Pattern tgg $.
wQg $a zw ( Tw ( 4w ( SwE oAg pgg ) ( SwE qwg mwg ) ) ( SwE ( rwg oAg qwg ) mwg ) ) $.
xAg $a #Pattern xQg $.
Lgk $a #Pattern Lwk $.
NQk $a #Pattern Ngk $.
PAk $a #Pattern PQk $.
Qwk $a #Pattern RAk $.
WQk $a #Pattern Wgk $.
egk $a #Pattern ewk $.
rQk $a #Pattern rgk $.
6wk $a #Pattern 7Ak $.
8gk $a #Pattern 8wk $.
.Qk $a #Pattern .gk $.
Aw0 $a #Pattern ( BA0 oAg ) $.
0A4 $a #Pattern ( 0Q4 oAg qwg ) $.
3Q4 $a zw ( Tw ( 4w ( SwE oAg Lwk ) ( SwE qwg PQk ) ) ( SwE ( 0Q4 oAg qwg ) 7Ak ) ) $.
8A4 $a #Pattern ( 8Q4 oAg ) $.
-Q4 $a #Pattern ( -g4 oAg qwg ) $.
Cg8 $a zw ( Tw ( 4w ( SwE oAg 7Ak ) ( SwE qwg RAk ) ) ( SwE ( -g4 oAg qwg ) Ngk ) ) $.
HQ8 $a #Pattern ( Hg8 oAg ) $.
Jw8 $a zw ( Tw ( SwE oAg mwg ) ( SwE ( Hg8 oAg ) Lwk ) ) $.
Kg8 $a #Pattern ( Kw8 oAg ) $.
yxA $a #Pattern ( zBA oAg qwg ) $.
WxI $a #Pattern ( XBI oAg qwg ) $.
6xI $a #Pattern ( 7BI oAg qwg ) $.
nxM $a #Pattern ( oBM oAg qwg ) $.
${ pBM $e iA qwg tAg oAg ngg $.
   pRM $e iA sgg tgg oAg ngg $.
   phM $a iA ( oBM qwg sgg ) ( oBM tAg tgg ) oAg ngg $. $}
rBM $a zw ( Tw ( 4w ( SwE oAg .gk ) ( SwE qwg .gk ) ) ( SwE ( oBM oAg qwg ) .gk ) ) $.
bxQ $a #Pattern ( cBQ oAg qwg ) $.
VRc $a #Pattern ( Vhc oAg ) $.
Xxc $a zw ( Tw ( SwE oAg mwg ) ( SwE ( Vhc oAg ) .gk ) ) $.
lRg $a #Pattern ( lhg oAg ) $.
${ mhg $e iA qwg sgg oAg ngg $.
   mxg $a iA ( lhg qwg ) ( lhg sgg ) oAg ngg $. $}
5hw $a #Pattern 5xw $.
8Rw $a #Pattern 8hw $.
Eh0 $a #Pattern Ex0 $.
Ph0 $a #Pattern Px0 $.
nB4 $f #ElementVariable nR4 $.
vB4 $a #Pattern vR4 $.
wx4 $a #Pattern xB4 $.
yh4 $a #Pattern yx4 $.
0R4 $a #Pattern 0h4 $.
2B4 $a #Pattern 2R4 $.
3x4 $a #Pattern 4B4 $.
7R4 $a #Pattern 7h4 $.
9B4 $a #Pattern 9R4 $.
.R4 $a zw ( Tw IQE ( SwE ( twM Ngk ) Ngk ) ) $.
Kx8 $a zw ( Tw IQE ( SwE ( 8Q4 ( IAQ rgk 8hw ) ) RAk ) ) $.
6h8 $a #Pattern nR4 $.
byA $a zw ( Tw IQE ( SwE ( IAQ .gk Px0 ) .gk ) ) $.
dyA $a zw ( Tw IQE ( SwE ( rwg ( LAQ 8wk pgg ( XBI ( IAQ ewk 7h4 ) ( zBA ( LAQ ewk Wgk ( IAQ ewk 7h4 ) ) ( LAQ ewk Wgk ( IAQ ewk 2R4 ) ) ) ) ) ( rwg ( LAQ 8wk pgg ( XBI ( IAQ ewk xB4 ) ( LAQ rgk Wgk ( IAQ rgk Ex0 ) ) ) ) xQg ) ) mwg ) ) $.
lCA $a #Pattern lSA $.
pSA $a zw ( Tw IQE ( SwE ( LAQ Wgk pgg ( zBA ( LAQ ewk Wgk ( IAQ ewk 7h4 ) ) ( LAQ ewk Wgk ( IAQ ewk 2R4 ) ) ) ) pgg ) ) $.
qCA $a zw ( Tw IQE ( SwE ( rwg ( BA0 ( rwg ( LAQ ewk pgg ( IAQ ewk 7h4 ) ) xQg ) ) ( rwg ( LAQ 8wk pgg ( XBI ( IAQ ewk xB4 ) ( LAQ rgk Wgk ( IAQ rgk Ex0 ) ) ) ) xQg ) ) mwg ) ) $.
qSA $a zw ( Tw IQE ( SwE ( Kw8 ( 7BI ( cBQ ( LAQ ewk pgg ( IAQ ewk xB4 ) ) ( LAQ rgk pgg ( IAQ rgk 8hw ) ) ) ( 7BI ( cBQ ( LAQ ewk pgg ( IAQ ewk vR4 ) ) ( LAQ rgk pgg ( IAQ rgk lSA ) ) ) ( 7BI ( cBQ ( LAQ ewk pgg ( IAQ ewk 9R4 ) ) ( LAQ rgk pgg ( IAQ rgk yx4 ) ) ) ( 7BI ( cBQ ( LAQ ewk pgg ( IAQ ewk 7h4 ) ) ( LAQ rgk pgg ( IAQ rgk 4B4 ) ) ) ( cBQ ( LAQ ewk pgg ( IAQ ewk 2R4 ) ) ( LAQ rgk pgg ( IAQ rgk 0h4 ) ) ) ) ) ) ) ) PQk ) ) $.
lys $a zw ( Tw IQE ( tQM cwE ( 0wM .gk cwE ( lhg ( IAQ .gk Px0 ) ) ( IAQ .gk 5xw ) ) ) ) $.
mCs $a zw ( Tw IQE ( SwE ( lhg ( IAQ .gk Px0 ) ) .gk ) ) $.
mSs $a zw ( Tw IQE ( SwE ( IAQ .gk 5xw ) .gk ) ) $.
mys $a zw ( Tw IQE ( tQM cwE ( 0wM .gk cwE ( oBM ( IAQ .gk 5xw ) ( IAQ .gk 5xw ) ) ( IAQ .gk 5xw ) ) ) ) $.
1DM $a zw ( Tw IQE ( tQM Ngk ( .gM Ngk ( wQM Ngk ( 0wM .gk Ngk ( oBM ( IAQ .gk 5xw ) ( lhg ( Vhc ( rwg ( LAQ Wgk pgg ( zBA ( LAQ ewk Wgk ( IAQ ewk 7h4 ) ) ( LAQ ewk Wgk ( IAQ ewk 2R4 ) ) ) ) xQg ) ) ) ) ( IAQ .gk 5xw ) ) ( -g4 ( 0Q4 ( Hg8 ( rwg ( LAQ 8wk pgg ( XBI ( IAQ ewk 7h4 ) ( zBA ( LAQ ewk Wgk ( IAQ ewk 7h4 ) ) ( LAQ ewk Wgk ( IAQ ewk 2R4 ) ) ) ) ) ( rwg ( LAQ 8wk pgg ( XBI ( IAQ ewk xB4 ) ( LAQ rgk Wgk ( IAQ rgk Ex0 ) ) ) ) xQg ) ) ) ( Kw8 ( 7BI ( cBQ ( LAQ ewk pgg ( IAQ ewk xB4 ) ) ( LAQ rgk pgg ( IAQ rgk 8hw ) ) ) ( 7BI ( cBQ ( LAQ ewk pgg ( IAQ ewk vR4 ) ) ( LAQ rgk pgg ( IAQ rgk lSA ) ) ) ( 7BI ( cBQ ( LAQ ewk pgg ( IAQ ewk 9R4 ) ) ( LAQ rgk pgg ( IAQ rgk yx4 ) ) ) ( 7BI ( cBQ ( LAQ ewk pgg ( IAQ ewk 7h4 ) ) ( LAQ rgk pgg ( IAQ rgk 4B4 ) ) ) ( cBQ ( LAQ ewk pgg ( IAQ ewk 2R4 ) ) ( LAQ rgk pgg ( IAQ rgk 0h4 ) ) ) ) ) ) ) ) ) ( 8Q4 ( IAQ rgk 8hw ) ) ) ) ( wQM Ngk ( twM Ngk ) ( -g4 ( 0Q4 ( Hg8 ( rwg ( LAQ Wgk pgg ( zBA ( LAQ ewk Wgk ( IAQ ewk 7h4 ) ) ( LAQ ewk Wgk ( IAQ ewk 2R4 ) ) ) ) ( rwg ( BA0 ( rwg ( LAQ ewk pgg ( IAQ ewk 7h4 ) ) xQg ) ) ( rwg ( LAQ 8wk pgg ( XBI ( IAQ ewk xB4 ) ( LAQ rgk Wgk ( IAQ rgk Ex0 ) ) ) ) xQg ) ) ) ) ( Kw8 ( 7BI ( cBQ ( LAQ ewk pgg ( IAQ ewk xB4 ) ) ( LAQ rgk pgg ( IAQ rgk 8hw ) ) ) ( 7BI ( cBQ ( LAQ ewk pgg ( IAQ ewk vR4 ) ) ( LAQ rgk pgg ( IAQ rgk lSA ) ) ) ( 7BI ( cBQ ( LAQ ewk pgg ( IAQ ewk 9R4 ) ) ( LAQ rgk pgg ( IAQ rgk yx4 ) ) ) ( 7BI ( cBQ ( LAQ ewk pgg ( IAQ ewk 7h4 ) ) ( LAQ rgk pgg ( IAQ rgk 4B4 ) ) ) ( cBQ ( LAQ ewk pgg ( IAQ ewk 2R4 ) ) ( LAQ rgk pgg ( IAQ rgk 0h4 ) ) ) ) ) ) ) ) ) ( 8Q4 ( IAQ rgk 8hw ) ) ) ) ) ) ) $.
2zM $a zw ( Tw IQE ( SwE ( rwg ( LAQ Wgk pgg ( zBA ( LAQ ewk Wgk ( IAQ ewk 7h4 ) ) ( LAQ ewk Wgk ( IAQ ewk 2R4 ) ) ) ) xQg ) mwg ) ) $.
.jM $a zw ( Tw IQE ( tQM cwE ( 0wM .gk cwE ( Vhc ( rwg ( LAQ Wgk pgg ( zBA ( LAQ ewk Wgk ( IAQ ewk 7h4 ) ) ( LAQ ewk Wgk ( IAQ ewk 2R4 ) ) ) ) xQg ) ) ( IAQ .gk Px0 ) ) ) ) $.
-TM $a zw ( Tw IQE ( tQM Ngk ( xwM Ngk ( wQM Ngk ( wQM Ngk ( twM Ngk ) ( twM Ngk ) ) ( -g4 ( 0Q4 ( Hg8 ( rwg ( LAQ 8wk pgg ( XBI ( IAQ ewk 7h4 ) ( zBA ( LAQ ewk Wgk ( IAQ ewk 7h4 ) ) ( LAQ ewk Wgk ( IAQ ewk 2R4 ) ) ) ) ) ( rwg ( LAQ 8wk pgg ( XBI ( IAQ ewk xB4 ) ( LAQ rgk Wgk ( IAQ rgk Ex0 ) ) ) ) xQg ) ) ) ( Kw8 ( 7BI ( cBQ ( LAQ ewk pgg ( IAQ ewk xB4 ) ) ( LAQ rgk pgg ( IAQ rgk 8hw ) ) ) ( 7BI ( cBQ ( LAQ ewk pgg ( IAQ ewk vR4 ) ) ( LAQ rgk pgg ( IAQ rgk lSA ) ) ) ( 7BI ( cBQ ( LAQ ewk pgg ( IAQ ewk 9R4 ) ) ( LAQ rgk pgg ( IAQ rgk yx4 ) ) ) ( 7BI ( cBQ ( LAQ ewk pgg ( IAQ ewk 7h4 ) ) ( LAQ rgk pgg ( IAQ rgk 4B4 ) ) ) ( cBQ ( LAQ ewk pgg ( IAQ ewk 2R4 ) ) ( LAQ rgk pgg ( IAQ rgk 0h4 ) ) ) ) ) ) ) ) ) ( 8Q4 ( IAQ rgk 8hw ) ) ) ) ( wQM Ngk ( 0wM .gk Ngk ( IAQ .gk 5xw ) ( IAQ .gk 5xw ) ) ( -g4 ( 0Q4 ( Hg8 ( rwg ( LAQ 8wk pgg ( XBI ( IAQ ewk 7h4 ) ( zBA ( LAQ ewk Wgk ( IAQ ewk 7h4 ) ) ( LAQ ewk Wgk ( IAQ ewk 2R4 ) ) ) ) ) ( rwg ( LAQ 8wk pgg ( XBI ( IAQ ewk xB4 ) ( LAQ rgk Wgk ( IAQ rgk Ex0 ) ) ) ) xQg ) ) ) ( Kw8 ( 7BI ( cBQ ( LAQ ewk pgg ( IAQ ewk xB4 ) ) ( LAQ rgk pgg ( IAQ rgk 8hw ) ) ) ( 7BI ( cBQ ( LAQ ewk pgg ( IAQ ewk vR4 ) ) ( LAQ rgk pgg ( IAQ rgk lSA ) ) ) ( 7BI ( cBQ ( LAQ ewk pgg ( IAQ ewk 9R4 ) ) ( LAQ rgk pgg ( IAQ rgk yx4 ) ) ) ( 7BI ( cBQ ( LAQ ewk pgg ( IAQ ewk 7h4 ) ) ( LAQ rgk pgg ( IAQ rgk 4B4 ) ) ) ( cBQ ( LAQ ewk pgg ( IAQ ewk 2R4 ) ) ( LAQ rgk pgg ( IAQ rgk 0h4 ) ) ) ) ) ) ) ) ) ( 8Q4 ( IAQ rgk 8hw ) ) ) ) ) ) ) $.
-jM $a zw ( Tw IQE ( tQM Ngk ( xwM Ngk ( wQM Ngk ( wQM Ngk ( twM Ngk ) ( twM Ngk ) ) ( -g4 ( 0Q4 ( Hg8 ( rwg ( LAQ Wgk pgg ( zBA ( LAQ ewk Wgk ( IAQ ewk 7h4 ) ) ( LAQ ewk Wgk ( IAQ ewk 2R4 ) ) ) ) ( rwg ( BA0 ( rwg ( LAQ ewk pgg ( IAQ ewk 7h4 ) ) xQg ) ) ( rwg ( LAQ 8wk pgg ( XBI ( IAQ ewk xB4 ) ( LAQ rgk Wgk ( IAQ rgk Ex0 ) ) ) ) xQg ) ) ) ) ( Kw8 ( 7BI ( cBQ ( LAQ ewk pgg ( IAQ ewk xB4 ) ) ( LAQ rgk pgg ( IAQ rgk 8hw ) ) ) ( 7BI ( cBQ ( LAQ ewk pgg ( IAQ ewk vR4 ) ) ( LAQ rgk pgg ( IAQ rgk lSA ) ) ) ( 7BI ( cBQ ( LAQ ewk pgg ( IAQ ewk 9R4 ) ) ( LAQ rgk pgg ( IAQ rgk yx4 ) ) ) ( 7BI ( cBQ ( LAQ ewk pgg ( IAQ ewk 7h4 ) ) ( LAQ rgk pgg ( IAQ rgk 4B4 ) ) ) ( cBQ ( LAQ ewk pgg ( IAQ ewk 2R4 ) ) ( LAQ rgk pgg ( IAQ rgk 0h4 ) ) ) ) ) ) ) ) ) ( 8Q4 ( IAQ rgk 8hw ) ) ) ) ( wQM Ngk ( wQM Ngk ( twM Ngk ) ( twM Ngk ) ) ( -g4 ( 0Q4 ( Hg8 ( rwg ( LAQ Wgk pgg ( zBA ( LAQ ewk Wgk ( IAQ ewk 7h4 ) ) ( LAQ ewk Wgk ( IAQ ewk 2R4 ) ) ) ) ( rwg ( BA0 ( rwg ( LAQ ewk pgg ( IAQ ewk 7h4 ) ) xQg ) ) ( rwg ( LAQ 8wk pgg ( XBI ( IAQ ewk xB4 ) ( LAQ rgk Wgk ( IAQ rgk Ex0 ) ) ) ) xQg ) ) ) ) ( Kw8 ( 7BI ( cBQ ( LAQ ewk pgg ( IAQ ewk xB4 ) ) ( LAQ rgk pgg ( IAQ rgk 8hw ) ) ) ( 7BI ( cBQ ( LAQ ewk pgg ( IAQ ewk vR4 ) ) ( LAQ rgk pgg ( IAQ rgk lSA ) ) ) ( 7BI ( cBQ ( LAQ ewk pgg ( IAQ ewk 9R4 ) ) ( LAQ rgk pgg ( IAQ rgk yx4 ) ) ) ( 7BI ( cBQ ( LAQ ewk pgg ( IAQ ewk 7h4 ) ) ( LAQ rgk pgg ( IAQ rgk 4B4 ) ) ) ( cBQ ( LAQ ewk pgg ( IAQ ewk 2R4 ) ) ( LAQ rgk pgg ( IAQ rgk 0h4 ) ) ) ) ) ) ) ) ) ( 8Q4 ( IAQ rgk 8hw ) ) ) ) ) ) ) $.
${ -zM $p zw ( Tw IQE ( tQM Ngk ( -QM Ngk ( wQM Ngk ( wQM Ngk ( twM Ngk ) ( twM Ngk ) ) ( -g4 ( 0Q4 ( Hg8 ( rwg ( LAQ 8wk pgg ( XBI ( IAQ ewk 7h4 ) ( zBA ( LAQ ewk Wgk ( IAQ ewk 7h4 ) ) ( LAQ ewk Wgk ( IAQ ewk 2R4 ) ) ) ) ) ( rwg ( LAQ 8wk pgg ( XBI ( IAQ ewk xB4 ) ( LAQ rgk Wgk ( IAQ rgk Ex0 ) ) ) ) xQg ) ) ) ( Kw8 ( 7BI ( cBQ ( LAQ ewk pgg ( IAQ ewk xB4 ) ) ( LAQ rgk pgg ( IAQ rgk 8hw ) ) ) ( 7BI ( cBQ ( LAQ ewk pgg ( IAQ ewk vR4 ) ) ( LAQ rgk pgg ( IAQ rgk lSA ) ) ) ( 7BI ( cBQ ( LAQ ewk pgg ( IAQ ewk 9R4 ) ) ( LAQ rgk pgg ( IAQ rgk yx4 ) ) ) ( 7BI ( cBQ ( LAQ ewk pgg ( IAQ ewk 7h4 ) ) ( LAQ rgk pgg ( IAQ rgk 4B4 ) ) ) ( cBQ ( LAQ ewk pgg ( IAQ ewk 2R4 ) ) ( LAQ rgk pgg ( IAQ rgk 0h4 ) ) ) ) ) ) ) ) ) ( 8Q4 ( IAQ rgk 8hw ) ) ) ) ( wQM Ngk ( wQM Ngk ( twM Ngk ) ( twM Ngk ) ) ( -g4 ( 0Q4 ( Hg8 ( rwg ( LAQ Wgk pgg ( zBA ( LAQ ewk Wgk ( IAQ ewk 7h4 ) ) ( LAQ ewk Wgk ( IAQ ewk 2R4 ) ) ) ) ( rwg ( BA0 ( rwg ( LAQ ewk pgg ( IAQ ewk 7h4 ) ) xQg ) ) ( rwg ( LAQ 8wk pgg ( XBI ( IAQ ewk xB4 ) ( LAQ rgk Wgk ( IAQ rgk Ex0 ) ) ) ) xQg ) ) ) ) ( Kw8 ( 7BI ( cBQ ( LAQ ewk pgg ( IAQ ewk xB4 ) ) ( LAQ rgk pgg ( IAQ rgk 8hw ) ) ) ( 7BI ( cBQ ( LAQ ewk pgg ( IAQ ewk vR4 ) ) ( LAQ rgk pgg ( IAQ rgk lSA ) ) ) ( 7BI ( cBQ ( LAQ ewk pgg ( IAQ ewk 9R4 ) ) ( LAQ rgk pgg ( IAQ rgk yx4 ) ) ) ( 7BI ( cBQ ( LAQ ewk pgg ( IAQ ewk 7h4 ) ) ( LAQ rgk pgg ( IAQ rgk 4B4 ) ) ) ( cBQ ( LAQ ewk pgg ( IAQ ewk 2R4 ) ) ( LAQ rgk pgg ( IAQ rgk 0h4 ) ) ) ) ) ) ) ) ) ( 8Q4 ( IAQ rgk 8hw ) ) ) ) ) ) ) $=
  ( NQk wAM pQg egk HwQ KwQ rQk rgg IAE SgE wgE mAE .Qk 0gM .QM IQI YgQ TQQ bgQ
  4g nB4 uwM 8gk 7R4 WQk 2B4 yxA WxI wx4 Eh0 xAg HQ8 8Rw bxQ vB4 lCA 9B4 yh4 6g
  3x4 0R4 6xI Kg8 0A4 8A4 -Q4 Aw0 .R4 JwU 6wk Qwk Lgk PAk mgg dyA Jw8 qSA SA jg
  3Q4 Kx8 Cg8 xgM tAM nAE oAU OAM swU 3gU pSA qCA wQg FgU NQY MwY 5hw -TM nxM
  6h8 mSs rBM mys Ph0 lRg mCs lys VRc 2zM Xxc byA .jM 1DM mxg phM QgQ uQY fwU
  rgc qAc vAc -jM 1Ac hgc ) AAAAUBZYDBZUCCDUDEZDUEYFFDUEDUFEZFUGZUHFUCCDUIEZGUE
  GUJEFUHFUKHZHZULZDCYIFGCGUMEZFUNDCDUOEFGCGUPEFUNDCDUQEFGCGUREFUNDCYFFZGCGUTEF
  UNDCYGFGCGVAEFUNVBVBVBVBVCZVDZYMVEZVFZBZYSAYEUECYHFZYNUKHVGYJHZHZULZYOVDZYQVF
  ZBZIAYEYEYRYRIIYDAJZUUGTYEAJZIUUGUUGVHVHKAYDYDVILZUUIIYPVJJZYQVKJZTYRAJZIUUJU
  UKIYLVLJZYOVMJZTUUJIUUMUUNIYKVNJUUMVOYKVPLVQKYLYOVTLWAKYPYQWBLZUUOIAAYEYEWCWD
  AYEIUUHUUIWEUSWFWGAYRIUUOWHWIAYSUUFIIUUHUULTYSAJIUUHUULUUIUUOKAYEYRVILIUUHUUE
  AJZTUUFAJIUUHUUPUUIIUUDVJJZUUKTUUPIUUQUUKIUUCVLJZUUNTUUQIUURUUNIUUBVNJZUURIYT
  CJZUUAVNJZTUUSIUUTUVAWJWKKYTUUAWLLUUBVPLVQKUUCYOVTLWAKUUDYQWBLZKAYEUUEVILZAYS
  UUFUUFIWMUVCUVCAYEYRUUEIAYDYDAWNZUVDWOUUIUUOUVBAYSAMAMWPEZUVENZYRBZUUEIWQAUVG
  AYDUUEBZUUEIWMIUUGUUPTUVHAJIUUGUUPVHUVBKAYDUUEVILUVBMUVEUVEWRZUVEAAMAUVIUVENZ
  YRBZUVHOZAAAMAUAWSZUVENZYRBZUVHOZWDAUVGUVHOZAAIUAIUVEMJZUVRTUVIMJIUVRUVRWTWTK
  UVEUVEXALWTXBMMXCEZXDZUVEAAMAUVEUVTWRZUVENZYRBZUVHOZAAAMAUVEUVMWRZUVENZYRBZUV
  HOZWDUVLAAIUAXEWTXFMYTUKHZXGZUVSAAMAUVEUWJXDZWRZUVENZYRBZUVHOZAAAMAUVEUVMXDZW
  RZUVENZYRBZUVHOZWDUWDAAIUAIUWIVNJUWJMJXHUWIXILXJXKXLAUWOAUWTUWJUAVRZAUWJUXAPZ
  AUWNUVHAUWSUVHUWJUXAUXBAUWMYRAUWRYRUWJUXAUXBMAUWLUVEMAUWQUVEUWJUXAMUWJUXAPUXB
  UXAUWJUVEUWKUVEUWPUVEUWJUXAPZUXAUWJUWJUVMUWJUXAVSXMXNUXCQYRUWJUXAPRUVHUWJUXAP
  SXOAUWDAUWTUVSUXAAUVSUXAPZAUWCUVHAUWSUVHUVSUXAUXDAUWBYRAUWRYRUVSUXAUXDMAUWAUV
  EMAUWQUVEUVSUXAMUVSUXAPUXDUXAUVSUVEUVTUVEUWPUVEUVSUXAPZUXAUVSUVSUVMUVSUXAVSXM
  XNUXEQYRUVSUXAPRUVHUVSUXAPSXOXPAUWDAUWHUVTUXAAUVTUXAPZAUWCUVHAUWGUVHUVTUXAUXF
  AUWBYRAUWFYRUVTUXAUXFMAUWAUVEMAUWEUVEUVTUXAMUVTUXAPUXFUXAUVTUVEUVTUVEUVMUVEUV
  TUXAPZUVTUXAVSXNUXGQYRUVTUXAPRUVHUVTUXAPSXOAUVLAUWHUVEUXAAUVEUXAPZAUVKUVHAUWG
  UVHUVEUXAUXHAUVJYRAUWFYRUVEUXAUXHMAUVIUVEMAUWEUVEUVEUXAMUVEUXAPZUXHUXAUVEUVEU
  VEUVEUVMUVEUVEUXAPZUVEUXAVSZXNUXJQYRUVEUXAPZRUVHUVEUXAPZSXOXPAUVLAUVPUVIUXAAU
  VIUXAPZAUVKUVHAUVOUVHUVIUXAUXNAUVJYRAUVNYRUVIUXAUXNMAUVIUVEMAUVMUVEUVIUXAMUVI
  UXAPUXNUVIUXAVSUVEUVIUXAPQYRUVIUXAPRUVHUVIUXAPSXOAUVQAUVPUVEUXAUXHAUVGUVHAUVO
  UVHUVEUXAUXHAUVFYRAUVNYRUVEUXAUXHMAUVEUVEMAUVMUVEUVEUXAUXIUXHUXKUXJQUXLRUXMSX
  OXPAYDUUEIVHUVBXQXRXSXTYAXRYBYC $. $}
