$c Wgk #Symbol Tw #Variable SwE #SetVariable zw 4w JAQ #ElementVariable IQE #Pattern ) ( $.
$v CQ Bw XRw Cw 2gg -Rs $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Cg $f #Pattern Cw $.
4g $a #Pattern ( 4w Bw CQ ) $.
IAE $a #Pattern IQE $.
SgE $a #Pattern ( SwE Bw CQ ) $.
lQE $a zw ( Tw Bw Bw ) $.
${ lgE $e zw ( Tw Bw CQ ) $.
   lwE $e zw ( Tw CQ Cw ) $.
   mAE $a zw ( Tw Bw Cw ) $. $}
nAE $a zw IQE $.
ugE $a zw ( Tw ( 4w Bw CQ ) Bw ) $.
uwE $a zw ( Tw ( 4w Bw CQ ) CQ ) $.
${ wAE $e zw ( Tw Bw CQ ) $.
   wQE $e zw ( Tw Bw Cw ) $.
   wgE $a zw ( Tw Bw ( 4w CQ Cw ) ) $. $}
${ NwM $e zw CQ $.
   OAM $a zw ( Tw Bw CQ ) $. $}
2Qg $f #ElementVariable 2gg $.
WQk $a #Pattern Wgk $.
-Bs $f #ElementVariable -Rs $.
XBw $f #ElementVariable XRw $.
QCE $a #Pattern XRw $.
QyE $a #Pattern -Rs $.
CCI $a #Pattern ( 4w ( JAQ 2gg ) ( 4w ( SwE XRw Wgk ) IQE ) ) $.
CyI $a zw ( Tw ( 4w ( JAQ 2gg ) ( 4w ( SwE XRw Wgk ) IQE ) ) ( SwE XRw Wgk ) ) $.
${ 2iI $p zw ( Tw ( 4w ( 4w ( JAQ 2gg ) ( 4w ( SwE XRw Wgk ) IQE ) ) ( 4w ( SwE -Rs Wgk ) IQE ) ) ( 4w ( SwE -Rs Wgk ) ( 4w ( SwE XRw Wgk ) IQE ) ) ) $=
  ( CCI QyE WQk SgE IAE 4g QCE uwE ugE lQE mAE CyI nAE OAM wgE ) ACDZBEFGZHIZIZ
  TCJFGZHIUBUATSUAKUATTTHLTMNNUBUCHUBSUCSUALACONUBHPQRR $. $}
