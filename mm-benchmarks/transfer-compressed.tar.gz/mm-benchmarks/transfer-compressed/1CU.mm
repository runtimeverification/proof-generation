$c IAQ Wgk Tw #Symbol #Variable SwE -gg #SetVariable zw 4w JAQ #ElementVariable IQE rgk #Pattern 8hw ) ( $.
$v 5Qg Cw CQ Bw $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Cg $f #Pattern Cw $.
4g $a #Pattern ( 4w Bw CQ ) $.
IAE $a #Pattern IQE $.
SgE $a #Pattern ( SwE Bw CQ ) $.
${ wAE $e zw ( Tw Bw CQ ) $.
   wQE $e zw ( Tw Bw Cw ) $.
   wgE $a zw ( Tw Bw ( 4w CQ Cw ) ) $. $}
HwQ $a #Pattern ( IAQ Bw CQ ) $.
IwQ $a #Pattern ( JAQ Bw ) $.
5Ag $f #ElementVariable 5Qg $.
-Qg $a #Pattern -gg $.
WQk $a #Pattern Wgk $.
rQk $a #Pattern rgk $.
8Rw $a #Pattern 8hw $.
YCU $a #Pattern 5Qg $.
tSU $a zw ( Tw ( 4w ( SwE 5Qg -gg ) IQE ) ( 4w ( JAQ rgk ) ( JAQ Wgk ) ) ) $.
0yU $a zw ( Tw ( 4w ( SwE 5Qg -gg ) IQE ) ( SwE ( IAQ rgk 8hw ) rgk ) ) $.
${ 1CU $p zw ( Tw ( 4w ( SwE 5Qg -gg ) IQE ) ( 4w ( 4w ( JAQ rgk ) ( JAQ Wgk ) ) ( SwE ( IAQ rgk 8hw ) rgk ) ) ) $=
  ( YCU -Qg SgE IAE 4g rQk IwQ WQk 8Rw HwQ tSU 0yU wgE ) ABCDEFGHIHFGJKGDALAMN
  $. $}
