$c Tw #Symbol zw pwk JAQ rgk pgg #Pattern ( LAQ IAQ Wgk #Variable SwE PQk #SetVariable hgk 4w #ElementVariable IQE mwg 8hw ) $.
$v 4wg CQ qwg 3gg -Bw Bw oAg 5Qg MB0 Cw sgg $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Cg $f #Pattern Cw $.
4g $a #Pattern ( 4w Bw CQ ) $.
SgE $a #Pattern ( SwE Bw CQ ) $.
${ lgE $e zw ( Tw Bw CQ ) $.
   lwE $e zw ( Tw CQ Cw ) $.
   mAE $a zw ( Tw Bw Cw ) $. $}
HwQ $a #Pattern ( IAQ Bw CQ ) $.
IwQ $a #Pattern ( JAQ Bw ) $.
KwQ $a #Pattern ( LAQ Bw CQ Cw ) $.
mgg $a #Pattern mwg $.
nwg $f #Pattern oAg $.
qgg $f #Pattern qwg $.
sQg $f #Pattern sgg $.
3Qg $f #ElementVariable 3gg $.
4gg $f #ElementVariable 4wg $.
5Ag $f #ElementVariable 5Qg $.
.gg $a zw ( Tw ( 4w ( 4w ( JAQ oAg ) ( JAQ qwg ) ) ( SwE sgg oAg ) ) ( SwE ( LAQ oAg qwg sgg ) qwg ) ) $.
PAk $a #Pattern PQk $.
WQk $a #Pattern Wgk $.
pgk $a #Pattern pwk $.
rQk $a #Pattern rgk $.
8Rw $a #Pattern 8hw $.
.xw $f #ElementVariable -Bw $.
Lx0 $f #ElementVariable MB0 $.
XiU $a #Pattern 3gg $.
XyU $a #Pattern 4wg $.
YCU $a #Pattern 5Qg $.
rC8 $a #Pattern ( 4w ( SwE -Bw pgg ) ( 4w ( SwE MB0 hgk ) IQE ) ) $.
3i8 $a zw ( Tw ( 4w ( SwE 3gg mwg ) ( 4w ( SwE 4wg PQk ) ( 4w ( SwE 5Qg pwk ) ( 4w ( SwE -Bw pgg ) ( 4w ( SwE MB0 hgk ) IQE ) ) ) ) ) ( 4w ( 4w ( JAQ rgk ) ( JAQ Wgk ) ) ( SwE ( IAQ rgk 8hw ) rgk ) ) ) $.
${ 3y8 $p zw ( Tw ( 4w ( SwE 3gg mwg ) ( 4w ( SwE 4wg PQk ) ( 4w ( SwE 5Qg pwk ) ( 4w ( SwE -Bw pgg ) ( 4w ( SwE MB0 hgk ) IQE ) ) ) ) ) ( SwE ( LAQ rgk Wgk ( IAQ rgk 8hw ) ) Wgk ) ) $=
  ( XiU mgg SgE XyU PAk YCU pgk rC8 4g rQk IwQ WQk 8Rw HwQ KwQ 3i8 .gg mAE ) AF
  GHBIJHCKLHDEMNNNOPQPNORSZOHNOQUDTQHABCDEUAOQUDUBUC $. $}
