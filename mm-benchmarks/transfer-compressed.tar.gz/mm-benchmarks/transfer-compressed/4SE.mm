$c 2R4 Tw #Symbol -gg zw JAQ #Pattern ( 0wM ewk tQM IAQ 3BA #Variable SwE #SetVariable 4w rwM #ElementVariable IQE ) $.
$v yhs CQ Bw XRw Kw Cw 2gg $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Cg $f #Pattern Cw $.
Kg $f #ElementVariable Kw $.
4g $a #Pattern ( 4w Bw CQ ) $.
IAE $a #Pattern IQE $.
SgE $a #Pattern ( SwE Bw CQ ) $.
${ lgE $e zw ( Tw Bw CQ ) $.
   lwE $e zw ( Tw CQ Cw ) $.
   mAE $a zw ( Tw Bw Cw ) $. $}
rgM $a #Pattern ( rwM Bw CQ Kw Cw ) $.
tAM $a #Pattern ( tQM Bw CQ ) $.
IwQ $a #Pattern ( JAQ Bw ) $.
2Qg $f #ElementVariable 2gg $.
-Qg $a #Pattern -gg $.
yRs $f #ElementVariable yhs $.
XBw $f #ElementVariable XRw $.
Wh8 $a #Pattern 2gg $.
QCE $a #Pattern XRw $.
YyE $a #Pattern ( 4w ( JAQ 2gg ) ( 4w ( SwE XRw -gg ) IQE ) ) $.
gCE $a #Pattern ( 0wM -gg 2gg yhs ( 3BA ( IAQ ewk 2R4 ) XRw ) ) $.
hiE $a zw ( Tw ( 4w ( JAQ 2gg ) ( 4w ( SwE XRw -gg ) IQE ) ) ( tQM 2gg ( rwM -gg 2gg yhs ( 0wM -gg 2gg yhs ( 3BA ( IAQ ewk 2R4 ) XRw ) ) ) ) ) $.
siE $a zw ( Tw ( 4w ( 4w ( JAQ 2gg ) IQE ) ( 4w ( SwE XRw -gg ) IQE ) ) ( 4w ( JAQ 2gg ) ( 4w ( SwE XRw -gg ) IQE ) ) ) $.
${ 4SE $p zw ( Tw ( 4w ( 4w ( JAQ 2gg ) IQE ) ( 4w ( SwE XRw -gg ) IQE ) ) ( tQM 2gg ( rwM -gg 2gg yhs ( 0wM -gg 2gg yhs ( 3BA ( IAQ ewk 2R4 ) XRw ) ) ) ) ) $=
  ( Wh8 IwQ IAE 4g QCE -Qg SgE YyE gCE rgM tAM siE hiE mAE ) ADZEFGCHIJFGGACKRI
  RABCLBMNACOABCPQ $. $}
