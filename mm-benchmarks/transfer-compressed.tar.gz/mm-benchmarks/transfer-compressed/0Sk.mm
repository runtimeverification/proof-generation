$c Uw PgE Tw #Symbol zw JAQ pgg rgk #Pattern ( 0wM LAQ tQM IAQ 0h4 #Variable SwE #SetVariable iA 4w rwM #ElementVariable IQE ) $.
$v th1 yhs 7Rw CQ Bw Cw 2gg z ph2 Ew ph0 x Lw LQ Ow ph6 DQ ph1 EQ y th2 Dw HQ xX Gw th0 zBs Hw Kw GQ nR4 $.
$d z y $.
$d z x $.
$d y x $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Cg $f #Pattern Cw $.
DA $f #Pattern DQ $.
Dg $f #Pattern Dw $.
EA $f #Pattern EQ $.
Eg $f #Pattern Ew $.
GA $f #Pattern GQ $.
Gg $f #Pattern Gw $.
HA $f #Pattern HQ $.
Hg $f #Pattern Hw $.
Kg $f #ElementVariable Kw $.
LA $f #ElementVariable LQ $.
Lg $f #ElementVariable Lw $.
Og $f #Variable Ow $.
SA $a #Variable Kw $.
jg $a iA Bw Ow Bw Ow $.
${ kg $e iA CQ DQ Bw Ow $.
   kw $e iA Cw Dw Bw Ow $.
   lA $a iA ( Tw CQ Cw ) ( Tw DQ Dw ) Bw Ow $. $}
4g $a #Pattern ( 4w Bw CQ ) $.
IAE $a #Pattern IQE $.
SgE $a #Pattern ( SwE Bw CQ ) $.
${ lgE $e zw ( Tw Bw CQ ) $.
   lwE $e zw ( Tw CQ Cw ) $.
   mAE $a zw ( Tw Bw Cw ) $. $}
${ wAE $e zw ( Tw Bw CQ ) $.
   wQE $e zw ( Tw Bw Cw ) $.
   wgE $a zw ( Tw Bw ( 4w CQ Cw ) ) $. $}
${ $d xX ph0 $.
   IQI $a iA Bw Bw CQ Ow $. $}
${ KAI $e iA CQ DQ Bw Ow $.
   KQI $e iA Cw Dw Bw Ow $.
   KgI $a iA ( 4w CQ Cw ) ( 4w DQ Dw ) Bw Ow $. $}
${ OgI $e iA CQ DQ Bw Ow $.
   OwI $e iA Cw Dw Bw Ow $.
   PAI $a iA ( SwE CQ Cw ) ( SwE DQ Dw ) Bw Ow $. $}
rgM $a #Pattern ( rwM Bw CQ Kw Cw ) $.
tAM $a #Pattern ( tQM Bw CQ ) $.
0gM $a #Pattern ( 0wM Bw CQ Cw DQ ) $.
HwQ $a #Pattern ( IAQ Bw CQ ) $.
IwQ $a #Pattern ( JAQ Bw ) $.
KwQ $a #Pattern ( LAQ Bw CQ Cw ) $.
${ $d xX y $.
   $d y ph6 $.
   OAQ $e iA Bw DQ Ew Ow $.
   OQQ $e iA CQ Dw Ew Ow $.
   OgQ $e iA Cw EQ Ew Ow $.
   OwQ $a iA ( rwM Bw CQ LQ Cw ) ( rwM DQ Dw LQ EQ ) Ew Ow $. $}
${ QAQ $e iA Bw Cw Dw Ow $.
   QQQ $e iA CQ DQ Dw Ow $.
   QgQ $a iA ( tQM Bw CQ ) ( tQM Cw DQ ) Dw Ow $. $}
${ $d z ph0 $.
   $d z ph1 $.
   $d z ph2 $.
   $d z y $.
   $d z x $.
   $d z th1 $.
   $d z th2 $.
   $d x ph0 $.
   $d y th0 $.
   lAY $e zw ( Tw GQ ( Uw Kw ( PgE Kw Bw ) ) ) $.
   lQY $e zw ( Tw ( 4w GQ Gw ) CQ ) $.
   lgY $e iA ( Tw HQ Cw ) ( Tw Gw CQ ) Bw LQ $.
   lwY $e iA ( Tw Hw DQ ) ( Tw Gw CQ ) Lw LQ $.
   mAY $a zw ( Tw ( 4w GQ HQ ) Cw ) $. $}
pQg $a #Pattern pgg $.
2Qg $f #ElementVariable 2gg $.
rQk $a #Pattern rgk $.
yRs $f #ElementVariable yhs $.
yxs $f #ElementVariable zBs $.
7Bw $f #ElementVariable 7Rw $.
nB4 $f #ElementVariable nR4 $.
0R4 $a #Pattern 0h4 $.
Wh8 $a #Pattern 2gg $.
6h8 $a #Pattern nR4 $.
9h8 $a zw ( Tw ( 4w ( JAQ 2gg ) IQE ) ( 4w ( JAQ 2gg ) IQE ) ) $.
UyA $a zw ( Tw ( 4w ( JAQ 2gg ) IQE ) ( Uw 7Rw ( PgE 7Rw ( IAQ rgk 0h4 ) ) ) ) $.
XyA $a zw ( Tw ( 4w ( JAQ 2gg ) IQE ) ( 4w ( SwE ( IAQ rgk 0h4 ) rgk ) IQE ) ) $.
7SA $a #Pattern yhs $.
JiE $a #Pattern zBs $.
NSE $a iA 2gg 2gg nR4 zBs $.
LyI $a iA ( 4w ( SwE nR4 rgk ) IQE ) ( 4w ( SwE zBs rgk ) IQE ) nR4 zBs $.
aSI $a iA 2gg 2gg ( IAQ rgk 0h4 ) zBs $.
TCY $a #Pattern ( 0wM pgg 2gg yhs ( LAQ rgk pgg zBs ) ) $.
TSY $a zw ( Tw ( 4w ( 4w ( JAQ 2gg ) IQE ) ( 4w ( SwE zBs rgk ) IQE ) ) ( tQM 2gg ( rwM pgg 2gg yhs ( 0wM pgg 2gg yhs ( LAQ rgk pgg zBs ) ) ) ) ) $.
TiY $a #Pattern ( 0wM pgg 2gg yhs ( LAQ rgk pgg nR4 ) ) $.
UiY $a iA ( rwM pgg 2gg yhs ( 0wM pgg 2gg yhs ( LAQ rgk pgg nR4 ) ) ) ( rwM pgg 2gg yhs ( 0wM pgg 2gg yhs ( LAQ rgk pgg zBs ) ) ) nR4 zBs $.
0Ck $a iA ( 0wM pgg 2gg yhs ( LAQ rgk pgg ( IAQ rgk 0h4 ) ) ) ( 0wM pgg 2gg yhs ( LAQ rgk pgg zBs ) ) ( IAQ rgk 0h4 ) zBs $.
${ 0Sk $p zw ( Tw ( 4w ( JAQ 2gg ) IQE ) ( tQM 2gg ( rwM pgg 2gg yhs ( 0wM pgg 2gg yhs ( LAQ rgk pgg ( IAQ rgk 0h4 ) ) ) ) ) ) $=
  ( yxs nB4 7Bw Wh8 IwQ IAE 4g rQk 0R4 HwQ SgE pQg 7SA rgM tAM IQI QgQ lA SA jg
  KwQ 0gM 9h8 XyA wgE TCY TiY JiE 6h8 UyA TSY PAI KgI aSI 0Ck OwQ LyI NSE UiY
  mAY mAE ) AFZGHIZVEJKLZJMZHIZIVDNVDNVDBOJNVFUCUDZBPZQZVEVEVHAUEAUFUGVFVDNVDAB
  CUHZBPZQZVKVDNVDABDUIBPZQZVECUJZJMZHIZVHDUKZJMHIZECDAEULABCUMVFVHVKVSVNCUAZVF
  VGHVRHWBVFVFJVQJWBVFWBUBJVFWBRUNHVFWBRUOVDVJVDVMVFWBACUPZNVDVINVDVLVFBWBNVFWB
  RWCABCUQURSTVTWAVPVSVNWBCDUSVDVOVDVMVTWBACDUTABCDVASTVBVC $. $}
