$c Uw Ngk #Symbol 7h4 DBE 8Q4 zw pgg #Pattern 0Q4 Kw0 rwg 0wM oBM Ex0 xB4 tQM Wgk 5xw #Variable SwE PQk #SetVariable iA vR4 4w rwM #ElementVariable IQE qxs mwg 8hw xQg Vhc kBM 2R4 zBA XBI PgE Tw cwE wQM -g4 zBI pwk .gk rgk ( RQ0 twM .gM LAQ ewk IAQ Hg8 hgk ) $.
$v th1 CQ -Bw Bw Cw sgg ngg z ph2 3gg Ew ph0 5Qg x Lw LQ Ow qwg DQ ph1 EQ y th2 tAg Dw HQ 4wg xX Gw th0 Hw Kw oAg 6Ag GQ nR4 tgg $.
$d z y $.
$d z x $.
$d y x $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Cg $f #Pattern Cw $.
DA $f #Pattern DQ $.
Dg $f #Pattern Dw $.
EA $f #Pattern EQ $.
Eg $f #Pattern Ew $.
GA $f #Pattern GQ $.
Gg $f #Pattern Gw $.
HA $f #Pattern HQ $.
Hg $f #Pattern Hw $.
Kg $f #ElementVariable Kw $.
LA $f #ElementVariable LQ $.
Lg $f #ElementVariable Lw $.
Og $f #Variable Ow $.
SA $a #Variable Kw $.
Tg $a #Pattern ( Tw Bw CQ ) $.
Ug $a #Pattern ( Uw Kw Bw ) $.
jg $a iA Bw Ow Bw Ow $.
${ kg $e iA CQ DQ Bw Ow $.
   kw $e iA Cw Dw Bw Ow $.
   lA $a iA ( Tw CQ Cw ) ( Tw DQ Dw ) Bw Ow $. $}
4g $a #Pattern ( 4w Bw CQ ) $.
5Q $a zw ( Tw Bw ( Tw CQ Bw ) ) $.
${ 6A $e zw ( Tw Bw CQ ) $.
   6Q $e zw Bw $.
   6g $a zw CQ $. $}
IAE $a #Pattern IQE $.
PQE $a #Pattern ( PgE Bw CQ ) $.
SgE $a #Pattern ( SwE Bw CQ ) $.
lQE $a zw ( Tw Bw Bw ) $.
${ lgE $e zw ( Tw Bw CQ ) $.
   lwE $e zw ( Tw CQ Cw ) $.
   mAE $a zw ( Tw Bw Cw ) $. $}
nAE $a zw IQE $.
ugE $a zw ( Tw ( 4w Bw CQ ) Bw ) $.
uwE $a zw ( Tw ( 4w Bw CQ ) CQ ) $.
${ wAE $e zw ( Tw Bw CQ ) $.
   wQE $e zw ( Tw Bw Cw ) $.
   wgE $a zw ( Tw Bw ( 4w CQ Cw ) ) $. $}
${ $d xX ph0 $.
   IQI $a iA Bw Bw CQ Ow $. $}
${ KAI $e iA CQ DQ Bw Ow $.
   KQI $e iA Cw Dw Bw Ow $.
   KgI $a iA ( 4w CQ Cw ) ( 4w DQ Dw ) Bw Ow $. $}
${ OgI $e iA CQ DQ Bw Ow $.
   OwI $e iA Cw Dw Bw Ow $.
   PAI $a iA ( SwE CQ Cw ) ( SwE DQ Dw ) Bw Ow $. $}
${ NwM $e zw CQ $.
   OAM $a zw ( Tw Bw CQ ) $. $}
tAM $a #Pattern ( tQM Bw CQ ) $.
uwM $a #Pattern ( twM Bw ) $.
wAM $a #Pattern ( wQM Bw CQ Cw ) $.
0gM $a #Pattern ( 0wM Bw CQ Cw DQ ) $.
.QM $a #Pattern ( .gM Bw CQ Cw ) $.
HwQ $a #Pattern ( IAQ Bw CQ ) $.
KwQ $a #Pattern ( LAQ Bw CQ Cw ) $.
${ QAQ $e iA Bw Cw Dw Ow $.
   QQQ $e iA CQ DQ Dw Ow $.
   QgQ $a iA ( tQM Bw CQ ) ( tQM Cw DQ ) Dw Ow $. $}
${ SgQ $e iA Bw DQ Ew Ow $.
   SwQ $e iA CQ Dw Ew Ow $.
   TAQ $e iA Cw EQ Ew Ow $.
   TQQ $a iA ( wQM Bw CQ Cw ) ( wQM DQ Dw EQ ) Ew Ow $. $}
${ awQ $e iA Bw DQ Ew Ow $.
   bAQ $e iA CQ Dw Ew Ow $.
   bQQ $e iA Cw EQ Ew Ow $.
   bgQ $a iA ( .gM Bw CQ Cw ) ( .gM DQ Dw EQ ) Ew Ow $. $}
${ $d z ph0 $.
   $d z ph1 $.
   $d z ph2 $.
   $d z y $.
   $d z x $.
   $d z th1 $.
   $d z th2 $.
   $d x ph0 $.
   $d y th0 $.
   lAY $e zw ( Tw GQ ( Uw Kw ( PgE Kw Bw ) ) ) $.
   lQY $e zw ( Tw ( 4w GQ Gw ) CQ ) $.
   lgY $e iA ( Tw HQ Cw ) ( Tw Gw CQ ) Bw LQ $.
   lwY $e iA ( Tw Hw DQ ) ( Tw Gw CQ ) Lw LQ $.
   mAY $a zw ( Tw ( 4w GQ HQ ) Cw ) $. $}
${ $d x ph0 $.
   $d x ph1 $.
   vwY $e zw ( Tw GQ ( SwE CQ Bw ) ) $.
   wAY $e zw ( Tw GQ ( tQM cwE ( rwM Bw cwE Kw ( 0wM Bw cwE Kw CQ ) ) ) ) $.
   wQY $a zw ( Tw GQ ( Uw Kw ( PgE Kw CQ ) ) ) $. $}
mgg $a #Pattern mwg $.
nQg $f #Variable ngg $.
nwg $f #Pattern oAg $.
pQg $a #Pattern pgg $.
qgg $f #Pattern qwg $.
rgg $a #Pattern ( rwg oAg qwg ) $.
sQg $f #Pattern sgg $.
swg $f #Pattern tAg $.
tQg $f #Pattern tgg $.
${ uQg $e iA qwg tAg oAg ngg $.
   ugg $e iA sgg tgg oAg ngg $.
   uwg $a iA ( rwg qwg sgg ) ( rwg tAg tgg ) oAg ngg $. $}
wQg $a zw ( Tw ( 4w ( SwE oAg pgg ) ( SwE qwg mwg ) ) ( SwE ( rwg oAg qwg ) mwg ) ) $.
xAg $a #Pattern xQg $.
yAg $a zw ( SwE xQg mwg ) $.
3Qg $f #ElementVariable 3gg $.
4gg $f #ElementVariable 4wg $.
5Ag $f #ElementVariable 5Qg $.
5wg $f #ElementVariable 6Ag $.
NQk $a #Pattern Ngk $.
PAk $a #Pattern PQk $.
WQk $a #Pattern Wgk $.
egk $a #Pattern ewk $.
hQk $a #Pattern hgk $.
pgk $a #Pattern pwk $.
rQk $a #Pattern rgk $.
.Qk $a #Pattern .gk $.
Kg0 $a #Pattern ( Kw0 oAg ) $.
RA0 $a #Pattern ( RQ0 oAg qwg ) $.
UQ0 $a zw ( Tw ( 4w ( SwE oAg mwg ) ( SwE qwg mwg ) ) ( SwE ( RQ0 oAg qwg ) pgg ) ) $.
0A4 $a #Pattern ( 0Q4 oAg qwg ) $.
${ 1Q4 $e iA qwg tAg oAg ngg $.
   1g4 $e iA sgg tgg oAg ngg $.
   1w4 $a iA ( 0Q4 qwg sgg ) ( 0Q4 tAg tgg ) oAg ngg $. $}
8A4 $a #Pattern ( 8Q4 oAg ) $.
-Q4 $a #Pattern ( -g4 oAg qwg ) $.
${ Ag8 $e iA qwg tAg oAg ngg $.
   Aw8 $e iA sgg tgg oAg ngg $.
   BA8 $a iA ( -g4 qwg sgg ) ( -g4 tAg tgg ) oAg ngg $. $}
HQ8 $a #Pattern ( Hg8 oAg ) $.
${ Ig8 $e iA qwg sgg oAg ngg $.
   Iw8 $a iA ( Hg8 qwg ) ( Hg8 sgg ) oAg ngg $. $}
yxA $a #Pattern ( zBA oAg qwg ) $.
CxE $a #Pattern ( DBE oAg qwg ) $.
WxI $a #Pattern ( XBI oAg qwg ) $.
yxI $a #Pattern ( zBI oAg qwg ) $.
jxM $a #Pattern ( kBM oAg qwg ) $.
nxM $a #Pattern ( oBM oAg qwg ) $.
VRc $a #Pattern ( Vhc oAg ) $.
qhs $a #Pattern ( qxs oAg ) $.
5hw $a #Pattern 5xw $.
8Rw $a #Pattern 8hw $.
.xw $f #ElementVariable -Bw $.
Eh0 $a #Pattern Ex0 $.
nB4 $f #ElementVariable nR4 $.
vB4 $a #Pattern vR4 $.
wx4 $a #Pattern xB4 $.
2B4 $a #Pattern 2R4 $.
7R4 $a #Pattern 7h4 $.
JB8 $a zw ( Tw IQE ( SwE xQg mwg ) ) $.
VB8 $a zw ( Tw IQE ( SwE ( rwg ( LAQ hgk pgg ( qxs ( XBI ( IAQ ewk xB4 ) ( LAQ rgk Wgk ( IAQ rgk 8hw ) ) ) ) ) xQg ) mwg ) ) $.
VR8 $a zw ( Tw IQE ( SwE ( rwg ( LAQ hgk pgg ( qxs ( kBM ( kBM ( XBI ( IAQ ewk vR4 ) ( DBE ( LAQ ewk Wgk ( IAQ ewk vR4 ) ) ( LAQ ewk Wgk ( IAQ ewk 2R4 ) ) ) ) ( XBI ( IAQ ewk 7h4 ) ( zBA ( LAQ ewk Wgk ( IAQ ewk 7h4 ) ) ( LAQ ewk Wgk ( IAQ ewk 2R4 ) ) ) ) ) ( XBI ( IAQ ewk xB4 ) ( LAQ rgk Wgk ( IAQ rgk Ex0 ) ) ) ) ) ) xQg ) mwg ) ) $.
6h8 $a #Pattern nR4 $.
BCE $a #Pattern 6Ag $.
XiU $a #Pattern 3gg $.
XyU $a #Pattern 4wg $.
YCU $a #Pattern 5Qg $.
kSU $a iA Ngk Ngk nR4 3gg $.
liU $a iA 4wg 4wg nR4 3gg $.
yyg $a #Pattern -Bw $.
xCo $a iA ( 4w ( SwE nR4 mwg ) IQE ) ( 4w ( SwE 3gg mwg ) IQE ) nR4 3gg $.
9ys $a #Pattern ( 0Q4 ( Hg8 ( rwg ( LAQ pwk pgg ( zBI 5Qg ( LAQ ewk Wgk ( IAQ ewk vR4 ) ) ) ) 3gg ) ) 4wg ) $.
Wyw $a zw ( Tw IQE ( tQM cwE ( rwM mwg cwE 6Ag ( 0wM mwg cwE 6Ag ( rwg ( RQ0 ( rwg ( LAQ hgk pgg ( qxs ( XBI ( IAQ ewk xB4 ) ( LAQ rgk Wgk ( IAQ rgk 8hw ) ) ) ) ) xQg ) ( rwg ( LAQ hgk pgg ( qxs ( kBM ( kBM ( XBI ( IAQ ewk vR4 ) ( DBE ( LAQ ewk Wgk ( IAQ ewk vR4 ) ) ( LAQ ewk Wgk ( IAQ ewk 2R4 ) ) ) ) ( XBI ( IAQ ewk 7h4 ) ( zBA ( LAQ ewk Wgk ( IAQ ewk 7h4 ) ) ( LAQ ewk Wgk ( IAQ ewk 2R4 ) ) ) ) ) ( XBI ( IAQ ewk xB4 ) ( LAQ rgk Wgk ( IAQ rgk Ex0 ) ) ) ) ) ) xQg ) ) xQg ) ) ) ) ) $.
XSw $a #Pattern ( 0Q4 ( Hg8 ( rwg ( LAQ pwk pgg ( zBI 5Qg ( LAQ ewk Wgk ( IAQ ewk vR4 ) ) ) ) nR4 ) ) 4wg ) $.
Xiw $a iA ( -g4 ( 0Q4 ( Hg8 ( rwg ( LAQ pwk pgg ( zBI 5Qg ( LAQ ewk Wgk ( IAQ ewk vR4 ) ) ) ) nR4 ) ) 4wg ) ( 8Q4 ( IAQ rgk 8hw ) ) ) ( -g4 ( 0Q4 ( Hg8 ( rwg ( LAQ pwk pgg ( zBI 5Qg ( LAQ ewk Wgk ( IAQ ewk vR4 ) ) ) ) 3gg ) ) 4wg ) ( 8Q4 ( IAQ rgk 8hw ) ) ) nR4 3gg $.
pC0 $a #Pattern ( 4w ( SwE 5Qg Wgk ) ( 4w ( SwE -Bw pgg ) IQE ) ) $.
wy0 $a zw ( Tw ( 4w ( SwE 3gg mwg ) ( 4w ( SwE 4wg PQk ) ( 4w ( SwE 5Qg Wgk ) ( 4w ( SwE -Bw pgg ) IQE ) ) ) ) ( tQM Ngk ( .gM Ngk ( wQM Ngk ( 0wM .gk Ngk ( oBM ( IAQ .gk 5xw ) ( Vhc ( rwg -Bw xQg ) ) ) ( IAQ .gk 5xw ) ) ( -g4 ( 0Q4 ( Hg8 ( rwg ( wQM pgg ( LAQ Wgk pgg 5Qg ) -Bw ) ( rwg ( Kw0 ( rwg ( LAQ Wgk pgg ( LAQ ewk Wgk ( IAQ ewk vR4 ) ) ) xQg ) ) 3gg ) ) ) 4wg ) ( 8Q4 ( IAQ rgk 8hw ) ) ) ) ( wQM Ngk ( twM Ngk ) ( -g4 ( 0Q4 ( Hg8 ( rwg ( LAQ pwk pgg ( zBI 5Qg ( LAQ ewk Wgk ( IAQ ewk vR4 ) ) ) ) 3gg ) ) 4wg ) ( 8Q4 ( IAQ rgk 8hw ) ) ) ) ) ) ) $.
xy0 $a zw ( Tw ( 4w ( 4w ( SwE 4wg PQk ) ( 4w ( SwE 5Qg Wgk ) ( 4w ( SwE -Bw pgg ) IQE ) ) ) ( 4w ( SwE 3gg mwg ) IQE ) ) ( 4w ( SwE 5Qg Wgk ) ( 4w ( SwE -Bw pgg ) IQE ) ) ) $.
yS0 $a zw ( Tw ( 4w ( SwE 4wg PQk ) ( 4w ( SwE 5Qg Wgk ) ( 4w ( SwE -Bw pgg ) IQE ) ) ) ( 4w ( SwE 5Qg Wgk ) ( 4w ( SwE -Bw pgg ) IQE ) ) ) $.
0C0 $a zw ( Tw ( 4w ( SwE 4wg PQk ) ( 4w ( SwE 5Qg Wgk ) ( 4w ( SwE -Bw pgg ) IQE ) ) ) ( SwE ( rwg ( LAQ hgk pgg ( qxs ( XBI ( IAQ ewk xB4 ) ( LAQ rgk Wgk ( IAQ rgk 8hw ) ) ) ) ) xQg ) mwg ) ) $.
2i0 $a zw ( Tw ( 4w ( SwE 4wg PQk ) ( 4w ( SwE 5Qg Wgk ) ( 4w ( SwE -Bw pgg ) IQE ) ) ) ( SwE ( LAQ hgk pgg ( qxs ( kBM ( kBM ( XBI ( IAQ ewk vR4 ) ( DBE ( LAQ ewk Wgk ( IAQ ewk vR4 ) ) ( LAQ ewk Wgk ( IAQ ewk 2R4 ) ) ) ) ( XBI ( IAQ ewk 7h4 ) ( zBA ( LAQ ewk Wgk ( IAQ ewk 7h4 ) ) ( LAQ ewk Wgk ( IAQ ewk 2R4 ) ) ) ) ) ( XBI ( IAQ ewk xB4 ) ( LAQ rgk Wgk ( IAQ rgk Ex0 ) ) ) ) ) ) pgg ) ) $.
${ 2y0 $p zw ( Tw ( 4w ( SwE 4wg PQk ) ( 4w ( SwE 5Qg Wgk ) ( 4w ( SwE -Bw pgg ) IQE ) ) ) ( tQM Ngk ( .gM Ngk ( wQM Ngk ( 0wM .gk Ngk ( oBM ( IAQ .gk 5xw ) ( Vhc ( rwg -Bw xQg ) ) ) ( IAQ .gk 5xw ) ) ( -g4 ( 0Q4 ( Hg8 ( rwg ( wQM pgg ( LAQ Wgk pgg 5Qg ) -Bw ) ( rwg ( Kw0 ( rwg ( LAQ Wgk pgg ( LAQ ewk Wgk ( IAQ ewk vR4 ) ) ) xQg ) ) ( rwg ( RQ0 ( rwg ( LAQ hgk pgg ( qxs ( XBI ( IAQ ewk xB4 ) ( LAQ rgk Wgk ( IAQ rgk 8hw ) ) ) ) ) xQg ) ( rwg ( LAQ hgk pgg ( qxs ( kBM ( kBM ( XBI ( IAQ ewk vR4 ) ( DBE ( LAQ ewk Wgk ( IAQ ewk vR4 ) ) ( LAQ ewk Wgk ( IAQ ewk 2R4 ) ) ) ) ( XBI ( IAQ ewk 7h4 ) ( zBA ( LAQ ewk Wgk ( IAQ ewk 7h4 ) ) ( LAQ ewk Wgk ( IAQ ewk 2R4 ) ) ) ) ) ( XBI ( IAQ ewk xB4 ) ( LAQ rgk Wgk ( IAQ rgk Ex0 ) ) ) ) ) ) xQg ) ) xQg ) ) ) ) 4wg ) ( 8Q4 ( IAQ rgk 8hw ) ) ) ) ( wQM Ngk ( twM Ngk ) ( -g4 ( 0Q4 ( Hg8 ( rwg ( LAQ pwk pgg ( zBI 5Qg ( LAQ ewk Wgk ( IAQ ewk vR4 ) ) ) ) ( rwg ( RQ0 ( rwg ( LAQ hgk pgg ( qxs ( XBI ( IAQ ewk xB4 ) ( LAQ rgk Wgk ( IAQ rgk 8hw ) ) ) ) ) xQg ) ( rwg ( LAQ hgk pgg ( qxs ( kBM ( kBM ( XBI ( IAQ ewk vR4 ) ( DBE ( LAQ ewk Wgk ( IAQ ewk vR4 ) ) ( LAQ ewk Wgk ( IAQ ewk 2R4 ) ) ) ) ( XBI ( IAQ ewk 7h4 ) ( zBA ( LAQ ewk Wgk ( IAQ ewk 7h4 ) ) ( LAQ ewk Wgk ( IAQ ewk 2R4 ) ) ) ) ) ( XBI ( IAQ ewk xB4 ) ( LAQ rgk Wgk ( IAQ rgk Ex0 ) ) ) ) ) ) xQg ) ) xQg ) ) ) 4wg ) ( 8Q4 ( IAQ rgk 8hw ) ) ) ) ) ) ) $=
  ( 3Qg nB4 SgE 4g pQg egk HwQ WQk KwQ xAg rgg mgg IAE NQk mAE wgE IQI Tg 5Q 6g
  5wg XyU PAk pC0 hQk wx4 rQk 8Rw WxI qhs vB4 2B4 CxE 7R4 yxA jxM Eh0 RA0 Ug SA
  .Qk 5hw yyg VRc nxM 0gM YCU wAM Kg0 HQ8 0A4 8A4 -Q4 uwM pgk yxI .QM tAM jg lA
  ugE lQE yS0 0C0 2i0 yAg wQg UQ0 nAE OAM XiU 9ys 6h8 XSw BCE PQE VB8 VR8 JB8
  Wyw wQY uwE xy0 wy0 PAI KgI uwg Iw8 1w4 BA8 TQQ bgQ QgQ xCo kSU liU Xiw mAY )
  AUEZUFFZBCUGZGZYEUHHIUIJZUJKUJUKJZLULUMLMNZUHHIUNJZIKYILZIKIUOJLZUPULIUQJZIKY
  LLYKURULUSYFUJKUJUTJLULUSUMLZMNZVAZMNZOFZPGZGQQQVDQVDVEJZCVFZMNVGVHYSVIZHKHBV
  JZLYTVKZKHYJLMNVLZYPNZNZVMZYBVNZYGVOZVPZVKZQQVQZVRHUUBYJVSLZYPNZVMZYBVNZUUIVP
  ZVKZVTZWAZYEYEYRYEYCYDYEYCYCYCYDWDZYCWERABCWFSYEYQPYEYOHFZMOFZGZYQYEUVBUVCYEY
  HOFZYNOFZGZUVBYEUVEUVFABCWGYEYMHFZUVCGUVFYEUVHUVCABCWHUVCYEUVCUAUVCYEUBWIUCZS
  YMMWJRSYHYNWKZRUVISYOMWJZRYEPWLWMZSSYPQQQUUAUUCUUDDWNZNZNZVMZYBVNZUUIVPZVKZQU
  ULDABWOZUUIVPZVKZVTZWAZUUTQQQUUAUUCUUDEWPZNZNZVMZYBVNZUUIVPZVKZQUULABEWQUUIVP
  ZVKZVTZWAZYEUVMOFZPGZYRUWEOFPGZUDDEYEPUDWRYPWSUDVBUVLOYPPUDPUVDYQPUVBUVCPUVGU
  VBPUVEUVFWTXASUVJRXBSUVKRUDXCXDRYEUWQGZUWPYEGUWDUWSUWPYEUWSUWQUWPYEUWQXEUWQUW
  PUWPUWPPWDUWPWERRUWSYCYDUWSYEYCYEUWQWDUVARDABCXFSSDABCXGRYPYRUUTUWQUWDDVCZYPY
  QPUWPPUWTYPYPOUVMOUWTYPUWTWBZOYPUWTTXHPYPUWTTXIQUUSQUWCYPUWTQYPUWTTZQUUKUURQU
  VSUWBYPUWTUXBQUUAUUJQUUAUVRYPUWTUXBUUAYPUWTTUWTYPUUHUUIUVQUUIUWTYPUUGYBUVPYBU
  WTYPUUFUVOUWTYPUUCUUEUUCUVNUUCYPUWTTUWTYPUUDYPUUDUVMUUDYPUWTTUXAXJXJXKYBYPUWT
  TZXLUUIYPUWTTZXMXNQUULUUQQUULUWAYPUWTUXBUULYPUWTTUWTYPUUPUUIUVTUUIUWTYPUUOYBU
  UMUVMNZVMYBUWTYPUUNUXEUWTYPUUMYPUUMUVMUUMYPUWTTUXAXJXKUXCXLUXDXMXNXOXPWCUWEUW
  RUWOUWQUWDUWTDEXQQUWNQUWCUWEUWTDEXRZQUWKUWMQUVSUWBUWEUWTUXFQUUAUWJQUUAUVRUWEU
  WTUXFUUAUWEUWTTUWTUWEUWIUUIUVQUUIUWTUWEUWHYBUVPYBUWTUWEUWGUVOUWTUWEUUCUWFUUCU
  VNUUCUWEUWTTUWTUWEUUDUWEUUDUVMUUDUWEUWTTUWEUWTWBXJXJXKDAEXSXLUUIUWEUWTTXMXNQU
  ULUWLQUULUWAUWEUWTUXFUULUWEUWTTDABEXTXNXOXPWCYAR $. $}
