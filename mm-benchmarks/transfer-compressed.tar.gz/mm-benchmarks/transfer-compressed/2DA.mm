$c LAQ #Symbol #Variable #SetVariable iA pwk #ElementVariable .gk #Pattern ) ( $.
$v Ow CQ DQ Ew Bw Kw Cw nR4 EQ mh4 Dw $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Cg $f #Pattern Cw $.
DA $f #Pattern DQ $.
Dg $f #Pattern Dw $.
EA $f #Pattern EQ $.
Eg $f #Pattern Ew $.
Kg $f #ElementVariable Kw $.
Og $f #Variable Ow $.
SA $a #Variable Kw $.
jg $a iA Bw Ow Bw Ow $.
${ lAQ $e iA Bw DQ Ew Ow $.
   lQQ $e iA CQ Dw Ew Ow $.
   lgQ $e iA Cw EQ Ew Ow $.
   lwQ $a iA ( LAQ Bw CQ Cw ) ( LAQ DQ Dw EQ ) Ew Ow $. $}
pgk $a #Pattern pwk $.
.Qk $a #Pattern .gk $.
mR4 $f #ElementVariable mh4 $.
nB4 $f #ElementVariable nR4 $.
YR8 $a #Pattern mh4 $.
6h8 $a #Pattern nR4 $.
rDA $a iA .gk .gk nR4 mh4 $.
1zA $a iA pwk pwk nR4 mh4 $.
${ 2DA $p iA ( LAQ .gk pwk nR4 ) ( LAQ .gk pwk mh4 ) nR4 mh4 $=
  ( .Qk pgk 6h8 YR8 SA rDA 1zA jg lwQ ) CDBEZCDAFLAGZABHABILMJK $. $}
