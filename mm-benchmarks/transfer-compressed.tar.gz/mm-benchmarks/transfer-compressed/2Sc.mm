$c 0wM LAQ ewk xB4 cBQ IAQ #Symbol #Variable #SetVariable iA rwM YQk #ElementVariable pgg #Pattern ) ( $.
$v yhs Fw Ow CQ ph6 qwg DQ Bw XRw Cw 2gg EQ y -Rs sgg tAg Dw ngg FQ xX Ew Kw ph0 oAg tgg LQ $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Cg $f #Pattern Cw $.
DA $f #Pattern DQ $.
Dg $f #Pattern Dw $.
EA $f #Pattern EQ $.
Eg $f #Pattern Ew $.
FA $f #Pattern FQ $.
Fg $f #Pattern Fw $.
Kg $f #ElementVariable Kw $.
LA $f #ElementVariable LQ $.
Og $f #Variable Ow $.
SA $a #Variable Kw $.
jg $a iA Bw Ow Bw Ow $.
${ $d xX ph0 $.
   IQI $a iA Bw Bw CQ Ow $. $}
HwQ $a #Pattern ( IAQ Bw CQ ) $.
KwQ $a #Pattern ( LAQ Bw CQ Cw ) $.
${ $d xX y $.
   $d y ph6 $.
   OAQ $e iA Bw DQ Ew Ow $.
   OQQ $e iA CQ Dw Ew Ow $.
   OgQ $e iA Cw EQ Ew Ow $.
   OwQ $a iA ( rwM Bw CQ LQ Cw ) ( rwM DQ Dw LQ EQ ) Ew Ow $. $}
${ XgQ $e iA Bw Dw Fw Ow $.
   XwQ $e iA CQ EQ Fw Ow $.
   YAQ $e iA Cw Ew Fw Ow $.
   YQQ $e iA DQ FQ Fw Ow $.
   YgQ $a iA ( 0wM Bw CQ Cw DQ ) ( 0wM Dw EQ Ew FQ ) Fw Ow $. $}
nQg $f #Variable ngg $.
nwg $f #Pattern oAg $.
pQg $a #Pattern pgg $.
qgg $f #Pattern qwg $.
sQg $f #Pattern sgg $.
swg $f #Pattern tAg $.
tQg $f #Pattern tgg $.
2Qg $f #ElementVariable 2gg $.
YAk $a #Pattern YQk $.
egk $a #Pattern ewk $.
bxQ $a #Pattern ( cBQ oAg qwg ) $.
${ dBQ $e iA qwg tAg oAg ngg $.
   dRQ $e iA sgg tgg oAg ngg $.
   dhQ $a iA ( cBQ qwg sgg ) ( cBQ tAg tgg ) oAg ngg $. $}
yRs $f #ElementVariable yhs $.
-Bs $f #ElementVariable -Rs $.
XBw $f #ElementVariable XRw $.
wx4 $a #Pattern xB4 $.
Wh8 $a #Pattern 2gg $.
7SA $a #Pattern yhs $.
QCE $a #Pattern XRw $.
QyE $a #Pattern -Rs $.
SCE $a #Pattern ( cBQ -Rs XRw ) $.
SSE $a #Pattern ( 0wM YQk 2gg yhs ( cBQ -Rs XRw ) ) $.
2Cc $a #Pattern ( 0wM YQk 2gg yhs ( cBQ ( LAQ ewk pgg ( IAQ ewk xB4 ) ) XRw ) ) $.
${ 2Sc $p iA ( rwM YQk 2gg yhs ( 0wM YQk 2gg yhs ( cBQ ( LAQ ewk pgg ( IAQ ewk xB4 ) ) XRw ) ) ) ( rwM YQk 2gg yhs ( 0wM YQk 2gg yhs ( cBQ -Rs XRw ) ) ) ( LAQ ewk pgg ( IAQ ewk xB4 ) ) -Rs $=
  ( YAk Wh8 2Cc SSE egk pQg wx4 HwQ KwQ SA IQI 7SA QCE bxQ SCE QyE dhQ YgQ OwQ
  jg ) EAFZABDGEUEABCDHIJIKLMZBCNZEUFUGOZUEUFUGOZEUEBPZUFDQZREUEUJCDSUFUGUHUIUJ
  UFUGOUGUFUFUKCTUKUFUGUDUKUFUGOUAUBUC $. $}
