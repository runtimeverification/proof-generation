$c Tw #Symbol zw JAQ pgg #Pattern ( rwg 0wM LAQ ewk tQM IAQ #Variable #SetVariable vR4 4w rwM #ElementVariable IQE mwg xQg ) $.
$v CQ qwg DQ Bw Kw oAg Cw 6Ag 2gg $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Cg $f #Pattern Cw $.
DA $f #Pattern DQ $.
Kg $f #ElementVariable Kw $.
4g $a #Pattern ( 4w Bw CQ ) $.
IAE $a #Pattern IQE $.
${ lgE $e zw ( Tw Bw CQ ) $.
   lwE $e zw ( Tw CQ Cw ) $.
   mAE $a zw ( Tw Bw Cw ) $. $}
nAE $a zw IQE $.
${ wAE $e zw ( Tw Bw CQ ) $.
   wQE $e zw ( Tw Bw Cw ) $.
   wgE $a zw ( Tw Bw ( 4w CQ Cw ) ) $. $}
${ NwM $e zw CQ $.
   OAM $a zw ( Tw Bw CQ ) $. $}
rgM $a #Pattern ( rwM Bw CQ Kw Cw ) $.
tAM $a #Pattern ( tQM Bw CQ ) $.
0gM $a #Pattern ( 0wM Bw CQ Cw DQ ) $.
HwQ $a #Pattern ( IAQ Bw CQ ) $.
IwQ $a #Pattern ( JAQ Bw ) $.
KwQ $a #Pattern ( LAQ Bw CQ Cw ) $.
mgg $a #Pattern mwg $.
nwg $f #Pattern oAg $.
pQg $a #Pattern pgg $.
qgg $f #Pattern qwg $.
rgg $a #Pattern ( rwg oAg qwg ) $.
xAg $a #Pattern xQg $.
2Qg $f #ElementVariable 2gg $.
5wg $f #ElementVariable 6Ag $.
egk $a #Pattern ewk $.
vB4 $a #Pattern vR4 $.
Wh8 $a #Pattern 2gg $.
.h8 $a zw ( Tw ( 4w IQE ( 4w ( JAQ 2gg ) IQE ) ) ( JAQ 2gg ) ) $.
BCE $a #Pattern 6Ag $.
-iw $a zw ( Tw ( 4w ( JAQ 2gg ) IQE ) ( tQM 2gg ( rwM mwg 2gg 6Ag ( 0wM mwg 2gg 6Ag ( rwg ( LAQ ewk pgg ( IAQ ewk vR4 ) ) xQg ) ) ) ) ) $.
${ -yw $p zw ( Tw ( 4w IQE ( 4w ( JAQ 2gg ) IQE ) ) ( tQM 2gg ( rwM mwg 2gg 6Ag ( 0wM mwg 2gg 6Ag ( rwg ( LAQ ewk pgg ( IAQ ewk vR4 ) ) xQg ) ) ) ) ) $=
  ( IAE Wh8 IwQ 4g mgg BCE egk pQg vB4 HwQ KwQ xAg rgg 0gM rgM tAM .h8 nAE OAM
  wgE -iw mAE ) CADZEZCFZFZUGUEGUEGUEBHIJIKLMNOPBQRUHUFCASUHCTUAUBABUCUD $. $}
