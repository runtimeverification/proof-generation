$c 0wM tQM Tw #Symbol #Variable #SetVariable zw 4w rwM JAQ #ElementVariable IQE mwg #Pattern xQg ) ( $.
$v CQ Bw Kw Cw 6Ag 2gg $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Cg $f #Pattern Cw $.
Kg $f #ElementVariable Kw $.
4g $a #Pattern ( 4w Bw CQ ) $.
IAE $a #Pattern IQE $.
${ lgE $e zw ( Tw Bw CQ ) $.
   lwE $e zw ( Tw CQ Cw ) $.
   mAE $a zw ( Tw Bw Cw ) $. $}
nAE $a zw IQE $.
${ wAE $e zw ( Tw Bw CQ ) $.
   wQE $e zw ( Tw Bw Cw ) $.
   wgE $a zw ( Tw Bw ( 4w CQ Cw ) ) $. $}
${ NwM $e zw CQ $.
   OAM $a zw ( Tw Bw CQ ) $. $}
rgM $a #Pattern ( rwM Bw CQ Kw Cw ) $.
tAM $a #Pattern ( tQM Bw CQ ) $.
IwQ $a #Pattern ( JAQ Bw ) $.
mgg $a #Pattern mwg $.
2Qg $f #ElementVariable 2gg $.
5wg $f #ElementVariable 6Ag $.
7gg $a zw ( Tw ( 4w ( JAQ 2gg ) IQE ) ( tQM 2gg ( rwM mwg 2gg 6Ag ( 0wM mwg 2gg 6Ag xQg ) ) ) ) $.
Wh8 $a #Pattern 2gg $.
.h8 $a zw ( Tw ( 4w IQE ( 4w ( JAQ 2gg ) IQE ) ) ( JAQ 2gg ) ) $.
2CQ $a #Pattern ( 0wM mwg 2gg 6Ag xQg ) $.
${ 2SQ $p zw ( Tw ( 4w IQE ( 4w ( JAQ 2gg ) IQE ) ) ( tQM 2gg ( rwM mwg 2gg 6Ag ( 0wM mwg 2gg 6Ag xQg ) ) ) ) $=
  ( IAE Wh8 IwQ 4g mgg 2CQ rgM tAM .h8 nAE OAM wgE 7gg mAE ) CADZEZCFZFZSQGQABH
  BIJTRCAKTCLMNABOP $. $}
