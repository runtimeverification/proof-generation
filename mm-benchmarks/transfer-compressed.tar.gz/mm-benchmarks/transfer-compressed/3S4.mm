$c Uw PgE Tw #Symbol cwE zw YQk #Pattern ( 0wM ewk tQM IAQ #Variable SwE #SetVariable vR4 4w rwM #ElementVariable IQE ) $.
$v 7Rw CQ -Bw Bw Kw ph1 ph0 Cw GQ x $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Cg $f #Pattern Cw $.
GA $f #Pattern GQ $.
Kg $f #ElementVariable Kw $.
Ug $a #Pattern ( Uw Kw Bw ) $.
4g $a #Pattern ( 4w Bw CQ ) $.
IAE $a #Pattern IQE $.
PQE $a #Pattern ( PgE Bw CQ ) $.
SgE $a #Pattern ( SwE Bw CQ ) $.
${ lgE $e zw ( Tw Bw CQ ) $.
   lwE $e zw ( Tw CQ Cw ) $.
   mAE $a zw ( Tw Bw Cw ) $. $}
nAE $a zw IQE $.
${ NwM $e zw CQ $.
   OAM $a zw ( Tw Bw CQ ) $. $}
HwQ $a #Pattern ( IAQ Bw CQ ) $.
${ $d x ph0 $.
   $d x ph1 $.
   vwY $e zw ( Tw GQ ( SwE CQ Bw ) ) $.
   wAY $e zw ( Tw GQ ( tQM cwE ( rwM Bw cwE Kw ( 0wM Bw cwE Kw CQ ) ) ) ) $.
   wQY $a zw ( Tw GQ ( Uw Kw ( PgE Kw CQ ) ) ) $. $}
YAk $a #Pattern YQk $.
egk $a #Pattern ewk $.
7Bw $f #ElementVariable 7Rw $.
.xw $f #ElementVariable -Bw $.
vB4 $a #Pattern vR4 $.
-R4 $a zw ( Tw IQE ( SwE ( IAQ ewk vR4 ) ewk ) ) $.
1B8 $a #Pattern 7Rw $.
ByA $a zw ( Tw IQE ( tQM cwE ( rwM ewk cwE 7Rw ( 0wM ewk cwE 7Rw ( IAQ ewk vR4 ) ) ) ) ) $.
yyg $a #Pattern -Bw $.
${ 3S4 $p zw ( Tw ( 4w ( SwE -Bw YQk ) IQE ) ( Uw 7Rw ( PgE 7Rw ( IAQ ewk vR4 ) ) ) ) $=
  ( yyg YAk SgE IAE 4g 1B8 egk vB4 HwQ PQE Ug nAE OAM -R4 ByA wQY mAE ) BCDEFGZ
  FAHIJKZLAMTFNOIUAFAPAQRS $. $}
