$c #SetVariable 0wM zBI pwk #ElementVariable #Symbol #Variable #Pattern ) ( $.
$v yhs Cw 2gg CQ -Rs Bw DQ XRw $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Cg $f #Pattern Cw $.
DA $f #Pattern DQ $.
0gM $a #Pattern ( 0wM Bw CQ Cw DQ ) $.
2Qg $f #ElementVariable 2gg $.
pgk $a #Pattern pwk $.
yRs $f #ElementVariable yhs $.
-Bs $f #ElementVariable -Rs $.
XBw $f #ElementVariable XRw $.
Wh8 $a #Pattern 2gg $.
7SA $a #Pattern yhs $.
3CI $a #Pattern ( zBI -Rs XRw ) $.
${ 3SI $p #Pattern ( 0wM pwk 2gg yhs ( zBI -Rs XRw ) ) $=
  ( pgk Wh8 7SA 3CI 0gM ) EAFBGCDHI $. $}
