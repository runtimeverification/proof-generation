$c Tw #Symbol #Variable SwE PQk #SetVariable hgk zw 4w pwk #ElementVariable IQE mwg pgg #Pattern ) ( $.
$v 4wg CQ 3gg -Bw Bw 5Qg MB0 Cw 4Ag $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Cg $f #Pattern Cw $.
4g $a #Pattern ( 4w Bw CQ ) $.
IAE $a #Pattern IQE $.
SgE $a #Pattern ( SwE Bw CQ ) $.
lQE $a zw ( Tw Bw Bw ) $.
${ lgE $e zw ( Tw Bw CQ ) $.
   lwE $e zw ( Tw CQ Cw ) $.
   mAE $a zw ( Tw Bw Cw ) $. $}
ugE $a zw ( Tw ( 4w Bw CQ ) Bw ) $.
uwE $a zw ( Tw ( 4w Bw CQ ) CQ ) $.
${ wAE $e zw ( Tw Bw CQ ) $.
   wQE $e zw ( Tw Bw Cw ) $.
   wgE $a zw ( Tw Bw ( 4w CQ Cw ) ) $. $}
mgg $a #Pattern mwg $.
3Qg $f #ElementVariable 3gg $.
3wg $f #ElementVariable 4Ag $.
4gg $f #ElementVariable 4wg $.
5Ag $f #ElementVariable 5Qg $.
PAk $a #Pattern PQk $.
hQk $a #Pattern hgk $.
pgk $a #Pattern pwk $.
.xw $f #ElementVariable -Bw $.
Lx0 $f #ElementVariable MB0 $.
BCQ $a #Pattern 4Ag $.
XiU $a #Pattern 3gg $.
XyU $a #Pattern 4wg $.
YCU $a #Pattern 5Qg $.
rC8 $a #Pattern ( 4w ( SwE -Bw pgg ) ( 4w ( SwE MB0 hgk ) IQE ) ) $.
yy8 $a zw ( Tw ( 4w ( 4w ( SwE 3gg mwg ) ( 4w ( SwE 4wg PQk ) ( 4w ( SwE 5Qg pwk ) ( 4w ( SwE -Bw pgg ) ( 4w ( SwE MB0 hgk ) IQE ) ) ) ) ) ( 4w ( SwE 4Ag hgk ) IQE ) ) ( SwE 5Qg pwk ) ) $.
zy8 $a zw ( Tw ( 4w ( 4w ( SwE 3gg mwg ) ( 4w ( SwE 4wg PQk ) ( 4w ( SwE 5Qg pwk ) ( 4w ( SwE -Bw pgg ) ( 4w ( SwE MB0 hgk ) IQE ) ) ) ) ) ( 4w ( SwE 4Ag hgk ) IQE ) ) ( 4w ( SwE -Bw pgg ) ( 4w ( SwE MB0 hgk ) IQE ) ) ) $.
${ 0C8 $p zw ( Tw ( 4w ( 4w ( SwE 3gg mwg ) ( 4w ( SwE 4wg PQk ) ( 4w ( SwE 5Qg pwk ) ( 4w ( SwE -Bw pgg ) ( 4w ( SwE MB0 hgk ) IQE ) ) ) ) ) ( 4w ( SwE 4Ag hgk ) IQE ) ) ( 4w ( SwE 4wg PQk ) ( 4w ( SwE 5Qg pwk ) ( 4w ( SwE -Bw pgg ) ( 4w ( SwE MB0 hgk ) IQE ) ) ) ) ) $=
  ( XiU mgg SgE XyU PAk YCU pgk rC8 4g BCQ hQk ugE mAE wgE IAE uwE lQE yy8 zy8
  ) AGHIZCJKIZDLMIZEFNZOZOZOZBPQIUAOZOZUGUJUNULUGULUMRULUKUGUFUKUBUKUGUGUGUJRUG
  UCSSSUNUHUIABCDEFUDABCDEFUETT $. $}
