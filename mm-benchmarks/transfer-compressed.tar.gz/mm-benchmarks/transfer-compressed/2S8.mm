$c rwg LAQ Hg8 #Symbol #Variable 0hU #SetVariable iA #ElementVariable 8wk pgg #Pattern ) ( $.
$v ngg CQ qwg 3gg Bw Kw oAg 5Qg MB0 Cw nR4 sgg 4Ag $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Cg $f #Pattern Cw $.
Kg $f #ElementVariable Kw $.
SA $a #Variable Kw $.
KwQ $a #Pattern ( LAQ Bw CQ Cw ) $.
nQg $f #Variable ngg $.
nwg $f #Pattern oAg $.
pQg $a #Pattern pgg $.
qgg $f #Pattern qwg $.
rgg $a #Pattern ( rwg oAg qwg ) $.
sQg $f #Pattern sgg $.
3Qg $f #ElementVariable 3gg $.
3wg $f #ElementVariable 4Ag $.
5Ag $f #ElementVariable 5Qg $.
8gk $a #Pattern 8wk $.
${ Ig8 $e iA qwg sgg oAg ngg $.
   Iw8 $a iA ( Hg8 qwg ) ( Hg8 sgg ) oAg ngg $. $}
Lx0 $f #ElementVariable MB0 $.
nB4 $f #ElementVariable nR4 $.
6h8 $a #Pattern nR4 $.
XiU $a #Pattern 3gg $.
wS8 $a #Pattern ( 0hU 5Qg 4Ag MB0 ) $.
0i8 $a #Pattern ( 0hU 5Qg nR4 MB0 ) $.
2C8 $a iA ( rwg ( LAQ 8wk pgg ( 0hU 5Qg nR4 MB0 ) ) 3gg ) ( rwg ( LAQ 8wk pgg ( 0hU 5Qg 4Ag MB0 ) ) 3gg ) nR4 4Ag $.
${ 2S8 $p iA ( Hg8 ( rwg ( LAQ 8wk pgg ( 0hU 5Qg nR4 MB0 ) ) 3gg ) ) ( Hg8 ( rwg ( LAQ 8wk pgg ( 0hU 5Qg 4Ag MB0 ) ) 3gg ) ) nR4 4Ag $=
  ( SA 6h8 8gk pQg 0i8 KwQ XiU rgg wS8 2C8 Iw8 ) BFEGHICDEJKALZMHIBCDNKQMABCDEO
  P $. $}
