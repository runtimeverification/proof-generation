$c #SetVariable iA ) #ElementVariable Wgk #Symbol #Variable #Pattern ( $.
$v Ow CQ xX Bw Kw ph0 nR4 4Ag $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Kg $f #ElementVariable Kw $.
Og $f #Variable Ow $.
SA $a #Variable Kw $.
${ $d xX ph0 $.
   IQI $a iA Bw Bw CQ Ow $. $}
3wg $f #ElementVariable 4Ag $.
WQk $a #Pattern Wgk $.
nB4 $f #ElementVariable nR4 $.
6h8 $a #Pattern nR4 $.
${ -Ss $p iA Wgk Wgk nR4 4Ag $=
  ( WQk 6h8 SA IQI ) CBDAEF $. $}
