$c LAQ ewk IAQ Wgk Tw #Symbol #Variable 7h4 SwE -gg #SetVariable zw 4w JAQ #ElementVariable IQE #Pattern ) ( $.
$v CQ qwg Bw oAg 5Qg Cw sgg $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Cg $f #Pattern Cw $.
4g $a #Pattern ( 4w Bw CQ ) $.
IAE $a #Pattern IQE $.
SgE $a #Pattern ( SwE Bw CQ ) $.
${ lgE $e zw ( Tw Bw CQ ) $.
   lwE $e zw ( Tw CQ Cw ) $.
   mAE $a zw ( Tw Bw Cw ) $. $}
HwQ $a #Pattern ( IAQ Bw CQ ) $.
IwQ $a #Pattern ( JAQ Bw ) $.
KwQ $a #Pattern ( LAQ Bw CQ Cw ) $.
nwg $f #Pattern oAg $.
qgg $f #Pattern qwg $.
sQg $f #Pattern sgg $.
5Ag $f #ElementVariable 5Qg $.
.gg $a zw ( Tw ( 4w ( 4w ( JAQ oAg ) ( JAQ qwg ) ) ( SwE sgg oAg ) ) ( SwE ( LAQ oAg qwg sgg ) qwg ) ) $.
-Qg $a #Pattern -gg $.
WQk $a #Pattern Wgk $.
egk $a #Pattern ewk $.
7R4 $a #Pattern 7h4 $.
YCU $a #Pattern 5Qg $.
2iU $a zw ( Tw ( 4w ( SwE 5Qg -gg ) IQE ) ( 4w ( 4w ( JAQ ewk ) ( JAQ Wgk ) ) ( SwE ( IAQ ewk 7h4 ) ewk ) ) ) $.
${ 2yU $p zw ( Tw ( 4w ( SwE 5Qg -gg ) IQE ) ( SwE ( LAQ ewk Wgk ( IAQ ewk 7h4 ) ) Wgk ) ) $=
  ( YCU -Qg SgE IAE 4g egk IwQ WQk 7R4 HwQ KwQ 2iU .gg mAE ) ABCDEFGHIHFGJKZGDF
  GIPLIDAMGIPNO $. $}
