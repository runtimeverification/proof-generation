$c Wgk #Symbol #Variable SwE #SetVariable iA #ElementVariable #Pattern ) ( $.
$v Ow CQ DQ Bw Kw Cw nR4 Dw 4Ag $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Cg $f #Pattern Cw $.
DA $f #Pattern DQ $.
Dg $f #Pattern Dw $.
Kg $f #ElementVariable Kw $.
Og $f #Variable Ow $.
SA $a #Variable Kw $.
jg $a iA Bw Ow Bw Ow $.
${ OgI $e iA CQ DQ Bw Ow $.
   OwI $e iA Cw Dw Bw Ow $.
   PAI $a iA ( SwE CQ Cw ) ( SwE DQ Dw ) Bw Ow $. $}
3wg $f #ElementVariable 4Ag $.
WQk $a #Pattern Wgk $.
nB4 $f #ElementVariable nR4 $.
6h8 $a #Pattern nR4 $.
BCQ $a #Pattern 4Ag $.
-Ss $a iA Wgk Wgk nR4 4Ag $.
${ -is $p iA ( SwE nR4 Wgk ) ( SwE 4Ag Wgk ) nR4 4Ag $=
  ( 6h8 WQk BCQ SA jg -Ss PAI ) BCZJDAEDAFZJKGABHI $. $}
