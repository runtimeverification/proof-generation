$c 0wM LAQ ewk Wgk #Symbol #Variable #SetVariable iA #ElementVariable #Pattern ) ( $.
$v yhs Fw Ow CQ FQ zBs DQ Ew Bw Kw Cw 2gg nR4 EQ Dw $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Cg $f #Pattern Cw $.
DA $f #Pattern DQ $.
Dg $f #Pattern Dw $.
EA $f #Pattern EQ $.
Eg $f #Pattern Ew $.
FA $f #Pattern FQ $.
Fg $f #Pattern Fw $.
Kg $f #ElementVariable Kw $.
Og $f #Variable Ow $.
SA $a #Variable Kw $.
KwQ $a #Pattern ( LAQ Bw CQ Cw ) $.
${ XgQ $e iA Bw Dw Fw Ow $.
   XwQ $e iA CQ EQ Fw Ow $.
   YAQ $e iA Cw Ew Fw Ow $.
   YQQ $e iA DQ FQ Fw Ow $.
   YgQ $a iA ( 0wM Bw CQ Cw DQ ) ( 0wM Dw EQ Ew FQ ) Fw Ow $. $}
2Qg $f #ElementVariable 2gg $.
WQk $a #Pattern Wgk $.
egk $a #Pattern ewk $.
yRs $f #ElementVariable yhs $.
yxs $f #ElementVariable zBs $.
nB4 $f #ElementVariable nR4 $.
Wh8 $a #Pattern 2gg $.
6h8 $a #Pattern nR4 $.
7SA $a #Pattern yhs $.
JiE $a #Pattern zBs $.
NSE $a iA 2gg 2gg nR4 zBs $.
NyE $a iA yhs yhs nR4 zBs $.
MCI $a iA Wgk Wgk nR4 zBs $.
0yI $a iA ( LAQ ewk Wgk nR4 ) ( LAQ ewk Wgk zBs ) nR4 zBs $.
${ 1CI $p iA ( 0wM Wgk 2gg yhs ( LAQ ewk Wgk nR4 ) ) ( 0wM Wgk 2gg yhs ( LAQ ewk Wgk zBs ) ) nR4 zBs $=
  ( WQk Wh8 7SA egk 6h8 KwQ JiE SA MCI NSE NyE 0yI YgQ ) EAFZBGZHEDIZJERSHECKJT
  CLCDMACDNBCDOCDPQ $. $}
