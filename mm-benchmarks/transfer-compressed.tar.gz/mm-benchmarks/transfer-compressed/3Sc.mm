$c 0wM LAQ ewk xB4 cBQ IAQ #Symbol #Variable #SetVariable iA YQk #ElementVariable pgg #Pattern ) ( $.
$v yhs Fw Ow CQ qwg DQ Bw XRw Cw 2gg EQ sgg tAg Dw ngg FQ xX Ew Kw ph0 oAg nR4 tgg $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Cg $f #Pattern Cw $.
DA $f #Pattern DQ $.
Dg $f #Pattern Dw $.
EA $f #Pattern EQ $.
Eg $f #Pattern Ew $.
FA $f #Pattern FQ $.
Fg $f #Pattern Fw $.
Kg $f #ElementVariable Kw $.
Og $f #Variable Ow $.
SA $a #Variable Kw $.
jg $a iA Bw Ow Bw Ow $.
${ $d xX ph0 $.
   IQI $a iA Bw Bw CQ Ow $. $}
HwQ $a #Pattern ( IAQ Bw CQ ) $.
KwQ $a #Pattern ( LAQ Bw CQ Cw ) $.
${ XgQ $e iA Bw Dw Fw Ow $.
   XwQ $e iA CQ EQ Fw Ow $.
   YAQ $e iA Cw Ew Fw Ow $.
   YQQ $e iA DQ FQ Fw Ow $.
   YgQ $a iA ( 0wM Bw CQ Cw DQ ) ( 0wM Dw EQ Ew FQ ) Fw Ow $. $}
nQg $f #Variable ngg $.
nwg $f #Pattern oAg $.
pQg $a #Pattern pgg $.
qgg $f #Pattern qwg $.
sQg $f #Pattern sgg $.
swg $f #Pattern tAg $.
tQg $f #Pattern tgg $.
2Qg $f #ElementVariable 2gg $.
YAk $a #Pattern YQk $.
egk $a #Pattern ewk $.
bxQ $a #Pattern ( cBQ oAg qwg ) $.
${ dBQ $e iA qwg tAg oAg ngg $.
   dRQ $e iA sgg tgg oAg ngg $.
   dhQ $a iA ( cBQ qwg sgg ) ( cBQ tAg tgg ) oAg ngg $. $}
yRs $f #ElementVariable yhs $.
XBw $f #ElementVariable XRw $.
nB4 $f #ElementVariable nR4 $.
wx4 $a #Pattern xB4 $.
Wh8 $a #Pattern 2gg $.
6h8 $a #Pattern nR4 $.
7SA $a #Pattern yhs $.
QCE $a #Pattern XRw $.
viE $a iA 2gg 2gg nR4 XRw $.
vyE $a iA yhs yhs nR4 XRw $.
5yM $a iA YQk YQk nR4 XRw $.
${ 3Sc $p iA ( 0wM YQk 2gg yhs ( cBQ ( LAQ ewk pgg ( IAQ ewk xB4 ) ) nR4 ) ) ( 0wM YQk 2gg yhs ( cBQ ( LAQ ewk pgg ( IAQ ewk xB4 ) ) XRw ) ) nR4 XRw $=
  ( YAk Wh8 7SA egk pQg wx4 HwQ KwQ 6h8 bxQ QCE SA 5yM viE vyE IQI jg dhQ YgQ )
  EAFZBGZHIHJKLZDMZNEUDUEUFCOZNUGCPZCDQACDRBCDSUIUGUFUGUFUHUFUGUITUGUIUAUBUC $. $}
