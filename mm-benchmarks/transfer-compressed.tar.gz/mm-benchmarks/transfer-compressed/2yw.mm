$c ewk #Symbol #Variable SwE #SetVariable ) 4w YQk #ElementVariable IQE #Pattern ( $.
$v 5Qg CQ -Bw Bw $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
4g $a #Pattern ( 4w Bw CQ ) $.
IAE $a #Pattern IQE $.
SgE $a #Pattern ( SwE Bw CQ ) $.
5Ag $f #ElementVariable 5Qg $.
YAk $a #Pattern YQk $.
egk $a #Pattern ewk $.
.xw $f #ElementVariable -Bw $.
YCU $a #Pattern 5Qg $.
yyg $a #Pattern -Bw $.
${ 2yw $p #Pattern ( 4w ( SwE 5Qg ewk ) ( 4w ( SwE -Bw YQk ) IQE ) ) $=
  ( YCU egk SgE yyg YAk IAE 4g ) ACDEBFGEHII $. $}
