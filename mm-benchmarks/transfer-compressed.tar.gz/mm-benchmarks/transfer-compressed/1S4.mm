$c Uw #Symbol 7h4 DBE zw pgg #Pattern rwg 0wM Ex0 xB4 tQM 0h4 Wgk #Variable #SetVariable iA vR4 rwM 4w #ElementVariable IQE qxs mwg xQg 8hw kBM 2R4 zBA XBI PgE Tw cwE JAQ rgk ( RQ0 LAQ ewk IAQ OA0 hgk ) $.
$v th1 Fw CQ Bw Cw 2gg Pw FQ z ph2 Ew ph0 x Lw 6xw LQ Ow ph6 qwg DQ ph1 EQ y th2 Dw HQ xX Gw th0 Hw Kw oAg 6Ag GQ $.
$d z y $.
$d z x $.
$d y x $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Cg $f #Pattern Cw $.
DA $f #Pattern DQ $.
Dg $f #Pattern Dw $.
EA $f #Pattern EQ $.
Eg $f #Pattern Ew $.
FA $f #Pattern FQ $.
Fg $f #Pattern Fw $.
GA $f #Pattern GQ $.
Gg $f #Pattern Gw $.
HA $f #Pattern HQ $.
Hg $f #Pattern Hw $.
Kg $f #ElementVariable Kw $.
LA $f #ElementVariable LQ $.
Lg $f #ElementVariable Lw $.
Og $f #Variable Ow $.
Pg $f #Symbol Pw $.
SA $a #Variable Kw $.
Sw $a #Pattern Pw $.
Ug $a #Pattern ( Uw Kw Bw ) $.
jg $a iA Bw Ow Bw Ow $.
${ kg $e iA CQ DQ Bw Ow $.
   kw $e iA Cw Dw Bw Ow $.
   lA $a iA ( Tw CQ Cw ) ( Tw DQ Dw ) Bw Ow $. $}
4g $a #Pattern ( 4w Bw CQ ) $.
IAE $a #Pattern IQE $.
cgE $a #Symbol cwE $.
${ lgE $e zw ( Tw Bw CQ ) $.
   lwE $e zw ( Tw CQ Cw ) $.
   mAE $a zw ( Tw Bw Cw ) $. $}
nAE $a zw IQE $.
${ wAE $e zw ( Tw Bw CQ ) $.
   wQE $e zw ( Tw Bw Cw ) $.
   wgE $a zw ( Tw Bw ( 4w CQ Cw ) ) $. $}
${ $d xX ph0 $.
   IQI $a iA Bw Bw CQ Ow $. $}
${ NwM $e zw CQ $.
   OAM $a zw ( Tw Bw CQ ) $. $}
rgM $a #Pattern ( rwM Bw CQ Kw Cw ) $.
tAM $a #Pattern ( tQM Bw CQ ) $.
0gM $a #Pattern ( 0wM Bw CQ Cw DQ ) $.
HwQ $a #Pattern ( IAQ Bw CQ ) $.
IwQ $a #Pattern ( JAQ Bw ) $.
KwQ $a #Pattern ( LAQ Bw CQ Cw ) $.
${ $d xX y $.
   $d y ph6 $.
   OAQ $e iA Bw DQ Ew Ow $.
   OQQ $e iA CQ Dw Ew Ow $.
   OgQ $e iA Cw EQ Ew Ow $.
   OwQ $a iA ( rwM Bw CQ LQ Cw ) ( rwM DQ Dw LQ EQ ) Ew Ow $. $}
${ QAQ $e iA Bw Cw Dw Ow $.
   QQQ $e iA CQ DQ Dw Ow $.
   QgQ $a iA ( tQM Bw CQ ) ( tQM Cw DQ ) Dw Ow $. $}
${ XgQ $e iA Bw Dw Fw Ow $.
   XwQ $e iA CQ EQ Fw Ow $.
   YAQ $e iA Cw Ew Fw Ow $.
   YQQ $e iA DQ FQ Fw Ow $.
   YgQ $a iA ( 0wM Bw CQ Cw DQ ) ( 0wM Dw EQ Ew FQ ) Fw Ow $. $}
iwY $a zw ( Uw Kw ( PgE Kw cwE ) ) $.
${ $d z ph0 $.
   $d z ph1 $.
   $d z ph2 $.
   $d z y $.
   $d z x $.
   $d z th1 $.
   $d z th2 $.
   $d x ph0 $.
   $d y th0 $.
   lAY $e zw ( Tw GQ ( Uw Kw ( PgE Kw Bw ) ) ) $.
   lQY $e zw ( Tw ( 4w GQ Gw ) CQ ) $.
   lgY $e iA ( Tw HQ Cw ) ( Tw Gw CQ ) Bw LQ $.
   lwY $e iA ( Tw Hw DQ ) ( Tw Gw CQ ) Lw LQ $.
   mAY $a zw ( Tw ( 4w GQ HQ ) Cw ) $. $}
mgg $a #Pattern mwg $.
nwg $f #Pattern oAg $.
pQg $a #Pattern pgg $.
qgg $f #Pattern qwg $.
rgg $a #Pattern ( rwg oAg qwg ) $.
xAg $a #Pattern xQg $.
2Qg $f #ElementVariable 2gg $.
5wg $f #ElementVariable 6Ag $.
WQk $a #Pattern Wgk $.
egk $a #Pattern ewk $.
hQk $a #Pattern hgk $.
rQk $a #Pattern rgk $.
Nw0 $a #Pattern ( OA0 oAg ) $.
RA0 $a #Pattern ( RQ0 oAg qwg ) $.
yxA $a #Pattern ( zBA oAg qwg ) $.
CxE $a #Pattern ( DBE oAg qwg ) $.
WxI $a #Pattern ( XBI oAg qwg ) $.
jxM $a #Pattern ( kBM oAg qwg ) $.
qhs $a #Pattern ( qxs oAg ) $.
6hw $f #ElementVariable 6xw $.
8Rw $a #Pattern 8hw $.
Eh0 $a #Pattern Ex0 $.
vB4 $a #Pattern vR4 $.
wx4 $a #Pattern xB4 $.
0R4 $a #Pattern 0h4 $.
2B4 $a #Pattern 2R4 $.
7R4 $a #Pattern 7h4 $.
Wh8 $a #Pattern 2gg $.
dB8 $a #Pattern 6xw $.
0h8 $a #Pattern ( PgE Kw cwE ) $.
5B8 $a zw ( Tw IQE ( 4w ( JAQ cwE ) IQE ) ) $.
.h8 $a zw ( Tw ( 4w IQE ( 4w ( JAQ 2gg ) IQE ) ) ( JAQ 2gg ) ) $.
-R8 $a iA ( 4w ( JAQ cwE ) IQE ) ( 4w ( JAQ 2gg ) IQE ) cwE 2gg $.
ASA $a iA ( 4w ( JAQ 6xw ) IQE ) ( 4w ( JAQ 2gg ) IQE ) 6xw 2gg $.
BCE $a #Pattern 6Ag $.
AiQ $a iA 6Ag 6Ag cwE 2gg $.
AyQ $a iA 6Ag 6Ag 6xw 2gg $.
3CQ $a iA mwg mwg cwE 2gg $.
3yQ $a iA mwg mwg 6xw 2gg $.
1C4 $a zw ( Tw ( 4w ( JAQ 2gg ) IQE ) ( tQM 2gg ( rwM mwg 2gg 6Ag ( 0wM mwg 2gg 6Ag ( rwg ( OA0 ( rwg ( LAQ rgk pgg ( IAQ rgk 0h4 ) ) xQg ) ) ( rwg ( RQ0 ( rwg ( LAQ hgk pgg ( qxs ( XBI ( IAQ ewk xB4 ) ( LAQ rgk Wgk ( IAQ rgk 8hw ) ) ) ) ) xQg ) ( rwg ( LAQ hgk pgg ( qxs ( kBM ( kBM ( XBI ( IAQ ewk vR4 ) ( DBE ( LAQ ewk Wgk ( IAQ ewk vR4 ) ) ( LAQ ewk Wgk ( IAQ ewk 2R4 ) ) ) ) ( XBI ( IAQ ewk 7h4 ) ( zBA ( LAQ ewk Wgk ( IAQ ewk 7h4 ) ) ( LAQ ewk Wgk ( IAQ ewk 2R4 ) ) ) ) ) ( XBI ( IAQ ewk xB4 ) ( LAQ rgk Wgk ( IAQ rgk Ex0 ) ) ) ) ) ) xQg ) ) xQg ) ) ) ) ) ) $.
${ 1S4 $p zw ( Tw IQE ( tQM cwE ( rwM mwg cwE 6Ag ( 0wM mwg cwE 6Ag ( rwg ( OA0 ( rwg ( LAQ rgk pgg ( IAQ rgk 0h4 ) ) xQg ) ) ( rwg ( RQ0 ( rwg ( LAQ hgk pgg ( qxs ( XBI ( IAQ ewk xB4 ) ( LAQ rgk Wgk ( IAQ rgk 8hw ) ) ) ) ) xQg ) ( rwg ( LAQ hgk pgg ( qxs ( kBM ( kBM ( XBI ( IAQ ewk vR4 ) ( DBE ( LAQ ewk Wgk ( IAQ ewk vR4 ) ) ( LAQ ewk Wgk ( IAQ ewk 2R4 ) ) ) ) ( XBI ( IAQ ewk 7h4 ) ( zBA ( LAQ ewk Wgk ( IAQ ewk 7h4 ) ) ( LAQ ewk Wgk ( IAQ ewk 2R4 ) ) ) ) ) ( XBI ( IAQ ewk xB4 ) ( LAQ rgk Wgk ( IAQ rgk Ex0 ) ) ) ) ) ) xQg ) ) xQg ) ) ) ) ) ) $=
  ( 2Qg 6hw Kg IAE IwQ 4g mgg rQk pQg HwQ KwQ xAg rgg egk WQk WxI 0gM rgM tAM
  cgE Sw BCE 0R4 Nw0 hQk wx4 8Rw qhs vB4 2B4 CxE 7R4 yxA jxM Eh0 RA0 nAE OAM Ug
  5B8 wgE Wh8 dB8 0h8 iwY .h8 1C4 mAE SA -R8 jg 3CQ AiQ IQI YgQ OwQ QgQ ASA 3yQ
  lA AyQ mAY ) EEUAUBZFEGZGWDHWDHWDAUCZIJIUDKLMNUEUFJOUGKZIPIUHKLQUILMNUFJOUJKZ
  OPWHLOPOUKKLZULQOUMKZOPWJLWIUNQUOWGIPIUPKLQUOUILMNUQMNNZRZASZTZEEWEEEURUSVAVB
  WDBVCZHWOHWOWFWKRZASZTZWNCVDZHWSHWSWFWKRZASZTZEWOFZEGZWEWSFEGZDBCEDVEDUTDVFUS
  EXDGZXDWRXFXCEBVGXFEURUSVBBAVHVIWDWEWNXDWRBVJZBVKWDWMWOWQWDXGWDXGVLZHWDWLHWOW
  PWDAXGBVMZXHHWDWFWKHWOWFWKWDXGXIXHBAVNWKWDXGVOVPVQVRWAWSXEXBXDWRXGBCVSWSXAWOW
  QWSXGWSXGVLZHWSWTHWOWPWSAXGBCVTZXJHWSWFWKHWOWFWKWSXGXKXJBACWBWKWSXGVOVPVQVRWA
  WCVI $. $}
