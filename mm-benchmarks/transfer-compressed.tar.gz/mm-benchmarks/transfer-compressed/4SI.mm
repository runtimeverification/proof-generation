$c #SetVariable 0wM zBI pwk #ElementVariable #Symbol #Variable #Pattern ) ( $.
$v yhs Cw 2gg nR4 CQ Bw DQ XRw $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Cg $f #Pattern Cw $.
DA $f #Pattern DQ $.
0gM $a #Pattern ( 0wM Bw CQ Cw DQ ) $.
2Qg $f #ElementVariable 2gg $.
pgk $a #Pattern pwk $.
yRs $f #ElementVariable yhs $.
XBw $f #ElementVariable XRw $.
nB4 $f #ElementVariable nR4 $.
Wh8 $a #Pattern 2gg $.
7SA $a #Pattern yhs $.
4CI $a #Pattern ( zBI nR4 XRw ) $.
${ 4SI $p #Pattern ( 0wM pwk 2gg yhs ( zBI nR4 XRw ) ) $=
  ( pgk Wh8 7SA 4CI 0gM ) EAFBGCDHI $. $}
