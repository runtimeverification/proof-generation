$c 0wM LAQ 1wk #Symbol #Variable #SetVariable ) #ElementVariable pgg #Pattern ( $.
$v yhs CQ zBs DQ Bw Cw 2gg $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Cg $f #Pattern Cw $.
DA $f #Pattern DQ $.
0gM $a #Pattern ( 0wM Bw CQ Cw DQ ) $.
KwQ $a #Pattern ( LAQ Bw CQ Cw ) $.
pQg $a #Pattern pgg $.
2Qg $f #ElementVariable 2gg $.
1gk $a #Pattern 1wk $.
yRs $f #ElementVariable yhs $.
yxs $f #ElementVariable zBs $.
Wh8 $a #Pattern 2gg $.
7SA $a #Pattern yhs $.
JiE $a #Pattern zBs $.
${ 1CM $p #Pattern ( 0wM pgg 2gg yhs ( LAQ 1wk pgg zBs ) ) $=
  ( pQg Wh8 7SA 1gk JiE KwQ 0gM ) DAEBFGDCHIJ $. $}
