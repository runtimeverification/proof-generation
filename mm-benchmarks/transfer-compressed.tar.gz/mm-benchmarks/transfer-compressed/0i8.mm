$c #SetVariable ) #ElementVariable #Symbol #Variable 0hU #Pattern ( $.
$v oAg 5Qg MB0 nR4 qwg sgg $.
nwg $f #Pattern oAg $.
qgg $f #Pattern qwg $.
sQg $f #Pattern sgg $.
5Ag $f #ElementVariable 5Qg $.
0RU $a #Pattern ( 0hU oAg qwg sgg ) $.
Lx0 $f #ElementVariable MB0 $.
nB4 $f #ElementVariable nR4 $.
6h8 $a #Pattern nR4 $.
YCU $a #Pattern 5Qg $.
qy8 $a #Pattern MB0 $.
${ 0i8 $p #Pattern ( 0hU 5Qg nR4 MB0 ) $=
  ( YCU 6h8 qy8 0RU ) ADCEBFG $. $}
