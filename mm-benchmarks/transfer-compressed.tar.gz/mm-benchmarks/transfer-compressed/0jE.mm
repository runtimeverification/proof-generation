$c LAQ Wgk #Symbol #Variable #SetVariable iA #ElementVariable pgg #Pattern ) ( $.
$v Ow CQ 3gg DQ Ew Bw Kw Cw nR4 EQ Dw $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Cg $f #Pattern Cw $.
DA $f #Pattern DQ $.
Dg $f #Pattern Dw $.
EA $f #Pattern EQ $.
Eg $f #Pattern Ew $.
Kg $f #ElementVariable Kw $.
Og $f #Variable Ow $.
SA $a #Variable Kw $.
jg $a iA Bw Ow Bw Ow $.
${ lAQ $e iA Bw DQ Ew Ow $.
   lQQ $e iA CQ Dw Ew Ow $.
   lgQ $e iA Cw EQ Ew Ow $.
   lwQ $a iA ( LAQ Bw CQ Cw ) ( LAQ DQ Dw EQ ) Ew Ow $. $}
pQg $a #Pattern pgg $.
3Qg $f #ElementVariable 3gg $.
WQk $a #Pattern Wgk $.
nB4 $f #ElementVariable nR4 $.
6h8 $a #Pattern nR4 $.
XiU $a #Pattern 3gg $.
kyU $a iA pgg pgg nR4 3gg $.
Iyk $a iA Wgk Wgk nR4 3gg $.
${ 0jE $p iA ( LAQ Wgk pgg nR4 ) ( LAQ Wgk pgg 3gg ) nR4 3gg $=
  ( WQk pQg 6h8 XiU SA Iyk kyU jg lwQ ) CDBEZCDAFLAGZABHABILMJK $. $}
