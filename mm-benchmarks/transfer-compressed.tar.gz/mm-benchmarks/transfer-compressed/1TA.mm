$c 0wM LAQ #Symbol #Variable #SetVariable iA pwk #ElementVariable .gk #Pattern ) ( $.
$v Fw Ow CQ DQ Bw Cw 2gg EQ mh4 Dw FQ xX Ew lB4 Kw ph0 6xw $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Cg $f #Pattern Cw $.
DA $f #Pattern DQ $.
Dg $f #Pattern Dw $.
EA $f #Pattern EQ $.
Eg $f #Pattern Ew $.
FA $f #Pattern FQ $.
Fg $f #Pattern Fw $.
Kg $f #ElementVariable Kw $.
Og $f #Variable Ow $.
SA $a #Variable Kw $.
jg $a iA Bw Ow Bw Ow $.
${ $d xX ph0 $.
   IQI $a iA Bw Bw CQ Ow $. $}
KwQ $a #Pattern ( LAQ Bw CQ Cw ) $.
${ XgQ $e iA Bw Dw Fw Ow $.
   XwQ $e iA CQ EQ Fw Ow $.
   YAQ $e iA Cw Ew Fw Ow $.
   YQQ $e iA DQ FQ Fw Ow $.
   YgQ $a iA ( 0wM Bw CQ Cw DQ ) ( 0wM Dw EQ Ew FQ ) Fw Ow $. $}
${ lAQ $e iA Bw DQ Ew Ow $.
   lQQ $e iA CQ Dw Ew Ow $.
   lgQ $e iA Cw EQ Ew Ow $.
   lwQ $a iA ( LAQ Bw CQ Cw ) ( LAQ DQ Dw EQ ) Ew Ow $. $}
2Qg $f #ElementVariable 2gg $.
pgk $a #Pattern pwk $.
.Qk $a #Pattern .gk $.
6hw $f #ElementVariable 6xw $.
kx4 $f #ElementVariable lB4 $.
mR4 $f #ElementVariable mh4 $.
Wh8 $a #Pattern 2gg $.
XB8 $a #Pattern lB4 $.
YR8 $a #Pattern mh4 $.
dB8 $a #Pattern 6xw $.
yB8 $a iA 2gg 2gg 6xw lB4 $.
cjA $a #Pattern ( LAQ .gk lB4 mh4 ) $.
kTA $a #Pattern ( LAQ .gk 6xw mh4 ) $.
pDA $a iA ( LAQ .gk 6xw mh4 ) ( LAQ .gk lB4 mh4 ) 6xw lB4 $.
1DA $a iA pwk pwk 6xw lB4 $.
${ 1TA $p iA ( 0wM 6xw 2gg ( LAQ pwk 6xw ( LAQ .gk pwk mh4 ) ) ( LAQ .gk 6xw mh4 ) ) ( 0wM lB4 2gg ( LAQ pwk lB4 ( LAQ .gk pwk mh4 ) ) ( LAQ .gk lB4 mh4 ) ) 6xw lB4 $=
  ( dB8 Wh8 pgk .Qk YR8 KwQ kTA XB8 cjA SA jg yB8 1DA IQI lwQ pDA YgQ ) BEZAFZG
  UBHGDIJZJBDKCLZUCGUEUDJCDMUBCNZUBUFOZABCPGUBUDGUEUDUBUFBCQUGUDUBUFRSBCDTUA $. $}
