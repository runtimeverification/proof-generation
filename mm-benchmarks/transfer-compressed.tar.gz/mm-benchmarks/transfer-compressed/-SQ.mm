$c #Symbol #Variable SwE #SetVariable iA #ElementVariable mwg #Pattern ) ( $.
$v Ow CQ DQ Bw Kw Cw nR4 3Ag Dw $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Cg $f #Pattern Cw $.
DA $f #Pattern DQ $.
Dg $f #Pattern Dw $.
Kg $f #ElementVariable Kw $.
Og $f #Variable Ow $.
SA $a #Variable Kw $.
jg $a iA Bw Ow Bw Ow $.
${ OgI $e iA CQ DQ Bw Ow $.
   OwI $e iA Cw Dw Bw Ow $.
   PAI $a iA ( SwE CQ Cw ) ( SwE DQ Dw ) Bw Ow $. $}
mgg $a #Pattern mwg $.
2wg $f #ElementVariable 3Ag $.
nB4 $f #ElementVariable nR4 $.
6h8 $a #Pattern nR4 $.
ByQ $a #Pattern 3Ag $.
-CQ $a iA mwg mwg nR4 3Ag $.
${ -SQ $p iA ( SwE nR4 mwg ) ( SwE 3Ag mwg ) nR4 3Ag $=
  ( 6h8 mgg ByQ SA jg -CQ PAI ) BCZJDAEDAFZJKGABHI $. $}
