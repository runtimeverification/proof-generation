$c Tw #Symbol 5x4 zw JAQ rgk pgg #Pattern ( rwg LAQ IAQ #Variable SwE #SetVariable 4w #ElementVariable IQE mwg xQg ) $.
$v 7Ag CQ qwg Bw oAg Cw 2gg $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Cg $f #Pattern Cw $.
Tg $a #Pattern ( Tw Bw CQ ) $.
4g $a #Pattern ( 4w Bw CQ ) $.
5Q $a zw ( Tw Bw ( Tw CQ Bw ) ) $.
${ 6A $e zw ( Tw Bw CQ ) $.
   6Q $e zw Bw $.
   6g $a zw CQ $. $}
SgE $a #Pattern ( SwE Bw CQ ) $.
${ lgE $e zw ( Tw Bw CQ ) $.
   lwE $e zw ( Tw CQ Cw ) $.
   mAE $a zw ( Tw Bw Cw ) $. $}
${ wAE $e zw ( Tw Bw CQ ) $.
   wQE $e zw ( Tw Bw Cw ) $.
   wgE $a zw ( Tw Bw ( 4w CQ Cw ) ) $. $}
HwQ $a #Pattern ( IAQ Bw CQ ) $.
KwQ $a #Pattern ( LAQ Bw CQ Cw ) $.
mgg $a #Pattern mwg $.
nwg $f #Pattern oAg $.
pQg $a #Pattern pgg $.
qgg $f #Pattern qwg $.
rgg $a #Pattern ( rwg oAg qwg ) $.
wQg $a zw ( Tw ( 4w ( SwE oAg pgg ) ( SwE qwg mwg ) ) ( SwE ( rwg oAg qwg ) mwg ) ) $.
xAg $a #Pattern xQg $.
yAg $a zw ( SwE xQg mwg ) $.
2Qg $f #ElementVariable 2gg $.
6wg $f #ElementVariable 7Ag $.
rQk $a #Pattern rgk $.
5h4 $a #Pattern 5x4 $.
pyQ $a #Pattern ( 4w ( JAQ 2gg ) ( 4w ( SwE 7Ag mwg ) IQE ) ) $.
Ay8 $a zw ( Tw ( 4w ( JAQ 2gg ) ( 4w ( SwE 7Ag mwg ) IQE ) ) ( SwE ( LAQ rgk pgg ( IAQ rgk 5x4 ) ) pgg ) ) $.
${ 2TI $p zw ( Tw ( 4w ( JAQ 2gg ) ( 4w ( SwE 7Ag mwg ) IQE ) ) ( SwE ( rwg ( LAQ rgk pgg ( IAQ rgk 5x4 ) ) xQg ) mwg ) ) $=
  ( pyQ rQk pQg 5h4 HwQ KwQ SgE xAg mgg 4g rgg Ay8 Tg 5Q yAg 6g wgE wQg mAE ) A
  BCZDEDFGHZEIZJKIZLUCJMKIUBUDUEABNUEUBUEOUEUBPQRSUCJTUA $. $}
