$c ewk RAk Tw #Symbol #Variable SwE pgg PQk #SetVariable zw 4w YQk #ElementVariable IQE mwg #Pattern ) ( $.
$v 4wg CQ 3gg -Bw Bw 5Qg Cw 3Ag 4Ag $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Cg $f #Pattern Cw $.
4g $a #Pattern ( 4w Bw CQ ) $.
IAE $a #Pattern IQE $.
SgE $a #Pattern ( SwE Bw CQ ) $.
lQE $a zw ( Tw Bw Bw ) $.
${ lgE $e zw ( Tw Bw CQ ) $.
   lwE $e zw ( Tw CQ Cw ) $.
   mAE $a zw ( Tw Bw Cw ) $. $}
ugE $a zw ( Tw ( 4w Bw CQ ) Bw ) $.
uwE $a zw ( Tw ( 4w Bw CQ ) CQ ) $.
mgg $a #Pattern mwg $.
pQg $a #Pattern pgg $.
2wg $f #ElementVariable 3Ag $.
3Qg $f #ElementVariable 3gg $.
3wg $f #ElementVariable 4Ag $.
4gg $f #ElementVariable 4wg $.
5Ag $f #ElementVariable 5Qg $.
PAk $a #Pattern PQk $.
Qwk $a #Pattern RAk $.
.xw $f #ElementVariable -Bw $.
BCQ $a #Pattern 4Ag $.
ByQ $a #Pattern 3Ag $.
XiU $a #Pattern 3gg $.
XyU $a #Pattern 4wg $.
2yw $a #Pattern ( 4w ( SwE 5Qg ewk ) ( 4w ( SwE -Bw YQk ) IQE ) ) $.
${ 3Sw $p zw ( Tw ( 4w ( 4w ( SwE 4Ag mwg ) ( 4w ( SwE 3gg PQk ) ( 4w ( SwE 4wg pgg ) ( 4w ( SwE 5Qg ewk ) ( 4w ( SwE -Bw YQk ) IQE ) ) ) ) ) ( 4w ( SwE 3Ag RAk ) IQE ) ) ( SwE 4wg pgg ) ) $=
  ( BCQ mgg SgE XiU PAk XyU pQg 2yw 4g ByQ Qwk ugE uwE mAE IAE lQE ) CGHIZBJKIZ
  DLMIZEFNZOZOZOZAPQIUAOZOUIUEUIUJRUIUHUEUCUHSUHUGUEUDUGSUGUEUEUEUFRUEUBTTTT $. $}
