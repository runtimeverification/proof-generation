$c #SetVariable cwE PgE #ElementVariable #Symbol #Variable #Pattern ) ( $.
$v CQ Pw Bw Kw $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Kg $f #ElementVariable Kw $.
Pg $f #Symbol Pw $.
Sw $a #Pattern Pw $.
PQE $a #Pattern ( PgE Bw CQ ) $.
cgE $a #Symbol cwE $.
Xh8 $a #Pattern Kw $.
${ 0h8 $p #Pattern ( PgE Kw cwE ) $=
  ( Xh8 cgE Sw PQE ) ABCDE $. $}
