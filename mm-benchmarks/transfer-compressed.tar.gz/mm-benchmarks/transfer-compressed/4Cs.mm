$c Wgk #Symbol #Variable SwE PQk #SetVariable ) 4w #ElementVariable IQE #Pattern ( $.
$v 4wg 5Qg CQ Bw $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
4g $a #Pattern ( 4w Bw CQ ) $.
IAE $a #Pattern IQE $.
SgE $a #Pattern ( SwE Bw CQ ) $.
4gg $f #ElementVariable 4wg $.
5Ag $f #ElementVariable 5Qg $.
PAk $a #Pattern PQk $.
WQk $a #Pattern Wgk $.
XyU $a #Pattern 4wg $.
YCU $a #Pattern 5Qg $.
${ 4Cs $p #Pattern ( 4w ( SwE 4wg PQk ) ( 4w ( SwE 5Qg Wgk ) IQE ) ) $=
  ( XyU PAk SgE YCU WQk IAE 4g ) ACDEBFGEHII $. $}
