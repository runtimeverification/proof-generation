$c Tw #Symbol zw JAQ pgg #Pattern ( 0wM LAQ ewk xB4 tQM IAQ #Variable #SetVariable 4w rwM #ElementVariable IQE ) $.
$v yhs CQ DQ Bw Kw Cw 2gg $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Cg $f #Pattern Cw $.
DA $f #Pattern DQ $.
Kg $f #ElementVariable Kw $.
4g $a #Pattern ( 4w Bw CQ ) $.
IAE $a #Pattern IQE $.
${ lgE $e zw ( Tw Bw CQ ) $.
   lwE $e zw ( Tw CQ Cw ) $.
   mAE $a zw ( Tw Bw Cw ) $. $}
nAE $a zw IQE $.
${ wAE $e zw ( Tw Bw CQ ) $.
   wQE $e zw ( Tw Bw Cw ) $.
   wgE $a zw ( Tw Bw ( 4w CQ Cw ) ) $. $}
${ NwM $e zw CQ $.
   OAM $a zw ( Tw Bw CQ ) $. $}
rgM $a #Pattern ( rwM Bw CQ Kw Cw ) $.
tAM $a #Pattern ( tQM Bw CQ ) $.
0gM $a #Pattern ( 0wM Bw CQ Cw DQ ) $.
HwQ $a #Pattern ( IAQ Bw CQ ) $.
IwQ $a #Pattern ( JAQ Bw ) $.
KwQ $a #Pattern ( LAQ Bw CQ Cw ) $.
pQg $a #Pattern pgg $.
2Qg $f #ElementVariable 2gg $.
egk $a #Pattern ewk $.
yRs $f #ElementVariable yhs $.
wx4 $a #Pattern xB4 $.
Wh8 $a #Pattern 2gg $.
.h8 $a zw ( Tw ( 4w IQE ( 4w ( JAQ 2gg ) IQE ) ) ( JAQ 2gg ) ) $.
7SA $a #Pattern yhs $.
1Cc $a zw ( Tw ( 4w ( JAQ 2gg ) IQE ) ( tQM 2gg ( rwM pgg 2gg yhs ( 0wM pgg 2gg yhs ( LAQ ewk pgg ( IAQ ewk xB4 ) ) ) ) ) ) $.
${ 1Sc $p zw ( Tw ( 4w IQE ( 4w ( JAQ 2gg ) IQE ) ) ( tQM 2gg ( rwM pgg 2gg yhs ( 0wM pgg 2gg yhs ( LAQ ewk pgg ( IAQ ewk xB4 ) ) ) ) ) ) $=
  ( IAE Wh8 IwQ 4g pQg 7SA egk wx4 HwQ KwQ 0gM rgM tAM .h8 nAE OAM wgE 1Cc mAE
  ) CADZEZCFZFZUDUBGUBGUBBHIGIJKLMBNOUEUCCAPUECQRSABTUA $. $}
