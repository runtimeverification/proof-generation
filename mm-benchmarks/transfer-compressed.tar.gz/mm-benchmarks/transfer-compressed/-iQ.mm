$c #Symbol #Variable SwE #SetVariable iA 4w #ElementVariable IQE mwg #Pattern ) ( $.
$v Ow CQ DQ Bw Kw Cw nR4 3Ag Dw $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Cg $f #Pattern Cw $.
DA $f #Pattern DQ $.
Dg $f #Pattern Dw $.
Kg $f #ElementVariable Kw $.
Og $f #Variable Ow $.
SA $a #Variable Kw $.
IAE $a #Pattern IQE $.
SgE $a #Pattern ( SwE Bw CQ ) $.
${ KAI $e iA CQ DQ Bw Ow $.
   KQI $e iA Cw Dw Bw Ow $.
   KgI $a iA ( 4w CQ Cw ) ( 4w DQ Dw ) Bw Ow $. $}
mgg $a #Pattern mwg $.
2wg $f #ElementVariable 3Ag $.
nB4 $f #ElementVariable nR4 $.
6h8 $a #Pattern nR4 $.
ByQ $a #Pattern 3Ag $.
EyQ $a iA IQE IQE nR4 3Ag $.
-SQ $a iA ( SwE nR4 mwg ) ( SwE 3Ag mwg ) nR4 3Ag $.
${ -iQ $p iA ( 4w ( SwE nR4 mwg ) IQE ) ( 4w ( SwE 3Ag mwg ) IQE ) nR4 3Ag $=
  ( 6h8 mgg SgE IAE ByQ SA -SQ EyQ KgI ) BCZLDEFAGDEFAHABIABJK $. $}
