$c XBI Tw #Symbol -gg zw rgk #Pattern ( LAQ ewk xB4 IAQ Wgk #Variable SwE #SetVariable hgk 4w #ElementVariable IQE qxs 8wk 8hw ) $.
$v CQ qwg Bw oAg 5Qg Cw $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Cg $f #Pattern Cw $.
4g $a #Pattern ( 4w Bw CQ ) $.
IAE $a #Pattern IQE $.
SgE $a #Pattern ( SwE Bw CQ ) $.
${ lgE $e zw ( Tw Bw CQ ) $.
   lwE $e zw ( Tw CQ Cw ) $.
   mAE $a zw ( Tw Bw Cw ) $. $}
HwQ $a #Pattern ( IAQ Bw CQ ) $.
KwQ $a #Pattern ( LAQ Bw CQ Cw ) $.
nwg $f #Pattern oAg $.
qgg $f #Pattern qwg $.
5Ag $f #ElementVariable 5Qg $.
-Qg $a #Pattern -gg $.
WQk $a #Pattern Wgk $.
egk $a #Pattern ewk $.
hQk $a #Pattern hgk $.
rQk $a #Pattern rgk $.
8gk $a #Pattern 8wk $.
WxI $a #Pattern ( XBI oAg qwg ) $.
qhs $a #Pattern ( qxs oAg ) $.
tBs $a zw ( Tw ( SwE oAg 8wk ) ( SwE ( qxs oAg ) hgk ) ) $.
8Rw $a #Pattern 8hw $.
wx4 $a #Pattern xB4 $.
YCU $a #Pattern 5Qg $.
1iU $a zw ( Tw ( 4w ( SwE 5Qg -gg ) IQE ) ( SwE ( XBI ( IAQ ewk xB4 ) ( LAQ rgk Wgk ( IAQ rgk 8hw ) ) ) 8wk ) ) $.
${ 1yU $p zw ( Tw ( 4w ( SwE 5Qg -gg ) IQE ) ( SwE ( qxs ( XBI ( IAQ ewk xB4 ) ( LAQ rgk Wgk ( IAQ rgk 8hw ) ) ) ) hgk ) ) $=
  ( YCU -Qg SgE IAE 4g egk wx4 HwQ rQk WQk 8Rw KwQ WxI 8gk qhs hQk 1iU tBs mAE
  ) ABCDEFGHIJKJLIMNZODUAPQDARUAST $. $}
