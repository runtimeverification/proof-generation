$c 4B4 Tw #Symbol wQM zw JAQ .gk xwM pgg rgk #Pattern ( rwg 0wM twM LAQ tQM IAQ 5xw #Variable 1gM #SetVariable 4w #ElementVariable IQE mwg xQg ) Vhc $.
$v CQ qwg DQ Bw oAg Cw 2gg GQ $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Cg $f #Pattern Cw $.
DA $f #Pattern DQ $.
GA $f #Pattern GQ $.
4g $a #Pattern ( 4w Bw CQ ) $.
IAE $a #Pattern IQE $.
lQE $a zw ( Tw Bw Bw ) $.
${ lgE $e zw ( Tw Bw CQ ) $.
   lwE $e zw ( Tw CQ Cw ) $.
   mAE $a zw ( Tw Bw Cw ) $. $}
nAE $a zw IQE $.
ugE $a zw ( Tw ( 4w Bw CQ ) Bw ) $.
${ wAE $e zw ( Tw Bw CQ ) $.
   wQE $e zw ( Tw Bw Cw ) $.
   wgE $a zw ( Tw Bw ( 4w CQ Cw ) ) $. $}
${ NwM $e zw CQ $.
   OAM $a zw ( Tw Bw CQ ) $. $}
tAM $a #Pattern ( tQM Bw CQ ) $.
uwM $a #Pattern ( twM Bw ) $.
wAM $a #Pattern ( wQM Bw CQ Cw ) $.
xgM $a #Pattern ( xwM Bw CQ Cw ) $.
0gM $a #Pattern ( 0wM Bw CQ Cw DQ ) $.
1QM $a #Pattern ( 1gM Bw CQ Cw DQ ) $.
HwQ $a #Pattern ( IAQ Bw CQ ) $.
IwQ $a #Pattern ( JAQ Bw ) $.
KwQ $a #Pattern ( LAQ Bw CQ Cw ) $.
${ UAU $e zw ( Tw GQ ( tQM Bw ( xwM Bw CQ Cw ) ) ) $.
   UQU $e zw ( Tw GQ ( tQM Bw CQ ) ) $.
   UgU $a zw ( Tw GQ ( tQM Bw Cw ) ) $. $}
mgg $a #Pattern mwg $.
nwg $f #Pattern oAg $.
pQg $a #Pattern pgg $.
qgg $f #Pattern qwg $.
rgg $a #Pattern ( rwg oAg qwg ) $.
xAg $a #Pattern xQg $.
2Qg $f #ElementVariable 2gg $.
rQk $a #Pattern rgk $.
.Qk $a #Pattern .gk $.
VRc $a #Pattern ( Vhc oAg ) $.
5hw $a #Pattern 5xw $.
3x4 $a #Pattern 4B4 $.
Wh8 $a #Pattern 2gg $.
9h8 $a zw ( Tw ( 4w ( JAQ 2gg ) IQE ) ( 4w ( JAQ 2gg ) IQE ) ) $.
1jQ $a zw ( Tw ( 4w ( JAQ 2gg ) IQE ) ( tQM 2gg ( xwM 2gg ( wQM 2gg ( twM 2gg ) ( wQM 2gg ( 1gM mwg 2gg ( rwg ( LAQ rgk pgg ( IAQ rgk 4B4 ) ) xQg ) ( rwg ( LAQ rgk pgg ( IAQ rgk 4B4 ) ) xQg ) ) ( twM 2gg ) ) ) ( wQM 2gg ( 0wM .gk 2gg ( Vhc ( rwg ( LAQ rgk pgg ( IAQ rgk 4B4 ) ) xQg ) ) ( IAQ .gk 5xw ) ) ( twM 2gg ) ) ) ) ) $.
2zQ $a zw ( Tw ( 4w ( JAQ 2gg ) IQE ) ( tQM 2gg ( wQM 2gg ( twM 2gg ) ( wQM 2gg ( 1gM mwg 2gg ( rwg ( LAQ rgk pgg ( IAQ rgk 4B4 ) ) xQg ) ( rwg ( LAQ rgk pgg ( IAQ rgk 4B4 ) ) xQg ) ) ( twM 2gg ) ) ) ) ) $.
${ 3DQ $p zw ( Tw ( 4w ( JAQ 2gg ) IQE ) ( tQM 2gg ( wQM 2gg ( 0wM .gk 2gg ( Vhc ( rwg ( LAQ rgk pgg ( IAQ rgk 4B4 ) ) xQg ) ) ( IAQ .gk 5xw ) ) ( twM 2gg ) ) ) ) $=
  ( Wh8 IwQ IAE 4g .Qk rQk pQg 3x4 HwQ KwQ xAg rgg wAM tAM nAE OAM wgE ugE mAE
  VRc 5hw 0gM uwM 9h8 mgg 1QM xgM lQE 1jQ 2zQ UgU ) ABZCZDEZUOUOUODEZEZEZUMUMFU
  MGHGIJKLMZUAFUBJUCUMUDZNZOUOUOUQAUEZUOUOUPVBUOUODVBUODPQRRRUMUMUTUMUFUMUSUSUG
  UTNNZVAURURUOUMUMVCVAUHOURUNDURUOUNUOUQSZUOUNUNUNDSUNUITTURDPQRAUJTURUOUMVCOV
  DAUKTULT $. $}
