$c LAQ ewk #Symbol #Variable ( #SetVariable ) #ElementVariable pgg #Pattern cBQ $.
$v oAg 4wg 5Qg Cw CQ qwg Bw $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Cg $f #Pattern Cw $.
KwQ $a #Pattern ( LAQ Bw CQ Cw ) $.
nwg $f #Pattern oAg $.
pQg $a #Pattern pgg $.
qgg $f #Pattern qwg $.
4gg $f #ElementVariable 4wg $.
5Ag $f #ElementVariable 5Qg $.
egk $a #Pattern ewk $.
bxQ $a #Pattern ( cBQ oAg qwg ) $.
XyU $a #Pattern 4wg $.
YCU $a #Pattern 5Qg $.
${ 2yg $p #Pattern ( cBQ ( LAQ ewk pgg 4wg ) 5Qg ) $=
  ( egk pQg XyU KwQ YCU bxQ ) CDAEFBGH $. $}
