$c lSA Tw #Symbol zw YQk JAQ rgk pgg #Pattern ( LAQ ewk xB4 IAQ #Variable SwE #SetVariable vR4 4w #ElementVariable IQE 7BI 8hw ) cBQ $.
$v CQ qwg Bw oAg Cw 2gg $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Cg $f #Pattern Cw $.
4g $a #Pattern ( 4w Bw CQ ) $.
IAE $a #Pattern IQE $.
SgE $a #Pattern ( SwE Bw CQ ) $.
${ lgE $e zw ( Tw Bw CQ ) $.
   lwE $e zw ( Tw CQ Cw ) $.
   mAE $a zw ( Tw Bw Cw ) $. $}
nAE $a zw IQE $.
${ wAE $e zw ( Tw Bw CQ ) $.
   wQE $e zw ( Tw Bw Cw ) $.
   wgE $a zw ( Tw Bw ( 4w CQ Cw ) ) $. $}
${ NwM $e zw CQ $.
   OAM $a zw ( Tw Bw CQ ) $. $}
HwQ $a #Pattern ( IAQ Bw CQ ) $.
IwQ $a #Pattern ( JAQ Bw ) $.
KwQ $a #Pattern ( LAQ Bw CQ Cw ) $.
nwg $f #Pattern oAg $.
pQg $a #Pattern pgg $.
qgg $f #Pattern qwg $.
2Qg $f #ElementVariable 2gg $.
YAk $a #Pattern YQk $.
egk $a #Pattern ewk $.
rQk $a #Pattern rgk $.
6xI $a #Pattern ( 7BI oAg qwg ) $.
.BI $a zw ( Tw ( 4w ( SwE oAg YQk ) ( SwE qwg YQk ) ) ( SwE ( 7BI oAg qwg ) YQk ) ) $.
bxQ $a #Pattern ( cBQ oAg qwg ) $.
8Rw $a #Pattern 8hw $.
vB4 $a #Pattern vR4 $.
wx4 $a #Pattern xB4 $.
Wh8 $a #Pattern 2gg $.
lCA $a #Pattern lSA $.
9yc $a zw ( Tw ( 4w ( JAQ 2gg ) IQE ) ( SwE ( cBQ ( LAQ ewk pgg ( IAQ ewk xB4 ) ) ( LAQ rgk pgg ( IAQ rgk 8hw ) ) ) YQk ) ) $.
yjM $a zw ( Tw ( 4w ( JAQ 2gg ) IQE ) ( SwE ( cBQ ( LAQ ewk pgg ( IAQ ewk vR4 ) ) ( LAQ rgk pgg ( IAQ rgk lSA ) ) ) YQk ) ) $.
${ -zQ $p zw ( Tw ( 4w ( JAQ 2gg ) IQE ) ( 4w ( SwE ( 7BI ( cBQ ( LAQ ewk pgg ( IAQ ewk vR4 ) ) ( LAQ rgk pgg ( IAQ rgk lSA ) ) ) ( cBQ ( LAQ ewk pgg ( IAQ ewk xB4 ) ) ( LAQ rgk pgg ( IAQ rgk 8hw ) ) ) ) YQk ) IQE ) ) $=
  ( Wh8 IwQ IAE 4g egk pQg vB4 HwQ KwQ rQk lCA bxQ wx4 8Rw 6xI YAk SgE yjM wgE
  9yc .BI mAE nAE OAM ) ABCDEZFGFHIJKGKLIJMZFGFNIJKGKOIJMZPQRZDUFUGQRZUHQRZEUIU
  FUJUKASAUATUGUHUBUCUFDUDUET $. $}
