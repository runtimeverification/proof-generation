$c #SetVariable 0wM #ElementVariable #Symbol #Variable mwg #Pattern xQg ) ( $.
$v Cw 6Ag CQ 6xw DQ Bw $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Cg $f #Pattern Cw $.
DA $f #Pattern DQ $.
0gM $a #Pattern ( 0wM Bw CQ Cw DQ ) $.
mgg $a #Pattern mwg $.
xAg $a #Pattern xQg $.
5wg $f #ElementVariable 6Ag $.
6hw $f #ElementVariable 6xw $.
dB8 $a #Pattern 6xw $.
BCE $a #Pattern 6Ag $.
${ 2yQ $p #Pattern ( 0wM mwg 6xw 6Ag xQg ) $=
  ( mgg dB8 BCE xAg 0gM ) CBDAEFG $. $}
