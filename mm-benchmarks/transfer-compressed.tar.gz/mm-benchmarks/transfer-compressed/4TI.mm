$c Uw Ngk #Symbol 7h4 8Q4 BA0 zw YQk pgg #Pattern 0Q4 rwg Ex0 0wM xB4 tQM Wgk #Variable SwE PQk #SetVariable iA vR4 4w rwM #ElementVariable IQE mwg xQg 8hw cBQ zBA 2R4 PgE XBI Tw cwE wQM -g4 5x4 jww rgk ( twM .gM LAQ ewk IAQ Hg8 Kw8 8wk 7BI ) $.
$v th1 CQ -Bw Bw Cw sgg ngg z ph2 3gg Ew ph0 5Qg x Lw LQ Ow qwg DQ ph1 EQ y th2 tAg Dw HQ 4wg xX Gw th0 Hw Kw oAg 6Ag GQ nR4 tgg 4Ag $.
$d z y $.
$d z x $.
$d y x $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Cg $f #Pattern Cw $.
DA $f #Pattern DQ $.
Dg $f #Pattern Dw $.
EA $f #Pattern EQ $.
Eg $f #Pattern Ew $.
GA $f #Pattern GQ $.
Gg $f #Pattern Gw $.
HA $f #Pattern HQ $.
Hg $f #Pattern Hw $.
Kg $f #ElementVariable Kw $.
LA $f #ElementVariable LQ $.
Lg $f #ElementVariable Lw $.
Og $f #Variable Ow $.
SA $a #Variable Kw $.
Ug $a #Pattern ( Uw Kw Bw ) $.
jg $a iA Bw Ow Bw Ow $.
${ kg $e iA CQ DQ Bw Ow $.
   kw $e iA Cw Dw Bw Ow $.
   lA $a iA ( Tw CQ Cw ) ( Tw DQ Dw ) Bw Ow $. $}
4g $a #Pattern ( 4w Bw CQ ) $.
IAE $a #Pattern IQE $.
PQE $a #Pattern ( PgE Bw CQ ) $.
SgE $a #Pattern ( SwE Bw CQ ) $.
lQE $a zw ( Tw Bw Bw ) $.
${ lgE $e zw ( Tw Bw CQ ) $.
   lwE $e zw ( Tw CQ Cw ) $.
   mAE $a zw ( Tw Bw Cw ) $. $}
nAE $a zw IQE $.
ugE $a zw ( Tw ( 4w Bw CQ ) Bw ) $.
uwE $a zw ( Tw ( 4w Bw CQ ) CQ ) $.
${ wAE $e zw ( Tw Bw CQ ) $.
   wQE $e zw ( Tw Bw Cw ) $.
   wgE $a zw ( Tw Bw ( 4w CQ Cw ) ) $. $}
${ $d xX ph0 $.
   IQI $a iA Bw Bw CQ Ow $. $}
${ KAI $e iA CQ DQ Bw Ow $.
   KQI $e iA Cw Dw Bw Ow $.
   KgI $a iA ( 4w CQ Cw ) ( 4w DQ Dw ) Bw Ow $. $}
${ OgI $e iA CQ DQ Bw Ow $.
   OwI $e iA Cw Dw Bw Ow $.
   PAI $a iA ( SwE CQ Cw ) ( SwE DQ Dw ) Bw Ow $. $}
${ NwM $e zw CQ $.
   OAM $a zw ( Tw Bw CQ ) $. $}
tAM $a #Pattern ( tQM Bw CQ ) $.
uwM $a #Pattern ( twM Bw ) $.
wAM $a #Pattern ( wQM Bw CQ Cw ) $.
.QM $a #Pattern ( .gM Bw CQ Cw ) $.
HwQ $a #Pattern ( IAQ Bw CQ ) $.
KwQ $a #Pattern ( LAQ Bw CQ Cw ) $.
${ QAQ $e iA Bw Cw Dw Ow $.
   QQQ $e iA CQ DQ Dw Ow $.
   QgQ $a iA ( tQM Bw CQ ) ( tQM Cw DQ ) Dw Ow $. $}
${ SgQ $e iA Bw DQ Ew Ow $.
   SwQ $e iA CQ Dw Ew Ow $.
   TAQ $e iA Cw EQ Ew Ow $.
   TQQ $a iA ( wQM Bw CQ Cw ) ( wQM DQ Dw EQ ) Ew Ow $. $}
${ awQ $e iA Bw DQ Ew Ow $.
   bAQ $e iA CQ Dw Ew Ow $.
   bQQ $e iA Cw EQ Ew Ow $.
   bgQ $a iA ( .gM Bw CQ Cw ) ( .gM DQ Dw EQ ) Ew Ow $. $}
${ $d z ph0 $.
   $d z ph1 $.
   $d z ph2 $.
   $d z y $.
   $d z x $.
   $d z th1 $.
   $d z th2 $.
   $d x ph0 $.
   $d y th0 $.
   lAY $e zw ( Tw GQ ( Uw Kw ( PgE Kw Bw ) ) ) $.
   lQY $e zw ( Tw ( 4w GQ Gw ) CQ ) $.
   lgY $e iA ( Tw HQ Cw ) ( Tw Gw CQ ) Bw LQ $.
   lwY $e iA ( Tw Hw DQ ) ( Tw Gw CQ ) Lw LQ $.
   mAY $a zw ( Tw ( 4w GQ HQ ) Cw ) $. $}
${ $d x ph0 $.
   $d x ph1 $.
   vwY $e zw ( Tw GQ ( SwE CQ Bw ) ) $.
   wAY $e zw ( Tw GQ ( tQM cwE ( rwM Bw cwE Kw ( 0wM Bw cwE Kw CQ ) ) ) ) $.
   wQY $a zw ( Tw GQ ( Uw Kw ( PgE Kw CQ ) ) ) $. $}
mgg $a #Pattern mwg $.
nQg $f #Variable ngg $.
nwg $f #Pattern oAg $.
pQg $a #Pattern pgg $.
qgg $f #Pattern qwg $.
rgg $a #Pattern ( rwg oAg qwg ) $.
sQg $f #Pattern sgg $.
swg $f #Pattern tAg $.
tQg $f #Pattern tgg $.
${ uQg $e iA qwg tAg oAg ngg $.
   ugg $e iA sgg tgg oAg ngg $.
   uwg $a iA ( rwg qwg sgg ) ( rwg tAg tgg ) oAg ngg $. $}
wQg $a zw ( Tw ( 4w ( SwE oAg pgg ) ( SwE qwg mwg ) ) ( SwE ( rwg oAg qwg ) mwg ) ) $.
xAg $a #Pattern xQg $.
3Qg $f #ElementVariable 3gg $.
3wg $f #ElementVariable 4Ag $.
4gg $f #ElementVariable 4wg $.
5Ag $f #ElementVariable 5Qg $.
5wg $f #ElementVariable 6Ag $.
NQk $a #Pattern Ngk $.
PAk $a #Pattern PQk $.
WQk $a #Pattern Wgk $.
egk $a #Pattern ewk $.
rQk $a #Pattern rgk $.
8gk $a #Pattern 8wk $.
jgw $a #Pattern ( jww oAg ) $.
mAw $a zw ( Tw ( SwE oAg mwg ) ( SwE ( jww oAg ) pgg ) ) $.
Aw0 $a #Pattern ( BA0 oAg ) $.
0A4 $a #Pattern ( 0Q4 oAg qwg ) $.
${ 1Q4 $e iA qwg tAg oAg ngg $.
   1g4 $e iA sgg tgg oAg ngg $.
   1w4 $a iA ( 0Q4 qwg sgg ) ( 0Q4 tAg tgg ) oAg ngg $. $}
8A4 $a #Pattern ( 8Q4 oAg ) $.
-Q4 $a #Pattern ( -g4 oAg qwg ) $.
${ Ag8 $e iA qwg tAg oAg ngg $.
   Aw8 $e iA sgg tgg oAg ngg $.
   BA8 $a iA ( -g4 qwg sgg ) ( -g4 tAg tgg ) oAg ngg $. $}
HQ8 $a #Pattern ( Hg8 oAg ) $.
${ Ig8 $e iA qwg sgg oAg ngg $.
   Iw8 $a iA ( Hg8 qwg ) ( Hg8 sgg ) oAg ngg $. $}
Kg8 $a #Pattern ( Kw8 oAg ) $.
yxA $a #Pattern ( zBA oAg qwg ) $.
WxI $a #Pattern ( XBI oAg qwg ) $.
6xI $a #Pattern ( 7BI oAg qwg ) $.
8Rw $a #Pattern 8hw $.
.xw $f #ElementVariable -Bw $.
Eh0 $a #Pattern Ex0 $.
nB4 $f #ElementVariable nR4 $.
vB4 $a #Pattern vR4 $.
wx4 $a #Pattern xB4 $.
2B4 $a #Pattern 2R4 $.
5h4 $a #Pattern 5x4 $.
7R4 $a #Pattern 7h4 $.
6h8 $a #Pattern nR4 $.
dyA $a zw ( Tw IQE ( SwE ( rwg ( LAQ 8wk pgg ( XBI ( IAQ ewk 7h4 ) ( zBA ( LAQ ewk Wgk ( IAQ ewk 7h4 ) ) ( LAQ ewk Wgk ( IAQ ewk 2R4 ) ) ) ) ) ( rwg ( LAQ 8wk pgg ( XBI ( IAQ ewk xB4 ) ( LAQ rgk Wgk ( IAQ rgk Ex0 ) ) ) ) xQg ) ) mwg ) ) $.
eSA $a zw ( Tw IQE ( SwE ( BA0 ( rwg ( LAQ ewk pgg ( IAQ ewk vR4 ) ) xQg ) ) pgg ) ) $.
jCA $a zw ( Tw IQE ( SwE ( jww ( rwg ( LAQ rgk pgg ( IAQ rgk 5x4 ) ) xQg ) ) pgg ) ) $.
BCE $a #Pattern 6Ag $.
BCQ $a #Pattern 4Ag $.
RyQ $a iA Ngk Ngk nR4 4Ag $.
XiU $a #Pattern 3gg $.
XyU $a #Pattern 4wg $.
YCU $a #Pattern 5Qg $.
iCc $a iA ( 4w ( SwE nR4 mwg ) IQE ) ( 4w ( SwE 4Ag mwg ) IQE ) nR4 4Ag $.
yyg $a #Pattern -Bw $.
2yw $a #Pattern ( 4w ( SwE 5Qg ewk ) ( 4w ( SwE -Bw YQk ) IQE ) ) $.
6Sw $a #Pattern ( rwg ( LAQ ewk pgg 5Qg ) 4Ag ) $.
6iw $a #Pattern ( cBQ ( LAQ ewk pgg 5Qg ) 4wg ) $.
6yw $a #Pattern ( rwg 4wg 4Ag ) $.
Iy0 $a zw ( Tw ( 4w ( 4w ( SwE 3gg PQk ) ( 4w ( SwE 4wg pgg ) ( 4w ( SwE 5Qg ewk ) ( 4w ( SwE -Bw YQk ) IQE ) ) ) ) ( 4w ( SwE 4Ag mwg ) IQE ) ) ( tQM Ngk ( .gM Ngk ( wQM Ngk ( twM Ngk ) ( -g4 ( 0Q4 ( Hg8 ( rwg ( LAQ ewk pgg 5Qg ) 4Ag ) ) ( wQM PQk ( Kw8 ( 7BI ( cBQ ( LAQ ewk pgg 5Qg ) 4wg ) -Bw ) ) 3gg ) ) ( 8Q4 ( IAQ rgk 8hw ) ) ) ) ( wQM Ngk ( twM Ngk ) ( -g4 ( 0Q4 ( Hg8 ( rwg 4wg 4Ag ) ) 3gg ) ( 8Q4 ( IAQ rgk 8hw ) ) ) ) ) ) ) $.
JC0 $a #Pattern ( rwg ( LAQ ewk pgg 5Qg ) nR4 ) $.
JS0 $a #Pattern ( rwg 4wg nR4 ) $.
Ji0 $a iA ( Hg8 ( rwg ( LAQ ewk pgg 5Qg ) nR4 ) ) ( Hg8 ( rwg ( LAQ ewk pgg 5Qg ) 4Ag ) ) nR4 4Ag $.
Ky0 $a iA ( wQM Ngk ( twM Ngk ) ( -g4 ( 0Q4 ( Hg8 ( rwg 4wg nR4 ) ) 3gg ) ( 8Q4 ( IAQ rgk 8hw ) ) ) ) ( wQM Ngk ( twM Ngk ) ( -g4 ( 0Q4 ( Hg8 ( rwg 4wg 4Ag ) ) 3gg ) ( 8Q4 ( IAQ rgk 8hw ) ) ) ) nR4 4Ag $.
LS0 $a zw ( Tw ( 4w ( SwE 3gg PQk ) ( 4w ( SwE 4wg pgg ) ( 4w ( SwE 5Qg ewk ) ( 4w ( SwE -Bw YQk ) IQE ) ) ) ) ( 4w ( SwE 5Qg ewk ) ( 4w ( SwE -Bw YQk ) IQE ) ) ) $.
jTI $a zw ( Tw ( 4w ( SwE 3gg PQk ) ( 4w ( SwE 4wg pgg ) ( 4w ( SwE 5Qg ewk ) ( 4w ( SwE -Bw YQk ) IQE ) ) ) ) ( SwE ( rwg ( BA0 ( rwg ( LAQ ewk pgg ( IAQ ewk vR4 ) ) xQg ) ) ( rwg ( LAQ 8wk pgg ( XBI ( IAQ ewk 7h4 ) ( zBA ( LAQ ewk Wgk ( IAQ ewk 7h4 ) ) ( LAQ ewk Wgk ( IAQ ewk 2R4 ) ) ) ) ) ( rwg ( LAQ 8wk pgg ( XBI ( IAQ ewk xB4 ) ( LAQ rgk Wgk ( IAQ rgk Ex0 ) ) ) ) xQg ) ) ) mwg ) ) $.
3jI $a zw ( Tw IQE ( tQM cwE ( rwM mwg cwE 6Ag ( 0wM mwg cwE 6Ag ( rwg ( jww ( rwg ( LAQ rgk pgg ( IAQ rgk 5x4 ) ) xQg ) ) ( rwg ( BA0 ( rwg ( LAQ ewk pgg ( IAQ ewk vR4 ) ) xQg ) ) ( rwg ( LAQ 8wk pgg ( XBI ( IAQ ewk 7h4 ) ( zBA ( LAQ ewk Wgk ( IAQ ewk 7h4 ) ) ( LAQ ewk Wgk ( IAQ ewk 2R4 ) ) ) ) ) ( rwg ( LAQ 8wk pgg ( XBI ( IAQ ewk xB4 ) ( LAQ rgk Wgk ( IAQ rgk Ex0 ) ) ) ) xQg ) ) ) ) ) ) ) ) $.
4DI $a zw ( Tw ( 4w ( SwE 3gg PQk ) ( 4w ( SwE 4wg pgg ) ( 4w ( SwE 5Qg ewk ) ( 4w ( SwE -Bw YQk ) IQE ) ) ) ) ( SwE ( rwg ( LAQ rgk pgg ( IAQ rgk 5x4 ) ) xQg ) mwg ) ) $.
${ 4TI $p zw ( Tw ( 4w ( SwE 3gg PQk ) ( 4w ( SwE 4wg pgg ) ( 4w ( SwE 5Qg ewk ) ( 4w ( SwE -Bw YQk ) IQE ) ) ) ) ( tQM Ngk ( .gM Ngk ( wQM Ngk ( twM Ngk ) ( -g4 ( 0Q4 ( Hg8 ( rwg ( LAQ ewk pgg 5Qg ) ( rwg ( jww ( rwg ( LAQ rgk pgg ( IAQ rgk 5x4 ) ) xQg ) ) ( rwg ( BA0 ( rwg ( LAQ ewk pgg ( IAQ ewk vR4 ) ) xQg ) ) ( rwg ( LAQ 8wk pgg ( XBI ( IAQ ewk 7h4 ) ( zBA ( LAQ ewk Wgk ( IAQ ewk 7h4 ) ) ( LAQ ewk Wgk ( IAQ ewk 2R4 ) ) ) ) ) ( rwg ( LAQ 8wk pgg ( XBI ( IAQ ewk xB4 ) ( LAQ rgk Wgk ( IAQ rgk Ex0 ) ) ) ) xQg ) ) ) ) ) ) ( wQM PQk ( Kw8 ( 7BI ( cBQ ( LAQ ewk pgg 5Qg ) 4wg ) -Bw ) ) 3gg ) ) ( 8Q4 ( IAQ rgk 8hw ) ) ) ) ( wQM Ngk ( twM Ngk ) ( -g4 ( 0Q4 ( Hg8 ( rwg 4wg ( rwg ( jww ( rwg ( LAQ rgk pgg ( IAQ rgk 5x4 ) ) xQg ) ) ( rwg ( BA0 ( rwg ( LAQ ewk pgg ( IAQ ewk vR4 ) ) xQg ) ) ( rwg ( LAQ 8wk pgg ( XBI ( IAQ ewk 7h4 ) ( zBA ( LAQ ewk Wgk ( IAQ ewk 7h4 ) ) ( LAQ ewk Wgk ( IAQ ewk 2R4 ) ) ) ) ) ( rwg ( LAQ 8wk pgg ( XBI ( IAQ ewk xB4 ) ( LAQ rgk Wgk ( IAQ rgk Ex0 ) ) ) ) xQg ) ) ) ) ) ) 3gg ) ( 8Q4 ( IAQ rgk 8hw ) ) ) ) ) ) ) $=
  ( 3wg nB4 SgE pQg 4g HwQ KwQ rgg egk mgg IAE NQk wAM mAE wgE IQI 5wg Ug SA jg
  XiU PAk XyU 2yw rQk 5h4 xAg jgw vB4 Aw0 8gk 7R4 WQk 2B4 yxA WxI wx4 Eh0 uwM
  YCU HQ8 6iw yyg 6xI Kg8 0A4 8Rw 8A4 -Q4 .QM tAM ugE lQE uwE LS0 4DI mAw jTI
  wQg nAE OAM 6Sw 6yw JC0 JS0 BCQ 6h8 BCE PQE jCA eSA dyA 3jI wQY Iy0 PAI KgI
  uwg Iw8 1w4 BA8 TQQ bgQ QgQ lA iCc RyQ Ji0 Ky0 mAY ) AUEZUFGZBUGZHGZCDUHZIZIZ
  YAUIHUIUJJKUKLZULZMHMUMJKUKLUNZUOHMUPJZMUQYEKMUQMURJKUSUTKUOHMVAJUIUQUIVBJKUT
  KUKLLZLZLZNGZOIZIPPPPVCZMHCVDKZYHLZVEZUFBCVFDVGVHVIXOQZVJZUIVKJVLZVMZQZPYKXQY
  HLZVEZXOVJZYQVMZQZVNZVOZYAYAYJYAXPXTYAXPXPXPXTVPXPVQRYAXRXSYAXTXRXPXTVRXTXRXR
  XRXSVPXRVQRRABCDVSSSYAYIOYAYCHGZYGNGZIZYIYAUUGUUHYAYBNGUUGABCDVTYBWARABCDWBSY
  CYGWCZRYAOWDWEZSSYHPPPYKECWFZVEZYOVJZYQVMZQZPYKEBWGZVEZXOVJZYQVMZQZVNZVOZUUFP
  PPYKCFWHVEZYOVJZYQVMZQZPYKBFWIVEXOVJYQVMQZVNZVOZYAEWJZNGZOIZYJFWKZNGOIZUAEFYA
  OUAWLYHWMUAUBUUKNYHOUAOUUIYIOUUGUUHWNOYDHGZYFNGZIUUHOUVPUVQWOWPSYDYFWCRSUUJRU
  AWQWRRAEBCDWSYHYJUUFUVMUVCEUCZYHYIOUVLOUVRYHYHNUVKNUVRYHUVRUDZNYHUVRTWTOYHUVR
  TXAPUUEPUVBYHUVRPYHUVRTZPYSUUDPUUPUVAYHUVRUVTPYKYRPYKUUOYHUVRUVTYKYHUVRTZUVRY
  HYPYQUUNYQUVRYHYNYOUUMYOUVRYHYMUULUVRYHYLYHYLUVKYLYHUVRTUVSXBXCYOYHUVRTXDYQYH
  UVRTZXEXFPYKUUCPYKUUTYHUVRUVTUWAUVRYHUUBYQUUSYQUVRYHUUAXOUURXOUVRYHYTUUQUVRYH
  XQYHXQUVKXQYHUVRTUVSXBXCXOYHUVRTXDUWBXEXFXGXHXIUVNUVOUVJUVMUVCUVREFXJPUVIPUVB
  UVNUVREFXKZPUVGUVHPUUPUVAUVNUVRUWCPYKUVFPYKUUOUVNUVRUWCYKUVNUVRTUVRUVNUVEYQUU
  NYQUVRUVNUVDYOUUMYOECFXLYOUVNUVRTXDYQUVNUVRTXEXFAEBFXMXGXHXIXNR $. $}
