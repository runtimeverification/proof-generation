$c 2R4 kBM 4B4 XBI zBA 1wk Tw #Symbol 7h4 -gg DBE zBI GBY 5x4 zw JAQ pwk pgg rgk vA4 #Pattern ( Ex0 LAQ ewk xB4 yx4 IAQ 9R4 Wgk 0h4 3BA #Variable SwE 0hU #SetVariable hgk vR4 4w #ElementVariable IQE qxs 8wk mwg 8hw ) $.
$v 7Ag CQ qwg Bw oAg Cw 2gg sgg $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Cg $f #Pattern Cw $.
4g $a #Pattern ( 4w Bw CQ ) $.
IAE $a #Pattern IQE $.
SgE $a #Pattern ( SwE Bw CQ ) $.
${ lgE $e zw ( Tw Bw CQ ) $.
   lwE $e zw ( Tw CQ Cw ) $.
   mAE $a zw ( Tw Bw Cw ) $. $}
nAE $a zw IQE $.
${ wAE $e zw ( Tw Bw CQ ) $.
   wQE $e zw ( Tw Bw Cw ) $.
   wgE $a zw ( Tw Bw ( 4w CQ Cw ) ) $. $}
${ NwM $e zw CQ $.
   OAM $a zw ( Tw Bw CQ ) $. $}
HwQ $a #Pattern ( IAQ Bw CQ ) $.
IwQ $a #Pattern ( JAQ Bw ) $.
KwQ $a #Pattern ( LAQ Bw CQ Cw ) $.
nwg $f #Pattern oAg $.
pQg $a #Pattern pgg $.
qgg $f #Pattern qwg $.
sQg $f #Pattern sgg $.
2Qg $f #ElementVariable 2gg $.
6wg $f #ElementVariable 7Ag $.
.gg $a zw ( Tw ( 4w ( 4w ( JAQ oAg ) ( JAQ qwg ) ) ( SwE sgg oAg ) ) ( SwE ( LAQ oAg qwg sgg ) qwg ) ) $.
-Qg $a #Pattern -gg $.
WQk $a #Pattern Wgk $.
egk $a #Pattern ewk $.
hQk $a #Pattern hgk $.
pgk $a #Pattern pwk $.
rQk $a #Pattern rgk $.
1gk $a #Pattern 1wk $.
8gk $a #Pattern 8wk $.
uw4 $a #Pattern vA4 $.
yxA $a #Pattern ( zBA oAg qwg ) $.
2xA $a #Pattern ( 3BA oAg qwg ) $.
CxE $a #Pattern ( DBE oAg qwg ) $.
WxI $a #Pattern ( XBI oAg qwg ) $.
yxI $a #Pattern ( zBI oAg qwg ) $.
jxM $a #Pattern ( kBM oAg qwg ) $.
nBM $a zw ( Tw ( 4w ( SwE oAg 8wk ) ( SwE qwg 8wk ) ) ( SwE ( kBM oAg qwg ) 8wk ) ) $.
0RU $a #Pattern ( 0hU oAg qwg sgg ) $.
3xU $a zw ( Tw ( 4w ( 4w ( SwE oAg pwk ) ( SwE qwg hgk ) ) ( SwE sgg hgk ) ) ( SwE ( 0hU oAg qwg sgg ) 8wk ) ) $.
FxY $a #Pattern ( GBY oAg qwg ) $.
JBY $a zw ( Tw ( 4w ( SwE oAg -gg ) ( SwE qwg 8wk ) ) ( SwE ( GBY oAg qwg ) 1wk ) ) $.
qhs $a #Pattern ( qxs oAg ) $.
tBs $a zw ( Tw ( SwE oAg 8wk ) ( SwE ( qxs oAg ) hgk ) ) $.
8Rw $a #Pattern 8hw $.
Eh0 $a #Pattern Ex0 $.
vB4 $a #Pattern vR4 $.
wx4 $a #Pattern xB4 $.
yh4 $a #Pattern yx4 $.
0R4 $a #Pattern 0h4 $.
2B4 $a #Pattern 2R4 $.
3x4 $a #Pattern 4B4 $.
5h4 $a #Pattern 5x4 $.
7R4 $a #Pattern 7h4 $.
9B4 $a #Pattern 9R4 $.
pyQ $a #Pattern ( 4w ( JAQ 2gg ) ( 4w ( SwE 7Ag mwg ) IQE ) ) $.
vCQ $a zw ( Tw ( 4w ( JAQ 2gg ) ( 4w ( SwE 7Ag mwg ) IQE ) ) ( 4w ( JAQ 1wk ) ( JAQ pgg ) ) ) $.
wSQ $a zw ( Tw ( 4w ( JAQ 2gg ) ( 4w ( SwE 7Ag mwg ) IQE ) ) ( SwE ( 3BA ( IAQ ewk 9R4 ) ( 3BA ( IAQ ewk 2R4 ) ( 3BA ( IAQ ewk vR4 ) ( 3BA ( IAQ ewk 7h4 ) ( 3BA ( IAQ ewk xB4 ) vA4 ) ) ) ) ) -gg ) ) $.
ySQ $a zw ( Tw ( 4w ( JAQ 2gg ) ( 4w ( SwE 7Ag mwg ) IQE ) ) ( SwE ( kBM ( kBM ( XBI ( IAQ ewk 9R4 ) ( LAQ rgk Wgk ( IAQ rgk yx4 ) ) ) ( XBI ( IAQ ewk 2R4 ) ( LAQ rgk Wgk ( IAQ rgk 0h4 ) ) ) ) ( XBI ( IAQ ewk vR4 ) ( LAQ rgk Wgk ( IAQ rgk 5x4 ) ) ) ) 8wk ) ) $.
yyQ $a zw ( Tw ( 4w ( JAQ 2gg ) ( 4w ( SwE 7Ag mwg ) IQE ) ) ( SwE ( XBI ( IAQ ewk 7h4 ) ( LAQ rgk Wgk ( IAQ rgk 4B4 ) ) ) 8wk ) ) $.
zyQ $a zw ( Tw ( 4w ( JAQ 2gg ) ( 4w ( SwE 7Ag mwg ) IQE ) ) ( SwE ( zBI ( LAQ ewk Wgk ( IAQ ewk 2R4 ) ) ( LAQ ewk Wgk ( IAQ ewk vR4 ) ) ) pwk ) ) $.
0SQ $a zw ( Tw ( 4w ( JAQ 2gg ) ( 4w ( SwE 7Ag mwg ) IQE ) ) ( SwE ( XBI ( IAQ ewk xB4 ) ( LAQ rgk Wgk ( IAQ rgk 8hw ) ) ) 8wk ) ) $.
0iQ $a zw ( Tw ( 4w ( JAQ 2gg ) ( 4w ( SwE 7Ag mwg ) IQE ) ) ( SwE ( XBI ( IAQ ewk vR4 ) ( DBE ( LAQ ewk Wgk ( IAQ ewk vR4 ) ) ( LAQ ewk Wgk ( IAQ ewk 2R4 ) ) ) ) 8wk ) ) $.
1CQ $a zw ( Tw ( 4w ( JAQ 2gg ) ( 4w ( SwE 7Ag mwg ) IQE ) ) ( SwE ( XBI ( IAQ ewk 7h4 ) ( zBA ( LAQ ewk Wgk ( IAQ ewk 7h4 ) ) ( LAQ ewk Wgk ( IAQ ewk 2R4 ) ) ) ) 8wk ) ) $.
1iQ $a zw ( Tw ( 4w ( JAQ 2gg ) ( 4w ( SwE 7Ag mwg ) IQE ) ) ( SwE ( XBI ( IAQ ewk xB4 ) ( LAQ rgk Wgk ( IAQ rgk Ex0 ) ) ) 8wk ) ) $.
${ 1yQ $p zw ( Tw ( 4w ( JAQ 2gg ) ( 4w ( SwE 7Ag mwg ) IQE ) ) ( 4w ( SwE ( LAQ 1wk pgg ( GBY ( 3BA ( IAQ ewk 9R4 ) ( 3BA ( IAQ ewk 2R4 ) ( 3BA ( IAQ ewk vR4 ) ( 3BA ( IAQ ewk 7h4 ) ( 3BA ( IAQ ewk xB4 ) vA4 ) ) ) ) ) ( kBM ( kBM ( kBM ( kBM ( XBI ( IAQ ewk 9R4 ) ( LAQ rgk Wgk ( IAQ rgk yx4 ) ) ) ( XBI ( IAQ ewk 2R4 ) ( LAQ rgk Wgk ( IAQ rgk 0h4 ) ) ) ) ( XBI ( IAQ ewk vR4 ) ( LAQ rgk Wgk ( IAQ rgk 5x4 ) ) ) ) ( XBI ( IAQ ewk 7h4 ) ( LAQ rgk Wgk ( IAQ rgk 4B4 ) ) ) ) ( 0hU ( zBI ( LAQ ewk Wgk ( IAQ ewk 2R4 ) ) ( LAQ ewk Wgk ( IAQ ewk vR4 ) ) ) ( qxs ( XBI ( IAQ ewk xB4 ) ( LAQ rgk Wgk ( IAQ rgk 8hw ) ) ) ) ( qxs ( kBM ( kBM ( XBI ( IAQ ewk vR4 ) ( DBE ( LAQ ewk Wgk ( IAQ ewk vR4 ) ) ( LAQ ewk Wgk ( IAQ ewk 2R4 ) ) ) ) ( XBI ( IAQ ewk 7h4 ) ( zBA ( LAQ ewk Wgk ( IAQ ewk 7h4 ) ) ( LAQ ewk Wgk ( IAQ ewk 2R4 ) ) ) ) ) ( XBI ( IAQ ewk xB4 ) ( LAQ rgk Wgk ( IAQ rgk Ex0 ) ) ) ) ) ) ) ) ) pgg ) IQE ) ) $=
  ( 1gk pQg egk HwQ 2xA rQk WQk KwQ WxI jxM qhs SgE IAE 4g 8gk wgE nBM mAE pyQ
  9B4 2B4 vB4 7R4 wx4 uw4 yh4 0R4 5h4 3x4 yxI 8Rw CxE yxA Eh0 0RU FxY IwQ vCQ
  -Qg wSQ ySQ yyQ pgk hQk zyQ 0SQ tBs 0iQ 1CQ 1iQ 3xU JBY .gg nAE OAM ) ABUAZCD
  EUBFZEUCFZEUDFZEUEFZEUFFZUGGGGGGZVSHIHUHFJKVTHIHUIFJKLWAHIHUJFJKLZWBHIHUKFJKZ
  LZEIVTJZEIWAJZULZWCHIHUMFJKZMZWAWIWHUNKZWBEIWBJWHUOKZLZWCHIHUPFJKZLZMZUQZLZUR
  ZJDNZOVRCUSDUSPZXACNZPXBVRXCXDABUTVRWDVANZWTQNZPXDVRXEXFABVBVRWGQNZWSQNZPXFVR
  XGXHVRWEQNZWFQNZPXGVRXIXJABVCABVDRWEWFSTVRWJVENZWLVFNZPZWRVFNZPXHVRXMXNVRXKXL
  ABVGVRWKQNXLABVHWKVITRVRWQQNZXNVRWOQNZWPQNZPXOVRXPXQVRWMQNZWNQNZPXPVRXRXSABVJ
  ABVKRWMWNSTABVLRWOWPSTWQVITRWJWLWRVMTRWGWSSTRWDWTVNTRCDXAVOTVROVPVQR $. $}
