$c 2R4 Tw #Symbol zw YQk JAQ pgg rgk #Pattern ( 0wM LAQ ewk tQM IAQ 0h4 #Variable #SetVariable 4w rwM #ElementVariable IQE ) cBQ $.
$v yhs CQ qwg DQ Bw Kw oAg Cw 2gg $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Cg $f #Pattern Cw $.
DA $f #Pattern DQ $.
Kg $f #ElementVariable Kw $.
4g $a #Pattern ( 4w Bw CQ ) $.
IAE $a #Pattern IQE $.
${ lgE $e zw ( Tw Bw CQ ) $.
   lwE $e zw ( Tw CQ Cw ) $.
   mAE $a zw ( Tw Bw Cw ) $. $}
nAE $a zw IQE $.
${ wAE $e zw ( Tw Bw CQ ) $.
   wQE $e zw ( Tw Bw Cw ) $.
   wgE $a zw ( Tw Bw ( 4w CQ Cw ) ) $. $}
${ NwM $e zw CQ $.
   OAM $a zw ( Tw Bw CQ ) $. $}
rgM $a #Pattern ( rwM Bw CQ Kw Cw ) $.
tAM $a #Pattern ( tQM Bw CQ ) $.
0gM $a #Pattern ( 0wM Bw CQ Cw DQ ) $.
HwQ $a #Pattern ( IAQ Bw CQ ) $.
IwQ $a #Pattern ( JAQ Bw ) $.
KwQ $a #Pattern ( LAQ Bw CQ Cw ) $.
nwg $f #Pattern oAg $.
pQg $a #Pattern pgg $.
qgg $f #Pattern qwg $.
2Qg $f #ElementVariable 2gg $.
YAk $a #Pattern YQk $.
egk $a #Pattern ewk $.
rQk $a #Pattern rgk $.
bxQ $a #Pattern ( cBQ oAg qwg ) $.
yRs $f #ElementVariable yhs $.
0R4 $a #Pattern 0h4 $.
2B4 $a #Pattern 2R4 $.
Wh8 $a #Pattern 2gg $.
.h8 $a zw ( Tw ( 4w IQE ( 4w ( JAQ 2gg ) IQE ) ) ( JAQ 2gg ) ) $.
7SA $a #Pattern yhs $.
1yk $a zw ( Tw ( 4w ( JAQ 2gg ) IQE ) ( tQM 2gg ( rwM YQk 2gg yhs ( 0wM YQk 2gg yhs ( cBQ ( LAQ ewk pgg ( IAQ ewk 2R4 ) ) ( LAQ rgk pgg ( IAQ rgk 0h4 ) ) ) ) ) ) ) $.
${ 2Ck $p zw ( Tw ( 4w IQE ( 4w ( JAQ 2gg ) IQE ) ) ( tQM 2gg ( rwM YQk 2gg yhs ( 0wM YQk 2gg yhs ( cBQ ( LAQ ewk pgg ( IAQ ewk 2R4 ) ) ( LAQ rgk pgg ( IAQ rgk 0h4 ) ) ) ) ) ) ) $=
  ( IAE Wh8 IwQ 4g YAk 7SA egk pQg 2B4 HwQ KwQ rQk 0R4 bxQ 0gM rgM tAM .h8 nAE
  OAM wgE 1yk mAE ) CADZEZCFZFZUHUFGUFGUFBHIJIKLMNJNOLMPQBRSUIUGCATUICUAUBUCABU
  DUE $. $}
