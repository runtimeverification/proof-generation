$c LAQ ewk Wgk #Symbol #Variable #SetVariable iA #ElementVariable #Pattern ) ( $.
$v Ow CQ zBs DQ Ew Bw Kw Cw nR4 EQ Dw $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Cg $f #Pattern Cw $.
DA $f #Pattern DQ $.
Dg $f #Pattern Dw $.
EA $f #Pattern EQ $.
Eg $f #Pattern Ew $.
Kg $f #ElementVariable Kw $.
Og $f #Variable Ow $.
SA $a #Variable Kw $.
jg $a iA Bw Ow Bw Ow $.
${ lAQ $e iA Bw DQ Ew Ow $.
   lQQ $e iA CQ Dw Ew Ow $.
   lgQ $e iA Cw EQ Ew Ow $.
   lwQ $a iA ( LAQ Bw CQ Cw ) ( LAQ DQ Dw EQ ) Ew Ow $. $}
WQk $a #Pattern Wgk $.
egk $a #Pattern ewk $.
yxs $f #ElementVariable zBs $.
nB4 $f #ElementVariable nR4 $.
6h8 $a #Pattern nR4 $.
JiE $a #Pattern zBs $.
MCI $a iA Wgk Wgk nR4 zBs $.
0CI $a iA ewk ewk nR4 zBs $.
${ 0yI $p iA ( LAQ ewk Wgk nR4 ) ( LAQ ewk Wgk zBs ) nR4 zBs $=
  ( egk WQk 6h8 JiE SA 0CI MCI jg lwQ ) CDBEZCDAFLAGZABHABILMJK $. $}
