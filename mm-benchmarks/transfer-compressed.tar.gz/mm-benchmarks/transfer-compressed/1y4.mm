$c Tw #Symbol zw YQk JAQ pgg rgk #Pattern ( LAQ ewk IAQ 0h4 #Variable SwE PQk #SetVariable 4w #ElementVariable IQE ) $.
$v 4wg CQ qwg 3gg -Bw Bw oAg 5Qg Cw sgg $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Cg $f #Pattern Cw $.
Tg $a #Pattern ( Tw Bw CQ ) $.
4g $a #Pattern ( 4w Bw CQ ) $.
5Q $a zw ( Tw Bw ( Tw CQ Bw ) ) $.
${ 6A $e zw ( Tw Bw CQ ) $.
   6Q $e zw Bw $.
   6g $a zw CQ $. $}
SgE $a #Pattern ( SwE Bw CQ ) $.
${ lgE $e zw ( Tw Bw CQ ) $.
   lwE $e zw ( Tw CQ Cw ) $.
   mAE $a zw ( Tw Bw Cw ) $. $}
${ wAE $e zw ( Tw Bw CQ ) $.
   wQE $e zw ( Tw Bw Cw ) $.
   wgE $a zw ( Tw Bw ( 4w CQ Cw ) ) $. $}
HwQ $a #Pattern ( IAQ Bw CQ ) $.
IgQ $a zw ( SwE ( IAQ Bw CQ ) Bw ) $.
IwQ $a #Pattern ( JAQ Bw ) $.
KwQ $a #Pattern ( LAQ Bw CQ Cw ) $.
nwg $f #Pattern oAg $.
pQg $a #Pattern pgg $.
qgg $f #Pattern qwg $.
sQg $f #Pattern sgg $.
3Qg $f #ElementVariable 3gg $.
4gg $f #ElementVariable 4wg $.
5Ag $f #ElementVariable 5Qg $.
.gg $a zw ( Tw ( 4w ( 4w ( JAQ oAg ) ( JAQ qwg ) ) ( SwE sgg oAg ) ) ( SwE ( LAQ oAg qwg sgg ) qwg ) ) $.
PAk $a #Pattern PQk $.
rQk $a #Pattern rgk $.
.xw $f #ElementVariable -Bw $.
0R4 $a #Pattern 0h4 $.
XiU $a #Pattern 3gg $.
XyU $a #Pattern 4wg $.
2yw $a #Pattern ( 4w ( SwE 5Qg ewk ) ( 4w ( SwE -Bw YQk ) IQE ) ) $.
1i4 $a zw ( Tw ( 4w ( SwE 3gg PQk ) ( 4w ( SwE 4wg pgg ) ( 4w ( SwE 5Qg ewk ) ( 4w ( SwE -Bw YQk ) IQE ) ) ) ) ( 4w ( JAQ rgk ) ( JAQ pgg ) ) ) $.
${ 1y4 $p zw ( Tw ( 4w ( SwE 3gg PQk ) ( 4w ( SwE 4wg pgg ) ( 4w ( SwE 5Qg ewk ) ( 4w ( SwE -Bw YQk ) IQE ) ) ) ) ( SwE ( LAQ rgk pgg ( IAQ rgk 0h4 ) ) pgg ) ) $=
  ( XiU PAk SgE XyU pQg 2yw 4g rQk IwQ 0R4 HwQ KwQ 1i4 Tg 5Q IgQ 6g wgE .gg mAE
  ) AEFGBHIGCDJKKZLMIMKZLNOZLGZKLIUGPIGUEUFUHABCDQUHUEUHRUHUESLNTUAUBLIUGUCUD
  $. $}
