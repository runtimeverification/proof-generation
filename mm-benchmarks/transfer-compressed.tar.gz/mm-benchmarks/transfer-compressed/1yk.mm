$c Uw 2R4 PgE Tw #Symbol zw YQk JAQ pgg rgk #Pattern ( 0wM LAQ ewk tQM IAQ 0h4 #Variable SwE #SetVariable iA 4w rwM #ElementVariable IQE ) cBQ $.
$v th1 yhs Fw CQ Bw Cw 2gg sgg ngg FQ z ph2 Ew ph0 x Lw LQ Ow ph6 qwg DQ XRw ph1 EQ y th2 Dw tAg HQ xX Gw th0 Hw Kw oAg GQ nR4 tgg $.
$d z y $.
$d z x $.
$d y x $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Cg $f #Pattern Cw $.
DA $f #Pattern DQ $.
Dg $f #Pattern Dw $.
EA $f #Pattern EQ $.
Eg $f #Pattern Ew $.
FA $f #Pattern FQ $.
Fg $f #Pattern Fw $.
GA $f #Pattern GQ $.
Gg $f #Pattern Gw $.
HA $f #Pattern HQ $.
Hg $f #Pattern Hw $.
Kg $f #ElementVariable Kw $.
LA $f #ElementVariable LQ $.
Lg $f #ElementVariable Lw $.
Og $f #Variable Ow $.
SA $a #Variable Kw $.
jg $a iA Bw Ow Bw Ow $.
${ kg $e iA CQ DQ Bw Ow $.
   kw $e iA Cw Dw Bw Ow $.
   lA $a iA ( Tw CQ Cw ) ( Tw DQ Dw ) Bw Ow $. $}
4g $a #Pattern ( 4w Bw CQ ) $.
IAE $a #Pattern IQE $.
SgE $a #Pattern ( SwE Bw CQ ) $.
${ lgE $e zw ( Tw Bw CQ ) $.
   lwE $e zw ( Tw CQ Cw ) $.
   mAE $a zw ( Tw Bw Cw ) $. $}
nAE $a zw IQE $.
${ wAE $e zw ( Tw Bw CQ ) $.
   wQE $e zw ( Tw Bw Cw ) $.
   wgE $a zw ( Tw Bw ( 4w CQ Cw ) ) $. $}
${ $d xX ph0 $.
   IQI $a iA Bw Bw CQ Ow $. $}
${ KAI $e iA CQ DQ Bw Ow $.
   KQI $e iA Cw Dw Bw Ow $.
   KgI $a iA ( 4w CQ Cw ) ( 4w DQ Dw ) Bw Ow $. $}
${ OgI $e iA CQ DQ Bw Ow $.
   OwI $e iA Cw Dw Bw Ow $.
   PAI $a iA ( SwE CQ Cw ) ( SwE DQ Dw ) Bw Ow $. $}
${ NwM $e zw CQ $.
   OAM $a zw ( Tw Bw CQ ) $. $}
rgM $a #Pattern ( rwM Bw CQ Kw Cw ) $.
tAM $a #Pattern ( tQM Bw CQ ) $.
0gM $a #Pattern ( 0wM Bw CQ Cw DQ ) $.
HwQ $a #Pattern ( IAQ Bw CQ ) $.
IwQ $a #Pattern ( JAQ Bw ) $.
KwQ $a #Pattern ( LAQ Bw CQ Cw ) $.
${ $d xX y $.
   $d y ph6 $.
   OAQ $e iA Bw DQ Ew Ow $.
   OQQ $e iA CQ Dw Ew Ow $.
   OgQ $e iA Cw EQ Ew Ow $.
   OwQ $a iA ( rwM Bw CQ LQ Cw ) ( rwM DQ Dw LQ EQ ) Ew Ow $. $}
${ QAQ $e iA Bw Cw Dw Ow $.
   QQQ $e iA CQ DQ Dw Ow $.
   QgQ $a iA ( tQM Bw CQ ) ( tQM Cw DQ ) Dw Ow $. $}
${ XgQ $e iA Bw Dw Fw Ow $.
   XwQ $e iA CQ EQ Fw Ow $.
   YAQ $e iA Cw Ew Fw Ow $.
   YQQ $e iA DQ FQ Fw Ow $.
   YgQ $a iA ( 0wM Bw CQ Cw DQ ) ( 0wM Dw EQ Ew FQ ) Fw Ow $. $}
${ $d z ph0 $.
   $d z ph1 $.
   $d z ph2 $.
   $d z y $.
   $d z x $.
   $d z th1 $.
   $d z th2 $.
   $d x ph0 $.
   $d y th0 $.
   lAY $e zw ( Tw GQ ( Uw Kw ( PgE Kw Bw ) ) ) $.
   lQY $e zw ( Tw ( 4w GQ Gw ) CQ ) $.
   lgY $e iA ( Tw HQ Cw ) ( Tw Gw CQ ) Bw LQ $.
   lwY $e iA ( Tw Hw DQ ) ( Tw Gw CQ ) Lw LQ $.
   mAY $a zw ( Tw ( 4w GQ HQ ) Cw ) $. $}
nQg $f #Variable ngg $.
nwg $f #Pattern oAg $.
pQg $a #Pattern pgg $.
qgg $f #Pattern qwg $.
sQg $f #Pattern sgg $.
swg $f #Pattern tAg $.
tQg $f #Pattern tgg $.
2Qg $f #ElementVariable 2gg $.
YAk $a #Pattern YQk $.
egk $a #Pattern ewk $.
rQk $a #Pattern rgk $.
bxQ $a #Pattern ( cBQ oAg qwg ) $.
${ dBQ $e iA qwg tAg oAg ngg $.
   dRQ $e iA sgg tgg oAg ngg $.
   dhQ $a iA ( cBQ qwg sgg ) ( cBQ tAg tgg ) oAg ngg $. $}
yRs $f #ElementVariable yhs $.
XBw $f #ElementVariable XRw $.
nB4 $f #ElementVariable nR4 $.
0R4 $a #Pattern 0h4 $.
2B4 $a #Pattern 2R4 $.
Wh8 $a #Pattern 2gg $.
6h8 $a #Pattern nR4 $.
9h8 $a zw ( Tw ( 4w ( JAQ 2gg ) IQE ) ( 4w ( JAQ 2gg ) IQE ) ) $.
7SA $a #Pattern yhs $.
QCE $a #Pattern XRw $.
QSE $a #Pattern ( 4w ( JAQ 2gg ) ( 4w ( SwE XRw pgg ) IQE ) ) $.
viE $a iA 2gg 2gg nR4 XRw $.
4iM $a zw ( Tw ( 4w ( 4w ( JAQ 2gg ) IQE ) ( 4w ( SwE XRw pgg ) IQE ) ) ( 4w ( JAQ 2gg ) ( 4w ( SwE XRw pgg ) IQE ) ) ) $.
5iM $a iA ( 4w ( SwE nR4 pgg ) IQE ) ( 4w ( SwE XRw pgg ) IQE ) nR4 XRw $.
5yM $a iA YQk YQk nR4 XRw $.
jSY $a #Pattern ( 0wM YQk 2gg yhs ( cBQ ( LAQ ewk pgg ( IAQ ewk 2R4 ) ) XRw ) ) $.
kCY $a zw ( Tw ( 4w ( JAQ 2gg ) ( 4w ( SwE XRw pgg ) IQE ) ) ( tQM 2gg ( rwM YQk 2gg yhs ( 0wM YQk 2gg yhs ( cBQ ( LAQ ewk pgg ( IAQ ewk 2R4 ) ) XRw ) ) ) ) ) $.
kSY $a #Pattern ( 0wM YQk 2gg yhs ( cBQ ( LAQ ewk pgg ( IAQ ewk 2R4 ) ) nR4 ) ) $.
kiY $a iA ( 0wM YQk 2gg yhs ( cBQ ( LAQ ewk pgg ( IAQ ewk 2R4 ) ) nR4 ) ) ( 0wM YQk 2gg yhs ( cBQ ( LAQ ewk pgg ( IAQ ewk 2R4 ) ) XRw ) ) nR4 XRw $.
1Ck $a zw ( Tw ( 4w ( JAQ 2gg ) IQE ) ( Uw yhs ( PgE yhs ( LAQ rgk pgg ( IAQ rgk 0h4 ) ) ) ) ) $.
1ik $a zw ( Tw ( 4w ( JAQ 2gg ) IQE ) ( SwE ( LAQ rgk pgg ( IAQ rgk 0h4 ) ) pgg ) ) $.
${ 1yk $p zw ( Tw ( 4w ( JAQ 2gg ) IQE ) ( tQM 2gg ( rwM YQk 2gg yhs ( 0wM YQk 2gg yhs ( cBQ ( LAQ ewk pgg ( IAQ ewk 2R4 ) ) ( LAQ rgk pgg ( IAQ rgk 0h4 ) ) ) ) ) ) ) $=
  ( XBw nB4 IAE 4g rQk pQg HwQ KwQ SgE YAk egk bxQ rgM tAM wgE mAE IQI OwQ Wh8
  IwQ 0R4 7SA 2B4 0gM 9h8 1ik nAE OAM jSY kSY QCE 6h8 1Ck QSE 4iM kCY SA jg PAI
  KgI dhQ YgQ QgQ lA 5iM viE 5yM kiY mAY ) AUAZUBEFZVMGHGUCIJZHKZEFZFVLLVLLVLBU
  DZMHMUEIJZVNNZUFZBOZPZVMVMVPAUGVMVOEAUHVMEUIUJQQVNVLLVLABCUKZBOZPZWBVLLVLABDU
  LZBOZPZVMCUMZHKZEFZVPDUNZHKEFZBCDABUOVMWKFACUPWEACUQABCURRVNVPWBWKWECUSZVNVOE
  WJEWNVNVNHWIHWNVNWNUTZHVNWNSVAEVNWNSVBVLWAVLWDVNWNVLVNWNSZLVLVTLVLWCVNBWNLVNW
  NSZWPLVLVQVSLVLVQVRWINVNWNWQWPVQVNWNSWNVNVRVNVRWIVRVNWNSWOVCVDTVEVFWLWMWHWKWE
  WNCDVGVLWGVLWDWLWNACDVHZLVLWFLVLWCWLBWNCDVIWRABCDVJTVEVFVKR $. $}
