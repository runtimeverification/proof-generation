$c 1wk Tw #Symbol zw JAQ pgg #Pattern ( 0wM LAQ tQM #Variable SwE #SetVariable 4w rwM #ElementVariable IQE ) $.
$v yhs CQ zBs Bw Kw Cw 2gg $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Cg $f #Pattern Cw $.
Kg $f #ElementVariable Kw $.
4g $a #Pattern ( 4w Bw CQ ) $.
IAE $a #Pattern IQE $.
SgE $a #Pattern ( SwE Bw CQ ) $.
${ lgE $e zw ( Tw Bw CQ ) $.
   lwE $e zw ( Tw CQ Cw ) $.
   mAE $a zw ( Tw Bw Cw ) $. $}
rgM $a #Pattern ( rwM Bw CQ Kw Cw ) $.
tAM $a #Pattern ( tQM Bw CQ ) $.
IwQ $a #Pattern ( JAQ Bw ) $.
pQg $a #Pattern pgg $.
2Qg $f #ElementVariable 2gg $.
1gk $a #Pattern 1wk $.
yRs $f #ElementVariable yhs $.
yxs $f #ElementVariable zBs $.
9Rs $a zw ( Tw ( 4w ( JAQ 2gg ) ( 4w ( SwE zBs 1wk ) IQE ) ) ( tQM 2gg ( rwM pgg 2gg yhs ( 0wM pgg 2gg yhs ( LAQ 1wk pgg zBs ) ) ) ) ) $.
Wh8 $a #Pattern 2gg $.
JiE $a #Pattern zBs $.
0iM $a zw ( Tw ( 4w ( 4w ( JAQ 2gg ) IQE ) ( 4w ( SwE zBs 1wk ) IQE ) ) ( 4w ( JAQ 2gg ) ( 4w ( SwE zBs 1wk ) IQE ) ) ) $.
0yM $a #Pattern ( 4w ( JAQ 2gg ) ( 4w ( SwE zBs 1wk ) IQE ) ) $.
1CM $a #Pattern ( 0wM pgg 2gg yhs ( LAQ 1wk pgg zBs ) ) $.
${ 1SM $p zw ( Tw ( 4w ( 4w ( JAQ 2gg ) IQE ) ( 4w ( SwE zBs 1wk ) IQE ) ) ( tQM 2gg ( rwM pgg 2gg yhs ( 0wM pgg 2gg yhs ( LAQ 1wk pgg zBs ) ) ) ) ) $=
  ( Wh8 IwQ IAE 4g JiE 1gk SgE 0yM pQg 1CM rgM tAM 0iM 9Rs mAE ) ADZEFGCHIJFGGA
  CKSLSABCMBNOACPABCQR $. $}
