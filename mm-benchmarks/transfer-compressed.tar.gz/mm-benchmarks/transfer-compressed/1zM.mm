$c zBA 2R4 Tw #Symbol 7h4 zw JAQ pgg #Pattern ( LAQ ewk IAQ Wgk #Variable SwE #SetVariable 4w #ElementVariable IQE mwg ) $.
$v 7Ag CQ qwg Bw oAg Cw 2gg $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Cg $f #Pattern Cw $.
4g $a #Pattern ( 4w Bw CQ ) $.
SgE $a #Pattern ( SwE Bw CQ ) $.
${ lgE $e zw ( Tw Bw CQ ) $.
   lwE $e zw ( Tw CQ Cw ) $.
   mAE $a zw ( Tw Bw Cw ) $. $}
${ wAE $e zw ( Tw Bw CQ ) $.
   wQE $e zw ( Tw Bw Cw ) $.
   wgE $a zw ( Tw Bw ( 4w CQ Cw ) ) $. $}
HwQ $a #Pattern ( IAQ Bw CQ ) $.
IwQ $a #Pattern ( JAQ Bw ) $.
KwQ $a #Pattern ( LAQ Bw CQ Cw ) $.
nwg $f #Pattern oAg $.
pQg $a #Pattern pgg $.
qgg $f #Pattern qwg $.
2Qg $f #ElementVariable 2gg $.
6wg $f #ElementVariable 7Ag $.
WQk $a #Pattern Wgk $.
egk $a #Pattern ewk $.
yxA $a #Pattern ( zBA oAg qwg ) $.
2BA $a zw ( Tw ( 4w ( SwE oAg Wgk ) ( SwE qwg Wgk ) ) ( SwE ( zBA oAg qwg ) Wgk ) ) $.
2B4 $a #Pattern 2R4 $.
7R4 $a #Pattern 7h4 $.
pyQ $a #Pattern ( 4w ( JAQ 2gg ) ( 4w ( SwE 7Ag mwg ) IQE ) ) $.
zSQ $a zw ( Tw ( 4w ( JAQ 2gg ) ( 4w ( SwE 7Ag mwg ) IQE ) ) ( SwE ( LAQ ewk Wgk ( IAQ ewk 2R4 ) ) Wgk ) ) $.
0yQ $a zw ( Tw ( 4w ( JAQ 2gg ) ( 4w ( SwE 7Ag mwg ) IQE ) ) ( SwE ( LAQ ewk Wgk ( IAQ ewk 7h4 ) ) Wgk ) ) $.
EzI $a zw ( Tw ( 4w ( JAQ 2gg ) ( 4w ( SwE 7Ag mwg ) IQE ) ) ( 4w ( JAQ Wgk ) ( JAQ pgg ) ) ) $.
${ 1zM $p zw ( Tw ( 4w ( JAQ 2gg ) ( 4w ( SwE 7Ag mwg ) IQE ) ) ( 4w ( 4w ( JAQ Wgk ) ( JAQ pgg ) ) ( SwE ( zBA ( LAQ ewk Wgk ( IAQ ewk 7h4 ) ) ( LAQ ewk Wgk ( IAQ ewk 2R4 ) ) ) Wgk ) ) ) $=
  ( pyQ WQk IwQ pQg 4g egk 7R4 HwQ KwQ 2B4 yxA SgE EzI 0yQ zSQ wgE 2BA mAE ) AB
  CZDEFEGHDHIJKZHDHLJKZMDNZABOUAUBDNZUCDNZGUDUAUEUFABPABQRUBUCSTR $. $}
