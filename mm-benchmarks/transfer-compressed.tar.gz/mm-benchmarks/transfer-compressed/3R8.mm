$c #SetVariable iA ) JAQ #ElementVariable #Symbol #Variable #Pattern ( $.
$v Ow CQ xX ph2 Bw Kw ph1 ph0 Cw 0R8 x 6xw $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Cg $f #Pattern Cw $.
Kg $f #ElementVariable Kw $.
Og $f #Variable Ow $.
SA $a #Variable Kw $.
jg $a iA Bw Ow Bw Ow $.
${ $d x ph0 $.
   $d x ph1 $.
   $d x ph2 $.
   $d x xX $.
   mAQ $e iA Bw CQ Cw Ow $.
   mQQ $a iA ( JAQ Bw ) ( JAQ CQ ) Cw Ow $. $}
6hw $f #ElementVariable 6xw $.
dB8 $a #Pattern 6xw $.
0B8 $f #ElementVariable 0R8 $.
1h8 $a #Pattern 0R8 $.
${ 3R8 $p iA ( JAQ 0R8 ) ( JAQ 6xw ) 0R8 6xw $=
  ( 1h8 dB8 SA jg mQQ ) BCZADHAEZHIFG $. $}
