$c #Symbol Tw #Variable SwE #SetVariable hgk zw 4w pwk #ElementVariable IQE #Pattern ) ( $.
$v 5Qg Cw CQ -Bw Bw $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Cg $f #Pattern Cw $.
4g $a #Pattern ( 4w Bw CQ ) $.
IAE $a #Pattern IQE $.
SgE $a #Pattern ( SwE Bw CQ ) $.
lQE $a zw ( Tw Bw Bw ) $.
${ lgE $e zw ( Tw Bw CQ ) $.
   lwE $e zw ( Tw CQ Cw ) $.
   mAE $a zw ( Tw Bw Cw ) $. $}
ugE $a zw ( Tw ( 4w Bw CQ ) Bw ) $.
5Ag $f #ElementVariable 5Qg $.
hQk $a #Pattern hgk $.
pgk $a #Pattern pwk $.
.xw $f #ElementVariable -Bw $.
YCU $a #Pattern 5Qg $.
yyg $a #Pattern -Bw $.
${ -So $p zw ( Tw ( 4w ( 4w ( SwE -Bw hgk ) IQE ) ( 4w ( SwE 5Qg pwk ) IQE ) ) ( SwE -Bw hgk ) ) $=
  ( yyg hQk SgE IAE 4g YCU pgk ugE lQE mAE ) BCDEZFGZAHIEFGZGNMNOJNMMMFJMKLL $. $}
