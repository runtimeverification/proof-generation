$c 2R4 zBA XBI Tw #Symbol 7h4 DBE zw pgg #Pattern ( LAQ ewk IAQ Wgk #Variable SwE PQk #SetVariable vR4 4w #ElementVariable IQE 8wk ) $.
$v 4wg CQ qwg -Bw Bw oAg 5Qg Cw $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Cg $f #Pattern Cw $.
Tg $a #Pattern ( Tw Bw CQ ) $.
4g $a #Pattern ( 4w Bw CQ ) $.
5Q $a zw ( Tw Bw ( Tw CQ Bw ) ) $.
${ 6A $e zw ( Tw Bw CQ ) $.
   6Q $e zw Bw $.
   6g $a zw CQ $. $}
SgE $a #Pattern ( SwE Bw CQ ) $.
${ lgE $e zw ( Tw Bw CQ ) $.
   lwE $e zw ( Tw CQ Cw ) $.
   mAE $a zw ( Tw Bw Cw ) $. $}
${ wAE $e zw ( Tw Bw CQ ) $.
   wQE $e zw ( Tw Bw Cw ) $.
   wgE $a zw ( Tw Bw ( 4w CQ Cw ) ) $. $}
HwQ $a #Pattern ( IAQ Bw CQ ) $.
IgQ $a zw ( SwE ( IAQ Bw CQ ) Bw ) $.
KwQ $a #Pattern ( LAQ Bw CQ Cw ) $.
nwg $f #Pattern oAg $.
qgg $f #Pattern qwg $.
4gg $f #ElementVariable 4wg $.
5Ag $f #ElementVariable 5Qg $.
PAk $a #Pattern PQk $.
WQk $a #Pattern Wgk $.
egk $a #Pattern ewk $.
8gk $a #Pattern 8wk $.
yxA $a #Pattern ( zBA oAg qwg ) $.
CxE $a #Pattern ( DBE oAg qwg ) $.
WxI $a #Pattern ( XBI oAg qwg ) $.
aBI $a zw ( Tw ( 4w ( SwE oAg ewk ) ( SwE qwg Wgk ) ) ( SwE ( XBI oAg qwg ) 8wk ) ) $.
.xw $f #ElementVariable -Bw $.
vB4 $a #Pattern vR4 $.
2B4 $a #Pattern 2R4 $.
7R4 $a #Pattern 7h4 $.
XyU $a #Pattern 4wg $.
pC0 $a #Pattern ( 4w ( SwE 5Qg Wgk ) ( 4w ( SwE -Bw pgg ) IQE ) ) $.
1C0 $a zw ( Tw ( 4w ( SwE 4wg PQk ) ( 4w ( SwE 5Qg Wgk ) ( 4w ( SwE -Bw pgg ) IQE ) ) ) ( SwE ( DBE ( LAQ ewk Wgk ( IAQ ewk vR4 ) ) ( LAQ ewk Wgk ( IAQ ewk 2R4 ) ) ) Wgk ) ) $.
1i0 $a zw ( Tw ( 4w ( SwE 4wg PQk ) ( 4w ( SwE 5Qg Wgk ) ( 4w ( SwE -Bw pgg ) IQE ) ) ) ( SwE ( zBA ( LAQ ewk Wgk ( IAQ ewk 7h4 ) ) ( LAQ ewk Wgk ( IAQ ewk 2R4 ) ) ) Wgk ) ) $.
${ 1y0 $p zw ( Tw ( 4w ( SwE 4wg PQk ) ( 4w ( SwE 5Qg Wgk ) ( 4w ( SwE -Bw pgg ) IQE ) ) ) ( 4w ( SwE ( XBI ( IAQ ewk vR4 ) ( DBE ( LAQ ewk Wgk ( IAQ ewk vR4 ) ) ( LAQ ewk Wgk ( IAQ ewk 2R4 ) ) ) ) 8wk ) ( SwE ( XBI ( IAQ ewk 7h4 ) ( zBA ( LAQ ewk Wgk ( IAQ ewk 7h4 ) ) ( LAQ ewk Wgk ( IAQ ewk 2R4 ) ) ) ) 8wk ) ) ) $=
  ( SgE 4g egk vB4 HwQ WQk KwQ WxI 8gk 7R4 Tg 5Q IgQ 6g wgE aBI mAE XyU PAk pC0
  2B4 CxE yxA 1C0 1i0 ) AUAUBDBCUCEZFGHZFIUJJFIFUDHJZUEZKLDZFMHZFIUNJUKUFZKLDZU
  IUJFDZULIDZEUMUIUQURUQUIUQNUQUIOFGPQABCUGRUJULSTUIUNFDZUOIDZEUPUIUSUTUSUIUSNU
  SUIOFMPQABCUHRUNUOSTR $. $}
