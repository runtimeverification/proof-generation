$c 0wM 1wk #Symbol #Variable #SetVariable GBY iA #ElementVariable #Pattern ) ( $.
$v yhs Fw Ow CQ FQ DQ Ew XRw Kw Bw Cw 2gg nR4 EQ -Rs Dw $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Cg $f #Pattern Cw $.
DA $f #Pattern DQ $.
Dg $f #Pattern Dw $.
EA $f #Pattern EQ $.
Eg $f #Pattern Ew $.
FA $f #Pattern FQ $.
Fg $f #Pattern Fw $.
Kg $f #ElementVariable Kw $.
Og $f #Variable Ow $.
SA $a #Variable Kw $.
${ XgQ $e iA Bw Dw Fw Ow $.
   XwQ $e iA CQ EQ Fw Ow $.
   YAQ $e iA Cw Ew Fw Ow $.
   YQQ $e iA DQ FQ Fw Ow $.
   YgQ $a iA ( 0wM Bw CQ Cw DQ ) ( 0wM Dw EQ Ew FQ ) Fw Ow $. $}
2Qg $f #ElementVariable 2gg $.
1gk $a #Pattern 1wk $.
yRs $f #ElementVariable yhs $.
-Bs $f #ElementVariable -Rs $.
XBw $f #ElementVariable XRw $.
nB4 $f #ElementVariable nR4 $.
Wh8 $a #Pattern 2gg $.
6h8 $a #Pattern nR4 $.
7SA $a #Pattern yhs $.
UyE $a iA 2gg 2gg nR4 -Rs $.
VSE $a iA yhs yhs nR4 -Rs $.
9SE $a #Pattern ( GBY -Rs XRw ) $.
.CE $a #Pattern ( GBY nR4 XRw ) $.
-CE $a iA 1wk 1wk nR4 -Rs $.
-SE $a iA ( GBY nR4 XRw ) ( GBY -Rs XRw ) nR4 -Rs $.
${ -iE $p iA ( 0wM 1wk 2gg yhs ( GBY nR4 XRw ) ) ( 0wM 1wk 2gg yhs ( GBY -Rs XRw ) ) nR4 -Rs $=
  ( 1gk Wh8 7SA .CE 9SE 6h8 SA -CE UyE VSE -SE YgQ ) FAGZBHZDEIFRSCDJEKCLCEMACE
  NBCEOCDEPQ $. $}
