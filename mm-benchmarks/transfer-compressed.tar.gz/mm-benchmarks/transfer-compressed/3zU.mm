$c LAQ IAQ Tw #Symbol #Variable 1CA SwE #SetVariable 3gk zw 4w JAQ #ElementVariable IQE rgk #Pattern ) ( $.
$v CQ qwg Bw oAg Cw 2gg sgg $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Cg $f #Pattern Cw $.
4g $a #Pattern ( 4w Bw CQ ) $.
IAE $a #Pattern IQE $.
SgE $a #Pattern ( SwE Bw CQ ) $.
${ lgE $e zw ( Tw Bw CQ ) $.
   lwE $e zw ( Tw CQ Cw ) $.
   mAE $a zw ( Tw Bw Cw ) $. $}
HwQ $a #Pattern ( IAQ Bw CQ ) $.
IwQ $a #Pattern ( JAQ Bw ) $.
KwQ $a #Pattern ( LAQ Bw CQ Cw ) $.
nwg $f #Pattern oAg $.
qgg $f #Pattern qwg $.
sQg $f #Pattern sgg $.
2Qg $f #ElementVariable 2gg $.
.gg $a zw ( Tw ( 4w ( 4w ( JAQ oAg ) ( JAQ qwg ) ) ( SwE sgg oAg ) ) ( SwE ( LAQ oAg qwg sgg ) qwg ) ) $.
rQk $a #Pattern rgk $.
3Qk $a #Pattern 3gk $.
Wh8 $a #Pattern 2gg $.
0yA $a #Pattern 1CA $.
3jU $a zw ( Tw ( 4w ( JAQ 2gg ) IQE ) ( 4w ( 4w ( JAQ rgk ) ( JAQ 3gk ) ) ( SwE ( IAQ rgk 1CA ) rgk ) ) ) $.
${ 3zU $p zw ( Tw ( 4w ( JAQ 2gg ) IQE ) ( SwE ( LAQ rgk 3gk ( IAQ rgk 1CA ) ) 3gk ) ) $=
  ( Wh8 IwQ IAE 4g rQk 3Qk 0yA HwQ SgE KwQ 3jU .gg mAE ) ABCDEFCGCEFHIZFJEFGOKG
  JALFGOMN $. $}
