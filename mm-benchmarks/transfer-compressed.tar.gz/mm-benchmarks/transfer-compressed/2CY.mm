$c #SetVariable iA ) YQk #ElementVariable #Symbol #Variable #Pattern ( $.
$v Ow CQ xX Bw Kw ph0 nR4 pxw $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Kg $f #ElementVariable Kw $.
Og $f #Variable Ow $.
SA $a #Variable Kw $.
${ $d xX ph0 $.
   IQI $a iA Bw Bw CQ Ow $. $}
YAk $a #Pattern YQk $.
phw $f #ElementVariable pxw $.
nB4 $f #ElementVariable nR4 $.
6h8 $a #Pattern nR4 $.
${ 2CY $p iA YQk YQk nR4 pxw $=
  ( YAk 6h8 SA IQI ) CBDAEF $. $}
