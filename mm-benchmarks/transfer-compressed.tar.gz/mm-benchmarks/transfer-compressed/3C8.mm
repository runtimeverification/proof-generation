$c Tw #Symbol #Variable SwE PQk #SetVariable hgk zw 4w pwk #ElementVariable IQE mwg pgg #Pattern ) ( $.
$v 4wg CQ 3gg -Bw Bw 5Qg MB0 Cw $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Cg $f #Pattern Cw $.
4g $a #Pattern ( 4w Bw CQ ) $.
IAE $a #Pattern IQE $.
SgE $a #Pattern ( SwE Bw CQ ) $.
${ wAE $e zw ( Tw Bw CQ ) $.
   wQE $e zw ( Tw Bw Cw ) $.
   wgE $a zw ( Tw Bw ( 4w CQ Cw ) ) $. $}
mgg $a #Pattern mwg $.
pQg $a #Pattern pgg $.
3Qg $f #ElementVariable 3gg $.
4gg $f #ElementVariable 4wg $.
5Ag $f #ElementVariable 5Qg $.
PAk $a #Pattern PQk $.
hQk $a #Pattern hgk $.
pgk $a #Pattern pwk $.
.xw $f #ElementVariable -Bw $.
Lx0 $f #ElementVariable MB0 $.
XiU $a #Pattern 3gg $.
XyU $a #Pattern 4wg $.
YCU $a #Pattern 5Qg $.
yyg $a #Pattern -Bw $.
qy8 $a #Pattern MB0 $.
rC8 $a #Pattern ( 4w ( SwE -Bw pgg ) ( 4w ( SwE MB0 hgk ) IQE ) ) $.
tC8 $a zw ( Tw ( 4w ( SwE 3gg mwg ) ( 4w ( SwE 4wg PQk ) ( 4w ( SwE 5Qg pwk ) ( 4w ( SwE -Bw pgg ) ( 4w ( SwE MB0 hgk ) IQE ) ) ) ) ) ( SwE -Bw pgg ) ) $.
2y8 $a zw ( Tw ( 4w ( SwE 3gg mwg ) ( 4w ( SwE 4wg PQk ) ( 4w ( SwE 5Qg pwk ) ( 4w ( SwE -Bw pgg ) ( 4w ( SwE MB0 hgk ) IQE ) ) ) ) ) ( 4w ( SwE MB0 hgk ) IQE ) ) $.
${ 3C8 $p zw ( Tw ( 4w ( SwE 3gg mwg ) ( 4w ( SwE 4wg PQk ) ( 4w ( SwE 5Qg pwk ) ( 4w ( SwE -Bw pgg ) ( 4w ( SwE MB0 hgk ) IQE ) ) ) ) ) ( 4w ( SwE -Bw pgg ) ( 4w ( SwE MB0 hgk ) IQE ) ) ) $=
  ( XiU mgg SgE XyU PAk YCU pgk rC8 4g yyg pQg qy8 hQk IAE tC8 2y8 wgE ) AFGHBI
  JHCKLHDEMNNNDOPHEQRHSNABCDETABCDEUAUB $. $}
