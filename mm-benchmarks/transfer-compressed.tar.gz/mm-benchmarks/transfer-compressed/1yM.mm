$c #SetVariable iA ) 1wk #ElementVariable #Symbol #Variable #Pattern ( $.
$v Ow CQ xX zBs Bw Kw ph0 nR4 $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Kg $f #ElementVariable Kw $.
Og $f #Variable Ow $.
SA $a #Variable Kw $.
${ $d xX ph0 $.
   IQI $a iA Bw Bw CQ Ow $. $}
1gk $a #Pattern 1wk $.
yxs $f #ElementVariable zBs $.
nB4 $f #ElementVariable nR4 $.
6h8 $a #Pattern nR4 $.
${ 1yM $p iA 1wk 1wk nR4 zBs $=
  ( 1gk 6h8 SA IQI ) CBDAEF $. $}
