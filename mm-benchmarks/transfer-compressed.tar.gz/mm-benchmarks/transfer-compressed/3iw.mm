$c ewk #Symbol Tw #Variable SwE #SetVariable zw 4w YQk #ElementVariable IQE #Pattern ) ( $.
$v 5Qg Cw CQ -Bw Bw $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Cg $f #Pattern Cw $.
4g $a #Pattern ( 4w Bw CQ ) $.
IAE $a #Pattern IQE $.
SgE $a #Pattern ( SwE Bw CQ ) $.
lQE $a zw ( Tw Bw Bw ) $.
${ lgE $e zw ( Tw Bw CQ ) $.
   lwE $e zw ( Tw CQ Cw ) $.
   mAE $a zw ( Tw Bw Cw ) $. $}
ugE $a zw ( Tw ( 4w Bw CQ ) Bw ) $.
5Ag $f #ElementVariable 5Qg $.
YAk $a #Pattern YQk $.
egk $a #Pattern ewk $.
.xw $f #ElementVariable -Bw $.
YCU $a #Pattern 5Qg $.
yyg $a #Pattern -Bw $.
2yw $a #Pattern ( 4w ( SwE 5Qg ewk ) ( 4w ( SwE -Bw YQk ) IQE ) ) $.
${ 3iw $p zw ( Tw ( 4w ( SwE 5Qg ewk ) ( 4w ( SwE -Bw YQk ) IQE ) ) ( SwE 5Qg ewk ) ) $=
  ( 2yw YCU egk SgE yyg YAk IAE 4g ugE lQE mAE ) ABCADEFZNNBGHFIJKNLM $. $}
