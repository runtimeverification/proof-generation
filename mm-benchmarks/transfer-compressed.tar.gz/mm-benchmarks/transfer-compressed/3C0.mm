$c Wgk #Symbol Tw #Variable SwE PQk #SetVariable zw 4w #ElementVariable IQE pgg #Pattern ) ( $.
$v 4wg CQ -Bw Bw 5Qg Cw $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Cg $f #Pattern Cw $.
4g $a #Pattern ( 4w Bw CQ ) $.
IAE $a #Pattern IQE $.
SgE $a #Pattern ( SwE Bw CQ ) $.
${ lgE $e zw ( Tw Bw CQ ) $.
   lwE $e zw ( Tw CQ Cw ) $.
   mAE $a zw ( Tw Bw Cw ) $. $}
nAE $a zw IQE $.
ugE $a zw ( Tw ( 4w Bw CQ ) Bw ) $.
${ wAE $e zw ( Tw Bw CQ ) $.
   wQE $e zw ( Tw Bw Cw ) $.
   wgE $a zw ( Tw Bw ( 4w CQ Cw ) ) $. $}
${ NwM $e zw CQ $.
   OAM $a zw ( Tw Bw CQ ) $. $}
pQg $a #Pattern pgg $.
4gg $f #ElementVariable 4wg $.
5Ag $f #ElementVariable 5Qg $.
PAk $a #Pattern PQk $.
WQk $a #Pattern Wgk $.
.xw $f #ElementVariable -Bw $.
XyU $a #Pattern 4wg $.
YCU $a #Pattern 5Qg $.
yyg $a #Pattern -Bw $.
pC0 $a #Pattern ( 4w ( SwE 5Qg Wgk ) ( 4w ( SwE -Bw pgg ) IQE ) ) $.
py0 $a zw ( Tw ( 4w ( SwE 5Qg Wgk ) ( 4w ( SwE -Bw pgg ) IQE ) ) ( SwE 5Qg Wgk ) ) $.
qy0 $a zw ( Tw ( 4w ( SwE 5Qg Wgk ) ( 4w ( SwE -Bw pgg ) IQE ) ) ( SwE -Bw pgg ) ) $.
${ 3C0 $p zw ( Tw ( 4w ( 4w ( SwE 5Qg Wgk ) ( 4w ( SwE -Bw pgg ) IQE ) ) ( 4w ( SwE 4wg PQk ) IQE ) ) ( 4w ( SwE 5Qg Wgk ) ( 4w ( SwE -Bw pgg ) IQE ) ) ) $=
  ( pC0 XyU PAk SgE IAE 4g YCU WQk yyg pQg ugE py0 mAE qy0 nAE OAM wgE ) BCDZAE
  FGHIZIZBJKGZCLMGZHIUCUAUDUAUBNZBCOPUCUEHUCUAUEUFBCQPUCHRSTT $. $}
