$c #SetVariable cwE iA ) #ElementVariable #Symbol #Variable pgg #Pattern ( $.
$v Ow CQ xX Bw Kw ph0 2gg Pw $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Kg $f #ElementVariable Kw $.
Og $f #Variable Ow $.
Pg $f #Symbol Pw $.
SA $a #Variable Kw $.
Sw $a #Pattern Pw $.
cgE $a #Symbol cwE $.
${ $d xX ph0 $.
   IQI $a iA Bw Bw CQ Ow $. $}
pQg $a #Pattern pgg $.
2Qg $f #ElementVariable 2gg $.
${ -h8 $p iA pgg pgg cwE 2gg $=
  ( pQg cgE Sw SA IQI ) BCDAEF $. $}
