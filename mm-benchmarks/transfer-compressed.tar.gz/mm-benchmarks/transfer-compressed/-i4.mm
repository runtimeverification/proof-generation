$c LAQ IAQ Wgk Tw #Symbol #Variable SwE pgg #SetVariable 5x4 zw 4w JAQ #ElementVariable IQE rgk #Pattern ) ( $.
$v CQ qwg -Bw Bw oAg Cw sgg $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Cg $f #Pattern Cw $.
4g $a #Pattern ( 4w Bw CQ ) $.
IAE $a #Pattern IQE $.
SgE $a #Pattern ( SwE Bw CQ ) $.
${ lgE $e zw ( Tw Bw CQ ) $.
   lwE $e zw ( Tw CQ Cw ) $.
   mAE $a zw ( Tw Bw Cw ) $. $}
HwQ $a #Pattern ( IAQ Bw CQ ) $.
IwQ $a #Pattern ( JAQ Bw ) $.
KwQ $a #Pattern ( LAQ Bw CQ Cw ) $.
nwg $f #Pattern oAg $.
pQg $a #Pattern pgg $.
qgg $f #Pattern qwg $.
sQg $f #Pattern sgg $.
.gg $a zw ( Tw ( 4w ( 4w ( JAQ oAg ) ( JAQ qwg ) ) ( SwE sgg oAg ) ) ( SwE ( LAQ oAg qwg sgg ) qwg ) ) $.
WQk $a #Pattern Wgk $.
rQk $a #Pattern rgk $.
.xw $f #ElementVariable -Bw $.
5h4 $a #Pattern 5x4 $.
yyg $a #Pattern -Bw $.
-S4 $a zw ( Tw ( 4w ( SwE -Bw pgg ) IQE ) ( 4w ( 4w ( JAQ rgk ) ( JAQ Wgk ) ) ( SwE ( IAQ rgk 5x4 ) rgk ) ) ) $.
${ -i4 $p zw ( Tw ( 4w ( SwE -Bw pgg ) IQE ) ( SwE ( LAQ rgk Wgk ( IAQ rgk 5x4 ) ) Wgk ) ) $=
  ( yyg pQg SgE IAE 4g rQk IwQ WQk 5h4 HwQ KwQ -S4 .gg mAE ) ABCDEFGHIHFGJKZGDF
  GIPLIDAMGIPNO $. $}
