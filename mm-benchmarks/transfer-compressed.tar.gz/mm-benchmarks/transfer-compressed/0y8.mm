$c rwg LAQ Hg8 #Symbol #Variable 0hU #SetVariable ) #ElementVariable 8wk pgg #Pattern 0Q4 ( $.
$v 4wg CQ qwg 3gg Bw oAg 5Qg MB0 Cw nR4 $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Cg $f #Pattern Cw $.
KwQ $a #Pattern ( LAQ Bw CQ Cw ) $.
nwg $f #Pattern oAg $.
pQg $a #Pattern pgg $.
qgg $f #Pattern qwg $.
rgg $a #Pattern ( rwg oAg qwg ) $.
3Qg $f #ElementVariable 3gg $.
4gg $f #ElementVariable 4wg $.
5Ag $f #ElementVariable 5Qg $.
8gk $a #Pattern 8wk $.
0A4 $a #Pattern ( 0Q4 oAg qwg ) $.
HQ8 $a #Pattern ( Hg8 oAg ) $.
Lx0 $f #ElementVariable MB0 $.
nB4 $f #ElementVariable nR4 $.
XiU $a #Pattern 3gg $.
XyU $a #Pattern 4wg $.
0i8 $a #Pattern ( 0hU 5Qg nR4 MB0 ) $.
${ 0y8 $p #Pattern ( 0Q4 ( Hg8 ( rwg ( LAQ 8wk pgg ( 0hU 5Qg nR4 MB0 ) ) 3gg ) ) 4wg ) $=
  ( 8gk pQg 0i8 KwQ XiU rgg HQ8 XyU 0A4 ) FGCDEHIAJKLBMN $. $}
