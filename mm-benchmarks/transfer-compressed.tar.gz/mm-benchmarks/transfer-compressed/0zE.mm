$c rwg LAQ Wgk #Symbol #Variable #SetVariable iA #ElementVariable pgg #Pattern xQg ) ( $.
$v ngg CQ qwg 3gg Bw Kw oAg Cw nR4 sgg tAg tgg $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Cg $f #Pattern Cw $.
Kg $f #ElementVariable Kw $.
SA $a #Variable Kw $.
KwQ $a #Pattern ( LAQ Bw CQ Cw ) $.
nQg $f #Variable ngg $.
nwg $f #Pattern oAg $.
pQg $a #Pattern pgg $.
qgg $f #Pattern qwg $.
sQg $f #Pattern sgg $.
swg $f #Pattern tAg $.
tQg $f #Pattern tgg $.
${ uQg $e iA qwg tAg oAg ngg $.
   ugg $e iA sgg tgg oAg ngg $.
   uwg $a iA ( rwg qwg sgg ) ( rwg tAg tgg ) oAg ngg $. $}
xAg $a #Pattern xQg $.
3Qg $f #ElementVariable 3gg $.
WQk $a #Pattern Wgk $.
nB4 $f #ElementVariable nR4 $.
6h8 $a #Pattern nR4 $.
XiU $a #Pattern 3gg $.
mSU $a iA xQg xQg nR4 3gg $.
0jE $a iA ( LAQ Wgk pgg nR4 ) ( LAQ Wgk pgg 3gg ) nR4 3gg $.
${ 0zE $p iA ( rwg ( LAQ Wgk pgg nR4 ) xQg ) ( rwg ( LAQ Wgk pgg 3gg ) xQg ) nR4 3gg $=
  ( SA 6h8 WQk pQg KwQ xAg XiU 0jE mSU uwg ) ACBDZEFMGHEFAIGHABJABKL $. $}
