$c rwg LAQ #Symbol #Variable 0hU #SetVariable iA #ElementVariable 8wk pgg #Pattern ) ( $.
$v ngg CQ qwg 3gg Bw Kw oAg 5Qg MB0 Cw nR4 sgg tAg tgg 4Ag $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Cg $f #Pattern Cw $.
Kg $f #ElementVariable Kw $.
SA $a #Variable Kw $.
KwQ $a #Pattern ( LAQ Bw CQ Cw ) $.
nQg $f #Variable ngg $.
nwg $f #Pattern oAg $.
pQg $a #Pattern pgg $.
qgg $f #Pattern qwg $.
sQg $f #Pattern sgg $.
swg $f #Pattern tAg $.
tQg $f #Pattern tgg $.
${ uQg $e iA qwg tAg oAg ngg $.
   ugg $e iA sgg tgg oAg ngg $.
   uwg $a iA ( rwg qwg sgg ) ( rwg tAg tgg ) oAg ngg $. $}
3Qg $f #ElementVariable 3gg $.
3wg $f #ElementVariable 4Ag $.
5Ag $f #ElementVariable 5Qg $.
8gk $a #Pattern 8wk $.
Lx0 $f #ElementVariable MB0 $.
nB4 $f #ElementVariable nR4 $.
6h8 $a #Pattern nR4 $.
XiU $a #Pattern 3gg $.
qio $a iA 3gg 3gg nR4 4Ag $.
wS8 $a #Pattern ( 0hU 5Qg 4Ag MB0 ) $.
0i8 $a #Pattern ( 0hU 5Qg nR4 MB0 ) $.
1y8 $a iA ( LAQ 8wk pgg ( 0hU 5Qg nR4 MB0 ) ) ( LAQ 8wk pgg ( 0hU 5Qg 4Ag MB0 ) ) nR4 4Ag $.
${ 2C8 $p iA ( rwg ( LAQ 8wk pgg ( 0hU 5Qg nR4 MB0 ) ) 3gg ) ( rwg ( LAQ 8wk pgg ( 0hU 5Qg 4Ag MB0 ) ) 3gg ) nR4 4Ag $=
  ( SA 6h8 8gk pQg 0i8 KwQ XiU wS8 1y8 qio uwg ) BFEGHICDEJKALZHIBCDMKQBCDENABE
  OP $. $}
