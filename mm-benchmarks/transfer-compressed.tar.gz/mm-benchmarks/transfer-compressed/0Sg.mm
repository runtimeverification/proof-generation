$c ewk Tw #Symbol #Variable SwE #SetVariable zw 4w YQk #ElementVariable IQE mwg rgk pgg #Pattern ) ( $.
$v 4wg CQ 3gg -Bw Bw 5Qg Cw 4Ag $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Cg $f #Pattern Cw $.
4g $a #Pattern ( 4w Bw CQ ) $.
SgE $a #Pattern ( SwE Bw CQ ) $.
${ lgE $e zw ( Tw Bw CQ ) $.
   lwE $e zw ( Tw CQ Cw ) $.
   mAE $a zw ( Tw Bw Cw ) $. $}
uwE $a zw ( Tw ( 4w Bw CQ ) CQ ) $.
mgg $a #Pattern mwg $.
pQg $a #Pattern pgg $.
3Qg $f #ElementVariable 3gg $.
3wg $f #ElementVariable 4Ag $.
4gg $f #ElementVariable 4wg $.
5Ag $f #ElementVariable 5Qg $.
egk $a #Pattern ewk $.
rQk $a #Pattern rgk $.
.xw $f #ElementVariable -Bw $.
BCQ $a #Pattern 4Ag $.
XiU $a #Pattern 3gg $.
XyU $a #Pattern 4wg $.
YCU $a #Pattern 5Qg $.
zCg $a #Pattern ( 4w ( SwE 5Qg pgg ) ( 4w ( SwE -Bw YQk ) IQE ) ) $.
0Cg $a zw ( Tw ( 4w ( SwE 3gg rgk ) ( 4w ( SwE 4wg ewk ) ( 4w ( SwE 5Qg pgg ) ( 4w ( SwE -Bw YQk ) IQE ) ) ) ) ( SwE 5Qg pgg ) ) $.
${ 0Sg $p zw ( Tw ( 4w ( SwE 4Ag mwg ) ( 4w ( SwE 3gg rgk ) ( 4w ( SwE 4wg ewk ) ( 4w ( SwE 5Qg pgg ) ( 4w ( SwE -Bw YQk ) IQE ) ) ) ) ) ( SwE 5Qg pgg ) ) $=
  ( BCQ mgg SgE XiU rQk XyU egk zCg 4g YCU pQg uwE 0Cg mAE ) BFGHZAIJHCKLHDEMNN
  ZNUADOPHTUAQACDERS $. $}
