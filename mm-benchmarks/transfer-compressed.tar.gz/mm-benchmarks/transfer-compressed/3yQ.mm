$c #SetVariable iA ) #ElementVariable #Symbol #Variable mwg #Pattern ( $.
$v Ow CQ xX Bw Kw ph0 2gg 6xw $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Kg $f #ElementVariable Kw $.
Og $f #Variable Ow $.
SA $a #Variable Kw $.
${ $d xX ph0 $.
   IQI $a iA Bw Bw CQ Ow $. $}
mgg $a #Pattern mwg $.
2Qg $f #ElementVariable 2gg $.
6hw $f #ElementVariable 6xw $.
dB8 $a #Pattern 6xw $.
${ 3yQ $p iA mwg mwg 6xw 2gg $=
  ( mgg dB8 SA IQI ) CBDAEF $. $}
