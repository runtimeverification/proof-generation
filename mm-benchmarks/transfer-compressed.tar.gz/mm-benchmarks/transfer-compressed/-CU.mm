$c #SetVariable ww4 iA ) #ElementVariable #Symbol #Variable #Pattern ( $.
$v Ow CQ xX qxw Bw Kw ph0 nR4 $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Kg $f #ElementVariable Kw $.
Og $f #Variable Ow $.
SA $a #Variable Kw $.
${ $d xX ph0 $.
   IQI $a iA Bw Bw CQ Ow $. $}
wg4 $a #Pattern ww4 $.
qhw $f #ElementVariable qxw $.
nB4 $f #ElementVariable nR4 $.
6h8 $a #Pattern nR4 $.
${ -CU $p iA ww4 ww4 nR4 qxw $=
  ( wg4 6h8 SA IQI ) CBDAEF $. $}
