$c #Symbol Tw #Variable SwE #SetVariable zw 4w JAQ #ElementVariable IQE pgg #Pattern ) ( $.
$v Cw 2gg XRw CQ Bw $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Cg $f #Pattern Cw $.
4g $a #Pattern ( 4w Bw CQ ) $.
IAE $a #Pattern IQE $.
SgE $a #Pattern ( SwE Bw CQ ) $.
lQE $a zw ( Tw Bw Bw ) $.
${ lgE $e zw ( Tw Bw CQ ) $.
   lwE $e zw ( Tw CQ Cw ) $.
   mAE $a zw ( Tw Bw Cw ) $. $}
ugE $a zw ( Tw ( 4w Bw CQ ) Bw ) $.
IwQ $a #Pattern ( JAQ Bw ) $.
pQg $a #Pattern pgg $.
2Qg $f #ElementVariable 2gg $.
XBw $f #ElementVariable XRw $.
Wh8 $a #Pattern 2gg $.
QCE $a #Pattern XRw $.
${ 4CM $p zw ( Tw ( 4w ( 4w ( JAQ 2gg ) IQE ) ( 4w ( SwE XRw pgg ) IQE ) ) ( JAQ 2gg ) ) $=
  ( Wh8 IwQ IAE 4g QCE pQg SgE ugE lQE mAE ) ACDZEFZBGHIEFZFNMNOJNMMMEJMKLL $. $}
