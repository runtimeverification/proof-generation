$c ewk #Symbol #Variable SwE #SetVariable iA #ElementVariable #Pattern ) ( $.
$v Ow CQ zBs DQ Bw Kw Cw nR4 Dw $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Cg $f #Pattern Cw $.
DA $f #Pattern DQ $.
Dg $f #Pattern Dw $.
Kg $f #ElementVariable Kw $.
Og $f #Variable Ow $.
SA $a #Variable Kw $.
jg $a iA Bw Ow Bw Ow $.
${ OgI $e iA CQ DQ Bw Ow $.
   OwI $e iA Cw Dw Bw Ow $.
   PAI $a iA ( SwE CQ Cw ) ( SwE DQ Dw ) Bw Ow $. $}
egk $a #Pattern ewk $.
yxs $f #ElementVariable zBs $.
nB4 $f #ElementVariable nR4 $.
6h8 $a #Pattern nR4 $.
JiE $a #Pattern zBs $.
0CI $a iA ewk ewk nR4 zBs $.
${ 0SI $p iA ( SwE nR4 ewk ) ( SwE zBs ewk ) nR4 zBs $=
  ( 6h8 egk JiE SA jg 0CI PAI ) BCZJDAEDAFZJKGABHI $. $}
