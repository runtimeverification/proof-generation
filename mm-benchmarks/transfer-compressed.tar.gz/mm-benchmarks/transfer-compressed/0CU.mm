$c LAQ ewk IAQ Wgk Tw #Symbol #Variable SwE -gg #SetVariable zw vR4 4w JAQ #ElementVariable IQE #Pattern ) ( $.
$v CQ qwg Bw oAg 5Qg Cw sgg $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Cg $f #Pattern Cw $.
4g $a #Pattern ( 4w Bw CQ ) $.
IAE $a #Pattern IQE $.
SgE $a #Pattern ( SwE Bw CQ ) $.
${ lgE $e zw ( Tw Bw CQ ) $.
   lwE $e zw ( Tw CQ Cw ) $.
   mAE $a zw ( Tw Bw Cw ) $. $}
HwQ $a #Pattern ( IAQ Bw CQ ) $.
IwQ $a #Pattern ( JAQ Bw ) $.
KwQ $a #Pattern ( LAQ Bw CQ Cw ) $.
nwg $f #Pattern oAg $.
qgg $f #Pattern qwg $.
sQg $f #Pattern sgg $.
5Ag $f #ElementVariable 5Qg $.
.gg $a zw ( Tw ( 4w ( 4w ( JAQ oAg ) ( JAQ qwg ) ) ( SwE sgg oAg ) ) ( SwE ( LAQ oAg qwg sgg ) qwg ) ) $.
-Qg $a #Pattern -gg $.
WQk $a #Pattern Wgk $.
egk $a #Pattern ewk $.
vB4 $a #Pattern vR4 $.
YCU $a #Pattern 5Qg $.
zyU $a zw ( Tw ( 4w ( SwE 5Qg -gg ) IQE ) ( 4w ( 4w ( JAQ ewk ) ( JAQ Wgk ) ) ( SwE ( IAQ ewk vR4 ) ewk ) ) ) $.
${ 0CU $p zw ( Tw ( 4w ( SwE 5Qg -gg ) IQE ) ( SwE ( LAQ ewk Wgk ( IAQ ewk vR4 ) ) Wgk ) ) $=
  ( YCU -Qg SgE IAE 4g egk IwQ WQk vB4 HwQ KwQ zyU .gg mAE ) ABCDEFGHIHFGJKZGDF
  GIPLIDAMGIPNO $. $}
