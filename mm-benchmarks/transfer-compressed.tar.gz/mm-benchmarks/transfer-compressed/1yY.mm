$c #SetVariable ww4 iA ) #ElementVariable #Symbol #Variable #Pattern ( $.
$v Ow CQ xX Bw Kw ph0 2gg pxw $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Kg $f #ElementVariable Kw $.
Og $f #Variable Ow $.
SA $a #Variable Kw $.
${ $d xX ph0 $.
   IQI $a iA Bw Bw CQ Ow $. $}
2Qg $f #ElementVariable 2gg $.
wg4 $a #Pattern ww4 $.
phw $f #ElementVariable pxw $.
Wh8 $a #Pattern 2gg $.
${ 1yY $p iA 2gg 2gg ww4 pxw $=
  ( Wh8 wg4 SA IQI ) ACDBEF $. $}
