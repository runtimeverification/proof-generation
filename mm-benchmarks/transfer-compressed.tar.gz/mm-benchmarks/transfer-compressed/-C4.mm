$c IAQ Tw #Symbol #Variable SwE pgg #SetVariable 5x4 zw 4w #ElementVariable IQE rgk #Pattern ) ( $.
$v CQ -Bw Bw $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Tg $a #Pattern ( Tw Bw CQ ) $.
4g $a #Pattern ( 4w Bw CQ ) $.
5Q $a zw ( Tw Bw ( Tw CQ Bw ) ) $.
${ 6A $e zw ( Tw Bw CQ ) $.
   6Q $e zw Bw $.
   6g $a zw CQ $. $}
IAE $a #Pattern IQE $.
SgE $a #Pattern ( SwE Bw CQ ) $.
HwQ $a #Pattern ( IAQ Bw CQ ) $.
IgQ $a zw ( SwE ( IAQ Bw CQ ) Bw ) $.
pQg $a #Pattern pgg $.
rQk $a #Pattern rgk $.
.xw $f #ElementVariable -Bw $.
5h4 $a #Pattern 5x4 $.
yyg $a #Pattern -Bw $.
${ -C4 $p zw ( Tw ( 4w ( SwE -Bw pgg ) IQE ) ( SwE ( IAQ rgk 5x4 ) rgk ) ) $=
  ( rQk 5h4 HwQ SgE yyg pQg IAE 4g Tg 5Q IgQ 6g ) BCDBEZAFGEHIZNJNOKBCLM $. $}
