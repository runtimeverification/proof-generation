$c #SetVariable cwE iA ) #ElementVariable #Symbol #Variable xQg #Pattern ( $.
$v Ow CQ xX Bw Kw ph0 2gg Pw $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Kg $f #ElementVariable Kw $.
Og $f #Variable Ow $.
Pg $f #Symbol Pw $.
SA $a #Variable Kw $.
Sw $a #Pattern Pw $.
cgE $a #Symbol cwE $.
${ $d xX ph0 $.
   IQI $a iA Bw Bw CQ Ow $. $}
xAg $a #Pattern xQg $.
2Qg $f #ElementVariable 2gg $.
${ 3SQ $p iA xQg xQg cwE 2gg $=
  ( xAg cgE Sw SA IQI ) BCDAEF $. $}
