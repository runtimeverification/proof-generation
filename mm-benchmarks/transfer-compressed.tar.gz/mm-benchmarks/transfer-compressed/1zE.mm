$c ewk #Symbol Tw #Variable SwE PQk #SetVariable zw 4w #ElementVariable IQE #Pattern ) ( $.
$v 4wg 5Qg Cw CQ Bw $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Cg $f #Pattern Cw $.
4g $a #Pattern ( 4w Bw CQ ) $.
IAE $a #Pattern IQE $.
SgE $a #Pattern ( SwE Bw CQ ) $.
nAE $a zw IQE $.
${ wAE $e zw ( Tw Bw CQ ) $.
   wQE $e zw ( Tw Bw Cw ) $.
   wgE $a zw ( Tw Bw ( 4w CQ Cw ) ) $. $}
${ NwM $e zw CQ $.
   OAM $a zw ( Tw Bw CQ ) $. $}
4gg $f #ElementVariable 4wg $.
5Ag $f #ElementVariable 5Qg $.
PAk $a #Pattern PQk $.
egk $a #Pattern ewk $.
XyU $a #Pattern 4wg $.
YCU $a #Pattern 5Qg $.
ljE $a #Pattern ( 4w ( SwE 4wg PQk ) ( 4w ( SwE 5Qg ewk ) IQE ) ) $.
mDE $a zw ( Tw ( 4w ( SwE 4wg PQk ) ( 4w ( SwE 5Qg ewk ) IQE ) ) ( SwE 4wg PQk ) ) $.
mzE $a zw ( Tw ( 4w ( SwE 4wg PQk ) ( 4w ( SwE 5Qg ewk ) IQE ) ) ( SwE 5Qg ewk ) ) $.
${ 1zE $p zw ( Tw ( 4w ( SwE 4wg PQk ) ( 4w ( SwE 5Qg ewk ) IQE ) ) ( 4w ( SwE 4wg PQk ) ( 4w ( SwE 5Qg ewk ) IQE ) ) ) $=
  ( ljE XyU PAk SgE YCU egk IAE 4g mDE mzE nAE OAM wgE ) ABCZADEFBGHFZIJABKPQIA
  BLPIMNOO $. $}
