$c Uw ww4 0wM PgE tQM Tw #Symbol #Variable cwE SwE #SetVariable zw 4w YQk JAQ rwM #ElementVariable IQE #Pattern ) ( $.
$v 7Ag yhs CQ Bw Kw ph1 ph0 Cw 2gg GQ x $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Cg $f #Pattern Cw $.
GA $f #Pattern GQ $.
Kg $f #ElementVariable Kw $.
Ug $a #Pattern ( Uw Kw Bw ) $.
IAE $a #Pattern IQE $.
PQE $a #Pattern ( PgE Bw CQ ) $.
${ lgE $e zw ( Tw Bw CQ ) $.
   lwE $e zw ( Tw CQ Cw ) $.
   mAE $a zw ( Tw Bw Cw ) $. $}
nAE $a zw IQE $.
${ NwM $e zw CQ $.
   OAM $a zw ( Tw Bw CQ ) $. $}
${ $d x ph0 $.
   $d x ph1 $.
   vwY $e zw ( Tw GQ ( SwE CQ Bw ) ) $.
   wAY $e zw ( Tw GQ ( tQM cwE ( rwM Bw cwE Kw ( 0wM Bw cwE Kw CQ ) ) ) ) $.
   wQY $a zw ( Tw GQ ( Uw Kw ( PgE Kw CQ ) ) ) $. $}
2Qg $f #ElementVariable 2gg $.
6wg $f #ElementVariable 7Ag $.
YAk $a #Pattern YQk $.
wg4 $a #Pattern ww4 $.
yRs $f #ElementVariable yhs $.
JR8 $a zw ( Tw IQE ( SwE ww4 YQk ) ) $.
7SA $a #Pattern yhs $.
.yA $a zw ( Tw IQE ( tQM cwE ( rwM YQk cwE yhs ( 0wM YQk cwE yhs ww4 ) ) ) ) $.
-SA $a #Pattern ( 4w ( JAQ 2gg ) ( 4w ( SwE 7Ag YQk ) IQE ) ) $.
${ -iA $p zw ( Tw ( 4w ( JAQ 2gg ) ( 4w ( SwE 7Ag YQk ) IQE ) ) ( Uw yhs ( PgE yhs ww4 ) ) ) $=
  ( -SA IAE 7SA wg4 PQE Ug nAE OAM YAk JR8 .yA wQY mAE ) ABDZECFGHCIQEJKLGECMCN
  OP $. $}
