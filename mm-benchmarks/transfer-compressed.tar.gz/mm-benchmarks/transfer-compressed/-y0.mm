$c rwg #Symbol #Variable ( #SetVariable iA #ElementVariable #Pattern xQg ) Vhc $.
$v ngg qwg -Bw Kw oAg nR4 sgg $.
Kg $f #ElementVariable Kw $.
SA $a #Variable Kw $.
nQg $f #Variable ngg $.
nwg $f #Pattern oAg $.
qgg $f #Pattern qwg $.
rgg $a #Pattern ( rwg oAg qwg ) $.
sQg $f #Pattern sgg $.
xAg $a #Pattern xQg $.
${ Whc $e iA qwg sgg oAg ngg $.
   Wxc $a iA ( Vhc qwg ) ( Vhc sgg ) oAg ngg $. $}
.xw $f #ElementVariable -Bw $.
nB4 $f #ElementVariable nR4 $.
6h8 $a #Pattern nR4 $.
yyg $a #Pattern -Bw $.
-i0 $a iA ( rwg nR4 xQg ) ( rwg -Bw xQg ) nR4 -Bw $.
${ -y0 $p iA ( Vhc ( rwg nR4 xQg ) ) ( Vhc ( rwg -Bw xQg ) ) nR4 -Bw $=
  ( SA 6h8 xAg rgg yyg -i0 Wxc ) ACBDZJEFAGEFABHI $. $}
