$c ewk #Symbol #Variable SwE #SetVariable iA 4w #ElementVariable IQE #Pattern ) ( $.
$v Ow CQ zBs DQ Bw Kw Cw nR4 Dw $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Cg $f #Pattern Cw $.
DA $f #Pattern DQ $.
Dg $f #Pattern Dw $.
Kg $f #ElementVariable Kw $.
Og $f #Variable Ow $.
SA $a #Variable Kw $.
IAE $a #Pattern IQE $.
SgE $a #Pattern ( SwE Bw CQ ) $.
${ KAI $e iA CQ DQ Bw Ow $.
   KQI $e iA Cw Dw Bw Ow $.
   KgI $a iA ( 4w CQ Cw ) ( 4w DQ Dw ) Bw Ow $. $}
egk $a #Pattern ewk $.
yxs $f #ElementVariable zBs $.
nB4 $f #ElementVariable nR4 $.
6h8 $a #Pattern nR4 $.
JiE $a #Pattern zBs $.
MyE $a iA IQE IQE nR4 zBs $.
0SI $a iA ( SwE nR4 ewk ) ( SwE zBs ewk ) nR4 zBs $.
${ 0iI $p iA ( 4w ( SwE nR4 ewk ) IQE ) ( 4w ( SwE zBs ewk ) IQE ) nR4 zBs $=
  ( 6h8 egk SgE IAE JiE SA 0SI MyE KgI ) BCZLDEFAGDEFAHABIABJK $. $}
