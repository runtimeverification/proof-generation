$c 4B4 Ngk Lwk #Symbol 7h4 DBE 8Q4 zw xwM pgg #Pattern 0Q4 Kw0 rwg Ex0 xB4 tQM Wgk 0h4 #Variable SwE PQk #SetVariable vR4 4w #ElementVariable IQE qxs mwg xQg 8hw cBQ 2R4 kBM zBA XBI RAk Tw wQM -g4 5x4 rgk ( RQ0 twM LAQ ewk yx4 IAQ 9R4 Hg8 Kw8 hgk 7Ak 7BI ) $.
$v oAg Cw GQ CQ qwg Bw $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Cg $f #Pattern Cw $.
GA $f #Pattern GQ $.
4g $a #Pattern ( 4w Bw CQ ) $.
IAE $a #Pattern IQE $.
SgE $a #Pattern ( SwE Bw CQ ) $.
${ lgE $e zw ( Tw Bw CQ ) $.
   lwE $e zw ( Tw CQ Cw ) $.
   mAE $a zw ( Tw Bw Cw ) $. $}
${ wAE $e zw ( Tw Bw CQ ) $.
   wQE $e zw ( Tw Bw Cw ) $.
   wgE $a zw ( Tw Bw ( 4w CQ Cw ) ) $. $}
uwM $a #Pattern ( twM Bw ) $.
wAM $a #Pattern ( wQM Bw CQ Cw ) $.
HwQ $a #Pattern ( IAQ Bw CQ ) $.
KwQ $a #Pattern ( LAQ Bw CQ Cw ) $.
JwU $a zw ( Tw ( 4w ( SwE CQ Bw ) ( SwE Cw Bw ) ) ( SwE ( wQM Bw CQ Cw ) Bw ) ) $.
${ sgU $e zw ( Tw GQ ( SwE CQ Bw ) ) $.
   swU $a zw ( Tw GQ ( tQM Bw ( xwM Bw CQ CQ ) ) ) $. $}
mgg $a #Pattern mwg $.
nwg $f #Pattern oAg $.
pQg $a #Pattern pgg $.
qgg $f #Pattern qwg $.
rgg $a #Pattern ( rwg oAg qwg ) $.
wQg $a zw ( Tw ( 4w ( SwE oAg pgg ) ( SwE qwg mwg ) ) ( SwE ( rwg oAg qwg ) mwg ) ) $.
xAg $a #Pattern xQg $.
Lgk $a #Pattern Lwk $.
NQk $a #Pattern Ngk $.
PAk $a #Pattern PQk $.
Qwk $a #Pattern RAk $.
WQk $a #Pattern Wgk $.
egk $a #Pattern ewk $.
hQk $a #Pattern hgk $.
rQk $a #Pattern rgk $.
6wk $a #Pattern 7Ak $.
Kg0 $a #Pattern ( Kw0 oAg ) $.
RA0 $a #Pattern ( RQ0 oAg qwg ) $.
UQ0 $a zw ( Tw ( 4w ( SwE oAg mwg ) ( SwE qwg mwg ) ) ( SwE ( RQ0 oAg qwg ) pgg ) ) $.
0A4 $a #Pattern ( 0Q4 oAg qwg ) $.
3Q4 $a zw ( Tw ( 4w ( SwE oAg Lwk ) ( SwE qwg PQk ) ) ( SwE ( 0Q4 oAg qwg ) 7Ak ) ) $.
8A4 $a #Pattern ( 8Q4 oAg ) $.
-Q4 $a #Pattern ( -g4 oAg qwg ) $.
Cg8 $a zw ( Tw ( 4w ( SwE oAg 7Ak ) ( SwE qwg RAk ) ) ( SwE ( -g4 oAg qwg ) Ngk ) ) $.
HQ8 $a #Pattern ( Hg8 oAg ) $.
Jw8 $a zw ( Tw ( SwE oAg mwg ) ( SwE ( Hg8 oAg ) Lwk ) ) $.
Kg8 $a #Pattern ( Kw8 oAg ) $.
yxA $a #Pattern ( zBA oAg qwg ) $.
CxE $a #Pattern ( DBE oAg qwg ) $.
WxI $a #Pattern ( XBI oAg qwg ) $.
6xI $a #Pattern ( 7BI oAg qwg ) $.
jxM $a #Pattern ( kBM oAg qwg ) $.
bxQ $a #Pattern ( cBQ oAg qwg ) $.
qhs $a #Pattern ( qxs oAg ) $.
8Rw $a #Pattern 8hw $.
Eh0 $a #Pattern Ex0 $.
vB4 $a #Pattern vR4 $.
wx4 $a #Pattern xB4 $.
yh4 $a #Pattern yx4 $.
0R4 $a #Pattern 0h4 $.
2B4 $a #Pattern 2R4 $.
3x4 $a #Pattern 4B4 $.
5h4 $a #Pattern 5x4 $.
7R4 $a #Pattern 7h4 $.
9B4 $a #Pattern 9R4 $.
.R4 $a zw ( Tw IQE ( SwE ( twM Ngk ) Ngk ) ) $.
JB8 $a zw ( Tw IQE ( SwE xQg mwg ) ) $.
Kx8 $a zw ( Tw IQE ( SwE ( 8Q4 ( IAQ rgk 8hw ) ) RAk ) ) $.
LR8 $a zw ( Tw IQE ( SwE ( LAQ ewk pgg ( IAQ ewk 2R4 ) ) pgg ) ) $.
VB8 $a zw ( Tw IQE ( SwE ( rwg ( LAQ hgk pgg ( qxs ( XBI ( IAQ ewk xB4 ) ( LAQ rgk Wgk ( IAQ rgk 8hw ) ) ) ) ) xQg ) mwg ) ) $.
VR8 $a zw ( Tw IQE ( SwE ( rwg ( LAQ hgk pgg ( qxs ( kBM ( kBM ( XBI ( IAQ ewk vR4 ) ( DBE ( LAQ ewk Wgk ( IAQ ewk vR4 ) ) ( LAQ ewk Wgk ( IAQ ewk 2R4 ) ) ) ) ( XBI ( IAQ ewk 7h4 ) ( zBA ( LAQ ewk Wgk ( IAQ ewk 7h4 ) ) ( LAQ ewk Wgk ( IAQ ewk 2R4 ) ) ) ) ) ( XBI ( IAQ ewk xB4 ) ( LAQ rgk Wgk ( IAQ rgk Ex0 ) ) ) ) ) ) xQg ) mwg ) ) $.
Vh8 $a zw ( Tw IQE ( SwE ( Kw8 ( 7BI ( cBQ ( LAQ ewk pgg ( IAQ ewk xB4 ) ) ( LAQ rgk pgg ( IAQ rgk 8hw ) ) ) ( 7BI ( cBQ ( LAQ ewk pgg ( IAQ ewk vR4 ) ) ( LAQ rgk pgg ( IAQ rgk 5x4 ) ) ) ( 7BI ( cBQ ( LAQ ewk pgg ( IAQ ewk 9R4 ) ) ( LAQ rgk pgg ( IAQ rgk yx4 ) ) ) ( 7BI ( cBQ ( LAQ ewk pgg ( IAQ ewk 7h4 ) ) ( LAQ rgk pgg ( IAQ rgk 4B4 ) ) ) ( cBQ ( LAQ ewk pgg ( IAQ ewk 2R4 ) ) ( LAQ rgk pgg ( IAQ rgk 0h4 ) ) ) ) ) ) ) ) PQk ) ) $.
DyA $a zw ( Tw IQE ( SwE ( Kw0 ( rwg ( LAQ ewk pgg ( IAQ ewk vR4 ) ) xQg ) ) pgg ) ) $.
${ 2Cw $p zw ( Tw IQE ( tQM Ngk ( xwM Ngk ( wQM Ngk ( wQM Ngk ( twM Ngk ) ( twM Ngk ) ) ( -g4 ( 0Q4 ( Hg8 ( rwg ( LAQ ewk pgg ( IAQ ewk 2R4 ) ) ( rwg ( Kw0 ( rwg ( LAQ ewk pgg ( IAQ ewk vR4 ) ) xQg ) ) ( rwg ( RQ0 ( rwg ( LAQ hgk pgg ( qxs ( XBI ( IAQ ewk xB4 ) ( LAQ rgk Wgk ( IAQ rgk 8hw ) ) ) ) ) xQg ) ( rwg ( LAQ hgk pgg ( qxs ( kBM ( kBM ( XBI ( IAQ ewk vR4 ) ( DBE ( LAQ ewk Wgk ( IAQ ewk vR4 ) ) ( LAQ ewk Wgk ( IAQ ewk 2R4 ) ) ) ) ( XBI ( IAQ ewk 7h4 ) ( zBA ( LAQ ewk Wgk ( IAQ ewk 7h4 ) ) ( LAQ ewk Wgk ( IAQ ewk 2R4 ) ) ) ) ) ( XBI ( IAQ ewk xB4 ) ( LAQ rgk Wgk ( IAQ rgk Ex0 ) ) ) ) ) ) xQg ) ) xQg ) ) ) ) ( Kw8 ( 7BI ( cBQ ( LAQ ewk pgg ( IAQ ewk xB4 ) ) ( LAQ rgk pgg ( IAQ rgk 8hw ) ) ) ( 7BI ( cBQ ( LAQ ewk pgg ( IAQ ewk vR4 ) ) ( LAQ rgk pgg ( IAQ rgk 5x4 ) ) ) ( 7BI ( cBQ ( LAQ ewk pgg ( IAQ ewk 9R4 ) ) ( LAQ rgk pgg ( IAQ rgk yx4 ) ) ) ( 7BI ( cBQ ( LAQ ewk pgg ( IAQ ewk 7h4 ) ) ( LAQ rgk pgg ( IAQ rgk 4B4 ) ) ) ( cBQ ( LAQ ewk pgg ( IAQ ewk 2R4 ) ) ( LAQ rgk pgg ( IAQ rgk 0h4 ) ) ) ) ) ) ) ) ) ( 8Q4 ( IAQ rgk 8hw ) ) ) ) ( wQM Ngk ( wQM Ngk ( twM Ngk ) ( twM Ngk ) ) ( -g4 ( 0Q4 ( Hg8 ( rwg ( LAQ ewk pgg ( IAQ ewk 2R4 ) ) ( rwg ( Kw0 ( rwg ( LAQ ewk pgg ( IAQ ewk vR4 ) ) xQg ) ) ( rwg ( RQ0 ( rwg ( LAQ hgk pgg ( qxs ( XBI ( IAQ ewk xB4 ) ( LAQ rgk Wgk ( IAQ rgk 8hw ) ) ) ) ) xQg ) ( rwg ( LAQ hgk pgg ( qxs ( kBM ( kBM ( XBI ( IAQ ewk vR4 ) ( DBE ( LAQ ewk Wgk ( IAQ ewk vR4 ) ) ( LAQ ewk Wgk ( IAQ ewk 2R4 ) ) ) ) ( XBI ( IAQ ewk 7h4 ) ( zBA ( LAQ ewk Wgk ( IAQ ewk 7h4 ) ) ( LAQ ewk Wgk ( IAQ ewk 2R4 ) ) ) ) ) ( XBI ( IAQ ewk xB4 ) ( LAQ rgk Wgk ( IAQ rgk Ex0 ) ) ) ) ) ) xQg ) ) xQg ) ) ) ) ( Kw8 ( 7BI ( cBQ ( LAQ ewk pgg ( IAQ ewk xB4 ) ) ( LAQ rgk pgg ( IAQ rgk 8hw ) ) ) ( 7BI ( cBQ ( LAQ ewk pgg ( IAQ ewk vR4 ) ) ( LAQ rgk pgg ( IAQ rgk 5x4 ) ) ) ( 7BI ( cBQ ( LAQ ewk pgg ( IAQ ewk 9R4 ) ) ( LAQ rgk pgg ( IAQ rgk yx4 ) ) ) ( 7BI ( cBQ ( LAQ ewk pgg ( IAQ ewk 7h4 ) ) ( LAQ rgk pgg ( IAQ rgk 4B4 ) ) ) ( cBQ ( LAQ ewk pgg ( IAQ ewk 2R4 ) ) ( LAQ rgk pgg ( IAQ rgk 0h4 ) ) ) ) ) ) ) ) ) ( 8Q4 ( IAQ rgk 8hw ) ) ) ) ) ) ) $=
  ( NQk wAM egk pQg HwQ KwQ xAg rgg rQk WQk WxI bxQ 6xI IAE SgE wgE mAE mgg wQg
  4g uwM 2B4 vB4 Kg0 hQk wx4 8Rw qhs CxE 7R4 yxA jxM Eh0 RA0 HQ8 5h4 9B4 yh4
  3x4 0R4 Kg8 0A4 8A4 -Q4 .R4 JwU 6wk Qwk Lgk PAk LR8 DyA VB8 VR8 UQ0 JB8 Jw8
  Vh8 3Q4 Kx8 Cg8 swU ) AAAAUAZWCBZCDCUBEZFZCDCUCEZFZGHUDZUEDCUFEZIJIUGEZFKUHFG
  HZUEDWGCJWGFCJWEFZUIKCUJEZCJWNFWMUKKULWJIJIUMEFKULUHFGHZUNZGHZHZHZUOZCDWJFIDW
  KFLWHIDIUPEFLCDCUQEFIDIUREFLCDWNFIDIUSEFLWFIDIUTEFLMMMMVAZVBZWKVCZVDZBZNNWDAO
  ZXDAOZTXEAONXFXGNWCAOZXHTXFNXHXHVEVEPAWCWCVFQNXBVGOZXCVHOZTXGNXIXJNWTVIOZXAVJ
  OZTXINXKXLNWSROZXKNWFDOZWRROZTXMNXNXOVKNWIDOZWQROZTXONXPXQVLNWPDOZGROZTXQNXRX
  SNWLROZWOROZTXRNXTYAVMVNPWLWOVOQVPPWPGSQPWIWQSQPWFWRSQWSVQQVRPWTXAVSQVTPXBXCW
  AQPAWDXDVFQWB $. $}
