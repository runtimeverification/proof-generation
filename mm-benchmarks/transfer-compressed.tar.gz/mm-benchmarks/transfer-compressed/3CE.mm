$c Tw #Symbol 7h4 -gg zw JAQ vA4 #Pattern ( ewk xB4 IAQ 3BA #Variable SwE #SetVariable 4w #ElementVariable IQE ) $.
$v oAg Cw 2gg CQ qwg Bw $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Cg $f #Pattern Cw $.
4g $a #Pattern ( 4w Bw CQ ) $.
IAE $a #Pattern IQE $.
SgE $a #Pattern ( SwE Bw CQ ) $.
nAE $a zw IQE $.
${ wAE $e zw ( Tw Bw CQ ) $.
   wQE $e zw ( Tw Bw Cw ) $.
   wgE $a zw ( Tw Bw ( 4w CQ Cw ) ) $. $}
${ NwM $e zw CQ $.
   OAM $a zw ( Tw Bw CQ ) $. $}
HwQ $a #Pattern ( IAQ Bw CQ ) $.
IwQ $a #Pattern ( JAQ Bw ) $.
nwg $f #Pattern oAg $.
qgg $f #Pattern qwg $.
2Qg $f #ElementVariable 2gg $.
-Qg $a #Pattern -gg $.
egk $a #Pattern ewk $.
uw4 $a #Pattern vA4 $.
2xA $a #Pattern ( 3BA oAg qwg ) $.
wx4 $a #Pattern xB4 $.
7R4 $a #Pattern 7h4 $.
Wh8 $a #Pattern 2gg $.
2yE $a zw ( Tw ( 4w ( JAQ 2gg ) IQE ) ( SwE ( 3BA ( IAQ ewk 7h4 ) ( 3BA ( IAQ ewk xB4 ) vA4 ) ) -gg ) ) $.
${ 3CE $p zw ( Tw ( 4w ( JAQ 2gg ) IQE ) ( 4w ( SwE ( 3BA ( IAQ ewk 7h4 ) ( 3BA ( IAQ ewk xB4 ) vA4 ) ) -gg ) IQE ) ) $=
  ( Wh8 IwQ IAE 4g egk 7R4 HwQ wx4 uw4 2xA -Qg SgE 2yE nAE OAM wgE ) ABCDEZFGHF
  IHJKKLMDANRDOPQ $. $}
