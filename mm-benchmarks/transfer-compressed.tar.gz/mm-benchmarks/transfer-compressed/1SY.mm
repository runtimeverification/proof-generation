$c #Symbol Tw #Variable SwE #SetVariable zw 4w YQk JAQ #ElementVariable IQE #Pattern ) ( $.
$v Cw 2gg CQ pxw Bw $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Cg $f #Pattern Cw $.
4g $a #Pattern ( 4w Bw CQ ) $.
IAE $a #Pattern IQE $.
SgE $a #Pattern ( SwE Bw CQ ) $.
nAE $a zw IQE $.
${ wAE $e zw ( Tw Bw CQ ) $.
   wQE $e zw ( Tw Bw Cw ) $.
   wgE $a zw ( Tw Bw ( 4w CQ Cw ) ) $. $}
${ NwM $e zw CQ $.
   OAM $a zw ( Tw Bw CQ ) $. $}
IwQ $a #Pattern ( JAQ Bw ) $.
2Qg $f #ElementVariable 2gg $.
YAk $a #Pattern YQk $.
phw $f #ElementVariable pxw $.
Wh8 $a #Pattern 2gg $.
sCY $a #Pattern pxw $.
0yY $a zw ( Tw ( 4w ( 4w ( JAQ 2gg ) IQE ) ( 4w ( SwE pxw YQk ) IQE ) ) ( JAQ 2gg ) ) $.
1CY $a zw ( Tw ( 4w ( 4w ( JAQ 2gg ) IQE ) ( 4w ( SwE pxw YQk ) IQE ) ) ( SwE pxw YQk ) ) $.
${ 1SY $p zw ( Tw ( 4w ( 4w ( JAQ 2gg ) IQE ) ( 4w ( SwE pxw YQk ) IQE ) ) ( 4w ( JAQ 2gg ) ( 4w ( SwE pxw YQk ) IQE ) ) ) $=
  ( Wh8 IwQ IAE 4g sCY YAk SgE 0yY 1CY nAE OAM wgE ) ACDZEFBGHIZEFZFZOQABJRPEAB
  KRELMNN $. $}
