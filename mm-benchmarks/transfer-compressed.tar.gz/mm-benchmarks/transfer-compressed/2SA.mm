$c 4B4 Tw #Symbol 1CA zw JAQ rgk #Pattern ( 0wM tQM IAQ 0h4 #Variable #SetVariable rBA 4w #ElementVariable IQE ) $.
$v CQ qwg DQ Bw oAg Cw 2gg $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Cg $f #Pattern Cw $.
DA $f #Pattern DQ $.
4g $a #Pattern ( 4w Bw CQ ) $.
IAE $a #Pattern IQE $.
${ lgE $e zw ( Tw Bw CQ ) $.
   lwE $e zw ( Tw CQ Cw ) $.
   mAE $a zw ( Tw Bw Cw ) $. $}
nAE $a zw IQE $.
${ wAE $e zw ( Tw Bw CQ ) $.
   wQE $e zw ( Tw Bw Cw ) $.
   wgE $a zw ( Tw Bw ( 4w CQ Cw ) ) $. $}
${ NwM $e zw CQ $.
   OAM $a zw ( Tw Bw CQ ) $. $}
tAM $a #Pattern ( tQM Bw CQ ) $.
0gM $a #Pattern ( 0wM Bw CQ Cw DQ ) $.
HwQ $a #Pattern ( IAQ Bw CQ ) $.
IwQ $a #Pattern ( JAQ Bw ) $.
nwg $f #Pattern oAg $.
qgg $f #Pattern qwg $.
2Qg $f #ElementVariable 2gg $.
rQk $a #Pattern rgk $.
qxA $a #Pattern ( rBA oAg qwg ) $.
0R4 $a #Pattern 0h4 $.
3x4 $a #Pattern 4B4 $.
Wh8 $a #Pattern 2gg $.
.h8 $a zw ( Tw ( 4w IQE ( 4w ( JAQ 2gg ) IQE ) ) ( JAQ 2gg ) ) $.
0yA $a #Pattern 1CA $.
2CA $a zw ( Tw ( 4w ( JAQ 2gg ) IQE ) ( tQM 2gg ( 0wM rgk 2gg ( rBA ( IAQ rgk 4B4 ) ( IAQ rgk 0h4 ) ) ( IAQ rgk 1CA ) ) ) ) $.
${ 2SA $p zw ( Tw ( 4w IQE ( 4w ( JAQ 2gg ) IQE ) ) ( tQM 2gg ( 0wM rgk 2gg ( rBA ( IAQ rgk 4B4 ) ( IAQ rgk 0h4 ) ) ( IAQ rgk 1CA ) ) ) ) $=
  ( IAE Wh8 IwQ 4g rQk 3x4 HwQ 0R4 qxA 0yA 0gM tAM .h8 nAE OAM wgE 2CA mAE ) BA
  CZDZBEZEZUBTFTFGHFIHJFKHLMUCUABANUCBOPQARS $. $}
