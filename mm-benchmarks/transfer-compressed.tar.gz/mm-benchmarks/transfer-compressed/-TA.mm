$c rwg LAQ 0Q4 Hg8 #Symbol #Variable #SetVariable iA hgk #ElementVariable pgg #Pattern xQg ) ( $.
$v 4wg ngg CQ qwg 3gg Bw Kw oAg Cw sgg tAg tgg 4Ag $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Cg $f #Pattern Cw $.
Kg $f #ElementVariable Kw $.
SA $a #Variable Kw $.
KwQ $a #Pattern ( LAQ Bw CQ Cw ) $.
nQg $f #Variable ngg $.
nwg $f #Pattern oAg $.
pQg $a #Pattern pgg $.
qgg $f #Pattern qwg $.
rgg $a #Pattern ( rwg oAg qwg ) $.
sQg $f #Pattern sgg $.
swg $f #Pattern tAg $.
tQg $f #Pattern tgg $.
xAg $a #Pattern xQg $.
3Qg $f #ElementVariable 3gg $.
3wg $f #ElementVariable 4Ag $.
4gg $f #ElementVariable 4wg $.
hQk $a #Pattern hgk $.
${ 1Q4 $e iA qwg tAg oAg ngg $.
   1g4 $e iA sgg tgg oAg ngg $.
   1w4 $a iA ( 0Q4 qwg sgg ) ( 0Q4 tAg tgg ) oAg ngg $. $}
HQ8 $a #Pattern ( Hg8 oAg ) $.
XiU $a #Pattern 3gg $.
XyU $a #Pattern 4wg $.
gyc $a iA 4wg 4wg xQg 4Ag $.
7TA $a #Pattern ( rwg ( LAQ hgk pgg 3gg ) 4Ag ) $.
-DA $a iA ( Hg8 ( rwg ( LAQ hgk pgg 3gg ) xQg ) ) ( Hg8 ( rwg ( LAQ hgk pgg 3gg ) 4Ag ) ) xQg 4Ag $.
${ -TA $p iA ( 0Q4 ( Hg8 ( rwg ( LAQ hgk pgg 3gg ) xQg ) ) 4wg ) ( 0Q4 ( Hg8 ( rwg ( LAQ hgk pgg 3gg ) 4Ag ) ) 4wg ) xQg 4Ag $=
  ( SA xAg hQk pQg XiU KwQ rgg HQ8 XyU 7TA -DA gyc 1w4 ) BDEFGAHIEJKCLZABMKQABN
  BCOP $. $}
