$c XBI LAQ Wgk #Symbol #Variable #SetVariable ) #ElementVariable rgk #Pattern ( $.
$v oAg 4wg Cw CQ qwg 3gg Bw $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Cg $f #Pattern Cw $.
KwQ $a #Pattern ( LAQ Bw CQ Cw ) $.
nwg $f #Pattern oAg $.
qgg $f #Pattern qwg $.
3Qg $f #ElementVariable 3gg $.
4gg $f #ElementVariable 4wg $.
WQk $a #Pattern Wgk $.
rQk $a #Pattern rgk $.
WxI $a #Pattern ( XBI oAg qwg ) $.
XiU $a #Pattern 3gg $.
XyU $a #Pattern 4wg $.
${ 2ig $p #Pattern ( XBI 4wg ( LAQ rgk Wgk 3gg ) ) $=
  ( XyU rQk WQk XiU KwQ WxI ) BCDEAFGH $. $}
