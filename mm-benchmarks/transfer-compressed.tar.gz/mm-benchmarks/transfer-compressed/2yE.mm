$c Tw #Symbol 7h4 -gg zw JAQ vA4 #Pattern ( ewk xB4 IAQ 3BA #Variable SwE #SetVariable 4w #ElementVariable IQE ) $.
$v oAg Cw 2gg CQ qwg Bw $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Cg $f #Pattern Cw $.
4g $a #Pattern ( 4w Bw CQ ) $.
IAE $a #Pattern IQE $.
SgE $a #Pattern ( SwE Bw CQ ) $.
${ lgE $e zw ( Tw Bw CQ ) $.
   lwE $e zw ( Tw CQ Cw ) $.
   mAE $a zw ( Tw Bw Cw ) $. $}
HwQ $a #Pattern ( IAQ Bw CQ ) $.
IwQ $a #Pattern ( JAQ Bw ) $.
nwg $f #Pattern oAg $.
qgg $f #Pattern qwg $.
2Qg $f #ElementVariable 2gg $.
-Qg $a #Pattern -gg $.
egk $a #Pattern ewk $.
uw4 $a #Pattern vA4 $.
2xA $a #Pattern ( 3BA oAg qwg ) $.
6BA $a zw ( Tw ( 4w ( SwE oAg ewk ) ( SwE qwg -gg ) ) ( SwE ( 3BA oAg qwg ) -gg ) ) $.
wx4 $a #Pattern xB4 $.
7R4 $a #Pattern 7h4 $.
Wh8 $a #Pattern 2gg $.
2iE $a zw ( Tw ( 4w ( JAQ 2gg ) IQE ) ( 4w ( SwE ( IAQ ewk 7h4 ) ewk ) ( SwE ( 3BA ( IAQ ewk xB4 ) vA4 ) -gg ) ) ) $.
${ 2yE $p zw ( Tw ( 4w ( JAQ 2gg ) IQE ) ( SwE ( 3BA ( IAQ ewk 7h4 ) ( 3BA ( IAQ ewk xB4 ) vA4 ) ) -gg ) ) $=
  ( Wh8 IwQ IAE 4g egk 7R4 HwQ SgE wx4 uw4 2xA -Qg 2iE 6BA mAE ) ABCDEFGHZFIFJH
  KLZMIEQRLMIANQROP $. $}
