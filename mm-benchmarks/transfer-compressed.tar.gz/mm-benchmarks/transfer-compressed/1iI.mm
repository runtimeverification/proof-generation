$c Uw 2R4 PgE Tw #Symbol zw JAQ #Pattern ( 0wM LAQ ewk tQM IAQ Wgk #Variable SwE #SetVariable iA 4w rwM #ElementVariable IQE ) $.
$v th1 yhs 7Rw CQ Bw Cw 2gg z ph2 Ew ph0 x Lw LQ Ow ph6 DQ ph1 EQ y th2 Dw HQ xX Gw th0 zBs Hw Kw GQ nR4 $.
$d z y $.
$d z x $.
$d y x $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Cg $f #Pattern Cw $.
DA $f #Pattern DQ $.
Dg $f #Pattern Dw $.
EA $f #Pattern EQ $.
Eg $f #Pattern Ew $.
GA $f #Pattern GQ $.
Gg $f #Pattern Gw $.
HA $f #Pattern HQ $.
Hg $f #Pattern Hw $.
Kg $f #ElementVariable Kw $.
LA $f #ElementVariable LQ $.
Lg $f #ElementVariable Lw $.
Og $f #Variable Ow $.
SA $a #Variable Kw $.
jg $a iA Bw Ow Bw Ow $.
${ kg $e iA CQ DQ Bw Ow $.
   kw $e iA Cw Dw Bw Ow $.
   lA $a iA ( Tw CQ Cw ) ( Tw DQ Dw ) Bw Ow $. $}
4g $a #Pattern ( 4w Bw CQ ) $.
IAE $a #Pattern IQE $.
SgE $a #Pattern ( SwE Bw CQ ) $.
${ lgE $e zw ( Tw Bw CQ ) $.
   lwE $e zw ( Tw CQ Cw ) $.
   mAE $a zw ( Tw Bw Cw ) $. $}
${ wAE $e zw ( Tw Bw CQ ) $.
   wQE $e zw ( Tw Bw Cw ) $.
   wgE $a zw ( Tw Bw ( 4w CQ Cw ) ) $. $}
${ $d xX ph0 $.
   IQI $a iA Bw Bw CQ Ow $. $}
${ KAI $e iA CQ DQ Bw Ow $.
   KQI $e iA Cw Dw Bw Ow $.
   KgI $a iA ( 4w CQ Cw ) ( 4w DQ Dw ) Bw Ow $. $}
${ OgI $e iA CQ DQ Bw Ow $.
   OwI $e iA Cw Dw Bw Ow $.
   PAI $a iA ( SwE CQ Cw ) ( SwE DQ Dw ) Bw Ow $. $}
rgM $a #Pattern ( rwM Bw CQ Kw Cw ) $.
tAM $a #Pattern ( tQM Bw CQ ) $.
0gM $a #Pattern ( 0wM Bw CQ Cw DQ ) $.
HwQ $a #Pattern ( IAQ Bw CQ ) $.
IwQ $a #Pattern ( JAQ Bw ) $.
KwQ $a #Pattern ( LAQ Bw CQ Cw ) $.
${ $d xX y $.
   $d y ph6 $.
   OAQ $e iA Bw DQ Ew Ow $.
   OQQ $e iA CQ Dw Ew Ow $.
   OgQ $e iA Cw EQ Ew Ow $.
   OwQ $a iA ( rwM Bw CQ LQ Cw ) ( rwM DQ Dw LQ EQ ) Ew Ow $. $}
${ QAQ $e iA Bw Cw Dw Ow $.
   QQQ $e iA CQ DQ Dw Ow $.
   QgQ $a iA ( tQM Bw CQ ) ( tQM Cw DQ ) Dw Ow $. $}
${ $d z ph0 $.
   $d z ph1 $.
   $d z ph2 $.
   $d z y $.
   $d z x $.
   $d z th1 $.
   $d z th2 $.
   $d x ph0 $.
   $d y th0 $.
   lAY $e zw ( Tw GQ ( Uw Kw ( PgE Kw Bw ) ) ) $.
   lQY $e zw ( Tw ( 4w GQ Gw ) CQ ) $.
   lgY $e iA ( Tw HQ Cw ) ( Tw Gw CQ ) Bw LQ $.
   lwY $e iA ( Tw Hw DQ ) ( Tw Gw CQ ) Lw LQ $.
   mAY $a zw ( Tw ( 4w GQ HQ ) Cw ) $. $}
2Qg $f #ElementVariable 2gg $.
WQk $a #Pattern Wgk $.
egk $a #Pattern ewk $.
yRs $f #ElementVariable yhs $.
yxs $f #ElementVariable zBs $.
7Bw $f #ElementVariable 7Rw $.
nB4 $f #ElementVariable nR4 $.
2B4 $a #Pattern 2R4 $.
Wh8 $a #Pattern 2gg $.
5h8 $a zw ( Tw ( 4w ( JAQ 2gg ) IQE ) ( Uw 7Rw ( PgE 7Rw ( IAQ ewk 2R4 ) ) ) ) $.
6h8 $a #Pattern nR4 $.
9h8 $a zw ( Tw ( 4w ( JAQ 2gg ) IQE ) ( 4w ( JAQ 2gg ) IQE ) ) $.
.B8 $a zw ( Tw ( 4w ( JAQ 2gg ) IQE ) ( 4w ( SwE ( IAQ ewk 2R4 ) ewk ) IQE ) ) $.
7SA $a #Pattern yhs $.
JiE $a #Pattern zBs $.
NSE $a iA 2gg 2gg nR4 zBs $.
yiI $a #Pattern ( 0wM Wgk 2gg yhs ( LAQ ewk Wgk zBs ) ) $.
yyI $a zw ( Tw ( 4w ( 4w ( JAQ 2gg ) IQE ) ( 4w ( SwE zBs ewk ) IQE ) ) ( tQM 2gg ( rwM Wgk 2gg yhs ( 0wM Wgk 2gg yhs ( LAQ ewk Wgk zBs ) ) ) ) ) $.
zCI $a #Pattern ( 0wM Wgk 2gg yhs ( LAQ ewk Wgk nR4 ) ) $.
zSI $a iA 2gg 2gg ( IAQ ewk 2R4 ) zBs $.
zyI $a iA ( 0wM Wgk 2gg yhs ( LAQ ewk Wgk ( IAQ ewk 2R4 ) ) ) ( 0wM Wgk 2gg yhs ( LAQ ewk Wgk zBs ) ) ( IAQ ewk 2R4 ) zBs $.
0iI $a iA ( 4w ( SwE nR4 ewk ) IQE ) ( 4w ( SwE zBs ewk ) IQE ) nR4 zBs $.
1SI $a iA ( rwM Wgk 2gg yhs ( 0wM Wgk 2gg yhs ( LAQ ewk Wgk nR4 ) ) ) ( rwM Wgk 2gg yhs ( 0wM Wgk 2gg yhs ( LAQ ewk Wgk zBs ) ) ) nR4 zBs $.
${ 1iI $p zw ( Tw ( 4w ( JAQ 2gg ) IQE ) ( tQM 2gg ( rwM Wgk 2gg yhs ( 0wM Wgk 2gg yhs ( LAQ ewk Wgk ( IAQ ewk 2R4 ) ) ) ) ) ) $=
  ( yxs nB4 7Bw Wh8 IwQ IAE 4g egk 2B4 HwQ SgE WQk 7SA rgM tAM IQI QgQ lA SA jg
  KwQ 0gM 9h8 .B8 wgE yiI zCI JiE 6h8 5h8 yyI PAI KgI zSI zyI OwQ 0iI NSE 1SI
  mAY mAE ) AFZGHIZVEJKLZJMZHIZIVDNVDNVDBOJNVFUCUDZBPZQZVEVEVHAUEAUFUGVFVDNVDAB
  CUHZBPZQZVKVDNVDABDUIBPZQZVECUJZJMZHIZVHDUKZJMHIZECDAEULABCUMVFVHVKVSVNCUAZVF
  VGHVRHWBVFVFJVQJWBVFWBUBJVFWBRUNHVFWBRUOVDVJVDVMVFWBACUPZNVDVINVDVLVFBWBNVFWB
  RWCABCUQURSTVTWAVPVSVNWBCDUSVDVOVDVMVTWBACDUTABCDVASTVBVC $. $}
