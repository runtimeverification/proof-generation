$c #Symbol Tw #Variable #SetVariable zw 4w JAQ lAk #ElementVariable IQE pgg #Pattern ) ( $.
$v Cw 2gg CQ Bw $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Cg $f #Pattern Cw $.
4g $a #Pattern ( 4w Bw CQ ) $.
IAE $a #Pattern IQE $.
${ wAE $e zw ( Tw Bw CQ ) $.
   wQE $e zw ( Tw Bw Cw ) $.
   wgE $a zw ( Tw Bw ( 4w CQ Cw ) ) $. $}
IwQ $a #Pattern ( JAQ Bw ) $.
pQg $a #Pattern pgg $.
2Qg $f #ElementVariable 2gg $.
kwk $a #Pattern lAk $.
Wh8 $a #Pattern 2gg $.
6iM $a zw ( Tw ( 4w ( JAQ 2gg ) IQE ) ( JAQ pgg ) ) $.
-SM $a zw ( Tw ( 4w ( JAQ 2gg ) IQE ) ( JAQ lAk ) ) $.
${ -iM $p zw ( Tw ( 4w ( JAQ 2gg ) IQE ) ( 4w ( JAQ lAk ) ( JAQ pgg ) ) ) $=
  ( Wh8 IwQ IAE 4g kwk pQg -SM 6iM wgE ) ABCDEFCGCAHAIJ $. $}
