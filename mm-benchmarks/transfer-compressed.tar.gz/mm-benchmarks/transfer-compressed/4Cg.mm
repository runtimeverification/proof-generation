$c ewk RAk IAQ Tw #Symbol #Variable SwE #SetVariable 8Q4 zw 4w YQk #ElementVariable IQE mwg rgk pgg #Pattern 8hw ) ( $.
$v 4wg CQ 3gg -Bw Bw oAg 5Qg Cw 4Ag $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Cg $f #Pattern Cw $.
Tg $a #Pattern ( Tw Bw CQ ) $.
4g $a #Pattern ( 4w Bw CQ ) $.
5Q $a zw ( Tw Bw ( Tw CQ Bw ) ) $.
${ 6A $e zw ( Tw Bw CQ ) $.
   6Q $e zw Bw $.
   6g $a zw CQ $. $}
SgE $a #Pattern ( SwE Bw CQ ) $.
${ lgE $e zw ( Tw Bw CQ ) $.
   lwE $e zw ( Tw CQ Cw ) $.
   mAE $a zw ( Tw Bw Cw ) $. $}
HwQ $a #Pattern ( IAQ Bw CQ ) $.
IgQ $a zw ( SwE ( IAQ Bw CQ ) Bw ) $.
mgg $a #Pattern mwg $.
nwg $f #Pattern oAg $.
3Qg $f #ElementVariable 3gg $.
3wg $f #ElementVariable 4Ag $.
4gg $f #ElementVariable 4wg $.
5Ag $f #ElementVariable 5Qg $.
Qwk $a #Pattern RAk $.
egk $a #Pattern ewk $.
rQk $a #Pattern rgk $.
8A4 $a #Pattern ( 8Q4 oAg ) $.
.g4 $a zw ( Tw ( SwE oAg rgk ) ( SwE ( 8Q4 oAg ) RAk ) ) $.
8Rw $a #Pattern 8hw $.
.xw $f #ElementVariable -Bw $.
BCQ $a #Pattern 4Ag $.
XiU $a #Pattern 3gg $.
XyU $a #Pattern 4wg $.
zCg $a #Pattern ( 4w ( SwE 5Qg pgg ) ( 4w ( SwE -Bw YQk ) IQE ) ) $.
${ 4Cg $p zw ( Tw ( 4w ( SwE 4Ag mwg ) ( 4w ( SwE 3gg rgk ) ( 4w ( SwE 4wg ewk ) ( 4w ( SwE 5Qg pgg ) ( 4w ( SwE -Bw YQk ) IQE ) ) ) ) ) ( SwE ( 8Q4 ( IAQ rgk 8hw ) ) RAk ) ) $=
  ( BCQ mgg SgE XiU rQk XyU egk zCg 4g 8Rw HwQ 8A4 Qwk Tg 5Q IgQ 6g .g4 mAE ) B
  FGHAIJHCKLHDEMNNNZJOPZJHZUFQRHUGUEUGSUGUETJOUAUBUFUCUD $. $}
