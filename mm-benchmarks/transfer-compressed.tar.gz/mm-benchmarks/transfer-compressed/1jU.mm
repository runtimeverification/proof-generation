$c Tw #Symbol 1CA zw JAQ pgg rgk 3gk #Pattern ( rwg LAQ IAQ #Variable SwE #SetVariable 4w #ElementVariable IQE mwg xQg ) $.
$v CQ qwg Bw oAg Cw 2gg 4Ag $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Cg $f #Pattern Cw $.
Tg $a #Pattern ( Tw Bw CQ ) $.
4g $a #Pattern ( 4w Bw CQ ) $.
5Q $a zw ( Tw Bw ( Tw CQ Bw ) ) $.
${ 6A $e zw ( Tw Bw CQ ) $.
   6Q $e zw Bw $.
   6g $a zw CQ $. $}
SgE $a #Pattern ( SwE Bw CQ ) $.
${ lgE $e zw ( Tw Bw CQ ) $.
   lwE $e zw ( Tw CQ Cw ) $.
   mAE $a zw ( Tw Bw Cw ) $. $}
${ wAE $e zw ( Tw Bw CQ ) $.
   wQE $e zw ( Tw Bw Cw ) $.
   wgE $a zw ( Tw Bw ( 4w CQ Cw ) ) $. $}
HwQ $a #Pattern ( IAQ Bw CQ ) $.
KwQ $a #Pattern ( LAQ Bw CQ Cw ) $.
mgg $a #Pattern mwg $.
nwg $f #Pattern oAg $.
pQg $a #Pattern pgg $.
qgg $f #Pattern qwg $.
rgg $a #Pattern ( rwg oAg qwg ) $.
wQg $a zw ( Tw ( 4w ( SwE oAg pgg ) ( SwE qwg mwg ) ) ( SwE ( rwg oAg qwg ) mwg ) ) $.
xAg $a #Pattern xQg $.
yAg $a zw ( SwE xQg mwg ) $.
2Qg $f #ElementVariable 2gg $.
3wg $f #ElementVariable 4Ag $.
rQk $a #Pattern rgk $.
0yA $a #Pattern 1CA $.
DC4 $a #Pattern ( 4w ( JAQ 2gg ) ( 4w ( SwE 4Ag 3gk ) IQE ) ) $.
1TU $a zw ( Tw ( 4w ( JAQ 2gg ) ( 4w ( SwE 4Ag 3gk ) IQE ) ) ( SwE ( LAQ rgk pgg ( IAQ rgk 1CA ) ) pgg ) ) $.
${ 1jU $p zw ( Tw ( 4w ( JAQ 2gg ) ( 4w ( SwE 4Ag 3gk ) IQE ) ) ( SwE ( rwg ( LAQ rgk pgg ( IAQ rgk 1CA ) ) xQg ) mwg ) ) $=
  ( DC4 rQk pQg 0yA HwQ KwQ SgE xAg mgg 4g rgg 1TU Tg 5Q yAg 6g wgE wQg mAE ) A
  BCZDEDFGHZEIZJKIZLUCJMKIUBUDUEABNUEUBUEOUEUBPQRSUCJTUA $. $}
