$c Uw 2R4 PgE 4B4 Tw #Symbol 7h4 zw YQk JAQ pgg rgk #Pattern ( 0wM LAQ ewk yx4 tQM IAQ 0h4 9R4 #Variable SwE #SetVariable iA 4w #ElementVariable IQE 7BI ) cBQ $.
$v th1 yhs Fw CQ YBw Bw Cw 2gg sgg ngg FQ z ph2 Ew ph0 x Lw LQ Ow qwg DQ ph1 EQ y th2 tAg Dw HQ xX Gw th0 Hw Kw oAg GQ nR4 tgg $.
$d z y $.
$d z x $.
$d y x $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Cg $f #Pattern Cw $.
DA $f #Pattern DQ $.
Dg $f #Pattern Dw $.
EA $f #Pattern EQ $.
Eg $f #Pattern Ew $.
FA $f #Pattern FQ $.
Fg $f #Pattern Fw $.
GA $f #Pattern GQ $.
Gg $f #Pattern Gw $.
HA $f #Pattern HQ $.
Hg $f #Pattern Hw $.
Kg $f #ElementVariable Kw $.
LA $f #ElementVariable LQ $.
Lg $f #ElementVariable Lw $.
Og $f #Variable Ow $.
SA $a #Variable Kw $.
jg $a iA Bw Ow Bw Ow $.
${ kg $e iA CQ DQ Bw Ow $.
   kw $e iA Cw Dw Bw Ow $.
   lA $a iA ( Tw CQ Cw ) ( Tw DQ Dw ) Bw Ow $. $}
4g $a #Pattern ( 4w Bw CQ ) $.
IAE $a #Pattern IQE $.
SgE $a #Pattern ( SwE Bw CQ ) $.
${ lgE $e zw ( Tw Bw CQ ) $.
   lwE $e zw ( Tw CQ Cw ) $.
   mAE $a zw ( Tw Bw Cw ) $. $}
nAE $a zw IQE $.
${ wAE $e zw ( Tw Bw CQ ) $.
   wQE $e zw ( Tw Bw Cw ) $.
   wgE $a zw ( Tw Bw ( 4w CQ Cw ) ) $. $}
${ $d xX ph0 $.
   IQI $a iA Bw Bw CQ Ow $. $}
${ KAI $e iA CQ DQ Bw Ow $.
   KQI $e iA Cw Dw Bw Ow $.
   KgI $a iA ( 4w CQ Cw ) ( 4w DQ Dw ) Bw Ow $. $}
${ OgI $e iA CQ DQ Bw Ow $.
   OwI $e iA Cw Dw Bw Ow $.
   PAI $a iA ( SwE CQ Cw ) ( SwE DQ Dw ) Bw Ow $. $}
${ NwM $e zw CQ $.
   OAM $a zw ( Tw Bw CQ ) $. $}
tAM $a #Pattern ( tQM Bw CQ ) $.
0gM $a #Pattern ( 0wM Bw CQ Cw DQ ) $.
HwQ $a #Pattern ( IAQ Bw CQ ) $.
IwQ $a #Pattern ( JAQ Bw ) $.
KwQ $a #Pattern ( LAQ Bw CQ Cw ) $.
${ QAQ $e iA Bw Cw Dw Ow $.
   QQQ $e iA CQ DQ Dw Ow $.
   QgQ $a iA ( tQM Bw CQ ) ( tQM Cw DQ ) Dw Ow $. $}
${ XgQ $e iA Bw Dw Fw Ow $.
   XwQ $e iA CQ EQ Fw Ow $.
   YAQ $e iA Cw Ew Fw Ow $.
   YQQ $e iA DQ FQ Fw Ow $.
   YgQ $a iA ( 0wM Bw CQ Cw DQ ) ( 0wM Dw EQ Ew FQ ) Fw Ow $. $}
${ $d z ph0 $.
   $d z ph1 $.
   $d z ph2 $.
   $d z y $.
   $d z x $.
   $d z th1 $.
   $d z th2 $.
   $d x ph0 $.
   $d y th0 $.
   lAY $e zw ( Tw GQ ( Uw Kw ( PgE Kw Bw ) ) ) $.
   lQY $e zw ( Tw ( 4w GQ Gw ) CQ ) $.
   lgY $e iA ( Tw HQ Cw ) ( Tw Gw CQ ) Bw LQ $.
   lwY $e iA ( Tw Hw DQ ) ( Tw Gw CQ ) Lw LQ $.
   mAY $a zw ( Tw ( 4w GQ HQ ) Cw ) $. $}
nQg $f #Variable ngg $.
nwg $f #Pattern oAg $.
pQg $a #Pattern pgg $.
qgg $f #Pattern qwg $.
sQg $f #Pattern sgg $.
swg $f #Pattern tAg $.
tQg $f #Pattern tgg $.
2Qg $f #ElementVariable 2gg $.
YAk $a #Pattern YQk $.
egk $a #Pattern ewk $.
rQk $a #Pattern rgk $.
6xI $a #Pattern ( 7BI oAg qwg ) $.
${ 8BI $e iA qwg tAg oAg ngg $.
   8RI $e iA sgg tgg oAg ngg $.
   8hI $a iA ( 7BI qwg sgg ) ( 7BI tAg tgg ) oAg ngg $. $}
bxQ $a #Pattern ( cBQ oAg qwg ) $.
yRs $f #ElementVariable yhs $.
Xxw $f #ElementVariable YBw $.
nB4 $f #ElementVariable nR4 $.
yh4 $a #Pattern yx4 $.
0R4 $a #Pattern 0h4 $.
2B4 $a #Pattern 2R4 $.
3x4 $a #Pattern 4B4 $.
7R4 $a #Pattern 7h4 $.
9B4 $a #Pattern 9R4 $.
Wh8 $a #Pattern 2gg $.
6h8 $a #Pattern nR4 $.
9h8 $a zw ( Tw ( 4w ( JAQ 2gg ) IQE ) ( 4w ( JAQ 2gg ) IQE ) ) $.
ACM $a #Pattern YBw $.
vSM $a iA 2gg 2gg nR4 YBw $.
CSY $a #Pattern ( 4w ( JAQ 2gg ) ( 4w ( SwE YBw YQk ) IQE ) ) $.
JiY $a zw ( Tw ( 4w ( 4w ( JAQ 2gg ) IQE ) ( 4w ( SwE YBw YQk ) IQE ) ) ( 4w ( JAQ 2gg ) ( 4w ( SwE YBw YQk ) IQE ) ) ) $.
KiY $a iA YQk YQk nR4 YBw $.
LCY $a iA ( 4w ( SwE nR4 YQk ) IQE ) ( 4w ( SwE YBw YQk ) IQE ) nR4 YBw $.
iCk $a zw ( Tw ( 4w ( JAQ 2gg ) IQE ) ( SwE ( cBQ ( LAQ ewk pgg ( IAQ ewk 9R4 ) ) ( LAQ rgk pgg ( IAQ rgk yx4 ) ) ) YQk ) ) $.
-yk $a zw ( Tw ( 4w ( JAQ 2gg ) IQE ) ( Uw yhs ( PgE yhs ( cBQ ( LAQ ewk pgg ( IAQ ewk 9R4 ) ) ( LAQ rgk pgg ( IAQ rgk yx4 ) ) ) ) ) ) $.
1Cs $a zw ( Tw ( 4w ( JAQ 2gg ) ( 4w ( SwE YBw YQk ) IQE ) ) ( tQM 2gg ( 0wM YQk 2gg ( 7BI ( 7BI ( cBQ ( LAQ ewk pgg ( IAQ ewk 7h4 ) ) ( LAQ rgk pgg ( IAQ rgk 4B4 ) ) ) ( cBQ ( LAQ ewk pgg ( IAQ ewk 2R4 ) ) ( LAQ rgk pgg ( IAQ rgk 0h4 ) ) ) ) YBw ) ( 7BI YBw ( 7BI ( cBQ ( LAQ ewk pgg ( IAQ ewk 7h4 ) ) ( LAQ rgk pgg ( IAQ rgk 4B4 ) ) ) ( cBQ ( LAQ ewk pgg ( IAQ ewk 2R4 ) ) ( LAQ rgk pgg ( IAQ rgk 0h4 ) ) ) ) ) ) ) ) $.
${ 1Ss $p zw ( Tw ( 4w ( JAQ 2gg ) IQE ) ( tQM 2gg ( 0wM YQk 2gg ( 7BI ( 7BI ( cBQ ( LAQ ewk pgg ( IAQ ewk 7h4 ) ) ( LAQ rgk pgg ( IAQ rgk 4B4 ) ) ) ( cBQ ( LAQ ewk pgg ( IAQ ewk 2R4 ) ) ( LAQ rgk pgg ( IAQ rgk 0h4 ) ) ) ) ( cBQ ( LAQ ewk pgg ( IAQ ewk 9R4 ) ) ( LAQ rgk pgg ( IAQ rgk yx4 ) ) ) ) ( 7BI ( cBQ ( LAQ ewk pgg ( IAQ ewk 9R4 ) ) ( LAQ rgk pgg ( IAQ rgk yx4 ) ) ) ( 7BI ( cBQ ( LAQ ewk pgg ( IAQ ewk 7h4 ) ) ( LAQ rgk pgg ( IAQ rgk 4B4 ) ) ) ( cBQ ( LAQ ewk pgg ( IAQ ewk 2R4 ) ) ( LAQ rgk pgg ( IAQ rgk 0h4 ) ) ) ) ) ) ) ) $=
  ( Xxw nB4 yRs IAE 4g egk pQg HwQ KwQ rQk bxQ YAk SgE 6xI 0gM tAM wgE IQI 8hI
  Wh8 IwQ 9B4 yh4 7R4 3x4 2B4 0R4 9h8 iCk nAE OAM ACM 6h8 -yk CSY JiY 1Cs SA jg
  mAE PAI KgI YgQ QgQ lA LCY vSM KiY mAY ) AUAZUBEFZVLGHGUCIJKHKUDIJLZMNZEFZFVK
  MVKGHGUEIJKHKUFIJLGHGUGIJKHKUHIJLOZVMOZVMVPOZPZQZVLVLVOAUIVLVNEAUJVLEUKULRRVM
  VKMVKVPBUMZOZWAVPOZPZQZVTVKMVKVPCUNZOZWFVPOZPZQZVLWAMNZEFZVOWFMNEFZDBCADUOVLW
  LFABUPWEABUQABURVAVMVOVTWLWEBUSZVMVNEWKEWNVMVMMWAMWNVMWNUTZMVMWNSZVBEVMWNSVCV
  KVSVKWDVMWNVKVMWNSZMVKVQVRMVKWBWCVMWNWPWQWNVMVPVMVPWAVPVMWNSZWOTWNVMVMVPWAVPW
  OWRTVDVEVFWFWMWJWLWEWNBCVGVKWIVKWDWFWNABCVHZMVKWGWHMVKWBWCWFWNBCVIWSWNWFVPWFV
  PWAVPWFWNSZWFWNUTZTWNWFWFVPWAVPXAWTTVDVEVFVJVA $. $}
