$c ewk Wgk Tw #Symbol #Variable SwE PQk #SetVariable zw 4w JAQ #ElementVariable IQE pgg #Pattern ) ( $.
$v 4wg 5Qg Cw CQ -Bw Bw $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Cg $f #Pattern Cw $.
Tg $a #Pattern ( Tw Bw CQ ) $.
4g $a #Pattern ( 4w Bw CQ ) $.
5Q $a zw ( Tw Bw ( Tw CQ Bw ) ) $.
${ 6A $e zw ( Tw Bw CQ ) $.
   6Q $e zw Bw $.
   6g $a zw CQ $. $}
SgE $a #Pattern ( SwE Bw CQ ) $.
${ wAE $e zw ( Tw Bw CQ ) $.
   wQE $e zw ( Tw Bw Cw ) $.
   wgE $a zw ( Tw Bw ( 4w CQ Cw ) ) $. $}
IwQ $a #Pattern ( JAQ Bw ) $.
4gg $f #ElementVariable 4wg $.
5Ag $f #ElementVariable 5Qg $.
PAk $a #Pattern PQk $.
WQk $a #Pattern Wgk $.
XQk $a zw ( JAQ Wgk ) $.
egk $a #Pattern ewk $.
fgk $a zw ( JAQ ewk ) $.
.xw $f #ElementVariable -Bw $.
XyU $a #Pattern 4wg $.
pC0 $a #Pattern ( 4w ( SwE 5Qg Wgk ) ( 4w ( SwE -Bw pgg ) IQE ) ) $.
${ 0S0 $p zw ( Tw ( 4w ( SwE 4wg PQk ) ( 4w ( SwE 5Qg Wgk ) ( 4w ( SwE -Bw pgg ) IQE ) ) ) ( 4w ( JAQ ewk ) ( JAQ Wgk ) ) ) $=
  ( XyU PAk SgE pC0 4g egk IwQ WQk Tg 5Q fgk 6g XQk wgE ) ADEFBCGHZIJZKJZSRSLSR
  MNOTRTLTRMPOQ $. $}
