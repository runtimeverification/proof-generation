$c ewk IAQ Tw #Symbol #Variable SwE pgg #SetVariable 5x4 zw 4w YQk JAQ #ElementVariable IQE rgk #Pattern ) ( $.
$v 5Qg Cw CQ -Bw Bw $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Cg $f #Pattern Cw $.
Tg $a #Pattern ( Tw Bw CQ ) $.
4g $a #Pattern ( 4w Bw CQ ) $.
5Q $a zw ( Tw Bw ( Tw CQ Bw ) ) $.
${ 6A $e zw ( Tw Bw CQ ) $.
   6Q $e zw Bw $.
   6g $a zw CQ $. $}
SgE $a #Pattern ( SwE Bw CQ ) $.
${ wAE $e zw ( Tw Bw CQ ) $.
   wQE $e zw ( Tw Bw Cw ) $.
   wgE $a zw ( Tw Bw ( 4w CQ Cw ) ) $. $}
HwQ $a #Pattern ( IAQ Bw CQ ) $.
IgQ $a zw ( SwE ( IAQ Bw CQ ) Bw ) $.
IwQ $a #Pattern ( JAQ Bw ) $.
pQg $a #Pattern pgg $.
qQg $a zw ( JAQ pgg ) $.
5Ag $f #ElementVariable 5Qg $.
rQk $a #Pattern rgk $.
sQk $a zw ( JAQ rgk ) $.
.xw $f #ElementVariable -Bw $.
5h4 $a #Pattern 5x4 $.
2yw $a #Pattern ( 4w ( SwE 5Qg ewk ) ( 4w ( SwE -Bw YQk ) IQE ) ) $.
${ 2i4 $p zw ( Tw ( 4w ( SwE 5Qg ewk ) ( 4w ( SwE -Bw YQk ) IQE ) ) ( 4w ( 4w ( JAQ rgk ) ( JAQ pgg ) ) ( SwE ( IAQ rgk 5x4 ) rgk ) ) ) $=
  ( 2yw rQk IwQ pQg 4g 5h4 HwQ SgE Tg 5Q sQk 6g qQg wgE IgQ ) ABCZDEZFEZGDHIDJZ
  RSTSRSKSRLMNTRTKTRLONPUARUAKUARLDHQNP $. $}
