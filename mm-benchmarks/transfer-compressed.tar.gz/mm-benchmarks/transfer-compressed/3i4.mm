$c ewk IAQ #Symbol #Variable #SetVariable iA vR4 #ElementVariable #Pattern ) ( $.
$v Ow CQ xX -Bw Bw Kw ph0 5Qg $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Kg $f #ElementVariable Kw $.
Og $f #Variable Ow $.
SA $a #Variable Kw $.
${ $d xX ph0 $.
   IQI $a iA Bw Bw CQ Ow $. $}
HwQ $a #Pattern ( IAQ Bw CQ ) $.
5Ag $f #ElementVariable 5Qg $.
egk $a #Pattern ewk $.
.xw $f #ElementVariable -Bw $.
vB4 $a #Pattern vR4 $.
yyg $a #Pattern -Bw $.
${ 3i4 $p iA -Bw -Bw ( IAQ ewk vR4 ) 5Qg $=
  ( yyg egk vB4 HwQ SA IQI ) BCDEFAGH $. $}
