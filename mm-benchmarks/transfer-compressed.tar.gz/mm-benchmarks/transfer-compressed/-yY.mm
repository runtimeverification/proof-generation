$c ewk IAQ 7h4 #Symbol #Variable #SetVariable iA #ElementVariable #Pattern ) ( $.
$v Ow CQ xX 3gg Bw Kw ph0 5Qg $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Kg $f #ElementVariable Kw $.
Og $f #Variable Ow $.
SA $a #Variable Kw $.
${ $d xX ph0 $.
   IQI $a iA Bw Bw CQ Ow $. $}
HwQ $a #Pattern ( IAQ Bw CQ ) $.
3Qg $f #ElementVariable 3gg $.
5Ag $f #ElementVariable 5Qg $.
egk $a #Pattern ewk $.
7R4 $a #Pattern 7h4 $.
YCU $a #Pattern 5Qg $.
${ -yY $p iA 5Qg 5Qg ( IAQ ewk 7h4 ) 3gg $=
  ( YCU egk 7R4 HwQ SA IQI ) BCDEFAGH $. $}
