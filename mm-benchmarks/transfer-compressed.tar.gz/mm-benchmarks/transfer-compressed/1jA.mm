$c Uw PgE Tw #Symbol zw JAQ pwk .gk pgg #Pattern ( 0wM LAQ tQM #Variable SwE #SetVariable iA 4w #ElementVariable IQE ) $.
$v th1 Fw CQ Bw Cw 2gg FQ z ph2 Ew ph0 x Lw 6xw LQ Ow DQ ph1 EQ y th2 mh4 Dw HQ xX Gw th0 Hw lB4 Kw GQ $.
$d z y $.
$d z x $.
$d y x $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Cg $f #Pattern Cw $.
DA $f #Pattern DQ $.
Dg $f #Pattern Dw $.
EA $f #Pattern EQ $.
Eg $f #Pattern Ew $.
FA $f #Pattern FQ $.
Fg $f #Pattern Fw $.
GA $f #Pattern GQ $.
Gg $f #Pattern Gw $.
HA $f #Pattern HQ $.
Hg $f #Pattern Hw $.
Kg $f #ElementVariable Kw $.
LA $f #ElementVariable LQ $.
Lg $f #ElementVariable Lw $.
Og $f #Variable Ow $.
SA $a #Variable Kw $.
Tg $a #Pattern ( Tw Bw CQ ) $.
Ug $a #Pattern ( Uw Kw Bw ) $.
jg $a iA Bw Ow Bw Ow $.
${ kg $e iA CQ DQ Bw Ow $.
   kw $e iA Cw Dw Bw Ow $.
   lA $a iA ( Tw CQ Cw ) ( Tw DQ Dw ) Bw Ow $. $}
4g $a #Pattern ( 4w Bw CQ ) $.
5Q $a zw ( Tw Bw ( Tw CQ Bw ) ) $.
${ 6A $e zw ( Tw Bw CQ ) $.
   6Q $e zw Bw $.
   6g $a zw CQ $. $}
IAE $a #Pattern IQE $.
PQE $a #Pattern ( PgE Bw CQ ) $.
${ lgE $e zw ( Tw Bw CQ ) $.
   lwE $e zw ( Tw CQ Cw ) $.
   mAE $a zw ( Tw Bw Cw ) $. $}
nAE $a zw IQE $.
${ wAE $e zw ( Tw Bw CQ ) $.
   wQE $e zw ( Tw Bw Cw ) $.
   wgE $a zw ( Tw Bw ( 4w CQ Cw ) ) $. $}
${ $d xX ph0 $.
   IQI $a iA Bw Bw CQ Ow $. $}
${ NwM $e zw CQ $.
   OAM $a zw ( Tw Bw CQ ) $. $}
tAM $a #Pattern ( tQM Bw CQ ) $.
0gM $a #Pattern ( 0wM Bw CQ Cw DQ ) $.
IwQ $a #Pattern ( JAQ Bw ) $.
KwQ $a #Pattern ( LAQ Bw CQ Cw ) $.
${ QAQ $e iA Bw Cw Dw Ow $.
   QQQ $e iA CQ DQ Dw Ow $.
   QgQ $a iA ( tQM Bw CQ ) ( tQM Cw DQ ) Dw Ow $. $}
${ XgQ $e iA Bw Dw Fw Ow $.
   XwQ $e iA CQ EQ Fw Ow $.
   YAQ $e iA Cw Ew Fw Ow $.
   YQQ $e iA DQ FQ Fw Ow $.
   YgQ $a iA ( 0wM Bw CQ Cw DQ ) ( 0wM Dw EQ Ew FQ ) Fw Ow $. $}
${ lAQ $e iA Bw DQ Ew Ow $.
   lQQ $e iA CQ Dw Ew Ow $.
   lgQ $e iA Cw EQ Ew Ow $.
   lwQ $a iA ( LAQ Bw CQ Cw ) ( LAQ DQ Dw EQ ) Ew Ow $. $}
${ $d x ph0 $.
   jAY $e zw ( Tw GQ ( JAQ Bw ) ) $.
   jQY $a zw ( Tw GQ ( Uw Kw ( PgE Kw Bw ) ) ) $. $}
${ $d z ph0 $.
   $d z ph1 $.
   $d z ph2 $.
   $d z y $.
   $d z x $.
   $d z th1 $.
   $d z th2 $.
   $d x ph0 $.
   $d y th0 $.
   lAY $e zw ( Tw GQ ( Uw Kw ( PgE Kw Bw ) ) ) $.
   lQY $e zw ( Tw ( 4w GQ Gw ) CQ ) $.
   lgY $e iA ( Tw HQ Cw ) ( Tw Gw CQ ) Bw LQ $.
   lwY $e iA ( Tw Hw DQ ) ( Tw Gw CQ ) Lw LQ $.
   mAY $a zw ( Tw ( 4w GQ HQ ) Cw ) $. $}
pQg $a #Pattern pgg $.
qQg $a zw ( JAQ pgg ) $.
2Qg $f #ElementVariable 2gg $.
pgk $a #Pattern pwk $.
.Qk $a #Pattern .gk $.
6hw $f #ElementVariable 6xw $.
kx4 $f #ElementVariable lB4 $.
mR4 $f #ElementVariable mh4 $.
.x4 $a zw ( Tw IQE ( JAQ pgg ) ) $.
Wh8 $a #Pattern 2gg $.
XB8 $a #Pattern lB4 $.
Xh8 $a #Pattern Kw $.
YR8 $a #Pattern mh4 $.
dB8 $a #Pattern 6xw $.
wR8 $a iA ( 4w ( JAQ pgg ) IQE ) ( 4w ( JAQ lB4 ) IQE ) pgg lB4 $.
wh8 $a iA 2gg 2gg pgg lB4 $.
xx8 $a iA ( 4w ( JAQ 6xw ) IQE ) ( 4w ( JAQ lB4 ) IQE ) 6xw lB4 $.
yB8 $a iA 2gg 2gg 6xw lB4 $.
cjA $a #Pattern ( LAQ .gk lB4 mh4 ) $.
kTA $a #Pattern ( LAQ .gk 6xw mh4 ) $.
nDA $a #Pattern ( 4w ( JAQ 2gg ) ( 4w ( SwE mh4 .gk ) IQE ) ) $.
ojA $a iA ( LAQ .gk pgg mh4 ) ( LAQ .gk lB4 mh4 ) pgg lB4 $.
pjA $a zw ( Tw ( 4w ( JAQ 2gg ) ( 4w ( SwE mh4 .gk ) IQE ) ) ( 4w ( JAQ 2gg ) ( 4w ( SwE mh4 .gk ) IQE ) ) ) $.
0zA $a zw ( Tw ( 4w ( 4w ( JAQ 2gg ) ( 4w ( SwE mh4 .gk ) IQE ) ) ( 4w ( JAQ lB4 ) IQE ) ) ( tQM 2gg ( 0wM lB4 2gg ( LAQ pwk lB4 ( LAQ .gk pwk mh4 ) ) ( LAQ .gk lB4 mh4 ) ) ) ) $.
1TA $a iA ( 0wM 6xw 2gg ( LAQ pwk 6xw ( LAQ .gk pwk mh4 ) ) ( LAQ .gk 6xw mh4 ) ) ( 0wM lB4 2gg ( LAQ pwk lB4 ( LAQ .gk pwk mh4 ) ) ( LAQ .gk lB4 mh4 ) ) 6xw lB4 $.
${ 1jA $p zw ( Tw ( 4w ( JAQ 2gg ) ( 4w ( SwE mh4 .gk ) IQE ) ) ( tQM 2gg ( 0wM pgg 2gg ( LAQ pwk pgg ( LAQ .gk pwk mh4 ) ) ( LAQ .gk pgg mh4 ) ) ) ) $=
  ( kx4 6hw Kg nDA pQg IwQ IAE 4g pgk .Qk KwQ 0gM tAM wgE mAE IQI QgQ lA Wh8 Tg
  YR8 pjA 5Q qQg 6g nAE OAM XB8 cjA dB8 kTA Xh8 PQE .x4 jQY 0zA wR8 wh8 lwQ ojA
  Ug SA jg YgQ xx8 yB8 1TA mAY ) ABFZVKGHZIJZJAUAZGVNKGLKBUCZMZMZLGVOMZNZOZVKVK
  VMABUDVKVLIVLVKVLUBVLVKUEUFUGVKIUHUIZPPGVNCUJZVNKWBVPMZCBUKZNZOZVTVNDULZVNKWG
  VPMDBUMNZOZVKWBHIJZVMWGHIJZECDVKIEUNGUOEVCWAGIEUPUQQACBURGVMVTWJWFCVDZCUSVNVS
  VNWEGWLACUTZGVNVQVRWBVNWCWDGWLGWLVEZWMKGVPKWBVPGWLKGWLRWNVPGWLRVACBVBVFSTWGWK
  WIWJWFWLDCVGVNWHVNWEWGWLADCVHADCBVISTVJQ $. $}
