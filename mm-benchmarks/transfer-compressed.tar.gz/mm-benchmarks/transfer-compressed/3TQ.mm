$c 4B4 Tw #Symbol wQM zw JAQ .gk rgk pgg #Pattern ( rwg 0wM twM LAQ tQM IAQ 5xw #Variable SwE #SetVariable 4w #ElementVariable IQE xQg ) Vhc $.
$v CQ qwg DQ Bw oAg Cw 2gg GQ $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Cg $f #Pattern Cw $.
DA $f #Pattern DQ $.
GA $f #Pattern GQ $.
Tg $a #Pattern ( Tw Bw CQ ) $.
4g $a #Pattern ( 4w Bw CQ ) $.
5Q $a zw ( Tw Bw ( Tw CQ Bw ) ) $.
${ 6A $e zw ( Tw Bw CQ ) $.
   6Q $e zw Bw $.
   6g $a zw CQ $. $}
IAE $a #Pattern IQE $.
SgE $a #Pattern ( SwE Bw CQ ) $.
lQE $a zw ( Tw Bw Bw ) $.
${ lgE $e zw ( Tw Bw CQ ) $.
   lwE $e zw ( Tw CQ Cw ) $.
   mAE $a zw ( Tw Bw Cw ) $. $}
nAE $a zw IQE $.
ugE $a zw ( Tw ( 4w Bw CQ ) Bw ) $.
${ wAE $e zw ( Tw Bw CQ ) $.
   wQE $e zw ( Tw Bw Cw ) $.
   wgE $a zw ( Tw Bw ( 4w CQ Cw ) ) $. $}
${ NwM $e zw CQ $.
   OAM $a zw ( Tw Bw CQ ) $. $}
tAM $a #Pattern ( tQM Bw CQ ) $.
uwM $a #Pattern ( twM Bw ) $.
wAM $a #Pattern ( wQM Bw CQ Cw ) $.
0gM $a #Pattern ( 0wM Bw CQ Cw DQ ) $.
HwQ $a #Pattern ( IAQ Bw CQ ) $.
IwQ $a #Pattern ( JAQ Bw ) $.
KwQ $a #Pattern ( LAQ Bw CQ Cw ) $.
LAU $a zw ( SwE ( 0wM Bw CQ Cw DQ ) CQ ) $.
${ -wU $e zw ( Tw GQ ( SwE CQ Bw ) ) $.
   AAY $e zw ( Tw GQ ( tQM Bw ( wQM Bw CQ ( twM Bw ) ) ) ) $.
   AQY $a zw ( Tw GQ ( tQM Bw CQ ) ) $. $}
nwg $f #Pattern oAg $.
pQg $a #Pattern pgg $.
qgg $f #Pattern qwg $.
rgg $a #Pattern ( rwg oAg qwg ) $.
xAg $a #Pattern xQg $.
2Qg $f #ElementVariable 2gg $.
rQk $a #Pattern rgk $.
.Qk $a #Pattern .gk $.
VRc $a #Pattern ( Vhc oAg ) $.
5hw $a #Pattern 5xw $.
3x4 $a #Pattern 4B4 $.
Wh8 $a #Pattern 2gg $.
9h8 $a zw ( Tw ( 4w ( JAQ 2gg ) IQE ) ( 4w ( JAQ 2gg ) IQE ) ) $.
3DQ $a zw ( Tw ( 4w ( JAQ 2gg ) IQE ) ( tQM 2gg ( wQM 2gg ( 0wM .gk 2gg ( Vhc ( rwg ( LAQ rgk pgg ( IAQ rgk 4B4 ) ) xQg ) ) ( IAQ .gk 5xw ) ) ( twM 2gg ) ) ) ) $.
${ 3TQ $p zw ( Tw ( 4w ( JAQ 2gg ) IQE ) ( tQM 2gg ( 0wM .gk 2gg ( Vhc ( rwg ( LAQ rgk pgg ( IAQ rgk 4B4 ) ) xQg ) ) ( IAQ .gk 5xw ) ) ) ) $=
  ( Wh8 IwQ IAE 4g .Qk rQk pQg 3x4 HwQ KwQ xAg rgg VRc tAM nAE OAM wgE ugE mAE
  5hw 0gM 9h8 SgE Tg 5Q LAU 6g uwM wAM lQE 3DQ AQY ) ABZCZDEZUPUPDEZEZUNFUNGHGI
  JKLMNZFUAJZUBZOUPUPUQAUCZUPUPDVBUPDPQRRUNVAURVAUNUDZURVCUEVCURUFFUNUSUTUGUHUR
  UPUNUNVAUNUIUJOURUODURUPUOUPUQSUPUOUOUODSUOUKTTURDPQRAULTUMT $. $}
