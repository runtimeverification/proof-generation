$c Uw PgE Tw #Symbol cwE zw JAQ pgg rgk #Pattern ( 0wM LAQ tQM IAQ 0h4 #Variable SwE #SetVariable 4w rwM #ElementVariable IQE ) $.
$v yhs CQ Bw Kw ph1 ph0 Cw 2gg GQ x $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Cg $f #Pattern Cw $.
GA $f #Pattern GQ $.
Kg $f #ElementVariable Kw $.
Ug $a #Pattern ( Uw Kw Bw ) $.
4g $a #Pattern ( 4w Bw CQ ) $.
IAE $a #Pattern IQE $.
PQE $a #Pattern ( PgE Bw CQ ) $.
${ lgE $e zw ( Tw Bw CQ ) $.
   lwE $e zw ( Tw CQ Cw ) $.
   mAE $a zw ( Tw Bw Cw ) $. $}
nAE $a zw IQE $.
${ NwM $e zw CQ $.
   OAM $a zw ( Tw Bw CQ ) $. $}
HwQ $a #Pattern ( IAQ Bw CQ ) $.
IwQ $a #Pattern ( JAQ Bw ) $.
KwQ $a #Pattern ( LAQ Bw CQ Cw ) $.
${ $d x ph0 $.
   $d x ph1 $.
   vwY $e zw ( Tw GQ ( SwE CQ Bw ) ) $.
   wAY $e zw ( Tw GQ ( tQM cwE ( rwM Bw cwE Kw ( 0wM Bw cwE Kw CQ ) ) ) ) $.
   wQY $a zw ( Tw GQ ( Uw Kw ( PgE Kw CQ ) ) ) $. $}
pQg $a #Pattern pgg $.
2Qg $f #ElementVariable 2gg $.
rQk $a #Pattern rgk $.
yRs $f #ElementVariable yhs $.
0R4 $a #Pattern 0h4 $.
Rh8 $a zw ( Tw IQE ( SwE ( LAQ rgk pgg ( IAQ rgk 0h4 ) ) pgg ) ) $.
Wh8 $a #Pattern 2gg $.
7SA $a #Pattern yhs $.
0yk $a zw ( Tw IQE ( tQM cwE ( rwM pgg cwE yhs ( 0wM pgg cwE yhs ( LAQ rgk pgg ( IAQ rgk 0h4 ) ) ) ) ) ) $.
${ 1Ck $p zw ( Tw ( 4w ( JAQ 2gg ) IQE ) ( Uw yhs ( PgE yhs ( LAQ rgk pgg ( IAQ rgk 0h4 ) ) ) ) ) $=
  ( Wh8 IwQ IAE 4g 7SA rQk pQg 0R4 HwQ KwQ PQE Ug nAE OAM Rh8 0yk wQY mAE ) ACD
  EFZEBGHIHJKLZMBNUAEOPIUBEBQBRST $. $}
