$c Tw #Symbol 5x4 zw JAQ pgg rgk #Pattern ( LAQ IAQ #Variable SwE #SetVariable 4w #ElementVariable IQE mwg xQg ) $.
$v Cw 2gg CQ Bw $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Cg $f #Pattern Cw $.
4g $a #Pattern ( 4w Bw CQ ) $.
IAE $a #Pattern IQE $.
SgE $a #Pattern ( SwE Bw CQ ) $.
${ wAE $e zw ( Tw Bw CQ ) $.
   wQE $e zw ( Tw Bw Cw ) $.
   wgE $a zw ( Tw Bw ( 4w CQ Cw ) ) $. $}
HwQ $a #Pattern ( IAQ Bw CQ ) $.
IwQ $a #Pattern ( JAQ Bw ) $.
KwQ $a #Pattern ( LAQ Bw CQ Cw ) $.
mgg $a #Pattern mwg $.
pQg $a #Pattern pgg $.
xAg $a #Pattern xQg $.
2Qg $f #ElementVariable 2gg $.
rQk $a #Pattern rgk $.
5h4 $a #Pattern 5x4 $.
Wh8 $a #Pattern 2gg $.
7iQ $a zw ( Tw ( 4w ( JAQ 2gg ) IQE ) ( SwE xQg mwg ) ) $.
Rio $a zw ( Tw ( 4w ( JAQ 2gg ) IQE ) ( SwE ( LAQ rgk pgg ( IAQ rgk 5x4 ) ) pgg ) ) $.
${ 0TI $p zw ( Tw ( 4w ( JAQ 2gg ) IQE ) ( 4w ( SwE ( LAQ rgk pgg ( IAQ rgk 5x4 ) ) pgg ) ( SwE xQg mwg ) ) ) $=
  ( Wh8 IwQ IAE 4g rQk pQg 5h4 HwQ KwQ SgE xAg mgg Rio 7iQ wgE ) ABCDEFGFHIJGKL
  MKANAOP $. $}
