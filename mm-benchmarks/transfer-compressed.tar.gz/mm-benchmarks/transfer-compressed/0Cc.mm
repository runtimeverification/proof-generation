$c ewk xB4 IAQ #Symbol #Variable #SetVariable iA #ElementVariable #Pattern ) ( $.
$v Ow CQ xX zBs Bw Kw ph0 2gg $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Kg $f #ElementVariable Kw $.
Og $f #Variable Ow $.
SA $a #Variable Kw $.
${ $d xX ph0 $.
   IQI $a iA Bw Bw CQ Ow $. $}
HwQ $a #Pattern ( IAQ Bw CQ ) $.
2Qg $f #ElementVariable 2gg $.
egk $a #Pattern ewk $.
yxs $f #ElementVariable zBs $.
wx4 $a #Pattern xB4 $.
Wh8 $a #Pattern 2gg $.
${ 0Cc $p iA 2gg 2gg ( IAQ ewk xB4 ) zBs $=
  ( Wh8 egk wx4 HwQ SA IQI ) ACDEFBGH $. $}
