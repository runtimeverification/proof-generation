$c XBI Lwk Tw #Symbol 7h4 1CA zw rgk pgg #Pattern ( rwg Ex0 LAQ ewk xB4 IAQ Wgk Hg8 #Variable SwE #SetVariable 4w #ElementVariable IQE 8wk mwg xQg ) $.
$v oAg Cw CQ qwg Bw $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Cg $f #Pattern Cw $.
4g $a #Pattern ( 4w Bw CQ ) $.
IAE $a #Pattern IQE $.
SgE $a #Pattern ( SwE Bw CQ ) $.
${ lgE $e zw ( Tw Bw CQ ) $.
   lwE $e zw ( Tw CQ Cw ) $.
   mAE $a zw ( Tw Bw Cw ) $. $}
${ wAE $e zw ( Tw Bw CQ ) $.
   wQE $e zw ( Tw Bw Cw ) $.
   wgE $a zw ( Tw Bw ( 4w CQ Cw ) ) $. $}
HwQ $a #Pattern ( IAQ Bw CQ ) $.
KwQ $a #Pattern ( LAQ Bw CQ Cw ) $.
mgg $a #Pattern mwg $.
nwg $f #Pattern oAg $.
pQg $a #Pattern pgg $.
qgg $f #Pattern qwg $.
rgg $a #Pattern ( rwg oAg qwg ) $.
wQg $a zw ( Tw ( 4w ( SwE oAg pgg ) ( SwE qwg mwg ) ) ( SwE ( rwg oAg qwg ) mwg ) ) $.
xAg $a #Pattern xQg $.
Lgk $a #Pattern Lwk $.
WQk $a #Pattern Wgk $.
egk $a #Pattern ewk $.
rQk $a #Pattern rgk $.
8gk $a #Pattern 8wk $.
HQ8 $a #Pattern ( Hg8 oAg ) $.
Jw8 $a zw ( Tw ( SwE oAg mwg ) ( SwE ( Hg8 oAg ) Lwk ) ) $.
WxI $a #Pattern ( XBI oAg qwg ) $.
Eh0 $a #Pattern Ex0 $.
wx4 $a #Pattern xB4 $.
7R4 $a #Pattern 7h4 $.
dCA $a zw ( Tw IQE ( SwE ( rwg ( LAQ 8wk pgg ( XBI ( IAQ ewk xB4 ) ( LAQ rgk Wgk ( IAQ rgk Ex0 ) ) ) ) xQg ) mwg ) ) $.
0yA $a #Pattern 1CA $.
3iA $a zw ( Tw IQE ( SwE ( LAQ 8wk pgg ( XBI ( IAQ ewk 7h4 ) ( LAQ rgk Wgk ( IAQ rgk 1CA ) ) ) ) pgg ) ) $.
${ 3yA $p zw ( Tw IQE ( SwE ( Hg8 ( rwg ( LAQ 8wk pgg ( XBI ( IAQ ewk 7h4 ) ( LAQ rgk Wgk ( IAQ rgk 1CA ) ) ) ) ( rwg ( LAQ 8wk pgg ( XBI ( IAQ ewk xB4 ) ( LAQ rgk Wgk ( IAQ rgk Ex0 ) ) ) ) xQg ) ) ) Lwk ) ) $=
  ( IAE 8gk pQg egk 7R4 HwQ rQk WQk 0yA KwQ WxI wx4 Eh0 xAg rgg mgg SgE HQ8 Lgk
  mAE 4g 3iA dCA wgE wQg Jw8 ) ABCDEFGHGIFJKJZBCDLFGHGMFJKJNOZOZPQZUIRSQAUGCQZU
  HPQZUAUJAUKULUBUCUDUGUHUETUIUFT $. $}
