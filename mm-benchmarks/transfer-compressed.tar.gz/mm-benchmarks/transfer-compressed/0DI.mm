$c 0wM tQM #Symbol #Variable #SetVariable iA rwM jww #ElementVariable pgg #Pattern ) ( $.
$v yhs Ow CQ DQ Bw Kw Cw 2gg nR4 -Rs Dw $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Cg $f #Pattern Cw $.
DA $f #Pattern DQ $.
Dg $f #Pattern Dw $.
Kg $f #ElementVariable Kw $.
Og $f #Variable Ow $.
SA $a #Variable Kw $.
rgM $a #Pattern ( rwM Bw CQ Kw Cw ) $.
${ QAQ $e iA Bw Cw Dw Ow $.
   QQQ $e iA CQ DQ Dw Ow $.
   QgQ $a iA ( tQM Bw CQ ) ( tQM Cw DQ ) Dw Ow $. $}
pQg $a #Pattern pgg $.
2Qg $f #ElementVariable 2gg $.
yRs $f #ElementVariable yhs $.
-Bs $f #ElementVariable -Rs $.
nB4 $f #ElementVariable nR4 $.
Wh8 $a #Pattern 2gg $.
6h8 $a #Pattern nR4 $.
UyE $a iA 2gg 2gg nR4 -Rs $.
yjI $a #Pattern ( 0wM pgg 2gg yhs ( jww -Rs ) ) $.
zDI $a #Pattern ( 0wM pgg 2gg yhs ( jww nR4 ) ) $.
zzI $a iA ( rwM pgg 2gg yhs ( 0wM pgg 2gg yhs ( jww nR4 ) ) ) ( rwM pgg 2gg yhs ( 0wM pgg 2gg yhs ( jww -Rs ) ) ) nR4 -Rs $.
${ 0DI $p iA ( tQM 2gg ( rwM pgg 2gg yhs ( 0wM pgg 2gg yhs ( jww nR4 ) ) ) ) ( tQM 2gg ( rwM pgg 2gg yhs ( 0wM pgg 2gg yhs ( jww -Rs ) ) ) ) nR4 -Rs $=
  ( Wh8 pQg zDI rgM yjI 6h8 SA UyE zzI QgQ ) AEZFOABDGBHOFOABCIBHDJCKACDLABCDMN
  $. $}
