$c #SetVariable ) #ElementVariable #Symbol #Variable #Pattern ( $.
$v Ow 6gg Kw $.
Kg $f #ElementVariable Kw $.
Og $f #Variable Ow $.
SA $a #Variable Kw $.
Sg $a #Pattern Ow $.
6Qg $f #ElementVariable 6gg $.
${ -yA $p #Pattern 6gg $=
  ( SA Sg ) ABC $. $}
