$c LAQ 1wk #Symbol #Variable #SetVariable iA #ElementVariable pgg #Pattern ) ( $.
$v Ow CQ zBs DQ Ew Bw Kw Cw nR4 EQ Dw $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Cg $f #Pattern Cw $.
DA $f #Pattern DQ $.
Dg $f #Pattern Dw $.
EA $f #Pattern EQ $.
Eg $f #Pattern Ew $.
Kg $f #ElementVariable Kw $.
Og $f #Variable Ow $.
SA $a #Variable Kw $.
jg $a iA Bw Ow Bw Ow $.
${ lAQ $e iA Bw DQ Ew Ow $.
   lQQ $e iA CQ Dw Ew Ow $.
   lgQ $e iA Cw EQ Ew Ow $.
   lwQ $a iA ( LAQ Bw CQ Cw ) ( LAQ DQ Dw EQ ) Ew Ow $. $}
pQg $a #Pattern pgg $.
1gk $a #Pattern 1wk $.
yxs $f #ElementVariable zBs $.
nB4 $f #ElementVariable nR4 $.
6h8 $a #Pattern nR4 $.
JiE $a #Pattern zBs $.
NiE $a iA pgg pgg nR4 zBs $.
1yM $a iA 1wk 1wk nR4 zBs $.
${ 2iM $p iA ( LAQ 1wk pgg nR4 ) ( LAQ 1wk pgg zBs ) nR4 zBs $=
  ( 1gk pQg 6h8 JiE SA 1yM NiE jg lwQ ) CDBEZCDAFLAGZABHABILMJK $. $}
