$c 4B4 Ngk Lwk #Symbol 7h4 ZAE 8Q4 BA0 zw xwM pgg #Pattern 0Q4 rwg Ex0 0wM xB4 tQM Wgk 0h4 MAQ 5xw #Variable SwE PQk #SetVariable vR4 4w #ElementVariable IQE 8hw xQg cBQ lSA 2R4 XBI RAk Tw 1CA wQM -g4 .gk -QM rgk ( twM .gM LAQ ewk yx4 IAQ 9R4 Hg8 Kw8 8wk 7Ak 7BI ) $.
$v CQ qwg DQ Bw oAg Cw GQ Dw $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Cg $f #Pattern Cw $.
DA $f #Pattern DQ $.
Dg $f #Pattern Dw $.
GA $f #Pattern GQ $.
4g $a #Pattern ( 4w Bw CQ ) $.
${ 6A $e zw ( Tw Bw CQ ) $.
   6Q $e zw Bw $.
   6g $a zw CQ $. $}
IAE $a #Pattern IQE $.
SgE $a #Pattern ( SwE Bw CQ ) $.
${ lgE $e zw ( Tw Bw CQ ) $.
   lwE $e zw ( Tw CQ Cw ) $.
   mAE $a zw ( Tw Bw Cw ) $. $}
nAE $a zw IQE $.
${ wAE $e zw ( Tw Bw CQ ) $.
   wQE $e zw ( Tw Bw Cw ) $.
   wgE $a zw ( Tw Bw ( 4w CQ Cw ) ) $. $}
${ NwM $e zw CQ $.
   OAM $a zw ( Tw Bw CQ ) $. $}
tAM $a #Pattern ( tQM Bw CQ ) $.
uwM $a #Pattern ( twM Bw ) $.
wAM $a #Pattern ( wQM Bw CQ Cw ) $.
xgM $a #Pattern ( xwM Bw CQ Cw ) $.
0gM $a #Pattern ( 0wM Bw CQ Cw DQ ) $.
HwQ $a #Pattern ( IAQ Bw CQ ) $.
KwQ $a #Pattern ( LAQ Bw CQ Cw ) $.
FgU $a zw ( ZAE IQE ) $.
JwU $a zw ( Tw ( 4w ( SwE CQ Bw ) ( SwE Cw Bw ) ) ( SwE ( wQM Bw CQ Cw ) Bw ) ) $.
${ fQU $e zw ( Tw GQ ( SwE CQ Bw ) ) $.
   fgU $e zw ( Tw GQ ( SwE Cw Bw ) ) $.
   fwU $a zw ( Tw GQ ( tQM Bw ( xwM Bw ( wQM Bw CQ Cw ) Cw ) ) ) $. $}
${ nwU $e zw ( SwE CQ Bw ) $.
   oAU $a zw ( tQM Bw ( xwM Bw CQ CQ ) ) $. $}
${ sgU $e zw ( Tw GQ ( SwE CQ Bw ) ) $.
   swU $a zw ( Tw GQ ( tQM Bw ( xwM Bw CQ CQ ) ) ) $. $}
${ 2AU $e zw ( Tw GQ ( SwE CQ Bw ) ) $.
   2QU $e zw ( Tw GQ ( SwE Cw Bw ) ) $.
   2gU $e zw ( Tw GQ ( SwE DQ Bw ) ) $.
   2wU $e zw ( Tw GQ ( SwE Dw Bw ) ) $.
   3AU $e zw ( Tw GQ ( tQM Bw ( xwM Bw CQ Cw ) ) ) $.
   3QU $e zw ( Tw GQ ( tQM Bw ( xwM Bw DQ Dw ) ) ) $.
   3gU $a zw ( Tw GQ ( tQM Bw ( xwM Bw ( wQM Bw CQ DQ ) ( wQM Bw Cw Dw ) ) ) ) $. $}
${ MQY $e zw ( MAQ Bw CQ ) $.
   MgY $e zw ( MAQ Bw Cw ) $.
   MwY $a zw ( MAQ Bw ( wQM Bw CQ Cw ) ) $. $}
NQY $a zw ( MAQ Bw ( twM Bw ) ) $.
${ hAc $e zw ( Tw GQ ( tQM Bw ( xwM Bw CQ Cw ) ) ) $.
   hQc $e zw ( Tw GQ ( tQM Bw ( -QM Bw Cw DQ ) ) ) $.
   hgc $a zw ( Tw GQ ( tQM Bw ( -QM Bw CQ DQ ) ) ) $. $}
${ pgc $e zw ( Tw GQ ( tQM Bw ( xwM Bw CQ Cw ) ) ) $.
   pwc $e zw ( Tw GQ ( tQM Bw ( .gM Bw Cw DQ ) ) ) $.
   qAc $a zw ( Tw GQ ( tQM Bw ( .gM Bw CQ DQ ) ) ) $. $}
${ qQc $e zw ( ZAE GQ ) $.
   qgc $e zw ( Tw GQ ( SwE Cw Bw ) ) $.
   qwc $e zw ( Tw GQ ( SwE DQ Bw ) ) $.
   rAc $e zw ( Tw GQ ( tQM Bw ( .gM Bw CQ Cw ) ) ) $.
   rQc $e zw ( Tw GQ ( tQM Bw ( xwM Bw Cw DQ ) ) ) $.
   rgc $a zw ( Tw GQ ( tQM Bw ( .gM Bw CQ DQ ) ) ) $. $}
${ twc $e zw ( MAQ Bw CQ ) $.
   uAc $e zw ( Tw GQ ( SwE CQ Bw ) ) $.
   uQc $e zw ( Tw GQ ( SwE Cw Bw ) ) $.
   ugc $e zw ( Tw GQ ( SwE DQ Bw ) ) $.
   uwc $e zw ( Tw GQ ( tQM Bw ( .gM Bw ( wQM Bw CQ Cw ) DQ ) ) ) $.
   vAc $a zw ( Tw GQ ( tQM Bw ( .gM Bw ( wQM Bw CQ Cw ) ( wQM Bw CQ DQ ) ) ) ) $. $}
${ 0Qc $e zw ( Tw GQ ( SwE CQ Bw ) ) $.
   0gc $e zw ( Tw GQ ( SwE Cw Bw ) ) $.
   0wc $e zw ( Tw GQ ( tQM Bw ( .gM Bw CQ Cw ) ) ) $.
   1Ac $a zw ( Tw GQ ( tQM Bw ( -QM Bw CQ Cw ) ) ) $. $}
nwg $f #Pattern oAg $.
pQg $a #Pattern pgg $.
qgg $f #Pattern qwg $.
rgg $a #Pattern ( rwg oAg qwg ) $.
xAg $a #Pattern xQg $.
Lgk $a #Pattern Lwk $.
NQk $a #Pattern Ngk $.
PAk $a #Pattern PQk $.
Qwk $a #Pattern RAk $.
WQk $a #Pattern Wgk $.
egk $a #Pattern ewk $.
rQk $a #Pattern rgk $.
6wk $a #Pattern 7Ak $.
8gk $a #Pattern 8wk $.
.Qk $a #Pattern .gk $.
Aw0 $a #Pattern ( BA0 oAg ) $.
0A4 $a #Pattern ( 0Q4 oAg qwg ) $.
3Q4 $a zw ( Tw ( 4w ( SwE oAg Lwk ) ( SwE qwg PQk ) ) ( SwE ( 0Q4 oAg qwg ) 7Ak ) ) $.
8A4 $a #Pattern ( 8Q4 oAg ) $.
-Q4 $a #Pattern ( -g4 oAg qwg ) $.
Cg8 $a zw ( Tw ( 4w ( SwE oAg 7Ak ) ( SwE qwg RAk ) ) ( SwE ( -g4 oAg qwg ) Ngk ) ) $.
HQ8 $a #Pattern ( Hg8 oAg ) $.
Kg8 $a #Pattern ( Kw8 oAg ) $.
WxI $a #Pattern ( XBI oAg qwg ) $.
6xI $a #Pattern ( 7BI oAg qwg ) $.
bxQ $a #Pattern ( cBQ oAg qwg ) $.
5hw $a #Pattern 5xw $.
8Rw $a #Pattern 8hw $.
Eh0 $a #Pattern Ex0 $.
vB4 $a #Pattern vR4 $.
wx4 $a #Pattern xB4 $.
yh4 $a #Pattern yx4 $.
0R4 $a #Pattern 0h4 $.
2B4 $a #Pattern 2R4 $.
3x4 $a #Pattern 4B4 $.
7R4 $a #Pattern 7h4 $.
9B4 $a #Pattern 9R4 $.
.R4 $a zw ( Tw IQE ( SwE ( twM Ngk ) Ngk ) ) $.
Kx8 $a zw ( Tw IQE ( SwE ( 8Q4 ( IAQ rgk 8hw ) ) RAk ) ) $.
lCA $a #Pattern lSA $.
qSA $a zw ( Tw IQE ( SwE ( Kw8 ( 7BI ( cBQ ( LAQ ewk pgg ( IAQ ewk xB4 ) ) ( LAQ rgk pgg ( IAQ rgk 8hw ) ) ) ( 7BI ( cBQ ( LAQ ewk pgg ( IAQ ewk vR4 ) ) ( LAQ rgk pgg ( IAQ rgk lSA ) ) ) ( 7BI ( cBQ ( LAQ ewk pgg ( IAQ ewk 9R4 ) ) ( LAQ rgk pgg ( IAQ rgk yx4 ) ) ) ( 7BI ( cBQ ( LAQ ewk pgg ( IAQ ewk 7h4 ) ) ( LAQ rgk pgg ( IAQ rgk 4B4 ) ) ) ( cBQ ( LAQ ewk pgg ( IAQ ewk 2R4 ) ) ( LAQ rgk pgg ( IAQ rgk 0h4 ) ) ) ) ) ) ) ) PQk ) ) $.
0yA $a #Pattern 1CA $.
3yA $a zw ( Tw IQE ( SwE ( Hg8 ( rwg ( LAQ 8wk pgg ( XBI ( IAQ ewk 7h4 ) ( LAQ rgk Wgk ( IAQ rgk 1CA ) ) ) ) ( rwg ( LAQ 8wk pgg ( XBI ( IAQ ewk xB4 ) ( LAQ rgk Wgk ( IAQ rgk Ex0 ) ) ) ) xQg ) ) ) Lwk ) ) $.
njU $a zw ( Tw IQE ( SwE ( Hg8 ( rwg ( LAQ rgk pgg ( IAQ rgk 1CA ) ) ( rwg ( BA0 ( rwg ( LAQ ewk pgg ( IAQ ewk 7h4 ) ) xQg ) ) ( rwg ( LAQ 8wk pgg ( XBI ( IAQ ewk xB4 ) ( LAQ rgk Wgk ( IAQ rgk Ex0 ) ) ) ) xQg ) ) ) ) Lwk ) ) $.
9DU $a zw ( Tw IQE ( tQM Ngk ( .gM Ngk ( wQM Ngk ( 0wM .gk Ngk ( IAQ .gk 5xw ) ( IAQ .gk 5xw ) ) ( -g4 ( 0Q4 ( Hg8 ( rwg ( wQM pgg ( LAQ Wgk pgg ( LAQ rgk Wgk ( IAQ rgk 1CA ) ) ) ( LAQ rgk pgg ( IAQ rgk 1CA ) ) ) ( rwg ( BA0 ( rwg ( LAQ ewk pgg ( IAQ ewk 7h4 ) ) xQg ) ) ( rwg ( LAQ 8wk pgg ( XBI ( IAQ ewk xB4 ) ( LAQ rgk Wgk ( IAQ rgk Ex0 ) ) ) ) xQg ) ) ) ) ( Kw8 ( 7BI ( cBQ ( LAQ ewk pgg ( IAQ ewk xB4 ) ) ( LAQ rgk pgg ( IAQ rgk 8hw ) ) ) ( 7BI ( cBQ ( LAQ ewk pgg ( IAQ ewk vR4 ) ) ( LAQ rgk pgg ( IAQ rgk lSA ) ) ) ( 7BI ( cBQ ( LAQ ewk pgg ( IAQ ewk 9R4 ) ) ( LAQ rgk pgg ( IAQ rgk yx4 ) ) ) ( 7BI ( cBQ ( LAQ ewk pgg ( IAQ ewk 7h4 ) ) ( LAQ rgk pgg ( IAQ rgk 4B4 ) ) ) ( cBQ ( LAQ ewk pgg ( IAQ ewk 2R4 ) ) ( LAQ rgk pgg ( IAQ rgk 0h4 ) ) ) ) ) ) ) ) ) ( 8Q4 ( IAQ rgk 8hw ) ) ) ) ( wQM Ngk ( twM Ngk ) ( -g4 ( 0Q4 ( Hg8 ( rwg ( LAQ 8wk pgg ( XBI ( IAQ ewk 7h4 ) ( LAQ rgk Wgk ( IAQ rgk 1CA ) ) ) ) ( rwg ( LAQ 8wk pgg ( XBI ( IAQ ewk xB4 ) ( LAQ rgk Wgk ( IAQ rgk Ex0 ) ) ) ) xQg ) ) ) ( Kw8 ( 7BI ( cBQ ( LAQ ewk pgg ( IAQ ewk xB4 ) ) ( LAQ rgk pgg ( IAQ rgk 8hw ) ) ) ( 7BI ( cBQ ( LAQ ewk pgg ( IAQ ewk vR4 ) ) ( LAQ rgk pgg ( IAQ rgk lSA ) ) ) ( 7BI ( cBQ ( LAQ ewk pgg ( IAQ ewk 9R4 ) ) ( LAQ rgk pgg ( IAQ rgk yx4 ) ) ) ( 7BI ( cBQ ( LAQ ewk pgg ( IAQ ewk 7h4 ) ) ( LAQ rgk pgg ( IAQ rgk 4B4 ) ) ) ( cBQ ( LAQ ewk pgg ( IAQ ewk 2R4 ) ) ( LAQ rgk pgg ( IAQ rgk 0h4 ) ) ) ) ) ) ) ) ) ( 8Q4 ( IAQ rgk 8hw ) ) ) ) ) ) ) $.
-DU $a zw ( Tw IQE ( tQM Ngk ( xwM Ngk ( wQM Ngk ( wQM Ngk ( twM Ngk ) ( twM Ngk ) ) ( -g4 ( 0Q4 ( Hg8 ( rwg ( LAQ rgk pgg ( IAQ rgk 1CA ) ) ( rwg ( BA0 ( rwg ( LAQ ewk pgg ( IAQ ewk 7h4 ) ) xQg ) ) ( rwg ( LAQ 8wk pgg ( XBI ( IAQ ewk xB4 ) ( LAQ rgk Wgk ( IAQ rgk Ex0 ) ) ) ) xQg ) ) ) ) ( Kw8 ( 7BI ( cBQ ( LAQ ewk pgg ( IAQ ewk xB4 ) ) ( LAQ rgk pgg ( IAQ rgk 8hw ) ) ) ( 7BI ( cBQ ( LAQ ewk pgg ( IAQ ewk vR4 ) ) ( LAQ rgk pgg ( IAQ rgk lSA ) ) ) ( 7BI ( cBQ ( LAQ ewk pgg ( IAQ ewk 9R4 ) ) ( LAQ rgk pgg ( IAQ rgk yx4 ) ) ) ( 7BI ( cBQ ( LAQ ewk pgg ( IAQ ewk 7h4 ) ) ( LAQ rgk pgg ( IAQ rgk 4B4 ) ) ) ( cBQ ( LAQ ewk pgg ( IAQ ewk 2R4 ) ) ( LAQ rgk pgg ( IAQ rgk 0h4 ) ) ) ) ) ) ) ) ) ( 8Q4 ( IAQ rgk 8hw ) ) ) ) ( wQM Ngk ( 0wM .gk Ngk ( IAQ .gk 5xw ) ( IAQ .gk 5xw ) ) ( -g4 ( 0Q4 ( Hg8 ( rwg ( wQM pgg ( LAQ Wgk pgg ( LAQ rgk Wgk ( IAQ rgk 1CA ) ) ) ( LAQ rgk pgg ( IAQ rgk 1CA ) ) ) ( rwg ( BA0 ( rwg ( LAQ ewk pgg ( IAQ ewk 7h4 ) ) xQg ) ) ( rwg ( LAQ 8wk pgg ( XBI ( IAQ ewk xB4 ) ( LAQ rgk Wgk ( IAQ rgk Ex0 ) ) ) ) xQg ) ) ) ) ( Kw8 ( 7BI ( cBQ ( LAQ ewk pgg ( IAQ ewk xB4 ) ) ( LAQ rgk pgg ( IAQ rgk 8hw ) ) ) ( 7BI ( cBQ ( LAQ ewk pgg ( IAQ ewk vR4 ) ) ( LAQ rgk pgg ( IAQ rgk lSA ) ) ) ( 7BI ( cBQ ( LAQ ewk pgg ( IAQ ewk 9R4 ) ) ( LAQ rgk pgg ( IAQ rgk yx4 ) ) ) ( 7BI ( cBQ ( LAQ ewk pgg ( IAQ ewk 7h4 ) ) ( LAQ rgk pgg ( IAQ rgk 4B4 ) ) ) ( cBQ ( LAQ ewk pgg ( IAQ ewk 2R4 ) ) ( LAQ rgk pgg ( IAQ rgk 0h4 ) ) ) ) ) ) ) ) ) ( 8Q4 ( IAQ rgk 8hw ) ) ) ) ) ) ) $.
-TU $a zw ( Tw IQE ( tQM Ngk ( xwM Ngk ( wQM Ngk ( wQM Ngk ( twM Ngk ) ( twM Ngk ) ) ( -g4 ( 0Q4 ( Hg8 ( rwg ( LAQ 8wk pgg ( XBI ( IAQ ewk 7h4 ) ( LAQ rgk Wgk ( IAQ rgk 1CA ) ) ) ) ( rwg ( LAQ 8wk pgg ( XBI ( IAQ ewk xB4 ) ( LAQ rgk Wgk ( IAQ rgk Ex0 ) ) ) ) xQg ) ) ) ( Kw8 ( 7BI ( cBQ ( LAQ ewk pgg ( IAQ ewk xB4 ) ) ( LAQ rgk pgg ( IAQ rgk 8hw ) ) ) ( 7BI ( cBQ ( LAQ ewk pgg ( IAQ ewk vR4 ) ) ( LAQ rgk pgg ( IAQ rgk lSA ) ) ) ( 7BI ( cBQ ( LAQ ewk pgg ( IAQ ewk 9R4 ) ) ( LAQ rgk pgg ( IAQ rgk yx4 ) ) ) ( 7BI ( cBQ ( LAQ ewk pgg ( IAQ ewk 7h4 ) ) ( LAQ rgk pgg ( IAQ rgk 4B4 ) ) ) ( cBQ ( LAQ ewk pgg ( IAQ ewk 2R4 ) ) ( LAQ rgk pgg ( IAQ rgk 0h4 ) ) ) ) ) ) ) ) ) ( 8Q4 ( IAQ rgk 8hw ) ) ) ) ( wQM Ngk ( wQM Ngk ( twM Ngk ) ( twM Ngk ) ) ( -g4 ( 0Q4 ( Hg8 ( rwg ( LAQ 8wk pgg ( XBI ( IAQ ewk 7h4 ) ( LAQ rgk Wgk ( IAQ rgk 1CA ) ) ) ) ( rwg ( LAQ 8wk pgg ( XBI ( IAQ ewk xB4 ) ( LAQ rgk Wgk ( IAQ rgk Ex0 ) ) ) ) xQg ) ) ) ( Kw8 ( 7BI ( cBQ ( LAQ ewk pgg ( IAQ ewk xB4 ) ) ( LAQ rgk pgg ( IAQ rgk 8hw ) ) ) ( 7BI ( cBQ ( LAQ ewk pgg ( IAQ ewk vR4 ) ) ( LAQ rgk pgg ( IAQ rgk lSA ) ) ) ( 7BI ( cBQ ( LAQ ewk pgg ( IAQ ewk 9R4 ) ) ( LAQ rgk pgg ( IAQ rgk yx4 ) ) ) ( 7BI ( cBQ ( LAQ ewk pgg ( IAQ ewk 7h4 ) ) ( LAQ rgk pgg ( IAQ rgk 4B4 ) ) ) ( cBQ ( LAQ ewk pgg ( IAQ ewk 2R4 ) ) ( LAQ rgk pgg ( IAQ rgk 0h4 ) ) ) ) ) ) ) ) ) ( 8Q4 ( IAQ rgk 8hw ) ) ) ) ) ) ) $.
${ -jU $p zw ( Tw IQE ( tQM Ngk ( -QM Ngk ( wQM Ngk ( wQM Ngk ( twM Ngk ) ( twM Ngk ) ) ( -g4 ( 0Q4 ( Hg8 ( rwg ( LAQ rgk pgg ( IAQ rgk 1CA ) ) ( rwg ( BA0 ( rwg ( LAQ ewk pgg ( IAQ ewk 7h4 ) ) xQg ) ) ( rwg ( LAQ 8wk pgg ( XBI ( IAQ ewk xB4 ) ( LAQ rgk Wgk ( IAQ rgk Ex0 ) ) ) ) xQg ) ) ) ) ( Kw8 ( 7BI ( cBQ ( LAQ ewk pgg ( IAQ ewk xB4 ) ) ( LAQ rgk pgg ( IAQ rgk 8hw ) ) ) ( 7BI ( cBQ ( LAQ ewk pgg ( IAQ ewk vR4 ) ) ( LAQ rgk pgg ( IAQ rgk lSA ) ) ) ( 7BI ( cBQ ( LAQ ewk pgg ( IAQ ewk 9R4 ) ) ( LAQ rgk pgg ( IAQ rgk yx4 ) ) ) ( 7BI ( cBQ ( LAQ ewk pgg ( IAQ ewk 7h4 ) ) ( LAQ rgk pgg ( IAQ rgk 4B4 ) ) ) ( cBQ ( LAQ ewk pgg ( IAQ ewk 2R4 ) ) ( LAQ rgk pgg ( IAQ rgk 0h4 ) ) ) ) ) ) ) ) ) ( 8Q4 ( IAQ rgk 8hw ) ) ) ) ( wQM Ngk ( wQM Ngk ( twM Ngk ) ( twM Ngk ) ) ( -g4 ( 0Q4 ( Hg8 ( rwg ( LAQ 8wk pgg ( XBI ( IAQ ewk 7h4 ) ( LAQ rgk Wgk ( IAQ rgk 1CA ) ) ) ) ( rwg ( LAQ 8wk pgg ( XBI ( IAQ ewk xB4 ) ( LAQ rgk Wgk ( IAQ rgk Ex0 ) ) ) ) xQg ) ) ) ( Kw8 ( 7BI ( cBQ ( LAQ ewk pgg ( IAQ ewk xB4 ) ) ( LAQ rgk pgg ( IAQ rgk 8hw ) ) ) ( 7BI ( cBQ ( LAQ ewk pgg ( IAQ ewk vR4 ) ) ( LAQ rgk pgg ( IAQ rgk lSA ) ) ) ( 7BI ( cBQ ( LAQ ewk pgg ( IAQ ewk 9R4 ) ) ( LAQ rgk pgg ( IAQ rgk yx4 ) ) ) ( 7BI ( cBQ ( LAQ ewk pgg ( IAQ ewk 7h4 ) ) ( LAQ rgk pgg ( IAQ rgk 4B4 ) ) ) ( cBQ ( LAQ ewk pgg ( IAQ ewk 2R4 ) ) ( LAQ rgk pgg ( IAQ rgk 0h4 ) ) ) ) ) ) ) ) ) ( 8Q4 ( IAQ rgk 8hw ) ) ) ) ) ) ) $=
  ( NQk wAM rQk pQg HwQ KwQ egk rgg WQk HQ8 bxQ 6xI 0A4 IAE SgE .R4 wgE JwU mAE
  4g uwM 0yA 7R4 xAg Aw0 8gk wx4 Eh0 WxI 8Rw vB4 lCA 9B4 yh4 3x4 2B4 0R4 Kg8 6g
  8A4 -Q4 6wk Qwk Lgk PAk njU qSA 3Q4 Kx8 Cg8 xgM tAM nAE oAU OAM swU 3gU 3yA
  FgU NQY MwY .Qk 5hw 0gM -DU 9DU fwU rgc qAc vAc -TU 1Ac hgc ) AAAAUAZWNBZCDCU
  BEZFZGDGUCEZFZUDHUEUFDGUGEZCICUHEFUIFUDHZHZHJZGDWTFCDCUJEZFKGDGUKEFCDCULEFKGD
  GUMEFCDCUNEFKWSCDCUOEFKGDGUPEFCDCUQEFKLLLLURZMZXDUTZVAZBZXIAWOUFDWRCIWPFZUIFX
  AHJZXEMZXGVAZBZNAWOWOXHXHNNWNAOZXOTWOAOZNXOXOPPQAWNWNRSZXQNXFVBOZXGVCOZTXHAOZ
  NXRXSNXCVDOZXEVEOZTXRNYAYBVFVGQXCXEVHSVIQXFXGVJSZYCNAAWOWOVKVLAWONXPXQVMUSVNV
  OAXHNYCVPVQAXIXNNNXPXTTXIAONXPXTXQYCQAWOXHRSNXPXMAOZTXNAONXPYDXQNXLVBOZXSTYDN
  YEXSNXKVDOZYBTYENYFYBVRVGQXKXEVHSVIQXLXGVJSZQAWOXMRSZAXIXNXNNVSYHYHAWOXHXMNAW
  NWNAVTZYIWAXQYCYGAXIAWBAWBWCEZYJWDDIDXJFWQBXBHJXEMXGVABZXMNWEAYKAWNXMBZXMNVSN
  XOYDTYLAONXOYDPYGQAWNXMRSYGWFAWNXMNPYGWGWHWIWJWKWHWLWM $. $}
