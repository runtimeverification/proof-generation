$c 0wM #Symbol cwE #Variable #SetVariable ) #ElementVariable mwg xQg #Pattern ( $.
$v Cw 6Ag CQ DQ Pw Bw $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Cg $f #Pattern Cw $.
DA $f #Pattern DQ $.
Pg $f #Symbol Pw $.
Sw $a #Pattern Pw $.
cgE $a #Symbol cwE $.
0gM $a #Pattern ( 0wM Bw CQ Cw DQ ) $.
mgg $a #Pattern mwg $.
xAg $a #Pattern xQg $.
5wg $f #ElementVariable 6Ag $.
BCE $a #Pattern 6Ag $.
${ 2iQ $p #Pattern ( 0wM mwg cwE 6Ag xQg ) $=
  ( mgg cgE Sw BCE xAg 0gM ) BCDAEFG $. $}
