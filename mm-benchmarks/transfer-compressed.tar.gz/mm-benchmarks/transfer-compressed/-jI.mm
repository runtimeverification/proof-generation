$c rwg LAQ 0Q4 Wgk Hg8 #Symbol #Variable -g4 pgg DBE #SetVariable ) #ElementVariable rgk #Pattern ( $.
$v 4wg CQ qwg 3gg Bw oAg 5Qg Cw nR4 4Ag $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Cg $f #Pattern Cw $.
KwQ $a #Pattern ( LAQ Bw CQ Cw ) $.
nwg $f #Pattern oAg $.
pQg $a #Pattern pgg $.
qgg $f #Pattern qwg $.
rgg $a #Pattern ( rwg oAg qwg ) $.
3Qg $f #ElementVariable 3gg $.
3wg $f #ElementVariable 4Ag $.
4gg $f #ElementVariable 4wg $.
5Ag $f #ElementVariable 5Qg $.
WQk $a #Pattern Wgk $.
rQk $a #Pattern rgk $.
0A4 $a #Pattern ( 0Q4 oAg qwg ) $.
-Q4 $a #Pattern ( -g4 oAg qwg ) $.
HQ8 $a #Pattern ( Hg8 oAg ) $.
CxE $a #Pattern ( DBE oAg qwg ) $.
nB4 $f #ElementVariable nR4 $.
6h8 $a #Pattern nR4 $.
BCQ $a #Pattern 4Ag $.
XiU $a #Pattern 3gg $.
XyU $a #Pattern 4wg $.
YCU $a #Pattern 5Qg $.
${ -jI $p #Pattern ( -g4 ( 0Q4 ( Hg8 ( rwg ( LAQ Wgk pgg ( DBE ( LAQ rgk Wgk 5Qg ) ( LAQ rgk Wgk 4Ag ) ) ) 3gg ) ) 4wg ) nR4 ) $=
  ( WQk pQg rQk YCU KwQ BCQ CxE XiU rgg HQ8 XyU 0A4 6h8 -Q4 ) FGHFDIJHFBKJLJAMN
  OCPQERS $. $}
