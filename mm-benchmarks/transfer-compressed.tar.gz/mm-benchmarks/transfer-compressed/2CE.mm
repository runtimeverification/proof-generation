$c 0wM ewk IAQ 3BA #Symbol #Variable -gg #SetVariable vR4 #ElementVariable #Pattern ) ( $.
$v yhs CQ qwg DQ Bw oAg Cw 2gg nR4 $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Cg $f #Pattern Cw $.
DA $f #Pattern DQ $.
0gM $a #Pattern ( 0wM Bw CQ Cw DQ ) $.
HwQ $a #Pattern ( IAQ Bw CQ ) $.
nwg $f #Pattern oAg $.
qgg $f #Pattern qwg $.
2Qg $f #ElementVariable 2gg $.
-Qg $a #Pattern -gg $.
egk $a #Pattern ewk $.
2xA $a #Pattern ( 3BA oAg qwg ) $.
yRs $f #ElementVariable yhs $.
nB4 $f #ElementVariable nR4 $.
vB4 $a #Pattern vR4 $.
Wh8 $a #Pattern 2gg $.
6h8 $a #Pattern nR4 $.
7SA $a #Pattern yhs $.
${ 2CE $p #Pattern ( 0wM -gg 2gg yhs ( 3BA ( IAQ ewk vR4 ) nR4 ) ) $=
  ( -Qg Wh8 7SA egk vB4 HwQ 6h8 2xA 0gM ) DAEBFGHICJKL $. $}
