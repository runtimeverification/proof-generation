$c #SetVariable cwE iA ) ewk #ElementVariable #Symbol #Variable #Pattern ( $.
$v Ow CQ xX Bw Kw ph0 6xw Pw $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Kg $f #ElementVariable Kw $.
Og $f #Variable Ow $.
Pg $f #Symbol Pw $.
SA $a #Variable Kw $.
Sw $a #Pattern Pw $.
cgE $a #Symbol cwE $.
${ $d xX ph0 $.
   IQI $a iA Bw Bw CQ Ow $. $}
egk $a #Pattern ewk $.
6hw $f #ElementVariable 6xw $.
${ 2h8 $p iA ewk ewk cwE 6xw $=
  ( egk cgE Sw SA IQI ) BCDAEF $. $}
