$c 0wM 2R4 LAQ ewk IAQ Wgk #Symbol #Variable #SetVariable zBI ) pwk #ElementVariable #Pattern ( $.
$v yhs CQ qwg DQ Bw XRw oAg Cw 2gg $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Cg $f #Pattern Cw $.
DA $f #Pattern DQ $.
0gM $a #Pattern ( 0wM Bw CQ Cw DQ ) $.
HwQ $a #Pattern ( IAQ Bw CQ ) $.
KwQ $a #Pattern ( LAQ Bw CQ Cw ) $.
nwg $f #Pattern oAg $.
qgg $f #Pattern qwg $.
2Qg $f #ElementVariable 2gg $.
WQk $a #Pattern Wgk $.
egk $a #Pattern ewk $.
pgk $a #Pattern pwk $.
yxI $a #Pattern ( zBI oAg qwg ) $.
yRs $f #ElementVariable yhs $.
XBw $f #ElementVariable XRw $.
2B4 $a #Pattern 2R4 $.
Wh8 $a #Pattern 2gg $.
7SA $a #Pattern yhs $.
QCE $a #Pattern XRw $.
${ 3yI $p #Pattern ( 0wM pwk 2gg yhs ( zBI ( LAQ ewk Wgk ( IAQ ewk 2R4 ) ) XRw ) ) $=
  ( pgk Wh8 7SA egk WQk 2B4 HwQ KwQ QCE yxI 0gM ) DAEBFGHGIJKCLMN $. $}
