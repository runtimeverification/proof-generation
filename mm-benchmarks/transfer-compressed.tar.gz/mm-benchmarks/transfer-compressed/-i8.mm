$c Tw #Symbol 5x4 zw YQk pwk pgg rgk #Pattern ( LAQ ewk IAQ #Variable SwE #SetVariable hgk vR4 4w #ElementVariable IQE ) cBQ $.
$v CQ qwg -Bw Bw oAg 5Qg MB0 Cw $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Cg $f #Pattern Cw $.
4g $a #Pattern ( 4w Bw CQ ) $.
SgE $a #Pattern ( SwE Bw CQ ) $.
${ lgE $e zw ( Tw Bw CQ ) $.
   lwE $e zw ( Tw CQ Cw ) $.
   mAE $a zw ( Tw Bw Cw ) $. $}
${ wAE $e zw ( Tw Bw CQ ) $.
   wQE $e zw ( Tw Bw Cw ) $.
   wgE $a zw ( Tw Bw ( 4w CQ Cw ) ) $. $}
HwQ $a #Pattern ( IAQ Bw CQ ) $.
KwQ $a #Pattern ( LAQ Bw CQ Cw ) $.
nwg $f #Pattern oAg $.
pQg $a #Pattern pgg $.
qgg $f #Pattern qwg $.
5Ag $f #ElementVariable 5Qg $.
YAk $a #Pattern YQk $.
egk $a #Pattern ewk $.
pgk $a #Pattern pwk $.
rQk $a #Pattern rgk $.
bxQ $a #Pattern ( cBQ oAg qwg ) $.
fBQ $a zw ( Tw ( 4w ( SwE oAg pgg ) ( SwE qwg pgg ) ) ( SwE ( cBQ oAg qwg ) YQk ) ) $.
.xw $f #ElementVariable -Bw $.
Lx0 $f #ElementVariable MB0 $.
vB4 $a #Pattern vR4 $.
5h4 $a #Pattern 5x4 $.
YCU $a #Pattern 5Qg $.
rC8 $a #Pattern ( 4w ( SwE -Bw pgg ) ( 4w ( SwE MB0 hgk ) IQE ) ) $.
-C8 $a zw ( Tw ( 4w ( SwE 5Qg pwk ) ( 4w ( SwE -Bw pgg ) ( 4w ( SwE MB0 hgk ) IQE ) ) ) ( SwE ( LAQ ewk pgg ( IAQ ewk vR4 ) ) pgg ) ) $.
-S8 $a zw ( Tw ( 4w ( SwE 5Qg pwk ) ( 4w ( SwE -Bw pgg ) ( 4w ( SwE MB0 hgk ) IQE ) ) ) ( SwE ( LAQ rgk pgg ( IAQ rgk 5x4 ) ) pgg ) ) $.
${ -i8 $p zw ( Tw ( 4w ( SwE 5Qg pwk ) ( 4w ( SwE -Bw pgg ) ( 4w ( SwE MB0 hgk ) IQE ) ) ) ( SwE ( cBQ ( LAQ ewk pgg ( IAQ ewk vR4 ) ) ( LAQ rgk pgg ( IAQ rgk 5x4 ) ) ) YQk ) ) $=
  ( YCU pgk SgE rC8 4g egk pQg vB4 HwQ KwQ rQk 5h4 bxQ YAk -C8 -S8 wgE fBQ mAE
  ) ADEFBCGHZIJIKLMZJFZNJNOLMZJFZHUDUFPQFUCUEUGABCRABCSTUDUFUAUB $. $}
