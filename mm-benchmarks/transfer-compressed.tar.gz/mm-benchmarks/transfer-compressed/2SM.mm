$c 1wk #Symbol #Variable SwE #SetVariable iA 4w #ElementVariable IQE #Pattern ) ( $.
$v Ow CQ zBs DQ Bw Kw Cw nR4 Dw $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Cg $f #Pattern Cw $.
DA $f #Pattern DQ $.
Dg $f #Pattern Dw $.
Kg $f #ElementVariable Kw $.
Og $f #Variable Ow $.
SA $a #Variable Kw $.
IAE $a #Pattern IQE $.
SgE $a #Pattern ( SwE Bw CQ ) $.
${ KAI $e iA CQ DQ Bw Ow $.
   KQI $e iA Cw Dw Bw Ow $.
   KgI $a iA ( 4w CQ Cw ) ( 4w DQ Dw ) Bw Ow $. $}
1gk $a #Pattern 1wk $.
yxs $f #ElementVariable zBs $.
nB4 $f #ElementVariable nR4 $.
6h8 $a #Pattern nR4 $.
JiE $a #Pattern zBs $.
MyE $a iA IQE IQE nR4 zBs $.
2CM $a iA ( SwE nR4 1wk ) ( SwE zBs 1wk ) nR4 zBs $.
${ 2SM $p iA ( 4w ( SwE nR4 1wk ) IQE ) ( 4w ( SwE zBs 1wk ) IQE ) nR4 zBs $=
  ( 6h8 1gk SgE IAE JiE SA 2CM MyE KgI ) BCZLDEFAGDEFAHABIABJK $. $}
