$c Uw PgE Ngk 7BA RAk Tw #Symbol wQM -g4 DBE 8Q4 zw rgk pgg #Pattern ( 0Q4 rwg twM .gM LAQ tQM IAQ Wgk Hg8 #Variable SwE PQk #SetVariable iA 4w #ElementVariable IQE mwg 8hw ) $.
$v th1 yhs CQ Bw Cw sgg ngg z ph2 3gg Ew ph0 5Qg x Lw LQ Ow qwg DQ ph1 EQ y th2 3Ag tAg Dw HQ 4wg xX Gw th0 Hw Kw oAg GQ nR4 tgg 4Ag $.
$d z y $.
$d z x $.
$d y x $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Cg $f #Pattern Cw $.
DA $f #Pattern DQ $.
Dg $f #Pattern Dw $.
EA $f #Pattern EQ $.
Eg $f #Pattern Ew $.
GA $f #Pattern GQ $.
Gg $f #Pattern Gw $.
HA $f #Pattern HQ $.
Hg $f #Pattern Hw $.
Kg $f #ElementVariable Kw $.
LA $f #ElementVariable LQ $.
Lg $f #ElementVariable Lw $.
Og $f #Variable Ow $.
SA $a #Variable Kw $.
jg $a iA Bw Ow Bw Ow $.
${ kg $e iA CQ DQ Bw Ow $.
   kw $e iA Cw Dw Bw Ow $.
   lA $a iA ( Tw CQ Cw ) ( Tw DQ Dw ) Bw Ow $. $}
4g $a #Pattern ( 4w Bw CQ ) $.
IAE $a #Pattern IQE $.
SgE $a #Pattern ( SwE Bw CQ ) $.
lQE $a zw ( Tw Bw Bw ) $.
${ lgE $e zw ( Tw Bw CQ ) $.
   lwE $e zw ( Tw CQ Cw ) $.
   mAE $a zw ( Tw Bw Cw ) $. $}
ugE $a zw ( Tw ( 4w Bw CQ ) Bw ) $.
uwE $a zw ( Tw ( 4w Bw CQ ) CQ ) $.
${ wAE $e zw ( Tw Bw CQ ) $.
   wQE $e zw ( Tw Bw Cw ) $.
   wgE $a zw ( Tw Bw ( 4w CQ Cw ) ) $. $}
${ $d xX ph0 $.
   IQI $a iA Bw Bw CQ Ow $. $}
${ KAI $e iA CQ DQ Bw Ow $.
   KQI $e iA Cw Dw Bw Ow $.
   KgI $a iA ( 4w CQ Cw ) ( 4w DQ Dw ) Bw Ow $. $}
${ OgI $e iA CQ DQ Bw Ow $.
   OwI $e iA Cw Dw Bw Ow $.
   PAI $a iA ( SwE CQ Cw ) ( SwE DQ Dw ) Bw Ow $. $}
tAM $a #Pattern ( tQM Bw CQ ) $.
uwM $a #Pattern ( twM Bw ) $.
wAM $a #Pattern ( wQM Bw CQ Cw ) $.
.QM $a #Pattern ( .gM Bw CQ Cw ) $.
HwQ $a #Pattern ( IAQ Bw CQ ) $.
KwQ $a #Pattern ( LAQ Bw CQ Cw ) $.
${ QAQ $e iA Bw Cw Dw Ow $.
   QQQ $e iA CQ DQ Dw Ow $.
   QgQ $a iA ( tQM Bw CQ ) ( tQM Cw DQ ) Dw Ow $. $}
${ SgQ $e iA Bw DQ Ew Ow $.
   SwQ $e iA CQ Dw Ew Ow $.
   TAQ $e iA Cw EQ Ew Ow $.
   TQQ $a iA ( wQM Bw CQ Cw ) ( wQM DQ Dw EQ ) Ew Ow $. $}
${ awQ $e iA Bw DQ Ew Ow $.
   bAQ $e iA CQ Dw Ew Ow $.
   bQQ $e iA Cw EQ Ew Ow $.
   bgQ $a iA ( .gM Bw CQ Cw ) ( .gM DQ Dw EQ ) Ew Ow $. $}
${ $d z ph0 $.
   $d z ph1 $.
   $d z ph2 $.
   $d z y $.
   $d z x $.
   $d z th1 $.
   $d z th2 $.
   $d x ph0 $.
   $d y th0 $.
   lAY $e zw ( Tw GQ ( Uw Kw ( PgE Kw Bw ) ) ) $.
   lQY $e zw ( Tw ( 4w GQ Gw ) CQ ) $.
   lgY $e iA ( Tw HQ Cw ) ( Tw Gw CQ ) Bw LQ $.
   lwY $e iA ( Tw Hw DQ ) ( Tw Gw CQ ) Lw LQ $.
   mAY $a zw ( Tw ( 4w GQ HQ ) Cw ) $. $}
mgg $a #Pattern mwg $.
nQg $f #Variable ngg $.
nwg $f #Pattern oAg $.
pQg $a #Pattern pgg $.
qgg $f #Pattern qwg $.
rgg $a #Pattern ( rwg oAg qwg ) $.
sQg $f #Pattern sgg $.
swg $f #Pattern tAg $.
tQg $f #Pattern tgg $.
2wg $f #ElementVariable 3Ag $.
3Qg $f #ElementVariable 3gg $.
3wg $f #ElementVariable 4Ag $.
4gg $f #ElementVariable 4wg $.
5Ag $f #ElementVariable 5Qg $.
NQk $a #Pattern Ngk $.
Qwk $a #Pattern RAk $.
WQk $a #Pattern Wgk $.
rQk $a #Pattern rgk $.
0A4 $a #Pattern ( 0Q4 oAg qwg ) $.
8A4 $a #Pattern ( 8Q4 oAg ) $.
-Q4 $a #Pattern ( -g4 oAg qwg ) $.
${ Ag8 $e iA qwg tAg oAg ngg $.
   Aw8 $e iA sgg tgg oAg ngg $.
   BA8 $a iA ( -g4 qwg sgg ) ( -g4 tAg tgg ) oAg ngg $. $}
HQ8 $a #Pattern ( Hg8 oAg ) $.
CxE $a #Pattern ( DBE oAg qwg ) $.
yRs $f #ElementVariable yhs $.
8Rw $a #Pattern 8hw $.
nB4 $f #ElementVariable nR4 $.
6h8 $a #Pattern nR4 $.
BCQ $a #Pattern 4Ag $.
ByQ $a #Pattern 3Ag $.
GyQ $a iA Ngk Ngk nR4 3Ag $.
XiU $a #Pattern 3gg $.
XyU $a #Pattern 4wg $.
YCU $a #Pattern 5Qg $.
cSU $a iA ( 4w ( SwE nR4 RAk ) IQE ) ( 4w ( SwE 3Ag RAk ) IQE ) nR4 3Ag $.
NS8 $a #Pattern ( 4w ( SwE 4wg PQk ) ( 4w ( SwE 5Qg rgk ) IQE ) ) $.
Ni8 $a zw ( Tw ( 4w ( SwE 4Ag rgk ) ( 4w ( SwE 3gg mwg ) ( 4w ( SwE 4wg PQk ) ( 4w ( SwE 5Qg rgk ) IQE ) ) ) ) ( Uw yhs ( PgE yhs ( 8Q4 ( IAQ rgk 8hw ) ) ) ) ) $.
RC8 $a zw ( Tw ( 4w ( SwE 4Ag rgk ) ( 4w ( SwE 3gg mwg ) ( 4w ( SwE 4wg PQk ) ( 4w ( SwE 5Qg rgk ) IQE ) ) ) ) ( 4w ( SwE 4wg PQk ) ( 4w ( SwE 5Qg rgk ) IQE ) ) ) $.
RS8 $a zw ( Tw ( 4w ( SwE 4Ag rgk ) ( 4w ( SwE 3gg mwg ) ( 4w ( SwE 4wg PQk ) ( 4w ( SwE 5Qg rgk ) IQE ) ) ) ) ( 4w ( SwE ( 8Q4 ( IAQ rgk 8hw ) ) RAk ) IQE ) ) $.
.jI $a #Pattern ( -g4 ( 0Q4 ( Hg8 ( rwg ( LAQ Wgk pgg ( DBE ( LAQ rgk Wgk 5Qg ) ( LAQ rgk Wgk 4Ag ) ) ) 3gg ) ) 4wg ) 3Ag ) $.
-DI $a #Pattern ( 0Q4 ( Hg8 ( rwg ( LAQ rgk pgg ( 7BA 5Qg 4Ag ) ) 3gg ) ) 4wg ) $.
-TI $a zw ( Tw ( 4w ( 4w ( SwE 4Ag rgk ) ( 4w ( SwE 3gg mwg ) ( 4w ( SwE 4wg PQk ) ( 4w ( SwE 5Qg rgk ) IQE ) ) ) ) ( 4w ( SwE 3Ag RAk ) IQE ) ) ( tQM Ngk ( .gM Ngk ( wQM Ngk ( twM Ngk ) ( -g4 ( 0Q4 ( Hg8 ( rwg ( LAQ Wgk pgg ( DBE ( LAQ rgk Wgk 5Qg ) ( LAQ rgk Wgk 4Ag ) ) ) 3gg ) ) 4wg ) 3Ag ) ) ( wQM Ngk ( twM Ngk ) ( -g4 ( 0Q4 ( Hg8 ( rwg ( LAQ rgk pgg ( 7BA 5Qg 4Ag ) ) 3gg ) ) 4wg ) 3Ag ) ) ) ) ) $.
-jI $a #Pattern ( -g4 ( 0Q4 ( Hg8 ( rwg ( LAQ Wgk pgg ( DBE ( LAQ rgk Wgk 5Qg ) ( LAQ rgk Wgk 4Ag ) ) ) 3gg ) ) 4wg ) nR4 ) $.
${ -zI $p zw ( Tw ( 4w ( SwE 4Ag rgk ) ( 4w ( SwE 3gg mwg ) ( 4w ( SwE 4wg PQk ) ( 4w ( SwE 5Qg rgk ) IQE ) ) ) ) ( tQM Ngk ( .gM Ngk ( wQM Ngk ( twM Ngk ) ( -g4 ( 0Q4 ( Hg8 ( rwg ( LAQ Wgk pgg ( DBE ( LAQ rgk Wgk 5Qg ) ( LAQ rgk Wgk 4Ag ) ) ) 3gg ) ) 4wg ) ( 8Q4 ( IAQ rgk 8hw ) ) ) ) ( wQM Ngk ( twM Ngk ) ( -g4 ( 0Q4 ( Hg8 ( rwg ( LAQ rgk pgg ( 7BA 5Qg 4Ag ) ) 3gg ) ) 4wg ) ( 8Q4 ( IAQ rgk 8hw ) ) ) ) ) ) ) $=
  ( 2wg nB4 rQk SgE 4g Qwk IAE NQk WQk KwQ -Q4 wAM mAE IQI BA8 TQQ yRs SA jg lA
  BCQ XiU mgg NS8 8Rw HwQ 8A4 uwM pQg YCU CxE rgg HQ8 XyU 0A4 -DI .QM tAM ugE
  lQE uwE RC8 wgE RS8 .jI ByQ -jI 6h8 Ni8 -TI PAI KgI bgQ QgQ cSU GyQ mAY ) BUE
  ZGHZAUFZUGHZCDUHZIZIZWHGUIUJUKZJHZKIZILLLLULZMUMGMDUNNGMWBNUONWDUPUQCURUSZWIO
  ZPZLWLABCDUTZWIOZPZVAZVBZWHWHWKWHWCWGWHWCWCWCWGVCWCVDQWHWEWFWHWGWEWCWGVEWGWEW
  EWEWFVCWEVDQQABCDVFVGVGABCDVHVGWILLLWLEABCDVIZPZLWLWPEVJZOZPZVAZVBZWTLLLWLABC
  DFVKZPZLWLWPFVLZOZPZVAZVBZWHXCJHZKIZWKXJJHKIZUAEFABCDUAVMEABCDVNWIWKWTXPXGEUB
  ZWIWJKXOKXRWIWIJXCJXRWIXRUCZJWIXRRVOKWIXRRVPLWSLXFWIXRLWIXRRZLWOWRLXBXEWIXRXT
  LWLWNLWLXAWIXRXTWLWIXRRZXRWIWMWIWMXCWMWIXRRXSSTLWLWQLWLXDWIXRXTYAXRWIWPWIWPXC
  WPWIXRRXSSTVQVRUDXJXQXNXPXGXREFVSLXMLXFXJXREFVTZLXIXLLXBXEXJXRYBLWLXHLWLXAXJX
  RYBWLXJXRRZXRXJWMXJWMXCWMXJXRRXJXRUCZSTLWLXKLWLXDXJXRYBYCXRXJWPXJWPXCWPXJXRRY
  DSTVQVRUDWAQ $. $}
