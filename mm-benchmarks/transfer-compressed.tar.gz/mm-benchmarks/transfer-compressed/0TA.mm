$c 0wM LAQ #Symbol #Variable #SetVariable iA pwk #ElementVariable .gk #Pattern ) ( $.
$v Fw Ow CQ DQ Bw Cw 2gg EQ mh4 Dw FQ xX Ew lB4 lh4 Kw ph0 $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Cg $f #Pattern Cw $.
DA $f #Pattern DQ $.
Dg $f #Pattern Dw $.
EA $f #Pattern EQ $.
Eg $f #Pattern Ew $.
FA $f #Pattern FQ $.
Fg $f #Pattern Fw $.
Kg $f #ElementVariable Kw $.
Og $f #Variable Ow $.
SA $a #Variable Kw $.
${ $d xX ph0 $.
   IQI $a iA Bw Bw CQ Ow $. $}
KwQ $a #Pattern ( LAQ Bw CQ Cw ) $.
${ XgQ $e iA Bw Dw Fw Ow $.
   XwQ $e iA CQ EQ Fw Ow $.
   YAQ $e iA Cw Ew Fw Ow $.
   YQQ $e iA DQ FQ Fw Ow $.
   YgQ $a iA ( 0wM Bw CQ Cw DQ ) ( 0wM Dw EQ Ew FQ ) Fw Ow $. $}
2Qg $f #ElementVariable 2gg $.
pgk $a #Pattern pwk $.
.Qk $a #Pattern .gk $.
kx4 $f #ElementVariable lB4 $.
lR4 $f #ElementVariable lh4 $.
mR4 $f #ElementVariable mh4 $.
Wh8 $a #Pattern 2gg $.
Wx8 $a #Pattern lh4 $.
XB8 $a #Pattern lB4 $.
YR8 $a #Pattern mh4 $.
cTA $a #Pattern ( LAQ .gk lh4 mh4 ) $.
cjA $a #Pattern ( LAQ .gk lB4 mh4 ) $.
zDA $a iA 2gg 2gg pwk lh4 $.
zTA $a iA lB4 lB4 pwk lh4 $.
0DA $a iA ( LAQ pwk lB4 ( LAQ .gk pwk mh4 ) ) ( LAQ lh4 lB4 ( LAQ .gk lh4 mh4 ) ) pwk lh4 $.
${ 0TA $p iA ( 0wM lB4 2gg ( LAQ pwk lB4 ( LAQ .gk pwk mh4 ) ) ( LAQ .gk lB4 mh4 ) ) ( 0wM lB4 2gg ( LAQ lh4 lB4 ( LAQ .gk lh4 mh4 ) ) ( LAQ .gk lB4 mh4 ) ) pwk lh4 $=
  ( XB8 Wh8 pgk .Qk YR8 KwQ cjA Wx8 cTA SA zTA zDA 0DA IQI YgQ ) BEZAFZGTHGDIJJ
  BDKZTUACLTCDMJUBGCNZBCOACPBCDQUBGUCRS $. $}
