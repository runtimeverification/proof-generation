$c zBA 2R4 XBI Tw #Symbol 7h4 -gg zw #Pattern ( LAQ ewk IAQ Wgk #Variable SwE #SetVariable 4w #ElementVariable IQE 8wk ) $.
$v CQ qwg Bw oAg 5Qg Cw $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Cg $f #Pattern Cw $.
4g $a #Pattern ( 4w Bw CQ ) $.
IAE $a #Pattern IQE $.
SgE $a #Pattern ( SwE Bw CQ ) $.
${ lgE $e zw ( Tw Bw CQ ) $.
   lwE $e zw ( Tw CQ Cw ) $.
   mAE $a zw ( Tw Bw Cw ) $. $}
${ wAE $e zw ( Tw Bw CQ ) $.
   wQE $e zw ( Tw Bw Cw ) $.
   wgE $a zw ( Tw Bw ( 4w CQ Cw ) ) $. $}
HwQ $a #Pattern ( IAQ Bw CQ ) $.
KwQ $a #Pattern ( LAQ Bw CQ Cw ) $.
nwg $f #Pattern oAg $.
qgg $f #Pattern qwg $.
5Ag $f #ElementVariable 5Qg $.
-Qg $a #Pattern -gg $.
WQk $a #Pattern Wgk $.
egk $a #Pattern ewk $.
8gk $a #Pattern 8wk $.
yxA $a #Pattern ( zBA oAg qwg ) $.
WxI $a #Pattern ( XBI oAg qwg ) $.
aBI $a zw ( Tw ( 4w ( SwE oAg ewk ) ( SwE qwg Wgk ) ) ( SwE ( XBI oAg qwg ) 8wk ) ) $.
2B4 $a #Pattern 2R4 $.
7R4 $a #Pattern 7h4 $.
YCU $a #Pattern 5Qg $.
xSU $a zw ( Tw ( 4w ( SwE 5Qg -gg ) IQE ) ( SwE ( IAQ ewk 7h4 ) ewk ) ) $.
3CU $a zw ( Tw ( 4w ( SwE 5Qg -gg ) IQE ) ( SwE ( zBA ( LAQ ewk Wgk ( IAQ ewk 7h4 ) ) ( LAQ ewk Wgk ( IAQ ewk 2R4 ) ) ) Wgk ) ) $.
${ 3SU $p zw ( Tw ( 4w ( SwE 5Qg -gg ) IQE ) ( SwE ( XBI ( IAQ ewk 7h4 ) ( zBA ( LAQ ewk Wgk ( IAQ ewk 7h4 ) ) ( LAQ ewk Wgk ( IAQ ewk 2R4 ) ) ) ) 8wk ) ) $=
  ( YCU -Qg SgE IAE 4g egk 7R4 HwQ WQk KwQ 2B4 yxA WxI 8gk xSU 3CU wgE aBI mAE
  ) ABCDEFZGHIZGDZGJUBKGJGLIKMZJDZFUBUDNODUAUCUEAPAQRUBUDST $. $}
