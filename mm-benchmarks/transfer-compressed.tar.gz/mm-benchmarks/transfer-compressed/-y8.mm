$c LAQ ewk IAQ 9R4 Tw #Symbol #Variable SwE #SetVariable hgk zw 4w pwk JAQ #ElementVariable IQE pgg #Pattern ) ( $.
$v CQ qwg -Bw Bw oAg 5Qg MB0 Cw sgg $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Cg $f #Pattern Cw $.
Tg $a #Pattern ( Tw Bw CQ ) $.
4g $a #Pattern ( 4w Bw CQ ) $.
5Q $a zw ( Tw Bw ( Tw CQ Bw ) ) $.
${ 6A $e zw ( Tw Bw CQ ) $.
   6Q $e zw Bw $.
   6g $a zw CQ $. $}
SgE $a #Pattern ( SwE Bw CQ ) $.
${ lgE $e zw ( Tw Bw CQ ) $.
   lwE $e zw ( Tw CQ Cw ) $.
   mAE $a zw ( Tw Bw Cw ) $. $}
${ wAE $e zw ( Tw Bw CQ ) $.
   wQE $e zw ( Tw Bw Cw ) $.
   wgE $a zw ( Tw Bw ( 4w CQ Cw ) ) $. $}
HwQ $a #Pattern ( IAQ Bw CQ ) $.
IgQ $a zw ( SwE ( IAQ Bw CQ ) Bw ) $.
IwQ $a #Pattern ( JAQ Bw ) $.
KwQ $a #Pattern ( LAQ Bw CQ Cw ) $.
nwg $f #Pattern oAg $.
pQg $a #Pattern pgg $.
qgg $f #Pattern qwg $.
sQg $f #Pattern sgg $.
5Ag $f #ElementVariable 5Qg $.
.gg $a zw ( Tw ( 4w ( 4w ( JAQ oAg ) ( JAQ qwg ) ) ( SwE sgg oAg ) ) ( SwE ( LAQ oAg qwg sgg ) qwg ) ) $.
egk $a #Pattern ewk $.
pgk $a #Pattern pwk $.
.xw $f #ElementVariable -Bw $.
Lx0 $f #ElementVariable MB0 $.
9B4 $a #Pattern 9R4 $.
YCU $a #Pattern 5Qg $.
rC8 $a #Pattern ( 4w ( SwE -Bw pgg ) ( 4w ( SwE MB0 hgk ) IQE ) ) $.
9y8 $a zw ( Tw ( 4w ( SwE 5Qg pwk ) ( 4w ( SwE -Bw pgg ) ( 4w ( SwE MB0 hgk ) IQE ) ) ) ( 4w ( JAQ ewk ) ( JAQ pgg ) ) ) $.
${ -y8 $p zw ( Tw ( 4w ( SwE 5Qg pwk ) ( 4w ( SwE -Bw pgg ) ( 4w ( SwE MB0 hgk ) IQE ) ) ) ( SwE ( LAQ ewk pgg ( IAQ ewk 9R4 ) ) pgg ) ) $=
  ( YCU pgk SgE rC8 4g egk IwQ pQg 9B4 HwQ KwQ 9y8 Tg 5Q IgQ 6g wgE .gg mAE ) A
  DEFBCGHZIJKJHZILMZIFZHIKUENKFUCUDUFABCOUFUCUFPUFUCQILRSTIKUEUAUB $. $}
