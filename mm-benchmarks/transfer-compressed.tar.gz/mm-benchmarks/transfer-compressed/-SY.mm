$c Uw PgE Tw #Symbol 7h4 cwE -gg zw #Pattern ( 0wM ewk tQM IAQ #Variable SwE #SetVariable 4w rwM #ElementVariable IQE 8wk ) $.
$v 4wg 7Rw CQ Bw Kw ph1 ph0 5Qg Cw GQ x $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Cg $f #Pattern Cw $.
GA $f #Pattern GQ $.
Kg $f #ElementVariable Kw $.
Ug $a #Pattern ( Uw Kw Bw ) $.
IAE $a #Pattern IQE $.
PQE $a #Pattern ( PgE Bw CQ ) $.
${ lgE $e zw ( Tw Bw CQ ) $.
   lwE $e zw ( Tw CQ Cw ) $.
   mAE $a zw ( Tw Bw Cw ) $. $}
nAE $a zw IQE $.
${ NwM $e zw CQ $.
   OAM $a zw ( Tw Bw CQ ) $. $}
HwQ $a #Pattern ( IAQ Bw CQ ) $.
${ $d x ph0 $.
   $d x ph1 $.
   vwY $e zw ( Tw GQ ( SwE CQ Bw ) ) $.
   wAY $e zw ( Tw GQ ( tQM cwE ( rwM Bw cwE Kw ( 0wM Bw cwE Kw CQ ) ) ) ) $.
   wQY $a zw ( Tw GQ ( Uw Kw ( PgE Kw CQ ) ) ) $. $}
4gg $f #ElementVariable 4wg $.
5Ag $f #ElementVariable 5Qg $.
egk $a #Pattern ewk $.
7Bw $f #ElementVariable 7Rw $.
7R4 $a #Pattern 7h4 $.
-h4 $a zw ( Tw IQE ( SwE ( IAQ ewk 7h4 ) ewk ) ) $.
1B8 $a #Pattern 7Rw $.
ryA $a zw ( Tw IQE ( tQM cwE ( rwM ewk cwE 7Rw ( 0wM ewk cwE 7Rw ( IAQ ewk 7h4 ) ) ) ) ) $.
YSU $a #Pattern ( 4w ( SwE 4wg 8wk ) ( 4w ( SwE 5Qg -gg ) IQE ) ) $.
${ -SY $p zw ( Tw ( 4w ( SwE 4wg 8wk ) ( 4w ( SwE 5Qg -gg ) IQE ) ) ( Uw 7Rw ( PgE 7Rw ( IAQ ewk 7h4 ) ) ) ) $=
  ( YSU IAE 1B8 egk 7R4 HwQ PQE Ug nAE OAM -h4 ryA wQY mAE ) ABDZECFGHIZJCKRELM
  GSECNCOPQ $. $}
