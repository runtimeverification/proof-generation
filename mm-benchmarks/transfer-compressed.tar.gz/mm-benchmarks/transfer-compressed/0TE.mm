$c #SetVariable iA ) #ElementVariable .gk #Symbol #Variable #Pattern ( $.
$v Ow CQ xX 3gg Bw Kw ph0 nR4 $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Kg $f #ElementVariable Kw $.
Og $f #Variable Ow $.
SA $a #Variable Kw $.
${ $d xX ph0 $.
   IQI $a iA Bw Bw CQ Ow $. $}
3Qg $f #ElementVariable 3gg $.
.Qk $a #Pattern .gk $.
nB4 $f #ElementVariable nR4 $.
6h8 $a #Pattern nR4 $.
${ 0TE $p iA .gk .gk nR4 3gg $=
  ( .Qk 6h8 SA IQI ) CBDAEF $. $}
