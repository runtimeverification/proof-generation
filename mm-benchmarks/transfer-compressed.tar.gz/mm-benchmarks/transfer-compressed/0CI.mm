$c #SetVariable iA ) ewk #ElementVariable #Symbol #Variable #Pattern ( $.
$v Ow CQ xX zBs Bw Kw ph0 nR4 $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Kg $f #ElementVariable Kw $.
Og $f #Variable Ow $.
SA $a #Variable Kw $.
${ $d xX ph0 $.
   IQI $a iA Bw Bw CQ Ow $. $}
egk $a #Pattern ewk $.
yxs $f #ElementVariable zBs $.
nB4 $f #ElementVariable nR4 $.
6h8 $a #Pattern nR4 $.
${ 0CI $p iA ewk ewk nR4 zBs $=
  ( egk 6h8 SA IQI ) CBDAEF $. $}
