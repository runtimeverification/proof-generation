$c 0wM 2R4 ewk tQM IAQ Tw #Symbol #Variable #SetVariable zw 4w rwM JAQ #ElementVariable IQE #Pattern ) ( $.
$v 7Rw CQ DQ Bw Kw Cw 6xw $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Cg $f #Pattern Cw $.
DA $f #Pattern DQ $.
Kg $f #ElementVariable Kw $.
4g $a #Pattern ( 4w Bw CQ ) $.
IAE $a #Pattern IQE $.
${ lgE $e zw ( Tw Bw CQ ) $.
   lwE $e zw ( Tw CQ Cw ) $.
   mAE $a zw ( Tw Bw Cw ) $. $}
nAE $a zw IQE $.
${ wAE $e zw ( Tw Bw CQ ) $.
   wQE $e zw ( Tw Bw Cw ) $.
   wgE $a zw ( Tw Bw ( 4w CQ Cw ) ) $. $}
${ NwM $e zw CQ $.
   OAM $a zw ( Tw Bw CQ ) $. $}
rgM $a #Pattern ( rwM Bw CQ Kw Cw ) $.
tAM $a #Pattern ( tQM Bw CQ ) $.
0gM $a #Pattern ( 0wM Bw CQ Cw DQ ) $.
HwQ $a #Pattern ( IAQ Bw CQ ) $.
IwQ $a #Pattern ( JAQ Bw ) $.
egk $a #Pattern ewk $.
6hw $f #ElementVariable 6xw $.
7Bw $f #ElementVariable 7Rw $.
2B4 $a #Pattern 2R4 $.
3B4 $a zw ( Tw ( 4w ( JAQ 6xw ) IQE ) ( tQM 6xw ( rwM ewk 6xw 7Rw ( 0wM ewk 6xw 7Rw ( IAQ ewk 2R4 ) ) ) ) ) $.
dB8 $a #Pattern 6xw $.
0x8 $a zw ( Tw ( 4w IQE ( 4w ( JAQ 6xw ) IQE ) ) ( JAQ 6xw ) ) $.
1B8 $a #Pattern 7Rw $.
${ 1R8 $p zw ( Tw ( 4w IQE ( 4w ( JAQ 6xw ) IQE ) ) ( tQM 6xw ( rwM ewk 6xw 7Rw ( 0wM ewk 6xw 7Rw ( IAQ ewk 2R4 ) ) ) ) ) $=
  ( IAE dB8 IwQ 4g egk 1B8 2B4 HwQ 0gM rgM tAM 0x8 nAE OAM wgE 3B4 mAE ) CADZEZ
  CFZFZUBTGTGTBHGIJKBLMUCUACANUCCOPQABRS $. $}
