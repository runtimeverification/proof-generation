$c 2R4 LAQ ewk IAQ Tw #Symbol #Variable SwE #SetVariable zw 4w JAQ #ElementVariable IQE pgg #Pattern ) ( $.
$v CQ qwg Bw oAg 5Qg Cw sgg $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Cg $f #Pattern Cw $.
4g $a #Pattern ( 4w Bw CQ ) $.
IAE $a #Pattern IQE $.
SgE $a #Pattern ( SwE Bw CQ ) $.
${ lgE $e zw ( Tw Bw CQ ) $.
   lwE $e zw ( Tw CQ Cw ) $.
   mAE $a zw ( Tw Bw Cw ) $. $}
${ wAE $e zw ( Tw Bw CQ ) $.
   wQE $e zw ( Tw Bw Cw ) $.
   wgE $a zw ( Tw Bw ( 4w CQ Cw ) ) $. $}
HwQ $a #Pattern ( IAQ Bw CQ ) $.
IwQ $a #Pattern ( JAQ Bw ) $.
KwQ $a #Pattern ( LAQ Bw CQ Cw ) $.
nwg $f #Pattern oAg $.
pQg $a #Pattern pgg $.
qgg $f #Pattern qwg $.
sQg $f #Pattern sgg $.
5Ag $f #ElementVariable 5Qg $.
.gg $a zw ( Tw ( 4w ( 4w ( JAQ oAg ) ( JAQ qwg ) ) ( SwE sgg oAg ) ) ( SwE ( LAQ oAg qwg sgg ) qwg ) ) $.
egk $a #Pattern ewk $.
2B4 $a #Pattern 2R4 $.
YCU $a #Pattern 5Qg $.
4DE $a zw ( Tw ( 4w ( SwE 5Qg ewk ) IQE ) ( 4w ( JAQ ewk ) ( JAQ pgg ) ) ) $.
.zE $a zw ( Tw ( 4w ( SwE 5Qg ewk ) IQE ) ( SwE ( IAQ ewk 2R4 ) ewk ) ) $.
${ -DE $p zw ( Tw ( 4w ( SwE 5Qg ewk ) IQE ) ( SwE ( LAQ ewk pgg ( IAQ ewk 2R4 ) ) pgg ) ) $=
  ( YCU egk SgE IAE 4g IwQ pQg 2B4 HwQ KwQ 4DE .zE wgE .gg mAE ) ABCDEFZCGHGFZC
  IJZCDZFCHSKHDQRTALAMNCHSOP $. $}
