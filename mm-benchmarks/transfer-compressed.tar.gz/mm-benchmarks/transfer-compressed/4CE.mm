$c Uw PgE Tw #Symbol 7h4 cwE -gg zw JAQ vA4 #Pattern ( 0wM ewk xB4 tQM IAQ 3BA #Variable SwE #SetVariable vR4 4w rwM #ElementVariable IQE ) $.
$v yhs CQ qwg Bw Kw ph1 oAg ph0 2gg GQ Cw x $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Cg $f #Pattern Cw $.
GA $f #Pattern GQ $.
Kg $f #ElementVariable Kw $.
Ug $a #Pattern ( Uw Kw Bw ) $.
4g $a #Pattern ( 4w Bw CQ ) $.
IAE $a #Pattern IQE $.
PQE $a #Pattern ( PgE Bw CQ ) $.
${ lgE $e zw ( Tw Bw CQ ) $.
   lwE $e zw ( Tw CQ Cw ) $.
   mAE $a zw ( Tw Bw Cw ) $. $}
nAE $a zw IQE $.
${ NwM $e zw CQ $.
   OAM $a zw ( Tw Bw CQ ) $. $}
HwQ $a #Pattern ( IAQ Bw CQ ) $.
IwQ $a #Pattern ( JAQ Bw ) $.
${ $d x ph0 $.
   $d x ph1 $.
   vwY $e zw ( Tw GQ ( SwE CQ Bw ) ) $.
   wAY $e zw ( Tw GQ ( tQM cwE ( rwM Bw cwE Kw ( 0wM Bw cwE Kw CQ ) ) ) ) $.
   wQY $a zw ( Tw GQ ( Uw Kw ( PgE Kw CQ ) ) ) $. $}
nwg $f #Pattern oAg $.
qgg $f #Pattern qwg $.
2Qg $f #ElementVariable 2gg $.
-Qg $a #Pattern -gg $.
egk $a #Pattern ewk $.
uw4 $a #Pattern vA4 $.
2xA $a #Pattern ( 3BA oAg qwg ) $.
yRs $f #ElementVariable yhs $.
vB4 $a #Pattern vR4 $.
wx4 $a #Pattern xB4 $.
7R4 $a #Pattern 7h4 $.
Ax8 $a zw ( Tw IQE ( SwE ( 3BA ( IAQ ewk vR4 ) ( 3BA ( IAQ ewk 7h4 ) ( 3BA ( IAQ ewk xB4 ) vA4 ) ) ) -gg ) ) $.
Wh8 $a #Pattern 2gg $.
7SA $a #Pattern yhs $.
3yE $a zw ( Tw IQE ( tQM cwE ( rwM -gg cwE yhs ( 0wM -gg cwE yhs ( 3BA ( IAQ ewk vR4 ) ( 3BA ( IAQ ewk 7h4 ) ( 3BA ( IAQ ewk xB4 ) vA4 ) ) ) ) ) ) ) $.
${ 4CE $p zw ( Tw ( 4w ( JAQ 2gg ) IQE ) ( Uw yhs ( PgE yhs ( 3BA ( IAQ ewk vR4 ) ( 3BA ( IAQ ewk 7h4 ) ( 3BA ( IAQ ewk xB4 ) vA4 ) ) ) ) ) ) $=
  ( Wh8 IwQ IAE 4g 7SA egk vB4 HwQ 7R4 wx4 uw4 2xA PQE Ug nAE OAM -Qg Ax8 3yE
  wQY mAE ) ACDEFZEBGHIJHKJHLJMNNNZOBPUDEQRSUEEBTBUAUBUC $. $}
