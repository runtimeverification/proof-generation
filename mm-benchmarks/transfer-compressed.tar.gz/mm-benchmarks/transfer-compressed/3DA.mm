$c Uw PgE Tw #Symbol cwE zw pwk JAQ .gk Px0 pgg #Pattern ( 0wM LAQ tQM IAQ #Variable #SetVariable iA 4w #ElementVariable IQE ) $.
$v th1 Fw Ow CQ DQ Bw ph1 Cw 2gg EQ y th2 Dw Pw HQ FQ z xX ph2 th0 Gw Hw Ew Kw ph0 GQ x Lw 6xw LQ $.
$d z y $.
$d z x $.
$d y x $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Cg $f #Pattern Cw $.
DA $f #Pattern DQ $.
Dg $f #Pattern Dw $.
EA $f #Pattern EQ $.
Eg $f #Pattern Ew $.
FA $f #Pattern FQ $.
Fg $f #Pattern Fw $.
GA $f #Pattern GQ $.
Gg $f #Pattern Gw $.
HA $f #Pattern HQ $.
Hg $f #Pattern Hw $.
Kg $f #ElementVariable Kw $.
LA $f #ElementVariable LQ $.
Lg $f #ElementVariable Lw $.
Og $f #Variable Ow $.
Pg $f #Symbol Pw $.
SA $a #Variable Kw $.
Sw $a #Pattern Pw $.
Ug $a #Pattern ( Uw Kw Bw ) $.
jg $a iA Bw Ow Bw Ow $.
${ kg $e iA CQ DQ Bw Ow $.
   kw $e iA Cw Dw Bw Ow $.
   lA $a iA ( Tw CQ Cw ) ( Tw DQ Dw ) Bw Ow $. $}
4g $a #Pattern ( 4w Bw CQ ) $.
IAE $a #Pattern IQE $.
cgE $a #Symbol cwE $.
${ lgE $e zw ( Tw Bw CQ ) $.
   lwE $e zw ( Tw CQ Cw ) $.
   mAE $a zw ( Tw Bw Cw ) $. $}
nAE $a zw IQE $.
${ wAE $e zw ( Tw Bw CQ ) $.
   wQE $e zw ( Tw Bw Cw ) $.
   wgE $a zw ( Tw Bw ( 4w CQ Cw ) ) $. $}
${ $d xX ph0 $.
   IQI $a iA Bw Bw CQ Ow $. $}
${ NwM $e zw CQ $.
   OAM $a zw ( Tw Bw CQ ) $. $}
tAM $a #Pattern ( tQM Bw CQ ) $.
0gM $a #Pattern ( 0wM Bw CQ Cw DQ ) $.
HwQ $a #Pattern ( IAQ Bw CQ ) $.
IwQ $a #Pattern ( JAQ Bw ) $.
KwQ $a #Pattern ( LAQ Bw CQ Cw ) $.
${ QAQ $e iA Bw Cw Dw Ow $.
   QQQ $e iA CQ DQ Dw Ow $.
   QgQ $a iA ( tQM Bw CQ ) ( tQM Cw DQ ) Dw Ow $. $}
${ XgQ $e iA Bw Dw Fw Ow $.
   XwQ $e iA CQ EQ Fw Ow $.
   YAQ $e iA Cw Ew Fw Ow $.
   YQQ $e iA DQ FQ Fw Ow $.
   YgQ $a iA ( 0wM Bw CQ Cw DQ ) ( 0wM Dw EQ Ew FQ ) Fw Ow $. $}
iwY $a zw ( Uw Kw ( PgE Kw cwE ) ) $.
${ $d z ph0 $.
   $d z ph1 $.
   $d z ph2 $.
   $d z y $.
   $d z x $.
   $d z th1 $.
   $d z th2 $.
   $d x ph0 $.
   $d y th0 $.
   lAY $e zw ( Tw GQ ( Uw Kw ( PgE Kw Bw ) ) ) $.
   lQY $e zw ( Tw ( 4w GQ Gw ) CQ ) $.
   lgY $e iA ( Tw HQ Cw ) ( Tw Gw CQ ) Bw LQ $.
   lwY $e iA ( Tw Hw DQ ) ( Tw Gw CQ ) Lw LQ $.
   mAY $a zw ( Tw ( 4w GQ HQ ) Cw ) $. $}
pQg $a #Pattern pgg $.
2Qg $f #ElementVariable 2gg $.
pgk $a #Pattern pwk $.
.Qk $a #Pattern .gk $.
6hw $f #ElementVariable 6xw $.
Ph0 $a #Pattern Px0 $.
Wh8 $a #Pattern 2gg $.
dB8 $a #Pattern 6xw $.
0h8 $a #Pattern ( PgE Kw cwE ) $.
5B8 $a zw ( Tw IQE ( 4w ( JAQ cwE ) IQE ) ) $.
.h8 $a zw ( Tw ( 4w IQE ( 4w ( JAQ 2gg ) IQE ) ) ( JAQ 2gg ) ) $.
-R8 $a iA ( 4w ( JAQ cwE ) IQE ) ( 4w ( JAQ 2gg ) IQE ) cwE 2gg $.
-h8 $a iA pgg pgg cwE 2gg $.
ASA $a iA ( 4w ( JAQ 6xw ) IQE ) ( 4w ( JAQ 2gg ) IQE ) 6xw 2gg $.
AiA $a iA pgg pgg 6xw 2gg $.
2zA $a zw ( Tw ( 4w ( JAQ 2gg ) IQE ) ( tQM 2gg ( 0wM pgg 2gg ( LAQ .gk pgg ( IAQ .gk Px0 ) ) ( LAQ pwk pgg ( LAQ .gk pwk ( IAQ .gk Px0 ) ) ) ) ) ) $.
${ 3DA $p zw ( Tw IQE ( tQM cwE ( 0wM pgg cwE ( LAQ .gk pgg ( IAQ .gk Px0 ) ) ( LAQ pwk pgg ( LAQ .gk pwk ( IAQ .gk Px0 ) ) ) ) ) ) $=
  ( 2Qg 6hw Kg IAE IwQ 4g pQg .Qk KwQ pgk 0gM tAM nAE OAM wgE mAE IQI YgQ QgQ
  jg cgE Sw Ph0 HwQ 5B8 Wh8 dB8 0h8 Ug iwY .h8 2zA SA -R8 -h8 lA ASA AiA mAY )
  DDUAUBZEDFZFUTGUTHGHUCUDZIZJGHJVBIIZKZLZDDVADDMNUEOUTAUFZGVGVCVDKZLZVFBUGZGVJ
  VCVDKZLZDVGEZDFZVAVJEDFZCABDCUHCUICUJNDVNFZVNVIVPVMDAUKVPDMNOAULPUTVAVFVNVIAU
  MZAUNUTVEVGVHUTVQUTVQTZGUTVCVDGVGVCVDUTVQAUOVRVCUTVQQVDUTVQQRSUPVJVOVLVNVIVQA
  BUQVJVKVGVHVJVQVJVQTZGVJVCVDGVGVCVDVJVQABURVSVCVJVQQVDVJVQQRSUPUSP $. $}
