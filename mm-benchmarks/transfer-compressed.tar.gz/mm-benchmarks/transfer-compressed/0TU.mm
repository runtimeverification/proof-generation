$c Tw #Symbol 1CA zw JAQ rgk pgg #Pattern ( rwg 0wM LAQ tQM IAQ #Variable #SetVariable 4w rwM #ElementVariable IQE mwg xQg ) $.
$v CQ qwg DQ Bw Kw oAg Cw 6Ag 2gg $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Cg $f #Pattern Cw $.
DA $f #Pattern DQ $.
Kg $f #ElementVariable Kw $.
4g $a #Pattern ( 4w Bw CQ ) $.
IAE $a #Pattern IQE $.
${ lgE $e zw ( Tw Bw CQ ) $.
   lwE $e zw ( Tw CQ Cw ) $.
   mAE $a zw ( Tw Bw Cw ) $. $}
nAE $a zw IQE $.
${ wAE $e zw ( Tw Bw CQ ) $.
   wQE $e zw ( Tw Bw Cw ) $.
   wgE $a zw ( Tw Bw ( 4w CQ Cw ) ) $. $}
${ NwM $e zw CQ $.
   OAM $a zw ( Tw Bw CQ ) $. $}
rgM $a #Pattern ( rwM Bw CQ Kw Cw ) $.
tAM $a #Pattern ( tQM Bw CQ ) $.
0gM $a #Pattern ( 0wM Bw CQ Cw DQ ) $.
HwQ $a #Pattern ( IAQ Bw CQ ) $.
IwQ $a #Pattern ( JAQ Bw ) $.
KwQ $a #Pattern ( LAQ Bw CQ Cw ) $.
mgg $a #Pattern mwg $.
nwg $f #Pattern oAg $.
pQg $a #Pattern pgg $.
qgg $f #Pattern qwg $.
rgg $a #Pattern ( rwg oAg qwg ) $.
xAg $a #Pattern xQg $.
2Qg $f #ElementVariable 2gg $.
5wg $f #ElementVariable 6Ag $.
rQk $a #Pattern rgk $.
Wh8 $a #Pattern 2gg $.
.h8 $a zw ( Tw ( 4w IQE ( 4w ( JAQ 2gg ) IQE ) ) ( JAQ 2gg ) ) $.
0yA $a #Pattern 1CA $.
BCE $a #Pattern 6Ag $.
0DU $a zw ( Tw ( 4w ( JAQ 2gg ) IQE ) ( tQM 2gg ( rwM mwg 2gg 6Ag ( 0wM mwg 2gg 6Ag ( rwg ( LAQ rgk pgg ( IAQ rgk 1CA ) ) xQg ) ) ) ) ) $.
${ 0TU $p zw ( Tw ( 4w IQE ( 4w ( JAQ 2gg ) IQE ) ) ( tQM 2gg ( rwM mwg 2gg 6Ag ( 0wM mwg 2gg 6Ag ( rwg ( LAQ rgk pgg ( IAQ rgk 1CA ) ) xQg ) ) ) ) ) $=
  ( IAE Wh8 IwQ 4g mgg BCE rQk pQg 0yA HwQ KwQ xAg rgg 0gM rgM tAM .h8 nAE OAM
  wgE 0DU mAE ) CADZEZCFZFZUGUEGUEGUEBHIJIKLMNOPBQRUHUFCASUHCTUAUBABUCUD $. $}
