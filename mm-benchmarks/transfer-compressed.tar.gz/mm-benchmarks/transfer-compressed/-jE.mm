$c ewk IAQ 0h4 Tw #Symbol #Variable SwE pgg #SetVariable zw 4w JAQ #ElementVariable IQE rgk #Pattern ) ( $.
$v 5Qg Cw CQ Bw $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Cg $f #Pattern Cw $.
4g $a #Pattern ( 4w Bw CQ ) $.
IAE $a #Pattern IQE $.
SgE $a #Pattern ( SwE Bw CQ ) $.
${ wAE $e zw ( Tw Bw CQ ) $.
   wQE $e zw ( Tw Bw Cw ) $.
   wgE $a zw ( Tw Bw ( 4w CQ Cw ) ) $. $}
HwQ $a #Pattern ( IAQ Bw CQ ) $.
IwQ $a #Pattern ( JAQ Bw ) $.
pQg $a #Pattern pgg $.
5Ag $f #ElementVariable 5Qg $.
egk $a #Pattern ewk $.
rQk $a #Pattern rgk $.
0R4 $a #Pattern 0h4 $.
YCU $a #Pattern 5Qg $.
5DE $a zw ( Tw ( 4w ( SwE 5Qg ewk ) IQE ) ( 4w ( JAQ rgk ) ( JAQ pgg ) ) ) $.
-TE $a zw ( Tw ( 4w ( SwE 5Qg ewk ) IQE ) ( SwE ( IAQ rgk 0h4 ) rgk ) ) $.
${ -jE $p zw ( Tw ( 4w ( SwE 5Qg ewk ) IQE ) ( 4w ( 4w ( JAQ rgk ) ( JAQ pgg ) ) ( SwE ( IAQ rgk 0h4 ) rgk ) ) ) $=
  ( YCU egk SgE IAE 4g rQk IwQ pQg 0R4 HwQ 5DE -TE wgE ) ABCDEFGHIHFGJKGDALAMN
  $. $}
