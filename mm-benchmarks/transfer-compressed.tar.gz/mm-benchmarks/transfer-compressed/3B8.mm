$c 0wM 2R4 ewk IAQ #Symbol cwE #Variable #SetVariable iA #ElementVariable #Pattern ) ( $.
$v 7Rw Ow CQ Fw DQ Bw Cw EQ Dw Pw FQ xX Ew Kw ph0 6xw $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Cg $f #Pattern Cw $.
DA $f #Pattern DQ $.
Dg $f #Pattern Dw $.
EA $f #Pattern EQ $.
Eg $f #Pattern Ew $.
FA $f #Pattern FQ $.
Fg $f #Pattern Fw $.
Kg $f #ElementVariable Kw $.
Og $f #Variable Ow $.
Pg $f #Symbol Pw $.
SA $a #Variable Kw $.
Sw $a #Pattern Pw $.
jg $a iA Bw Ow Bw Ow $.
cgE $a #Symbol cwE $.
${ $d xX ph0 $.
   IQI $a iA Bw Bw CQ Ow $. $}
HwQ $a #Pattern ( IAQ Bw CQ ) $.
${ XgQ $e iA Bw Dw Fw Ow $.
   XwQ $e iA CQ EQ Fw Ow $.
   YAQ $e iA Cw Ew Fw Ow $.
   YQQ $e iA DQ FQ Fw Ow $.
   YgQ $a iA ( 0wM Bw CQ Cw DQ ) ( 0wM Dw EQ Ew FQ ) Fw Ow $. $}
egk $a #Pattern ewk $.
6hw $f #ElementVariable 6xw $.
7Bw $f #ElementVariable 7Rw $.
2B4 $a #Pattern 2R4 $.
dB8 $a #Pattern 6xw $.
1B8 $a #Pattern 7Rw $.
2h8 $a iA ewk ewk cwE 6xw $.
2x8 $a iA 7Rw 7Rw cwE 6xw $.
${ 3B8 $p iA ( 0wM ewk cwE 7Rw ( IAQ ewk 2R4 ) ) ( 0wM ewk 6xw 7Rw ( IAQ ewk 2R4 ) ) cwE 6xw $=
  ( egk cgE Sw 1B8 2B4 HwQ dB8 SA 2h8 jg 2x8 IQI YgQ ) CDEZBFZCGHZCAIQRPAJZAKPS
  LABMRPSNO $. $}
