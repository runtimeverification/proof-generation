$c #SetVariable 0wM #ElementVariable #Symbol #Variable mwg #Pattern xQg ) ( $.
$v Cw 6Ag 2gg CQ DQ Bw $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Cg $f #Pattern Cw $.
DA $f #Pattern DQ $.
0gM $a #Pattern ( 0wM Bw CQ Cw DQ ) $.
mgg $a #Pattern mwg $.
xAg $a #Pattern xQg $.
2Qg $f #ElementVariable 2gg $.
5wg $f #ElementVariable 6Ag $.
Wh8 $a #Pattern 2gg $.
BCE $a #Pattern 6Ag $.
${ 2CQ $p #Pattern ( 0wM mwg 2gg 6Ag xQg ) $=
  ( mgg Wh8 BCE xAg 0gM ) CADBEFG $. $}
