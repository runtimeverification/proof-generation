$c LAQ IAQ Tw #Symbol #Variable 1CA SwE pgg #SetVariable zw 4w JAQ #ElementVariable IQE rgk #Pattern ) ( $.
$v CQ qwg Bw oAg Cw sgg $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Cg $f #Pattern Cw $.
4g $a #Pattern ( 4w Bw CQ ) $.
IAE $a #Pattern IQE $.
SgE $a #Pattern ( SwE Bw CQ ) $.
${ lgE $e zw ( Tw Bw CQ ) $.
   lwE $e zw ( Tw CQ Cw ) $.
   mAE $a zw ( Tw Bw Cw ) $. $}
${ wAE $e zw ( Tw Bw CQ ) $.
   wQE $e zw ( Tw Bw Cw ) $.
   wgE $a zw ( Tw Bw ( 4w CQ Cw ) ) $. $}
HwQ $a #Pattern ( IAQ Bw CQ ) $.
IwQ $a #Pattern ( JAQ Bw ) $.
KwQ $a #Pattern ( LAQ Bw CQ Cw ) $.
nwg $f #Pattern oAg $.
pQg $a #Pattern pgg $.
qgg $f #Pattern qwg $.
sQg $f #Pattern sgg $.
.gg $a zw ( Tw ( 4w ( 4w ( JAQ oAg ) ( JAQ qwg ) ) ( SwE sgg oAg ) ) ( SwE ( LAQ oAg qwg sgg ) qwg ) ) $.
rQk $a #Pattern rgk $.
.x4 $a zw ( Tw IQE ( JAQ pgg ) ) $.
Bh8 $a zw ( Tw IQE ( JAQ rgk ) ) $.
0yA $a #Pattern 1CA $.
2yA $a zw ( Tw IQE ( SwE ( IAQ rgk 1CA ) rgk ) ) $.
${ 4SA $p zw ( Tw IQE ( SwE ( LAQ rgk pgg ( IAQ rgk 1CA ) ) pgg ) ) $=
  ( IAE rQk IwQ pQg 4g 0yA HwQ SgE KwQ Bh8 .x4 wgE 2yA .gg mAE ) ABCZDCZEZBFGZB
  HZEBDSIDHARTAPQJKLMLBDSNO $. $}
