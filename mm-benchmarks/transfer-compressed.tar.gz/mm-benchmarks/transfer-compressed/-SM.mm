$c #Symbol Tw #Variable #SetVariable zw 4w JAQ lAk #ElementVariable IQE #Pattern ) ( $.
$v 2gg CQ Bw $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Tg $a #Pattern ( Tw Bw CQ ) $.
4g $a #Pattern ( 4w Bw CQ ) $.
5Q $a zw ( Tw Bw ( Tw CQ Bw ) ) $.
${ 6A $e zw ( Tw Bw CQ ) $.
   6Q $e zw Bw $.
   6g $a zw CQ $. $}
IAE $a #Pattern IQE $.
IwQ $a #Pattern ( JAQ Bw ) $.
2Qg $f #ElementVariable 2gg $.
kwk $a #Pattern lAk $.
lwk $a zw ( JAQ lAk ) $.
Wh8 $a #Pattern 2gg $.
${ -SM $p zw ( Tw ( 4w ( JAQ 2gg ) IQE ) ( JAQ lAk ) ) $=
  ( kwk IwQ Wh8 IAE 4g Tg 5Q lwk 6g ) BCZADCEFZKGKLHIJ $. $}
