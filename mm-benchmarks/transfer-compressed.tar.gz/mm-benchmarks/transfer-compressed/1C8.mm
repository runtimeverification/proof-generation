$c XBI #Symbol pgg rgk #Pattern ( rwg LAQ ewk xB4 IAQ Wgk Hg8 #Variable 0hU #SetVariable iA #ElementVariable qxs 8wk 8hw ) $.
$v Ow CQ qwg DQ Bw Cw EQ sgg Zw0 tAg Dw ngg ZQ0 xX 3gg Ew Kw ph0 oAg 5Qg MB0 tgg 4Ag $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Cg $f #Pattern Cw $.
DA $f #Pattern DQ $.
Dg $f #Pattern Dw $.
EA $f #Pattern EQ $.
Eg $f #Pattern Ew $.
Kg $f #ElementVariable Kw $.
Og $f #Variable Ow $.
SA $a #Variable Kw $.
jg $a iA Bw Ow Bw Ow $.
${ $d xX ph0 $.
   IQI $a iA Bw Bw CQ Ow $. $}
HwQ $a #Pattern ( IAQ Bw CQ ) $.
KwQ $a #Pattern ( LAQ Bw CQ Cw ) $.
${ lAQ $e iA Bw DQ Ew Ow $.
   lQQ $e iA CQ Dw Ew Ow $.
   lgQ $e iA Cw EQ Ew Ow $.
   lwQ $a iA ( LAQ Bw CQ Cw ) ( LAQ DQ Dw EQ ) Ew Ow $. $}
nQg $f #Variable ngg $.
nwg $f #Pattern oAg $.
pQg $a #Pattern pgg $.
qgg $f #Pattern qwg $.
rgg $a #Pattern ( rwg oAg qwg ) $.
sQg $f #Pattern sgg $.
swg $f #Pattern tAg $.
tQg $f #Pattern tgg $.
${ uQg $e iA qwg tAg oAg ngg $.
   ugg $e iA sgg tgg oAg ngg $.
   uwg $a iA ( rwg qwg sgg ) ( rwg tAg tgg ) oAg ngg $. $}
3Qg $f #ElementVariable 3gg $.
3wg $f #ElementVariable 4Ag $.
5Ag $f #ElementVariable 5Qg $.
WQk $a #Pattern Wgk $.
egk $a #Pattern ewk $.
rQk $a #Pattern rgk $.
8gk $a #Pattern 8wk $.
ZA0 $f #Pattern ZQ0 $.
Zg0 $f #Pattern Zw0 $.
${ Ig8 $e iA qwg sgg oAg ngg $.
   Iw8 $a iA ( Hg8 qwg ) ( Hg8 sgg ) oAg ngg $. $}
WxI $a #Pattern ( XBI oAg qwg ) $.
0RU $a #Pattern ( 0hU oAg qwg sgg ) $.
${ 1BU $e iA qwg tgg oAg ngg $.
   1RU $e iA sgg ZQ0 oAg ngg $.
   1hU $e iA tAg Zw0 oAg ngg $.
   1xU $a iA ( 0hU qwg sgg tAg ) ( 0hU tgg ZQ0 Zw0 ) oAg ngg $. $}
qhs $a #Pattern ( qxs oAg ) $.
8Rw $a #Pattern 8hw $.
Lx0 $f #ElementVariable MB0 $.
wx4 $a #Pattern xB4 $.
BCQ $a #Pattern 4Ag $.
XiU $a #Pattern 3gg $.
YCU $a #Pattern 5Qg $.
qy8 $a #Pattern MB0 $.
wS8 $a #Pattern ( 0hU 5Qg 4Ag MB0 ) $.
0S8 $a #Pattern ( rwg ( LAQ 8wk pgg ( 0hU 5Qg ( qxs ( XBI ( IAQ ewk xB4 ) ( LAQ rgk Wgk ( IAQ rgk 8hw ) ) ) ) MB0 ) ) 3gg ) $.
${ 1C8 $p iA ( Hg8 ( rwg ( LAQ 8wk pgg ( 0hU 5Qg ( qxs ( XBI ( IAQ ewk xB4 ) ( LAQ rgk Wgk ( IAQ rgk 8hw ) ) ) ) MB0 ) ) 3gg ) ) ( Hg8 ( rwg ( LAQ 8wk pgg ( 0hU 5Qg 4Ag MB0 ) ) 3gg ) ) ( qxs ( XBI ( IAQ ewk xB4 ) ( LAQ rgk Wgk ( IAQ rgk 8hw ) ) ) ) 4Ag $=
  ( SA egk wx4 HwQ rQk WQk 8Rw KwQ WxI qhs 0S8 8gk pQg wS8 XiU IQI rgg YCU qy8
  0RU BCQ jg 1xU lwQ uwg Iw8 ) BEZFGHIJIKHLMNZACDOPQBCDRZLZASZUAUKULPQCUBZULDUC
  ZUDZLUOUNUOPQURPQUMULUKPULUKTQULUKTUKULUPULUQUPBUEUQUPULUKTULUKUFUQULUKTUGUHU
  OULUKTUIUJ $. $}
