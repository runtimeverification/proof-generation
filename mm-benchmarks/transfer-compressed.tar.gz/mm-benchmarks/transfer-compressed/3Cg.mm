$c LAQ ewk cBQ #Symbol #Variable pgg #SetVariable ) #ElementVariable 7BI rgk #Pattern ( $.
$v 4wg CQ qwg 3gg -Bw Bw oAg Cw $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Cg $f #Pattern Cw $.
KwQ $a #Pattern ( LAQ Bw CQ Cw ) $.
nwg $f #Pattern oAg $.
pQg $a #Pattern pgg $.
qgg $f #Pattern qwg $.
3Qg $f #ElementVariable 3gg $.
4gg $f #ElementVariable 4wg $.
egk $a #Pattern ewk $.
rQk $a #Pattern rgk $.
6xI $a #Pattern ( 7BI oAg qwg ) $.
bxQ $a #Pattern ( cBQ oAg qwg ) $.
.xw $f #ElementVariable -Bw $.
XiU $a #Pattern 3gg $.
XyU $a #Pattern 4wg $.
yyg $a #Pattern -Bw $.
${ 3Cg $p #Pattern ( 7BI ( cBQ ( LAQ ewk pgg 4wg ) ( LAQ rgk pgg 3gg ) ) -Bw ) $=
  ( egk pQg XyU KwQ rQk XiU bxQ yyg 6xI ) DEBFGHEAIGJCKL $. $}
