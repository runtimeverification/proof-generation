$c #SetVariable iA ) #ElementVariable #Symbol #Variable 0hU #Pattern ( $.
$v ngg Ow ZQ0 qwg Bw Kw oAg 5Qg MB0 nR4 sgg Zw0 tAg tgg 4Ag $.
Bg $f #Pattern Bw $.
Kg $f #ElementVariable Kw $.
Og $f #Variable Ow $.
SA $a #Variable Kw $.
jg $a iA Bw Ow Bw Ow $.
nQg $f #Variable ngg $.
nwg $f #Pattern oAg $.
qgg $f #Pattern qwg $.
sQg $f #Pattern sgg $.
swg $f #Pattern tAg $.
tQg $f #Pattern tgg $.
3wg $f #ElementVariable 4Ag $.
5Ag $f #ElementVariable 5Qg $.
ZA0 $f #Pattern ZQ0 $.
Zg0 $f #Pattern Zw0 $.
${ 1BU $e iA qwg tgg oAg ngg $.
   1RU $e iA sgg ZQ0 oAg ngg $.
   1hU $e iA tAg Zw0 oAg ngg $.
   1xU $a iA ( 0hU qwg sgg tAg ) ( 0hU tgg ZQ0 Zw0 ) oAg ngg $. $}
Lx0 $f #ElementVariable MB0 $.
nB4 $f #ElementVariable nR4 $.
6h8 $a #Pattern nR4 $.
BCQ $a #Pattern 4Ag $.
YCU $a #Pattern 5Qg $.
pio $a iA 5Qg 5Qg nR4 4Ag $.
qy8 $a #Pattern MB0 $.
1S8 $a iA MB0 MB0 nR4 4Ag $.
${ 1i8 $p iA ( 0hU 5Qg nR4 MB0 ) ( 0hU 5Qg 4Ag MB0 ) nR4 4Ag $=
  ( SA 6h8 YCU qy8 BCQ pio jg 1S8 1xU ) AEZDFZBGZOCHZPAIQABDJONKACDLM $. $}
