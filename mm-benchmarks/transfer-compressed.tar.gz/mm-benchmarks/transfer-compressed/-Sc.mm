$c #Symbol #Variable SwE PQk #SetVariable iA 4w #ElementVariable IQE #Pattern ) ( $.
$v 4wg Ow CQ DQ Bw Kw Cw nR4 Dw $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Cg $f #Pattern Cw $.
DA $f #Pattern DQ $.
Dg $f #Pattern Dw $.
Kg $f #ElementVariable Kw $.
Og $f #Variable Ow $.
SA $a #Variable Kw $.
IAE $a #Pattern IQE $.
SgE $a #Pattern ( SwE Bw CQ ) $.
${ KAI $e iA CQ DQ Bw Ow $.
   KQI $e iA Cw Dw Bw Ow $.
   KgI $a iA ( 4w CQ Cw ) ( 4w DQ Dw ) Bw Ow $. $}
4gg $f #ElementVariable 4wg $.
PAk $a #Pattern PQk $.
nB4 $f #ElementVariable nR4 $.
6h8 $a #Pattern nR4 $.
XyU $a #Pattern 4wg $.
piU $a iA IQE IQE nR4 4wg $.
-Cc $a iA ( SwE nR4 PQk ) ( SwE 4wg PQk ) nR4 4wg $.
${ -Sc $p iA ( 4w ( SwE nR4 PQk ) IQE ) ( 4w ( SwE 4wg PQk ) IQE ) nR4 4wg $=
  ( 6h8 PAk SgE IAE XyU SA -Cc piU KgI ) BCZLDEFAGDEFAHABIABJK $. $}
