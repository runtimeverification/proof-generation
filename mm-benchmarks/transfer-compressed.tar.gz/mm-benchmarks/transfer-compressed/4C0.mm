$c Tw #Symbol zw JAQ pgg rgk #Pattern ( LAQ ewk xB4 IAQ Wgk #Variable SwE #SetVariable 4w #ElementVariable IQE 8hw ) $.
$v CQ qwg -Bw Bw oAg 5Qg Cw sgg $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Cg $f #Pattern Cw $.
4g $a #Pattern ( 4w Bw CQ ) $.
SgE $a #Pattern ( SwE Bw CQ ) $.
${ lgE $e zw ( Tw Bw CQ ) $.
   lwE $e zw ( Tw CQ Cw ) $.
   mAE $a zw ( Tw Bw Cw ) $. $}
${ wAE $e zw ( Tw Bw CQ ) $.
   wQE $e zw ( Tw Bw Cw ) $.
   wgE $a zw ( Tw Bw ( 4w CQ Cw ) ) $. $}
HwQ $a #Pattern ( IAQ Bw CQ ) $.
IwQ $a #Pattern ( JAQ Bw ) $.
KwQ $a #Pattern ( LAQ Bw CQ Cw ) $.
nwg $f #Pattern oAg $.
pQg $a #Pattern pgg $.
qgg $f #Pattern qwg $.
sQg $f #Pattern sgg $.
5Ag $f #ElementVariable 5Qg $.
.gg $a zw ( Tw ( 4w ( 4w ( JAQ oAg ) ( JAQ qwg ) ) ( SwE sgg oAg ) ) ( SwE ( LAQ oAg qwg sgg ) qwg ) ) $.
egk $a #Pattern ewk $.
rQk $a #Pattern rgk $.
8Rw $a #Pattern 8hw $.
.xw $f #ElementVariable -Bw $.
wx4 $a #Pattern xB4 $.
pC0 $a #Pattern ( 4w ( SwE 5Qg Wgk ) ( 4w ( SwE -Bw pgg ) IQE ) ) $.
3i0 $a zw ( Tw ( 4w ( SwE 5Qg Wgk ) ( 4w ( SwE -Bw pgg ) IQE ) ) ( 4w ( 4w ( JAQ ewk ) ( JAQ pgg ) ) ( SwE ( IAQ ewk xB4 ) ewk ) ) ) $.
3y0 $a zw ( Tw ( 4w ( SwE 5Qg Wgk ) ( 4w ( SwE -Bw pgg ) IQE ) ) ( 4w ( 4w ( JAQ rgk ) ( JAQ pgg ) ) ( SwE ( IAQ rgk 8hw ) rgk ) ) ) $.
${ 4C0 $p zw ( Tw ( 4w ( SwE 5Qg Wgk ) ( 4w ( SwE -Bw pgg ) IQE ) ) ( 4w ( SwE ( LAQ ewk pgg ( IAQ ewk xB4 ) ) pgg ) ( SwE ( LAQ rgk pgg ( IAQ rgk 8hw ) ) pgg ) ) ) $=
  ( pC0 egk pQg wx4 HwQ KwQ SgE rQk 8Rw IwQ 4g 3i0 .gg mAE 3y0 wgE ) ABCZDEDFGZ
  HEIZJEJKGZHEIZSDLELZMTDIMUAABNDETOPSJLUDMUBJIMUCABQJEUBOPR $. $}
