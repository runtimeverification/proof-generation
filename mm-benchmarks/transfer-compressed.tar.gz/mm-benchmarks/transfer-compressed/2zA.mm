$c Tw #Symbol zw JAQ pwk .gk Px0 pgg #Pattern ( 0wM LAQ tQM IAQ #Variable #SetVariable 4w #ElementVariable IQE ) $.
$v CQ DQ Bw Cw 2gg GQ $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Cg $f #Pattern Cw $.
DA $f #Pattern DQ $.
GA $f #Pattern GQ $.
4g $a #Pattern ( 4w Bw CQ ) $.
IAE $a #Pattern IQE $.
lQE $a zw ( Tw Bw Bw ) $.
${ lgE $e zw ( Tw Bw CQ ) $.
   lwE $e zw ( Tw CQ Cw ) $.
   mAE $a zw ( Tw Bw Cw ) $. $}
nAE $a zw IQE $.
ugE $a zw ( Tw ( 4w Bw CQ ) Bw ) $.
${ wAE $e zw ( Tw Bw CQ ) $.
   wQE $e zw ( Tw Bw Cw ) $.
   wgE $a zw ( Tw Bw ( 4w CQ Cw ) ) $. $}
${ NwM $e zw CQ $.
   OAM $a zw ( Tw Bw CQ ) $. $}
tAM $a #Pattern ( tQM Bw CQ ) $.
0gM $a #Pattern ( 0wM Bw CQ Cw DQ ) $.
HwQ $a #Pattern ( IAQ Bw CQ ) $.
IwQ $a #Pattern ( JAQ Bw ) $.
KwQ $a #Pattern ( LAQ Bw CQ Cw ) $.
${ dQY $e zw ( Tw GQ ( tQM Bw ( 0wM CQ Bw DQ Cw ) ) ) $.
   dgY $a zw ( Tw GQ ( tQM Bw ( 0wM CQ Bw Cw DQ ) ) ) $. $}
pQg $a #Pattern pgg $.
2Qg $f #ElementVariable 2gg $.
pgk $a #Pattern pwk $.
.Qk $a #Pattern .gk $.
Ph0 $a #Pattern Px0 $.
Wh8 $a #Pattern 2gg $.
9h8 $a zw ( Tw ( 4w ( JAQ 2gg ) IQE ) ( 4w ( JAQ 2gg ) IQE ) ) $.
2jA $a zw ( Tw ( 4w ( JAQ 2gg ) IQE ) ( tQM 2gg ( 0wM pgg 2gg ( LAQ pwk pgg ( LAQ .gk pwk ( IAQ .gk Px0 ) ) ) ( LAQ .gk pgg ( IAQ .gk Px0 ) ) ) ) ) $.
${ 2zA $p zw ( Tw ( 4w ( JAQ 2gg ) IQE ) ( tQM 2gg ( 0wM pgg 2gg ( LAQ .gk pgg ( IAQ .gk Px0 ) ) ( LAQ pwk pgg ( LAQ .gk pwk ( IAQ .gk Px0 ) ) ) ) ) ) $=
  ( Wh8 IwQ IAE 4g pQg .Qk Ph0 HwQ KwQ pgk 0gM tAM 9h8 nAE OAM wgE ugE lQE mAE
  2jA dgY ) ABZCZDEZUEUEDEZEZUCFUCGFGHIZJZKFGKUHJJZLMUEUEUFANZUEUEDUKUEDOPQQUCF
  UIUJUGUGUEUCFUCUJUILMUGUDDUGUEUDUEUFRUEUDUDUDDRUDSTTUGDOPQAUATUBT $. $}
