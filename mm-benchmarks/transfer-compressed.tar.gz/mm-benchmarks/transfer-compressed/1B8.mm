$c #SetVariable ) #ElementVariable #Symbol #Variable #Pattern ( $.
$v 7Rw Ow Kw $.
Kg $f #ElementVariable Kw $.
Og $f #Variable Ow $.
SA $a #Variable Kw $.
Sg $a #Pattern Ow $.
7Bw $f #ElementVariable 7Rw $.
${ 1B8 $p #Pattern 7Rw $=
  ( SA Sg ) ABC $. $}
