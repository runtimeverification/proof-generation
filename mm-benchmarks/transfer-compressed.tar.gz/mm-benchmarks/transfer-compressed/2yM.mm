$c 0wM LAQ 1wk #Symbol #Variable #SetVariable iA #ElementVariable pgg #Pattern ) ( $.
$v yhs Fw Ow CQ FQ zBs DQ Ew Bw Kw Cw 2gg nR4 EQ Dw $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Cg $f #Pattern Cw $.
DA $f #Pattern DQ $.
Dg $f #Pattern Dw $.
EA $f #Pattern EQ $.
Eg $f #Pattern Ew $.
FA $f #Pattern FQ $.
Fg $f #Pattern Fw $.
Kg $f #ElementVariable Kw $.
Og $f #Variable Ow $.
SA $a #Variable Kw $.
KwQ $a #Pattern ( LAQ Bw CQ Cw ) $.
${ XgQ $e iA Bw Dw Fw Ow $.
   XwQ $e iA CQ EQ Fw Ow $.
   YAQ $e iA Cw Ew Fw Ow $.
   YQQ $e iA DQ FQ Fw Ow $.
   YgQ $a iA ( 0wM Bw CQ Cw DQ ) ( 0wM Dw EQ Ew FQ ) Fw Ow $. $}
pQg $a #Pattern pgg $.
2Qg $f #ElementVariable 2gg $.
1gk $a #Pattern 1wk $.
yRs $f #ElementVariable yhs $.
yxs $f #ElementVariable zBs $.
nB4 $f #ElementVariable nR4 $.
Wh8 $a #Pattern 2gg $.
6h8 $a #Pattern nR4 $.
7SA $a #Pattern yhs $.
JiE $a #Pattern zBs $.
NSE $a iA 2gg 2gg nR4 zBs $.
NiE $a iA pgg pgg nR4 zBs $.
NyE $a iA yhs yhs nR4 zBs $.
2iM $a iA ( LAQ 1wk pgg nR4 ) ( LAQ 1wk pgg zBs ) nR4 zBs $.
${ 2yM $p iA ( 0wM pgg 2gg yhs ( LAQ 1wk pgg nR4 ) ) ( 0wM pgg 2gg yhs ( LAQ 1wk pgg zBs ) ) nR4 zBs $=
  ( pQg Wh8 7SA 1gk 6h8 KwQ JiE SA NiE NSE NyE 2iM YgQ ) EAFZBGZHEDIZJERSHECKJT
  CLCDMACDNBCDOCDPQ $. $}
