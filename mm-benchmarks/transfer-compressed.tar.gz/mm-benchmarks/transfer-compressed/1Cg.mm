$c ewk Tw #Symbol #Variable SwE #SetVariable zw 4w YQk #ElementVariable IQE rgk pgg #Pattern ) ( $.
$v 4wg CQ 3gg -Bw Bw 5Qg Cw $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Cg $f #Pattern Cw $.
4g $a #Pattern ( 4w Bw CQ ) $.
SgE $a #Pattern ( SwE Bw CQ ) $.
${ lgE $e zw ( Tw Bw CQ ) $.
   lwE $e zw ( Tw CQ Cw ) $.
   mAE $a zw ( Tw Bw Cw ) $. $}
uwE $a zw ( Tw ( 4w Bw CQ ) CQ ) $.
3Qg $f #ElementVariable 3gg $.
4gg $f #ElementVariable 4wg $.
5Ag $f #ElementVariable 5Qg $.
YAk $a #Pattern YQk $.
egk $a #Pattern ewk $.
rQk $a #Pattern rgk $.
.xw $f #ElementVariable -Bw $.
XiU $a #Pattern 3gg $.
XyU $a #Pattern 4wg $.
yyg $a #Pattern -Bw $.
zCg $a #Pattern ( 4w ( SwE 5Qg pgg ) ( 4w ( SwE -Bw YQk ) IQE ) ) $.
0yg $a zw ( Tw ( 4w ( SwE 5Qg pgg ) ( 4w ( SwE -Bw YQk ) IQE ) ) ( SwE -Bw YQk ) ) $.
${ 1Cg $p zw ( Tw ( 4w ( SwE 3gg rgk ) ( 4w ( SwE 4wg ewk ) ( 4w ( SwE 5Qg pgg ) ( 4w ( SwE -Bw YQk ) IQE ) ) ) ) ( SwE -Bw YQk ) ) $=
  ( XiU rQk SgE XyU egk zCg 4g yyg YAk uwE 0yg mAE ) AEFGZBHIGZCDJZKZKTDLMGZQTN
  TSUARSNCDOPP $. $}
