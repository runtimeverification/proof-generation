$c #SetVariable GBY iA ) #ElementVariable #Symbol #Variable #Pattern ( $.
$v ngg Ow qwg sgg Bw XRw Kw oAg nR4 -Rs tAg tgg $.
Bg $f #Pattern Bw $.
Kg $f #ElementVariable Kw $.
Og $f #Variable Ow $.
SA $a #Variable Kw $.
jg $a iA Bw Ow Bw Ow $.
nQg $f #Variable ngg $.
nwg $f #Pattern oAg $.
qgg $f #Pattern qwg $.
sQg $f #Pattern sgg $.
swg $f #Pattern tAg $.
tQg $f #Pattern tgg $.
${ HBY $e iA qwg tAg oAg ngg $.
   HRY $e iA sgg tgg oAg ngg $.
   HhY $a iA ( GBY qwg sgg ) ( GBY tAg tgg ) oAg ngg $. $}
-Bs $f #ElementVariable -Rs $.
XBw $f #ElementVariable XRw $.
nB4 $f #ElementVariable nR4 $.
6h8 $a #Pattern nR4 $.
QCE $a #Pattern XRw $.
QyE $a #Pattern -Rs $.
ViE $a iA XRw XRw nR4 -Rs $.
${ -SE $p iA ( GBY nR4 XRw ) ( GBY -Rs XRw ) nR4 -Rs $=
  ( SA 6h8 QCE QyE jg ViE HhY ) ADZCEZLBFZAGMLKHABCIJ $. $}
