$c Uw PgE Tw #Symbol zw YQk JAQ pgg #Pattern ( 0wM LAQ ewk xB4 tQM IAQ #Variable SwE #SetVariable iA 4w rwM #ElementVariable IQE ) cBQ $.
$v th1 yhs Ow CQ DQ Bw XRw ph1 Cw 2gg y th2 -Rs Dw HQ z xX ph2 th0 Gw Hw Kw ph0 GQ nR4 x Lw LQ $.
$d z y $.
$d z x $.
$d y x $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Cg $f #Pattern Cw $.
DA $f #Pattern DQ $.
Dg $f #Pattern Dw $.
GA $f #Pattern GQ $.
Gg $f #Pattern Gw $.
HA $f #Pattern HQ $.
Hg $f #Pattern Hw $.
Kg $f #ElementVariable Kw $.
LA $f #ElementVariable LQ $.
Lg $f #ElementVariable Lw $.
Og $f #Variable Ow $.
SA $a #Variable Kw $.
jg $a iA Bw Ow Bw Ow $.
${ kg $e iA CQ DQ Bw Ow $.
   kw $e iA Cw Dw Bw Ow $.
   lA $a iA ( Tw CQ Cw ) ( Tw DQ Dw ) Bw Ow $. $}
4g $a #Pattern ( 4w Bw CQ ) $.
IAE $a #Pattern IQE $.
SgE $a #Pattern ( SwE Bw CQ ) $.
${ lgE $e zw ( Tw Bw CQ ) $.
   lwE $e zw ( Tw CQ Cw ) $.
   mAE $a zw ( Tw Bw Cw ) $. $}
nAE $a zw IQE $.
${ wAE $e zw ( Tw Bw CQ ) $.
   wQE $e zw ( Tw Bw Cw ) $.
   wgE $a zw ( Tw Bw ( 4w CQ Cw ) ) $. $}
${ $d xX ph0 $.
   IQI $a iA Bw Bw CQ Ow $. $}
${ KAI $e iA CQ DQ Bw Ow $.
   KQI $e iA Cw Dw Bw Ow $.
   KgI $a iA ( 4w CQ Cw ) ( 4w DQ Dw ) Bw Ow $. $}
${ OgI $e iA CQ DQ Bw Ow $.
   OwI $e iA Cw Dw Bw Ow $.
   PAI $a iA ( SwE CQ Cw ) ( SwE DQ Dw ) Bw Ow $. $}
${ NwM $e zw CQ $.
   OAM $a zw ( Tw Bw CQ ) $. $}
rgM $a #Pattern ( rwM Bw CQ Kw Cw ) $.
tAM $a #Pattern ( tQM Bw CQ ) $.
HwQ $a #Pattern ( IAQ Bw CQ ) $.
KwQ $a #Pattern ( LAQ Bw CQ Cw ) $.
${ QAQ $e iA Bw Cw Dw Ow $.
   QQQ $e iA CQ DQ Dw Ow $.
   QgQ $a iA ( tQM Bw CQ ) ( tQM Cw DQ ) Dw Ow $. $}
${ $d z ph0 $.
   $d z ph1 $.
   $d z ph2 $.
   $d z y $.
   $d z x $.
   $d z th1 $.
   $d z th2 $.
   $d x ph0 $.
   $d y th0 $.
   lAY $e zw ( Tw GQ ( Uw Kw ( PgE Kw Bw ) ) ) $.
   lQY $e zw ( Tw ( 4w GQ Gw ) CQ ) $.
   lgY $e iA ( Tw HQ Cw ) ( Tw Gw CQ ) Bw LQ $.
   lwY $e iA ( Tw Hw DQ ) ( Tw Gw CQ ) Lw LQ $.
   mAY $a zw ( Tw ( 4w GQ HQ ) Cw ) $. $}
pQg $a #Pattern pgg $.
2Qg $f #ElementVariable 2gg $.
YAk $a #Pattern YQk $.
egk $a #Pattern ewk $.
yRs $f #ElementVariable yhs $.
-Bs $f #ElementVariable -Rs $.
XBw $f #ElementVariable XRw $.
nB4 $f #ElementVariable nR4 $.
wx4 $a #Pattern xB4 $.
Wh8 $a #Pattern 2gg $.
6h8 $a #Pattern nR4 $.
QSE $a #Pattern ( 4w ( JAQ 2gg ) ( 4w ( SwE XRw pgg ) IQE ) ) $.
QyE $a #Pattern -Rs $.
SSE $a #Pattern ( 0wM YQk 2gg yhs ( cBQ -Rs XRw ) ) $.
SiE $a zw ( Tw ( 4w ( 4w ( JAQ 2gg ) ( 4w ( SwE XRw pgg ) IQE ) ) ( 4w ( SwE -Rs pgg ) IQE ) ) ( tQM 2gg ( rwM YQk 2gg yhs ( 0wM YQk 2gg yhs ( cBQ -Rs XRw ) ) ) ) ) $.
TSE $a #Pattern ( 0wM YQk 2gg yhs ( cBQ nR4 XRw ) ) $.
UiE $a iA ( 4w ( SwE nR4 pgg ) IQE ) ( 4w ( SwE -Rs pgg ) IQE ) nR4 -Rs $.
WiE $a iA ( tQM 2gg ( rwM YQk 2gg yhs ( 0wM YQk 2gg yhs ( cBQ nR4 XRw ) ) ) ) ( tQM 2gg ( rwM YQk 2gg yhs ( 0wM YQk 2gg yhs ( cBQ -Rs XRw ) ) ) ) nR4 -Rs $.
WyE $a zw ( Tw ( 4w ( JAQ 2gg ) ( 4w ( SwE XRw pgg ) IQE ) ) ( 4w ( JAQ 2gg ) ( 4w ( SwE XRw pgg ) IQE ) ) ) $.
1yc $a zw ( Tw ( 4w ( JAQ 2gg ) ( 4w ( SwE XRw pgg ) IQE ) ) ( Uw yhs ( PgE yhs ( LAQ ewk pgg ( IAQ ewk xB4 ) ) ) ) ) $.
2Cc $a #Pattern ( 0wM YQk 2gg yhs ( cBQ ( LAQ ewk pgg ( IAQ ewk xB4 ) ) XRw ) ) $.
2Sc $a iA ( rwM YQk 2gg yhs ( 0wM YQk 2gg yhs ( cBQ ( LAQ ewk pgg ( IAQ ewk xB4 ) ) XRw ) ) ) ( rwM YQk 2gg yhs ( 0wM YQk 2gg yhs ( cBQ -Rs XRw ) ) ) ( LAQ ewk pgg ( IAQ ewk xB4 ) ) -Rs $.
2ic $a zw ( Tw ( 4w ( JAQ 2gg ) ( 4w ( SwE XRw pgg ) IQE ) ) ( SwE ( LAQ ewk pgg ( IAQ ewk xB4 ) ) pgg ) ) $.
${ 2yc $p zw ( Tw ( 4w ( JAQ 2gg ) ( 4w ( SwE XRw pgg ) IQE ) ) ( tQM 2gg ( rwM YQk 2gg yhs ( 0wM YQk 2gg yhs ( cBQ ( LAQ ewk pgg ( IAQ ewk xB4 ) ) XRw ) ) ) ) ) $=
  ( -Bs nB4 QSE egk pQg wx4 HwQ KwQ SgE IAE 4g YAk rgM tAM wgE IQI lA Wh8 SA jg
  2Cc WyE 2ic nAE OAM SSE TSE QyE 6h8 1yc SiE PAI KgI 2Sc QgQ UiE WiE mAY mAE )
  ACFZVCGHGIJKZHLZMNZNAUAZOVGABCUDBPZQZVCVCVFACUEVCVEMACUFVCMUGUHRRVDVGOVGABDCU
  IBPZQZVIVGOVGABCEUJBPQZVCDUKZHLZMNZVFEULZHLMNZBDEABCUMABDCUNVDVFVIVOVKDUBZVDV
  EMVNMVRVDVDHVMHVRVDVRUCHVDVRSUOMVDVRSUPVGVHVGVJVDVRVGVDVRSABDCUQURTVPVQVLVOVK
  VRDEUSABDCEUTTVAVB $. $}
