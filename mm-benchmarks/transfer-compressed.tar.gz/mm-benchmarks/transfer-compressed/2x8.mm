$c #SetVariable cwE iA ) #ElementVariable #Symbol #Variable #Pattern ( $.
$v 7Rw Ow CQ xX Bw Kw ph0 6xw Pw $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Kg $f #ElementVariable Kw $.
Og $f #Variable Ow $.
Pg $f #Symbol Pw $.
SA $a #Variable Kw $.
Sw $a #Pattern Pw $.
cgE $a #Symbol cwE $.
${ $d xX ph0 $.
   IQI $a iA Bw Bw CQ Ow $. $}
6hw $f #ElementVariable 6xw $.
7Bw $f #ElementVariable 7Rw $.
1B8 $a #Pattern 7Rw $.
${ 2x8 $p iA 7Rw 7Rw cwE 6xw $=
  ( 1B8 cgE Sw SA IQI ) BCDEAFG $. $}
