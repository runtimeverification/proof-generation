$c 0wM LAQ tQM Tw #Symbol #Variable SwE #SetVariable zw 4w JAQ pwk #ElementVariable IQE .gk #Pattern ) ( $.
$v CQ DQ Bw lB4 Cw 2gg mh4 $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Cg $f #Pattern Cw $.
DA $f #Pattern DQ $.
4g $a #Pattern ( 4w Bw CQ ) $.
IAE $a #Pattern IQE $.
${ lgE $e zw ( Tw Bw CQ ) $.
   lwE $e zw ( Tw CQ Cw ) $.
   mAE $a zw ( Tw Bw Cw ) $. $}
ugE $a zw ( Tw ( 4w Bw CQ ) Bw ) $.
${ wAE $e zw ( Tw Bw CQ ) $.
   wQE $e zw ( Tw Bw Cw ) $.
   wgE $a zw ( Tw Bw ( 4w CQ Cw ) ) $. $}
tAM $a #Pattern ( tQM Bw CQ ) $.
0gM $a #Pattern ( 0wM Bw CQ Cw DQ ) $.
IwQ $a #Pattern ( JAQ Bw ) $.
KwQ $a #Pattern ( LAQ Bw CQ Cw ) $.
2Qg $f #ElementVariable 2gg $.
pgk $a #Pattern pwk $.
.Qk $a #Pattern .gk $.
kx4 $f #ElementVariable lB4 $.
mR4 $f #ElementVariable mh4 $.
Wh8 $a #Pattern 2gg $.
XB8 $a #Pattern lB4 $.
YR8 $a #Pattern mh4 $.
cjA $a #Pattern ( LAQ .gk lB4 mh4 ) $.
gDA $a #Pattern ( 4w ( JAQ lB4 ) ( 4w ( SwE mh4 .gk ) IQE ) ) $.
nDA $a #Pattern ( 4w ( JAQ 2gg ) ( 4w ( SwE mh4 .gk ) IQE ) ) $.
nTA $a zw ( Tw ( 4w ( JAQ 2gg ) ( 4w ( SwE mh4 .gk ) IQE ) ) ( JAQ 2gg ) ) $.
oDA $a zw ( Tw ( 4w ( 4w ( JAQ 2gg ) ( 4w ( SwE mh4 .gk ) IQE ) ) ( 4w ( JAQ lB4 ) IQE ) ) ( 4w ( JAQ lB4 ) ( 4w ( SwE mh4 .gk ) IQE ) ) ) $.
0jA $a zw ( Tw ( 4w ( JAQ 2gg ) ( 4w ( JAQ lB4 ) ( 4w ( SwE mh4 .gk ) IQE ) ) ) ( tQM 2gg ( 0wM lB4 2gg ( LAQ pwk lB4 ( LAQ .gk pwk mh4 ) ) ( LAQ .gk lB4 mh4 ) ) ) ) $.
${ 0zA $p zw ( Tw ( 4w ( 4w ( JAQ 2gg ) ( 4w ( SwE mh4 .gk ) IQE ) ) ( 4w ( JAQ lB4 ) IQE ) ) ( tQM 2gg ( 0wM lB4 2gg ( LAQ pwk lB4 ( LAQ .gk pwk mh4 ) ) ( LAQ .gk lB4 mh4 ) ) ) ) $=
  ( nDA XB8 IwQ IAE 4g Wh8 gDA pgk .Qk YR8 KwQ cjA 0gM tAM ugE nTA mAE oDA wgE
  0jA ) ACDZBEZFGHZHZAIZFZBCJZHUHUEUHKUELKCMNNBCOPQUGUIUJUGUDUIUDUFRACSTABCUAUB
  ABCUCT $. $}
