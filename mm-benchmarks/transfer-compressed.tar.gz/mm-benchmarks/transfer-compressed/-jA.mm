$c rwg LAQ 0Q4 IAQ Hg8 #Symbol #Variable 0hU #SetVariable iA pwk #ElementVariable 8wk .gk Px0 pgg #Pattern ) ( $.
$v Ow CQ qwg Bw Cw sgg tAg 4wg ngg xX 3gg Kw ph0 oAg 5Qg nR4 tgg 4Ag $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Cg $f #Pattern Cw $.
Kg $f #ElementVariable Kw $.
Og $f #Variable Ow $.
SA $a #Variable Kw $.
jg $a iA Bw Ow Bw Ow $.
${ $d xX ph0 $.
   IQI $a iA Bw Bw CQ Ow $. $}
HwQ $a #Pattern ( IAQ Bw CQ ) $.
KwQ $a #Pattern ( LAQ Bw CQ Cw ) $.
nQg $f #Variable ngg $.
nwg $f #Pattern oAg $.
pQg $a #Pattern pgg $.
qgg $f #Pattern qwg $.
sQg $f #Pattern sgg $.
swg $f #Pattern tAg $.
tQg $f #Pattern tgg $.
${ uQg $e iA qwg tAg oAg ngg $.
   ugg $e iA sgg tgg oAg ngg $.
   uwg $a iA ( rwg qwg sgg ) ( rwg tAg tgg ) oAg ngg $. $}
3Qg $f #ElementVariable 3gg $.
3wg $f #ElementVariable 4Ag $.
4gg $f #ElementVariable 4wg $.
5Ag $f #ElementVariable 5Qg $.
pgk $a #Pattern pwk $.
8gk $a #Pattern 8wk $.
.Qk $a #Pattern .gk $.
${ 1Q4 $e iA qwg tAg oAg ngg $.
   1g4 $e iA sgg tgg oAg ngg $.
   1w4 $a iA ( 0Q4 qwg sgg ) ( 0Q4 tAg tgg ) oAg ngg $. $}
HQ8 $a #Pattern ( Hg8 oAg ) $.
${ Ig8 $e iA qwg sgg oAg ngg $.
   Iw8 $a iA ( Hg8 qwg ) ( Hg8 sgg ) oAg ngg $. $}
0RU $a #Pattern ( 0hU oAg qwg sgg ) $.
Ph0 $a #Pattern Px0 $.
nB4 $f #ElementVariable nR4 $.
6h8 $a #Pattern nR4 $.
BCQ $a #Pattern 4Ag $.
XiU $a #Pattern 3gg $.
XyU $a #Pattern 4wg $.
YCU $a #Pattern 5Qg $.
iic $a iA 4wg 4wg nR4 4Ag $.
7DA $a #Pattern ( rwg ( LAQ 8wk pgg ( 0hU ( LAQ .gk pwk ( IAQ .gk Px0 ) ) 5Qg 3gg ) ) 4Ag ) $.
.jA $a #Pattern ( rwg ( LAQ 8wk pgg ( 0hU ( LAQ .gk pwk ( IAQ .gk Px0 ) ) 5Qg 3gg ) ) nR4 ) $.
${ -jA $p iA ( 0Q4 ( Hg8 ( rwg ( LAQ 8wk pgg ( 0hU ( LAQ .gk pwk ( IAQ .gk Px0 ) ) 5Qg 3gg ) ) nR4 ) ) 4wg ) ( 0Q4 ( Hg8 ( rwg ( LAQ 8wk pgg ( 0hU ( LAQ .gk pwk ( IAQ .gk Px0 ) ) 5Qg 3gg ) ) 4Ag ) ) 4wg ) nR4 4Ag $=
  ( SA 6h8 .jA HQ8 XyU 7DA 8gk pQg .Qk pgk Ph0 HwQ KwQ YCU XiU 0RU BCQ IQI uwg
  jg Iw8 iic 1w4 ) BFZEGZADEHZICJZABDKZIULUIUJUKUMUIUJLMNONPQRDSATUARZUJUNBUBUN
  UJUIUCUJUIUEUDUFBCEUGUH $. $}
