$c 0wM LAQ 1wk #Symbol #Variable #SetVariable iA rwM #ElementVariable pgg #Pattern ) ( $.
$v yhs Ow ph6 CQ xX zBs DQ Ew Bw Kw Cw 2gg nR4 EQ y Dw LQ $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Cg $f #Pattern Cw $.
DA $f #Pattern DQ $.
Dg $f #Pattern Dw $.
EA $f #Pattern EQ $.
Eg $f #Pattern Ew $.
Kg $f #ElementVariable Kw $.
LA $f #ElementVariable LQ $.
Og $f #Variable Ow $.
SA $a #Variable Kw $.
${ $d xX y $.
   $d y ph6 $.
   OAQ $e iA Bw DQ Ew Ow $.
   OQQ $e iA CQ Dw Ew Ow $.
   OgQ $e iA Cw EQ Ew Ow $.
   OwQ $a iA ( rwM Bw CQ LQ Cw ) ( rwM DQ Dw LQ EQ ) Ew Ow $. $}
pQg $a #Pattern pgg $.
2Qg $f #ElementVariable 2gg $.
yRs $f #ElementVariable yhs $.
yxs $f #ElementVariable zBs $.
nB4 $f #ElementVariable nR4 $.
Wh8 $a #Pattern 2gg $.
6h8 $a #Pattern nR4 $.
NSE $a iA 2gg 2gg nR4 zBs $.
NiE $a iA pgg pgg nR4 zBs $.
1CM $a #Pattern ( 0wM pgg 2gg yhs ( LAQ 1wk pgg zBs ) ) $.
1iM $a #Pattern ( 0wM pgg 2gg yhs ( LAQ 1wk pgg nR4 ) ) $.
2yM $a iA ( 0wM pgg 2gg yhs ( LAQ 1wk pgg nR4 ) ) ( 0wM pgg 2gg yhs ( LAQ 1wk pgg zBs ) ) nR4 zBs $.
${ 3CM $p iA ( rwM pgg 2gg yhs ( 0wM pgg 2gg yhs ( LAQ 1wk pgg nR4 ) ) ) ( rwM pgg 2gg yhs ( 0wM pgg 2gg yhs ( LAQ 1wk pgg zBs ) ) ) nR4 zBs $=
  ( pQg Wh8 1iM 1CM 6h8 SA NiE NSE 2yM OwQ ) EAFZABDGEOABCHDIBCJCDKACDLABCDMN
  $. $}
