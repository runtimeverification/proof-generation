$c vA4 ewk xB4 IAQ 3BA Tw #Symbol #Variable SwE -gg #SetVariable zw 4w JAQ #ElementVariable IQE #Pattern ) ( $.
$v oAg Cw 2gg CQ qwg Bw $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Cg $f #Pattern Cw $.
4g $a #Pattern ( 4w Bw CQ ) $.
IAE $a #Pattern IQE $.
SgE $a #Pattern ( SwE Bw CQ ) $.
${ lgE $e zw ( Tw Bw CQ ) $.
   lwE $e zw ( Tw CQ Cw ) $.
   mAE $a zw ( Tw Bw Cw ) $. $}
HwQ $a #Pattern ( IAQ Bw CQ ) $.
IwQ $a #Pattern ( JAQ Bw ) $.
nwg $f #Pattern oAg $.
qgg $f #Pattern qwg $.
2Qg $f #ElementVariable 2gg $.
-Qg $a #Pattern -gg $.
egk $a #Pattern ewk $.
uw4 $a #Pattern vA4 $.
2xA $a #Pattern ( 3BA oAg qwg ) $.
6BA $a zw ( Tw ( 4w ( SwE oAg ewk ) ( SwE qwg -gg ) ) ( SwE ( 3BA oAg qwg ) -gg ) ) $.
wx4 $a #Pattern xB4 $.
Wh8 $a #Pattern 2gg $.
0CE $a zw ( Tw ( 4w ( JAQ 2gg ) IQE ) ( 4w ( SwE ( IAQ ewk xB4 ) ewk ) ( SwE vA4 -gg ) ) ) $.
${ 0SE $p zw ( Tw ( 4w ( JAQ 2gg ) IQE ) ( SwE ( 3BA ( IAQ ewk xB4 ) vA4 ) -gg ) ) $=
  ( Wh8 IwQ IAE 4g egk wx4 HwQ SgE uw4 -Qg 2xA 0CE 6BA mAE ) ABCDEFGHZFIJKIEPJL
  KIAMPJNO $. $}
