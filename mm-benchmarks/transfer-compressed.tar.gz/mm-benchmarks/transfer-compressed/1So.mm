$c 4B4 Tw #Symbol 7h4 zw YQk JAQ rgk pgg #Pattern ( 0wM LAQ ewk tQM IAQ #Variable SwE #SetVariable 4w rwM #ElementVariable IQE 7BI ) cBQ $.
$v 7Ag CQ qwg DQ Bw Kw oAg Cw 6Ag 2gg $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Cg $f #Pattern Cw $.
DA $f #Pattern DQ $.
Kg $f #ElementVariable Kw $.
4g $a #Pattern ( 4w Bw CQ ) $.
IAE $a #Pattern IQE $.
SgE $a #Pattern ( SwE Bw CQ ) $.
${ lgE $e zw ( Tw Bw CQ ) $.
   lwE $e zw ( Tw CQ Cw ) $.
   mAE $a zw ( Tw Bw Cw ) $. $}
rgM $a #Pattern ( rwM Bw CQ Kw Cw ) $.
tAM $a #Pattern ( tQM Bw CQ ) $.
0gM $a #Pattern ( 0wM Bw CQ Cw DQ ) $.
HwQ $a #Pattern ( IAQ Bw CQ ) $.
IwQ $a #Pattern ( JAQ Bw ) $.
KwQ $a #Pattern ( LAQ Bw CQ Cw ) $.
nwg $f #Pattern oAg $.
pQg $a #Pattern pgg $.
qgg $f #Pattern qwg $.
2Qg $f #ElementVariable 2gg $.
5wg $f #ElementVariable 6Ag $.
6wg $f #ElementVariable 7Ag $.
YAk $a #Pattern YQk $.
egk $a #Pattern ewk $.
rQk $a #Pattern rgk $.
6xI $a #Pattern ( 7BI oAg qwg ) $.
bxQ $a #Pattern ( cBQ oAg qwg ) $.
3x4 $a #Pattern 4B4 $.
7R4 $a #Pattern 7h4 $.
Wh8 $a #Pattern 2gg $.
-CA $a #Pattern 7Ag $.
-SA $a #Pattern ( 4w ( JAQ 2gg ) ( 4w ( SwE 7Ag YQk ) IQE ) ) $.
BCE $a #Pattern 6Ag $.
8CM $a zw ( Tw ( 4w ( 4w ( JAQ 2gg ) IQE ) ( 4w ( SwE 7Ag YQk ) IQE ) ) ( 4w ( JAQ 2gg ) ( 4w ( SwE 7Ag YQk ) IQE ) ) ) $.
1Co $a zw ( Tw ( 4w ( JAQ 2gg ) ( 4w ( SwE 7Ag YQk ) IQE ) ) ( tQM 2gg ( rwM YQk 2gg 6Ag ( 0wM YQk 2gg 6Ag ( 7BI ( cBQ ( LAQ ewk pgg ( IAQ ewk 7h4 ) ) ( LAQ rgk pgg ( IAQ rgk 4B4 ) ) ) 7Ag ) ) ) ) ) $.
${ 1So $p zw ( Tw ( 4w ( 4w ( JAQ 2gg ) IQE ) ( 4w ( SwE 7Ag YQk ) IQE ) ) ( tQM 2gg ( rwM YQk 2gg 6Ag ( 0wM YQk 2gg 6Ag ( 7BI ( cBQ ( LAQ ewk pgg ( IAQ ewk 7h4 ) ) ( LAQ rgk pgg ( IAQ rgk 4B4 ) ) ) 7Ag ) ) ) ) ) $=
  ( Wh8 IwQ IAE 4g -CA YAk SgE -SA BCE egk pQg 7R4 HwQ KwQ rQk 3x4 bxQ 6xI 0gM
  rgM tAM 8CM 1Co mAE ) ADZEFGCHZIJFGGACKUHIUHIUHBLMNMOPQRNRSPQTUIUAUBBUCUDACUE
  ABCUFUG $. $}
