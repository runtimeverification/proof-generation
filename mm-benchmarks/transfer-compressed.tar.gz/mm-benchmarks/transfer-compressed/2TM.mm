$c Uw zBA 2R4 PgE Tw #Symbol 7h4 zw JAQ pgg #Pattern ( rwg 0wM LAQ ewk tQM IAQ Wgk #Variable SwE #SetVariable iA 4w rwM #ElementVariable IQE mwg xQg ) $.
$v th1 Fw CQ Bw Cw 2gg sgg ngg FQ z ph2 Ew ph0 x Lw LQ 7Ag Ow ph6 qwg DQ ph1 EQ y th2 tAg Dw HQ xX Gw th0 Hw Kw oAg 6Ag GQ nR4 tgg $.
$d z y $.
$d z x $.
$d y x $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Cg $f #Pattern Cw $.
DA $f #Pattern DQ $.
Dg $f #Pattern Dw $.
EA $f #Pattern EQ $.
Eg $f #Pattern Ew $.
FA $f #Pattern FQ $.
Fg $f #Pattern Fw $.
GA $f #Pattern GQ $.
Gg $f #Pattern Gw $.
HA $f #Pattern HQ $.
Hg $f #Pattern Hw $.
Kg $f #ElementVariable Kw $.
LA $f #ElementVariable LQ $.
Lg $f #ElementVariable Lw $.
Og $f #Variable Ow $.
SA $a #Variable Kw $.
jg $a iA Bw Ow Bw Ow $.
${ kg $e iA CQ DQ Bw Ow $.
   kw $e iA Cw Dw Bw Ow $.
   lA $a iA ( Tw CQ Cw ) ( Tw DQ Dw ) Bw Ow $. $}
4g $a #Pattern ( 4w Bw CQ ) $.
IAE $a #Pattern IQE $.
SgE $a #Pattern ( SwE Bw CQ ) $.
${ lgE $e zw ( Tw Bw CQ ) $.
   lwE $e zw ( Tw CQ Cw ) $.
   mAE $a zw ( Tw Bw Cw ) $. $}
${ wAE $e zw ( Tw Bw CQ ) $.
   wQE $e zw ( Tw Bw Cw ) $.
   wgE $a zw ( Tw Bw ( 4w CQ Cw ) ) $. $}
${ $d xX ph0 $.
   IQI $a iA Bw Bw CQ Ow $. $}
rgM $a #Pattern ( rwM Bw CQ Kw Cw ) $.
tAM $a #Pattern ( tQM Bw CQ ) $.
0gM $a #Pattern ( 0wM Bw CQ Cw DQ ) $.
HwQ $a #Pattern ( IAQ Bw CQ ) $.
IwQ $a #Pattern ( JAQ Bw ) $.
KwQ $a #Pattern ( LAQ Bw CQ Cw ) $.
${ $d xX y $.
   $d y ph6 $.
   OAQ $e iA Bw DQ Ew Ow $.
   OQQ $e iA CQ Dw Ew Ow $.
   OgQ $e iA Cw EQ Ew Ow $.
   OwQ $a iA ( rwM Bw CQ LQ Cw ) ( rwM DQ Dw LQ EQ ) Ew Ow $. $}
${ QAQ $e iA Bw Cw Dw Ow $.
   QQQ $e iA CQ DQ Dw Ow $.
   QgQ $a iA ( tQM Bw CQ ) ( tQM Cw DQ ) Dw Ow $. $}
${ XgQ $e iA Bw Dw Fw Ow $.
   XwQ $e iA CQ EQ Fw Ow $.
   YAQ $e iA Cw Ew Fw Ow $.
   YQQ $e iA DQ FQ Fw Ow $.
   YgQ $a iA ( 0wM Bw CQ Cw DQ ) ( 0wM Dw EQ Ew FQ ) Fw Ow $. $}
${ $d z ph0 $.
   $d z ph1 $.
   $d z ph2 $.
   $d z y $.
   $d z x $.
   $d z th1 $.
   $d z th2 $.
   $d x ph0 $.
   $d y th0 $.
   lAY $e zw ( Tw GQ ( Uw Kw ( PgE Kw Bw ) ) ) $.
   lQY $e zw ( Tw ( 4w GQ Gw ) CQ ) $.
   lgY $e iA ( Tw HQ Cw ) ( Tw Gw CQ ) Bw LQ $.
   lwY $e iA ( Tw Hw DQ ) ( Tw Gw CQ ) Lw LQ $.
   mAY $a zw ( Tw ( 4w GQ HQ ) Cw ) $. $}
mgg $a #Pattern mwg $.
nQg $f #Variable ngg $.
nwg $f #Pattern oAg $.
pQg $a #Pattern pgg $.
qgg $f #Pattern qwg $.
rgg $a #Pattern ( rwg oAg qwg ) $.
sQg $f #Pattern sgg $.
swg $f #Pattern tAg $.
tQg $f #Pattern tgg $.
${ uQg $e iA qwg tAg oAg ngg $.
   ugg $e iA sgg tgg oAg ngg $.
   uwg $a iA ( rwg qwg sgg ) ( rwg tAg tgg ) oAg ngg $. $}
xAg $a #Pattern xQg $.
2Qg $f #ElementVariable 2gg $.
5wg $f #ElementVariable 6Ag $.
6wg $f #ElementVariable 7Ag $.
WQk $a #Pattern Wgk $.
egk $a #Pattern ewk $.
yxA $a #Pattern ( zBA oAg qwg ) $.
nB4 $f #ElementVariable nR4 $.
2B4 $a #Pattern 2R4 $.
7R4 $a #Pattern 7h4 $.
Wh8 $a #Pattern 2gg $.
6h8 $a #Pattern nR4 $.
9h8 $a zw ( Tw ( 4w ( JAQ 2gg ) IQE ) ( 4w ( JAQ 2gg ) IQE ) ) $.
-CA $a #Pattern 7Ag $.
BCE $a #Pattern 6Ag $.
9yM $a iA 2gg 2gg nR4 7Ag $.
.CM $a iA 6Ag 6Ag nR4 7Ag $.
pyQ $a #Pattern ( 4w ( JAQ 2gg ) ( 4w ( SwE 7Ag mwg ) IQE ) ) $.
5CQ $a zw ( Tw ( 4w ( JAQ 2gg ) IQE ) ( Uw 6Ag ( PgE 6Ag xQg ) ) ) $.
5yQ $a zw ( Tw ( 4w ( 4w ( JAQ 2gg ) IQE ) ( 4w ( SwE 7Ag mwg ) IQE ) ) ( 4w ( JAQ 2gg ) ( 4w ( SwE 7Ag mwg ) IQE ) ) ) $.
6CQ $a iA ( 4w ( SwE xQg mwg ) IQE ) ( 4w ( SwE 7Ag mwg ) IQE ) xQg 7Ag $.
6SQ $a iA 2gg 2gg xQg 7Ag $.
6iQ $a iA 6Ag 6Ag xQg 7Ag $.
6yQ $a iA mwg mwg nR4 7Ag $.
7SQ $a iA ( 4w ( SwE nR4 mwg ) IQE ) ( 4w ( SwE 7Ag mwg ) IQE ) nR4 7Ag $.
7yQ $a zw ( Tw ( 4w ( JAQ 2gg ) IQE ) ( 4w ( SwE xQg mwg ) IQE ) ) $.
2DM $a zw ( Tw ( 4w ( JAQ 2gg ) ( 4w ( SwE 7Ag mwg ) IQE ) ) ( tQM 2gg ( rwM mwg 2gg 6Ag ( 0wM mwg 2gg 6Ag ( rwg ( LAQ Wgk pgg ( zBA ( LAQ ewk Wgk ( IAQ ewk 7h4 ) ) ( LAQ ewk Wgk ( IAQ ewk 2R4 ) ) ) ) 7Ag ) ) ) ) ) $.
${ 2TM $p zw ( Tw ( 4w ( JAQ 2gg ) IQE ) ( tQM 2gg ( rwM mwg 2gg 6Ag ( 0wM mwg 2gg 6Ag ( rwg ( LAQ Wgk pgg ( zBA ( LAQ ewk Wgk ( IAQ ewk 7h4 ) ) ( LAQ ewk Wgk ( IAQ ewk 2R4 ) ) ) ) xQg ) ) ) ) ) $=
  ( 6wg nB4 IAE 4g xAg mgg SgE WQk egk HwQ KwQ rgg 0gM rgM tAM mAE IQI jg SA lA
  Wh8 IwQ BCE pQg 7R4 2B4 yxA 9h8 7yQ wgE -CA 6h8 5CQ pyQ 5yQ 2DM 6CQ 6SQ 6iQ
  uwg YgQ OwQ QgQ 7SQ 9yM 6yQ .CM mAY ) AUCZUDEFZVLGHIEFZFVKHVKHVKBUEZJUFKJKUGL
  MKJKUHLMUIMZGNZOZBPZQZVLVLVMAUJAUKULGVKHVKHVKVNVOCUMZNZOZBPZQZVSVKHVKHVKVNVOD
  UNZNZOZBPZQZVLVTHIEFZVMWEHIEFZBCDABUOVLWJFACUPWDACUQABCURRGVMVSWJWDCUAZCUSVKV
  RVKWCGWLACUTZHVKVQHVKWBGBWLHGWLSZWMHVKVNVPHVKVNWAGWLWNWMBCVAWLGVOGVOVTVOGWLSG
  WLTVBVCVDVEUBWEWKWIWJWDWLCDVFVKWHVKWCWEWLACDVGZHVKWGHVKWBWEBWLCDVHZWOHVKVNWFH
  VKVNWAWEWLWPWOBCDVIWLWEVOWEVOVTVOWEWLSWEWLTVBVCVDVEUBVJR $. $}
