$c IAQ Tw #Symbol #Variable 1CA SwE #SetVariable 3gk zw 4w JAQ #ElementVariable IQE rgk #Pattern ) ( $.
$v Cw 2gg CQ Bw $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Cg $f #Pattern Cw $.
4g $a #Pattern ( 4w Bw CQ ) $.
IAE $a #Pattern IQE $.
SgE $a #Pattern ( SwE Bw CQ ) $.
${ wAE $e zw ( Tw Bw CQ ) $.
   wQE $e zw ( Tw Bw Cw ) $.
   wgE $a zw ( Tw Bw ( 4w CQ Cw ) ) $. $}
HwQ $a #Pattern ( IAQ Bw CQ ) $.
IwQ $a #Pattern ( JAQ Bw ) $.
2Qg $f #ElementVariable 2gg $.
rQk $a #Pattern rgk $.
3Qk $a #Pattern 3gk $.
Wh8 $a #Pattern 2gg $.
0yA $a #Pattern 1CA $.
Ni4 $a zw ( Tw ( 4w ( JAQ 2gg ) IQE ) ( 4w ( JAQ rgk ) ( JAQ 3gk ) ) ) $.
uTU $a zw ( Tw ( 4w ( JAQ 2gg ) IQE ) ( SwE ( IAQ rgk 1CA ) rgk ) ) $.
${ 3jU $p zw ( Tw ( 4w ( JAQ 2gg ) IQE ) ( 4w ( 4w ( JAQ rgk ) ( JAQ 3gk ) ) ( SwE ( IAQ rgk 1CA ) rgk ) ) ) $=
  ( Wh8 IwQ IAE 4g rQk 3Qk 0yA HwQ SgE Ni4 uTU wgE ) ABCDEFCGCEFHIFJAKALM $. $}
