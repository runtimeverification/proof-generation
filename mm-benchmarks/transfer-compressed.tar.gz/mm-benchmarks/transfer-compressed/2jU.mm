$c Tw #Symbol 1CA zw JAQ rgk 3gk #Pattern ( 0wM LAQ tQM IAQ #Variable #SetVariable 4w rwM #ElementVariable IQE ) $.
$v yhs CQ DQ Bw Kw Cw 2gg $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Cg $f #Pattern Cw $.
DA $f #Pattern DQ $.
Kg $f #ElementVariable Kw $.
4g $a #Pattern ( 4w Bw CQ ) $.
IAE $a #Pattern IQE $.
${ lgE $e zw ( Tw Bw CQ ) $.
   lwE $e zw ( Tw CQ Cw ) $.
   mAE $a zw ( Tw Bw Cw ) $. $}
nAE $a zw IQE $.
${ wAE $e zw ( Tw Bw CQ ) $.
   wQE $e zw ( Tw Bw Cw ) $.
   wgE $a zw ( Tw Bw ( 4w CQ Cw ) ) $. $}
${ NwM $e zw CQ $.
   OAM $a zw ( Tw Bw CQ ) $. $}
rgM $a #Pattern ( rwM Bw CQ Kw Cw ) $.
tAM $a #Pattern ( tQM Bw CQ ) $.
0gM $a #Pattern ( 0wM Bw CQ Cw DQ ) $.
HwQ $a #Pattern ( IAQ Bw CQ ) $.
IwQ $a #Pattern ( JAQ Bw ) $.
KwQ $a #Pattern ( LAQ Bw CQ Cw ) $.
2Qg $f #ElementVariable 2gg $.
rQk $a #Pattern rgk $.
3Qk $a #Pattern 3gk $.
yRs $f #ElementVariable yhs $.
Wh8 $a #Pattern 2gg $.
.h8 $a zw ( Tw ( 4w IQE ( 4w ( JAQ 2gg ) IQE ) ) ( JAQ 2gg ) ) $.
0yA $a #Pattern 1CA $.
7SA $a #Pattern yhs $.
2TU $a zw ( Tw ( 4w ( JAQ 2gg ) IQE ) ( tQM 2gg ( rwM 3gk 2gg yhs ( 0wM 3gk 2gg yhs ( LAQ rgk 3gk ( IAQ rgk 1CA ) ) ) ) ) ) $.
${ 2jU $p zw ( Tw ( 4w IQE ( 4w ( JAQ 2gg ) IQE ) ) ( tQM 2gg ( rwM 3gk 2gg yhs ( 0wM 3gk 2gg yhs ( LAQ rgk 3gk ( IAQ rgk 1CA ) ) ) ) ) ) $=
  ( IAE Wh8 IwQ 4g 3Qk 7SA rQk 0yA HwQ KwQ 0gM rgM tAM .h8 nAE OAM wgE 2TU mAE
  ) CADZEZCFZFZUDUBGUBGUBBHIGIJKLMBNOUEUCCAPUECQRSABTUA $. $}
