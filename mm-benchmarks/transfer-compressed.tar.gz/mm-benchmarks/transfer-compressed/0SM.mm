$c 1wk #Symbol Tw #Variable SwE #SetVariable zw 4w JAQ #ElementVariable IQE #Pattern ) ( $.
$v Cw 2gg CQ zBs Bw $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Cg $f #Pattern Cw $.
4g $a #Pattern ( 4w Bw CQ ) $.
IAE $a #Pattern IQE $.
SgE $a #Pattern ( SwE Bw CQ ) $.
lQE $a zw ( Tw Bw Bw ) $.
${ lgE $e zw ( Tw Bw CQ ) $.
   lwE $e zw ( Tw CQ Cw ) $.
   mAE $a zw ( Tw Bw Cw ) $. $}
ugE $a zw ( Tw ( 4w Bw CQ ) Bw ) $.
uwE $a zw ( Tw ( 4w Bw CQ ) CQ ) $.
IwQ $a #Pattern ( JAQ Bw ) $.
2Qg $f #ElementVariable 2gg $.
1gk $a #Pattern 1wk $.
yxs $f #ElementVariable zBs $.
Wh8 $a #Pattern 2gg $.
JiE $a #Pattern zBs $.
${ 0SM $p zw ( Tw ( 4w ( 4w ( JAQ 2gg ) IQE ) ( 4w ( SwE zBs 1wk ) IQE ) ) ( SwE zBs 1wk ) ) $=
  ( Wh8 IwQ IAE 4g JiE 1gk SgE uwE ugE lQE mAE ) ACDEFZBGHIZEFZFPONPJPOOOEKOLMM
  $. $}
