$c Uw PgE Tw #Symbol 1CA wQM zw JAQ .gk xwM rgk pgg 3gk #Pattern ( rwg 0wM twM LAQ tQM IAQ 1gM #Variable 5xw SwE #SetVariable iA 4w #ElementVariable IQE mwg xQg ) Vhc $.
$v th1 yhs Fw CQ Bw Cw 2gg sgg ngg FQ z ph2 Ew ph0 x Lw LQ Ow qwg DQ ph1 EQ y th2 Dw tAg HQ xX Gw th0 Hw Kw oAg GQ nR4 tgg 4Ag $.
$d z y $.
$d z x $.
$d y x $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Cg $f #Pattern Cw $.
DA $f #Pattern DQ $.
Dg $f #Pattern Dw $.
EA $f #Pattern EQ $.
Eg $f #Pattern Ew $.
FA $f #Pattern FQ $.
Fg $f #Pattern Fw $.
GA $f #Pattern GQ $.
Gg $f #Pattern Gw $.
HA $f #Pattern HQ $.
Hg $f #Pattern Hw $.
Kg $f #ElementVariable Kw $.
LA $f #ElementVariable LQ $.
Lg $f #ElementVariable Lw $.
Og $f #Variable Ow $.
SA $a #Variable Kw $.
jg $a iA Bw Ow Bw Ow $.
${ kg $e iA CQ DQ Bw Ow $.
   kw $e iA Cw Dw Bw Ow $.
   lA $a iA ( Tw CQ Cw ) ( Tw DQ Dw ) Bw Ow $. $}
4g $a #Pattern ( 4w Bw CQ ) $.
IAE $a #Pattern IQE $.
SgE $a #Pattern ( SwE Bw CQ ) $.
${ lgE $e zw ( Tw Bw CQ ) $.
   lwE $e zw ( Tw CQ Cw ) $.
   mAE $a zw ( Tw Bw Cw ) $. $}
nAE $a zw IQE $.
${ wAE $e zw ( Tw Bw CQ ) $.
   wQE $e zw ( Tw Bw Cw ) $.
   wgE $a zw ( Tw Bw ( 4w CQ Cw ) ) $. $}
${ $d xX ph0 $.
   IQI $a iA Bw Bw CQ Ow $. $}
${ KAI $e iA CQ DQ Bw Ow $.
   KQI $e iA Cw Dw Bw Ow $.
   KgI $a iA ( 4w CQ Cw ) ( 4w DQ Dw ) Bw Ow $. $}
${ OgI $e iA CQ DQ Bw Ow $.
   OwI $e iA Cw Dw Bw Ow $.
   PAI $a iA ( SwE CQ Cw ) ( SwE DQ Dw ) Bw Ow $. $}
${ NwM $e zw CQ $.
   OAM $a zw ( Tw Bw CQ ) $. $}
tAM $a #Pattern ( tQM Bw CQ ) $.
uwM $a #Pattern ( twM Bw ) $.
wAM $a #Pattern ( wQM Bw CQ Cw ) $.
xgM $a #Pattern ( xwM Bw CQ Cw ) $.
0gM $a #Pattern ( 0wM Bw CQ Cw DQ ) $.
1QM $a #Pattern ( 1gM Bw CQ Cw DQ ) $.
HwQ $a #Pattern ( IAQ Bw CQ ) $.
IwQ $a #Pattern ( JAQ Bw ) $.
KwQ $a #Pattern ( LAQ Bw CQ Cw ) $.
${ QAQ $e iA Bw Cw Dw Ow $.
   QQQ $e iA CQ DQ Dw Ow $.
   QgQ $a iA ( tQM Bw CQ ) ( tQM Cw DQ ) Dw Ow $. $}
${ SgQ $e iA Bw DQ Ew Ow $.
   SwQ $e iA CQ Dw Ew Ow $.
   TAQ $e iA Cw EQ Ew Ow $.
   TQQ $a iA ( wQM Bw CQ Cw ) ( wQM DQ Dw EQ ) Ew Ow $. $}
${ UgQ $e iA Bw DQ Ew Ow $.
   UwQ $e iA CQ Dw Ew Ow $.
   VAQ $e iA Cw EQ Ew Ow $.
   VQQ $a iA ( xwM Bw CQ Cw ) ( xwM DQ Dw EQ ) Ew Ow $. $}
${ YwQ $e iA Bw Dw Fw Ow $.
   ZAQ $e iA CQ EQ Fw Ow $.
   ZQQ $e iA Cw Ew Fw Ow $.
   ZgQ $e iA DQ FQ Fw Ow $.
   ZwQ $a iA ( 1gM Bw CQ Cw DQ ) ( 1gM Dw EQ Ew FQ ) Fw Ow $. $}
${ lAQ $e iA Bw DQ Ew Ow $.
   lQQ $e iA CQ Dw Ew Ow $.
   lgQ $e iA Cw EQ Ew Ow $.
   lwQ $a iA ( LAQ Bw CQ Cw ) ( LAQ DQ Dw EQ ) Ew Ow $. $}
${ $d z ph0 $.
   $d z ph1 $.
   $d z ph2 $.
   $d z y $.
   $d z x $.
   $d z th1 $.
   $d z th2 $.
   $d x ph0 $.
   $d y th0 $.
   lAY $e zw ( Tw GQ ( Uw Kw ( PgE Kw Bw ) ) ) $.
   lQY $e zw ( Tw ( 4w GQ Gw ) CQ ) $.
   lgY $e iA ( Tw HQ Cw ) ( Tw Gw CQ ) Bw LQ $.
   lwY $e iA ( Tw Hw DQ ) ( Tw Gw CQ ) Lw LQ $.
   mAY $a zw ( Tw ( 4w GQ HQ ) Cw ) $. $}
mgg $a #Pattern mwg $.
nQg $f #Variable ngg $.
nwg $f #Pattern oAg $.
pQg $a #Pattern pgg $.
qgg $f #Pattern qwg $.
rgg $a #Pattern ( rwg oAg qwg ) $.
sQg $f #Pattern sgg $.
swg $f #Pattern tAg $.
tQg $f #Pattern tgg $.
${ uQg $e iA qwg tAg oAg ngg $.
   ugg $e iA sgg tgg oAg ngg $.
   uwg $a iA ( rwg qwg sgg ) ( rwg tAg tgg ) oAg ngg $. $}
xAg $a #Pattern xQg $.
2Qg $f #ElementVariable 2gg $.
3wg $f #ElementVariable 4Ag $.
rQk $a #Pattern rgk $.
3Qk $a #Pattern 3gk $.
.Qk $a #Pattern .gk $.
VRc $a #Pattern ( Vhc oAg ) $.
yRs $f #ElementVariable yhs $.
5hw $a #Pattern 5xw $.
nB4 $f #ElementVariable nR4 $.
Wh8 $a #Pattern 2gg $.
6h8 $a #Pattern nR4 $.
9h8 $a zw ( Tw ( 4w ( JAQ 2gg ) IQE ) ( 4w ( JAQ 2gg ) IQE ) ) $.
0yA $a #Pattern 1CA $.
BCQ $a #Pattern 4Ag $.
RSQ $a iA 2gg 2gg nR4 4Ag $.
RiQ $a iA ( twM 2gg ) ( twM 2gg ) nR4 4Ag $.
JiU $a iA mwg mwg nR4 4Ag $.
DC4 $a #Pattern ( 4w ( JAQ 2gg ) ( 4w ( SwE 4Ag 3gk ) IQE ) ) $.
Ly4 $a zw ( Tw ( 4w ( 4w ( JAQ 2gg ) IQE ) ( 4w ( SwE 4Ag 3gk ) IQE ) ) ( 4w ( JAQ 2gg ) ( 4w ( SwE 4Ag 3gk ) IQE ) ) ) $.
Mi4 $a iA ( 4w ( SwE nR4 3gk ) IQE ) ( 4w ( SwE 4Ag 3gk ) IQE ) nR4 4Ag $.
NC4 $a iA ( rwg ( LAQ 3gk pgg nR4 ) xQg ) ( rwg ( LAQ 3gk pgg 4Ag ) xQg ) nR4 4Ag $.
1zU $a zw ( Tw ( 4w ( JAQ 2gg ) ( 4w ( SwE 4Ag 3gk ) IQE ) ) ( tQM 2gg ( xwM 2gg ( wQM 2gg ( twM 2gg ) ( wQM 2gg ( 1gM mwg 2gg ( rwg ( LAQ rgk pgg ( IAQ rgk 1CA ) ) xQg ) ( rwg ( LAQ 3gk pgg 4Ag ) xQg ) ) ( twM 2gg ) ) ) ( wQM 2gg ( 0wM .gk 2gg ( Vhc ( rwg ( LAQ rgk pgg ( IAQ rgk 1CA ) ) xQg ) ) ( IAQ .gk 5xw ) ) ( twM 2gg ) ) ) ) ) $.
3TU $a zw ( Tw ( 4w ( JAQ 2gg ) IQE ) ( Uw yhs ( PgE yhs ( LAQ rgk 3gk ( IAQ rgk 1CA ) ) ) ) ) $.
3zU $a zw ( Tw ( 4w ( JAQ 2gg ) IQE ) ( SwE ( LAQ rgk 3gk ( IAQ rgk 1CA ) ) 3gk ) ) $.
${ 4DU $p zw ( Tw ( 4w ( JAQ 2gg ) IQE ) ( tQM 2gg ( xwM 2gg ( wQM 2gg ( twM 2gg ) ( wQM 2gg ( 1gM mwg 2gg ( rwg ( LAQ rgk pgg ( IAQ rgk 1CA ) ) xQg ) ( rwg ( LAQ 3gk pgg ( LAQ rgk 3gk ( IAQ rgk 1CA ) ) ) xQg ) ) ( twM 2gg ) ) ) ( wQM 2gg ( 0wM .gk 2gg ( Vhc ( rwg ( LAQ rgk pgg ( IAQ rgk 1CA ) ) xQg ) ) ( IAQ .gk 5xw ) ) ( twM 2gg ) ) ) ) ) $=
  ( 3wg nB4 yRs IAE 4g rQk 3Qk KwQ SgE mgg pQg xAg rgg 1QM wAM xgM tAM IQI TQQ
  Wh8 IwQ 0yA HwQ uwM .Qk VRc 5hw 0gM 9h8 3zU nAE OAM wgE BCQ 6h8 3TU DC4 SA jg
  Ly4 1zU mAE PAI KgI lwQ uwg ZwQ VQQ QgQ lA Mi4 RSQ RiQ JiU NC4 mAY ) AUAZUBEF
  ZVSGHGUCUDZIZHJZEFZFVRVRVRVRUEZVRKVRGLVTIMNZHLWAIZMNZOZWDPZPZVRUFVRWEUGUFUHUD
  UIWDPZQZRZVSVSWCAUJVSWBEAUKVSEULUMUNUNWAVRVRVRWDVRKVRWEHLBUOZIZMNZOZWDPZPZWKQ
  ZRZWMVRVRVRWDVRKVRWEHLCUPZIMNZOZWDPZPZWKQZRZVSWNHJZEFZWCXBHJEFZDBCADUQVSXJFAB
  URXAABVAABVBVCWAWCWMXJXABUSZWAWBEXIEXLWAWAHWNHXLWAXLUTZHWAXLSZVDEWAXLSVEVRWLV
  RWTWAXLVRWAXLSZVRWJWKVRWSWKWAXLXOVRWDWIVRWDWRWAXLXOWDWAXLSZVRWHWDVRWQWDWAXLXO
  KVRWEWGKVRWEWPWAXLKWAXLSXOWEWAXLSXLWAWFMWOMHLWAHLWNWAXLXNLWAXLSXMVFMWAXLSVGVH
  XPTTWKWAXLSVIVJVKXBXKXHXJXAXLBCVLVRXGVRWTXBXLABCVMZVRXFWKVRWSWKXBXLXQVRWDXEVR
  WDWRXBXLXQABCVNZVRXDWDVRWQWDXBXLXQKVRWEXCKVRWEWPXBXLBCVOXQWEXBXLSBCVPVHXRTTWK
  XBXLSVIVJVKVQVC $. $}
