$c 4B4 Ngk Lwk #Symbol 7h4 DBE GBY 8Q4 zw YQk xwM pgg vA4 #Pattern 0Q4 rwg Ex0 0wM xB4 tQM Wgk 0h4 #Variable SwE 0hU PQk #SetVariable iA vR4 4w #ElementVariable IQE qxs xQg 8hw cBQ ww4 kBM 2R4 zBA XBI 1wk RAk Tw cwE wQM -g4 zBI 5x4 rgk ( twM LAQ ewk yx4 IAQ 9R4 Hg8 3BA Kw8 7Ak 7BI ) $.
$v Ow CQ qwg DQ Bw Cw EQ sgg tAg Dw ngg FQ xX Ew Kw ph0 oAg GQ nR4 tgg $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Cg $f #Pattern Cw $.
DA $f #Pattern DQ $.
Dg $f #Pattern Dw $.
EA $f #Pattern EQ $.
Eg $f #Pattern Ew $.
FA $f #Pattern FQ $.
GA $f #Pattern GQ $.
Kg $f #ElementVariable Kw $.
Og $f #Variable Ow $.
SA $a #Variable Kw $.
jg $a iA Bw Ow Bw Ow $.
4g $a #Pattern ( 4w Bw CQ ) $.
IAE $a #Pattern IQE $.
SgE $a #Pattern ( SwE Bw CQ ) $.
${ lgE $e zw ( Tw Bw CQ ) $.
   lwE $e zw ( Tw CQ Cw ) $.
   mAE $a zw ( Tw Bw Cw ) $. $}
${ wAE $e zw ( Tw Bw CQ ) $.
   wQE $e zw ( Tw Bw Cw ) $.
   wgE $a zw ( Tw Bw ( 4w CQ Cw ) ) $. $}
${ $d xX ph0 $.
   IQI $a iA Bw Bw CQ Ow $. $}
${ NwM $e zw CQ $.
   OAM $a zw ( Tw Bw CQ ) $. $}
tAM $a #Pattern ( tQM Bw CQ ) $.
uwM $a #Pattern ( twM Bw ) $.
wAM $a #Pattern ( wQM Bw CQ Cw ) $.
xgM $a #Pattern ( xwM Bw CQ Cw ) $.
HwQ $a #Pattern ( IAQ Bw CQ ) $.
KwQ $a #Pattern ( LAQ Bw CQ Cw ) $.
${ QAQ $e iA Bw Cw Dw Ow $.
   QQQ $e iA CQ DQ Dw Ow $.
   QgQ $a iA ( tQM Bw CQ ) ( tQM Cw DQ ) Dw Ow $. $}
${ SgQ $e iA Bw DQ Ew Ow $.
   SwQ $e iA CQ Dw Ew Ow $.
   TAQ $e iA Cw EQ Ew Ow $.
   TQQ $a iA ( wQM Bw CQ Cw ) ( wQM DQ Dw EQ ) Ew Ow $. $}
${ UgQ $e iA Bw DQ Ew Ow $.
   UwQ $e iA CQ Dw Ew Ow $.
   VAQ $e iA Cw EQ Ew Ow $.
   VQQ $a iA ( xwM Bw CQ Cw ) ( xwM DQ Dw EQ ) Ew Ow $. $}
JwU $a zw ( Tw ( 4w ( SwE CQ Bw ) ( SwE Cw Bw ) ) ( SwE ( wQM Bw CQ Cw ) Bw ) ) $.
SwU $a zw ( tQM Bw ( twM Bw ) ) $.
${ VwU $e zw ( Tw GQ ( tQM Bw Cw ) ) $.
   WAU $a zw ( Tw GQ ( tQM Bw ( xwM Bw CQ Cw ) ) ) $. $}
${ sgU $e zw ( Tw GQ ( SwE CQ Bw ) ) $.
   swU $a zw ( Tw GQ ( tQM Bw ( xwM Bw CQ CQ ) ) ) $. $}
${ AgY $e zw ( Tw GQ ( SwE CQ Bw ) ) $.
   AwY $e zw ( Tw GQ ( SwE Cw Bw ) ) $.
   BAY $e zw ( Tw GQ ( SwE Dw Bw ) ) $.
   BQY $e zw ( Tw GQ ( tQM Bw ( xwM Bw CQ Cw ) ) ) $.
   BgY $e zw ( Tw GQ ( tQM Bw ( xwM Bw DQ ( wQM Bw CQ Dw ) ) ) ) $.
   BwY $a zw ( Tw GQ ( tQM Bw ( xwM Bw DQ ( wQM Bw Cw Dw ) ) ) ) $. $}
${ swY $e zw ( Tw GQ ( SwE CQ Bw ) ) $.
   tAY $e zw ( Tw GQ ( SwE Cw Bw ) ) $.
   tQY $e zw ( Tw GQ ( tQM cwE ( 0wM Bw cwE CQ Cw ) ) ) $.
   tgY $e zw ( Tw GQ ( tQM Ew DQ ) ) $.
   twY $e iA ( tQM Ew DQ ) Dw CQ Kw $.
   uAY $e iA ( tQM FQ EQ ) Dw Cw Kw $.
   uQY $a zw ( Tw GQ ( tQM FQ EQ ) ) $. $}
nQg $f #Variable ngg $.
nwg $f #Pattern oAg $.
pQg $a #Pattern pgg $.
qgg $f #Pattern qwg $.
rgg $a #Pattern ( rwg oAg qwg ) $.
sQg $f #Pattern sgg $.
swg $f #Pattern tAg $.
tQg $f #Pattern tgg $.
xAg $a #Pattern xQg $.
Lgk $a #Pattern Lwk $.
NQk $a #Pattern Ngk $.
PAk $a #Pattern PQk $.
Qwk $a #Pattern RAk $.
WQk $a #Pattern Wgk $.
YAk $a #Pattern YQk $.
egk $a #Pattern ewk $.
rQk $a #Pattern rgk $.
1gk $a #Pattern 1wk $.
6wk $a #Pattern 7Ak $.
uw4 $a #Pattern vA4 $.
wg4 $a #Pattern ww4 $.
0A4 $a #Pattern ( 0Q4 oAg qwg ) $.
${ 1Q4 $e iA qwg tAg oAg ngg $.
   1g4 $e iA sgg tgg oAg ngg $.
   1w4 $a iA ( 0Q4 qwg sgg ) ( 0Q4 tAg tgg ) oAg ngg $. $}
3Q4 $a zw ( Tw ( 4w ( SwE oAg Lwk ) ( SwE qwg PQk ) ) ( SwE ( 0Q4 oAg qwg ) 7Ak ) ) $.
8A4 $a #Pattern ( 8Q4 oAg ) $.
-Q4 $a #Pattern ( -g4 oAg qwg ) $.
${ Ag8 $e iA qwg tAg oAg ngg $.
   Aw8 $e iA sgg tgg oAg ngg $.
   BA8 $a iA ( -g4 qwg sgg ) ( -g4 tAg tgg ) oAg ngg $. $}
Cg8 $a zw ( Tw ( 4w ( SwE oAg 7Ak ) ( SwE qwg RAk ) ) ( SwE ( -g4 oAg qwg ) Ngk ) ) $.
HQ8 $a #Pattern ( Hg8 oAg ) $.
Kg8 $a #Pattern ( Kw8 oAg ) $.
${ Lw8 $e iA qwg sgg oAg ngg $.
   MA8 $a iA ( Kw8 qwg ) ( Kw8 sgg ) oAg ngg $. $}
NA8 $a zw ( Tw ( SwE oAg YQk ) ( SwE ( Kw8 oAg ) PQk ) ) $.
yxA $a #Pattern ( zBA oAg qwg ) $.
2xA $a #Pattern ( 3BA oAg qwg ) $.
CxE $a #Pattern ( DBE oAg qwg ) $.
WxI $a #Pattern ( XBI oAg qwg ) $.
yxI $a #Pattern ( zBI oAg qwg ) $.
6xI $a #Pattern ( 7BI oAg qwg ) $.
${ 8BI $e iA qwg tAg oAg ngg $.
   8RI $e iA sgg tgg oAg ngg $.
   8hI $a iA ( 7BI qwg sgg ) ( 7BI tAg tgg ) oAg ngg $. $}
.BI $a zw ( Tw ( 4w ( SwE oAg YQk ) ( SwE qwg YQk ) ) ( SwE ( 7BI oAg qwg ) YQk ) ) $.
jxM $a #Pattern ( kBM oAg qwg ) $.
bxQ $a #Pattern ( cBQ oAg qwg ) $.
0RU $a #Pattern ( 0hU oAg qwg sgg ) $.
FxY $a #Pattern ( GBY oAg qwg ) $.
qhs $a #Pattern ( qxs oAg ) $.
8Rw $a #Pattern 8hw $.
Eh0 $a #Pattern Ex0 $.
nB4 $f #ElementVariable nR4 $.
vB4 $a #Pattern vR4 $.
wx4 $a #Pattern xB4 $.
yh4 $a #Pattern yx4 $.
0R4 $a #Pattern 0h4 $.
2B4 $a #Pattern 2R4 $.
3x4 $a #Pattern 4B4 $.
5h4 $a #Pattern 5x4 $.
7R4 $a #Pattern 7h4 $.
9B4 $a #Pattern 9R4 $.
.R4 $a zw ( Tw IQE ( SwE ( twM Ngk ) Ngk ) ) $.
KB8 $a zw ( Tw IQE ( SwE ( cBQ ( LAQ ewk pgg ( IAQ ewk 9R4 ) ) ( LAQ rgk pgg ( IAQ rgk 8hw ) ) ) YQk ) ) $.
Kx8 $a zw ( Tw IQE ( SwE ( 8Q4 ( IAQ rgk 8hw ) ) RAk ) ) $.
LB8 $a zw ( Tw IQE ( SwE ( Hg8 ( rwg ( LAQ 1wk pgg ( GBY ( 3BA ( IAQ ewk vR4 ) ( 3BA ( IAQ ewk 7h4 ) ( 3BA ( IAQ ewk xB4 ) vA4 ) ) ) ( kBM ( kBM ( kBM ( kBM ( XBI ( IAQ ewk 9R4 ) ( LAQ rgk Wgk ( IAQ rgk yx4 ) ) ) ( XBI ( IAQ ewk 2R4 ) ( LAQ rgk Wgk ( IAQ rgk 0h4 ) ) ) ) ( XBI ( IAQ ewk vR4 ) ( LAQ rgk Wgk ( IAQ rgk 5x4 ) ) ) ) ( XBI ( IAQ ewk 7h4 ) ( LAQ rgk Wgk ( IAQ rgk 4B4 ) ) ) ) ( 0hU ( zBI ( LAQ ewk Wgk ( IAQ ewk 2R4 ) ) ( LAQ ewk Wgk ( IAQ ewk vR4 ) ) ) ( qxs ( XBI ( IAQ ewk xB4 ) ( LAQ rgk Wgk ( IAQ rgk 8hw ) ) ) ) ( qxs ( kBM ( kBM ( XBI ( IAQ ewk vR4 ) ( DBE ( LAQ ewk Wgk ( IAQ ewk vR4 ) ) ( LAQ ewk Wgk ( IAQ ewk 2R4 ) ) ) ) ( XBI ( IAQ ewk 7h4 ) ( zBA ( LAQ ewk Wgk ( IAQ ewk 7h4 ) ) ( LAQ ewk Wgk ( IAQ ewk 2R4 ) ) ) ) ) ( XBI ( IAQ ewk xB4 ) ( LAQ rgk Wgk ( IAQ rgk Ex0 ) ) ) ) ) ) ) ) ) xQg ) ) Lwk ) ) $.
Lh8 $a zw ( Tw IQE ( SwE ( cBQ ( LAQ ewk pgg ( IAQ ewk 2R4 ) ) ( LAQ rgk pgg ( IAQ rgk 8hw ) ) ) YQk ) ) $.
6h8 $a #Pattern nR4 $.
riY $a zw ( Tw IQE ( tQM cwE ( 0wM YQk cwE ( cBQ ( LAQ ewk pgg ( IAQ ewk 2R4 ) ) ( LAQ rgk pgg ( IAQ rgk 8hw ) ) ) ( 7BI ( cBQ ( LAQ ewk pgg ( IAQ ewk 2R4 ) ) ( LAQ rgk pgg ( IAQ rgk 8hw ) ) ) ww4 ) ) ) ) $.
ryY $a zw ( Tw IQE ( SwE ( 7BI ( cBQ ( LAQ ewk pgg ( IAQ ewk 2R4 ) ) ( LAQ rgk pgg ( IAQ rgk 8hw ) ) ) ww4 ) YQk ) ) $.
3iY $a zw ( Tw IQE ( tQM cwE ( 0wM YQk cwE ( 7BI ( cBQ ( LAQ ewk pgg ( IAQ ewk 9R4 ) ) ( LAQ rgk pgg ( IAQ rgk 8hw ) ) ) ( 7BI ( cBQ ( LAQ ewk pgg ( IAQ ewk 2R4 ) ) ( LAQ rgk pgg ( IAQ rgk 8hw ) ) ) ww4 ) ) ( 7BI ( 7BI ( cBQ ( LAQ ewk pgg ( IAQ ewk 9R4 ) ) ( LAQ rgk pgg ( IAQ rgk 8hw ) ) ) ( cBQ ( LAQ ewk pgg ( IAQ ewk 2R4 ) ) ( LAQ rgk pgg ( IAQ rgk 8hw ) ) ) ) ww4 ) ) ) ) $.
3yY $a zw ( Tw IQE ( SwE ( 7BI ( 7BI ( cBQ ( LAQ ewk pgg ( IAQ ewk 9R4 ) ) ( LAQ rgk pgg ( IAQ rgk 8hw ) ) ) ( cBQ ( LAQ ewk pgg ( IAQ ewk 2R4 ) ) ( LAQ rgk pgg ( IAQ rgk 8hw ) ) ) ) ww4 ) YQk ) ) $.
${ 4CY $p zw ( Tw IQE ( tQM Ngk ( xwM Ngk ( wQM Ngk ( wQM Ngk ( twM Ngk ) ( twM Ngk ) ) ( -g4 ( 0Q4 ( Hg8 ( rwg ( LAQ 1wk pgg ( GBY ( 3BA ( IAQ ewk vR4 ) ( 3BA ( IAQ ewk 7h4 ) ( 3BA ( IAQ ewk xB4 ) vA4 ) ) ) ( kBM ( kBM ( kBM ( kBM ( XBI ( IAQ ewk 9R4 ) ( LAQ rgk Wgk ( IAQ rgk yx4 ) ) ) ( XBI ( IAQ ewk 2R4 ) ( LAQ rgk Wgk ( IAQ rgk 0h4 ) ) ) ) ( XBI ( IAQ ewk vR4 ) ( LAQ rgk Wgk ( IAQ rgk 5x4 ) ) ) ) ( XBI ( IAQ ewk 7h4 ) ( LAQ rgk Wgk ( IAQ rgk 4B4 ) ) ) ) ( 0hU ( zBI ( LAQ ewk Wgk ( IAQ ewk 2R4 ) ) ( LAQ ewk Wgk ( IAQ ewk vR4 ) ) ) ( qxs ( XBI ( IAQ ewk xB4 ) ( LAQ rgk Wgk ( IAQ rgk 8hw ) ) ) ) ( qxs ( kBM ( kBM ( XBI ( IAQ ewk vR4 ) ( DBE ( LAQ ewk Wgk ( IAQ ewk vR4 ) ) ( LAQ ewk Wgk ( IAQ ewk 2R4 ) ) ) ) ( XBI ( IAQ ewk 7h4 ) ( zBA ( LAQ ewk Wgk ( IAQ ewk 7h4 ) ) ( LAQ ewk Wgk ( IAQ ewk 2R4 ) ) ) ) ) ( XBI ( IAQ ewk xB4 ) ( LAQ rgk Wgk ( IAQ rgk Ex0 ) ) ) ) ) ) ) ) ) xQg ) ) ( Kw8 ( 7BI ( cBQ ( LAQ ewk pgg ( IAQ ewk 9R4 ) ) ( LAQ rgk pgg ( IAQ rgk 8hw ) ) ) ( cBQ ( LAQ ewk pgg ( IAQ ewk 2R4 ) ) ( LAQ rgk pgg ( IAQ rgk 8hw ) ) ) ) ) ) ( 8Q4 ( IAQ rgk 8hw ) ) ) ) ( wQM Ngk ( twM Ngk ) ( -g4 ( 0Q4 ( Hg8 ( rwg ( LAQ 1wk pgg ( GBY ( 3BA ( IAQ ewk vR4 ) ( 3BA ( IAQ ewk 7h4 ) ( 3BA ( IAQ ewk xB4 ) vA4 ) ) ) ( kBM ( kBM ( kBM ( kBM ( XBI ( IAQ ewk 9R4 ) ( LAQ rgk Wgk ( IAQ rgk yx4 ) ) ) ( XBI ( IAQ ewk 2R4 ) ( LAQ rgk Wgk ( IAQ rgk 0h4 ) ) ) ) ( XBI ( IAQ ewk vR4 ) ( LAQ rgk Wgk ( IAQ rgk 5x4 ) ) ) ) ( XBI ( IAQ ewk 7h4 ) ( LAQ rgk Wgk ( IAQ rgk 4B4 ) ) ) ) ( 0hU ( zBI ( LAQ ewk Wgk ( IAQ ewk 2R4 ) ) ( LAQ ewk Wgk ( IAQ ewk vR4 ) ) ) ( qxs ( XBI ( IAQ ewk xB4 ) ( LAQ rgk Wgk ( IAQ rgk 8hw ) ) ) ) ( qxs ( kBM ( kBM ( XBI ( IAQ ewk vR4 ) ( DBE ( LAQ ewk Wgk ( IAQ ewk vR4 ) ) ( LAQ ewk Wgk ( IAQ ewk 2R4 ) ) ) ) ( XBI ( IAQ ewk 7h4 ) ( zBA ( LAQ ewk Wgk ( IAQ ewk 7h4 ) ) ( LAQ ewk Wgk ( IAQ ewk 2R4 ) ) ) ) ) ( XBI ( IAQ ewk xB4 ) ( LAQ rgk Wgk ( IAQ rgk Ex0 ) ) ) ) ) ) ) ) ) xQg ) ) ( Kw8 ( 7BI ( 7BI ( cBQ ( LAQ ewk pgg ( IAQ ewk 9R4 ) ) ( LAQ rgk pgg ( IAQ rgk 8hw ) ) ) ( cBQ ( LAQ ewk pgg ( IAQ ewk 2R4 ) ) ( LAQ rgk pgg ( IAQ rgk 8hw ) ) ) ) ww4 ) ) ) ( 8Q4 ( IAQ rgk 8hw ) ) ) ) ) ) ) $=
  ( NQk wAM egk HwQ rQk WQk KwQ WxI jxM 6xI Kg8 0A4 -Q4 IAE SgE wgE mAE YAk IQI
  4g nB4 uwM 1gk pQg vB4 7R4 wx4 uw4 2xA 9B4 yh4 2B4 0R4 5h4 3x4 yxI 8Rw qhs SA
  CxE yxA Eh0 0RU FxY xAg rgg HQ8 bxQ 8A4 wg4 .R4 JwU 6wk Qwk Lgk PAk LB8 3yY
  NA8 3Q4 Kx8 Cg8 tAM SwU OAM WAU xgM 6h8 KB8 ryY .BI 3iY Lh8 riY swU 8hI MA8
  jg 1w4 BA8 TQQ VQQ QgQ uQY BwY ) AAAUBZXFBZXFAXGUCUDCUEDZCUFDZCUGDZUHUIUIUICU
  JDZEFEUKDGHCULDZEFEUMDGHIXHEFEUNDGHIXIEFEUODGHICFXLGZCFXHGZUPXJEFEUQDZGHURXHX
  NXMUTHXICFXIGXMVAHIXJEFEVBDGHIURVCIVDGVEVFVGZCUDXKGEUDXOGZVHZCUDXLGXQVHZJZKZL
  ZXOVIZMZBZXPXTVJJZKZLZYCMZNNXFAOZYJTXGAOZNYJYJVKVKPAXFXFVLQZVKNYHVMOZYCVNOZTY
  IAONYMYNNXPVOOZYGVPOZTYMNYOYPVQNYFROYPVRYFVSQPXPYGVTQWAPYHYCWBQAXGXFNNAXFWCAW
  DWEWFRXRXSVJJZJZYFAYEAXGXPYRKZLZYCMZBZWGZAAYEAXGXPUAWHZKZLZYCMZBZWGZWCAYEAXGY
  IBZWGZAANUANXRROZYQROZTYRRONUULUUMWIWJPXRYQWKQVRWLRXSYQAYEYEWGZAAYEAXGXPXRUUD
  JZKZLZYCMZBZWGZWCUUCAANUAWMWJWNAYENNYKYDAOZTYEAONYKUVAYLNYBVMOZYNTUVANUVBYNNY
  OYAVPOZTUVBNYOUVCVQNXTROZUVCNUULXSROZTUVDNUULUVEWIWMPXRXSWKQXTVSQPXPYAVTQWAPY
  BYCWBQPAXGYDVLQWOAUUNAUUTXSUAUSZAXSUVFSZAYEYEAYEUUSXSUVFUVGYEXSUVFSAXGYDAXGUU
  RXSUVFUVGXGXSUVFSUVFXSYBYCUUQYCUVFXSXPYAXPUUPXPXSUVFSUVFXSXTUUOUVFXSXRXSXRUUD
  XRXSUVFSXSUVFWRWPWQWSYCXSUVFSWTXAXBXCAUUCAUUTYQUVFAYQUVFSZAYEUUBAYEUUSYQUVFUV
  HYEYQUVFSAXGUUAAXGUURYQUVFUVHXGYQUVFSUVFYQYTYCUUQYCUVFYQXPYSXPUUPXPYQUVFSUVFY
  QYRUUOUVFYQXRYQXRUUDXRYQUVFSYQUVFWRWPWQWSYCYQUVFSWTXAXBXCXDAUUCAUUIYRUVFAYRUV
  FSZAYEUUBAYEUUHYRUVFUVIYEYRUVFSAXGUUAAXGUUGYRUVFUVIXGYRUVFSUVFYRYTYCUUFYCUVFY
  RXPYSXPUUEXPYRUVFSUVFYRYRUUDYRUVFWRWQWSYCYRUVFSWTXAXBXCAUUKAUUIYFUVFAYFUVFSZA
  YEUUJAYEUUHYFUVFUVJYEYFUVFSAXGYIAXGUUGYFUVFUVJXGYFUVFSUVFYFYHYCUUFYCUVFYFXPYG
  XPUUEXPYFUVFSUVFYFYFUUDYFUVFWRWQWSYCYFUVFSWTXAXBXCXDXE $. $}
