$c XBI Tw #Symbol zw JAQ rgk #Pattern ( LAQ ewk xB4 IAQ Wgk #Variable SwE #SetVariable 4w #ElementVariable IQE 8wk mwg 8hw ) $.
$v 7Ag CQ qwg Bw oAg Cw 2gg $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Cg $f #Pattern Cw $.
Tg $a #Pattern ( Tw Bw CQ ) $.
4g $a #Pattern ( 4w Bw CQ ) $.
5Q $a zw ( Tw Bw ( Tw CQ Bw ) ) $.
${ 6A $e zw ( Tw Bw CQ ) $.
   6Q $e zw Bw $.
   6g $a zw CQ $. $}
SgE $a #Pattern ( SwE Bw CQ ) $.
${ lgE $e zw ( Tw Bw CQ ) $.
   lwE $e zw ( Tw CQ Cw ) $.
   mAE $a zw ( Tw Bw Cw ) $. $}
${ wAE $e zw ( Tw Bw CQ ) $.
   wQE $e zw ( Tw Bw Cw ) $.
   wgE $a zw ( Tw Bw ( 4w CQ Cw ) ) $. $}
HwQ $a #Pattern ( IAQ Bw CQ ) $.
IgQ $a zw ( SwE ( IAQ Bw CQ ) Bw ) $.
KwQ $a #Pattern ( LAQ Bw CQ Cw ) $.
nwg $f #Pattern oAg $.
qgg $f #Pattern qwg $.
2Qg $f #ElementVariable 2gg $.
6wg $f #ElementVariable 7Ag $.
WQk $a #Pattern Wgk $.
egk $a #Pattern ewk $.
rQk $a #Pattern rgk $.
8gk $a #Pattern 8wk $.
WxI $a #Pattern ( XBI oAg qwg ) $.
aBI $a zw ( Tw ( 4w ( SwE oAg ewk ) ( SwE qwg Wgk ) ) ( SwE ( XBI oAg qwg ) 8wk ) ) $.
8Rw $a #Pattern 8hw $.
wx4 $a #Pattern xB4 $.
pyQ $a #Pattern ( 4w ( JAQ 2gg ) ( 4w ( SwE 7Ag mwg ) IQE ) ) $.
0CQ $a zw ( Tw ( 4w ( JAQ 2gg ) ( 4w ( SwE 7Ag mwg ) IQE ) ) ( SwE ( LAQ rgk Wgk ( IAQ rgk 8hw ) ) Wgk ) ) $.
${ 0SQ $p zw ( Tw ( 4w ( JAQ 2gg ) ( 4w ( SwE 7Ag mwg ) IQE ) ) ( SwE ( XBI ( IAQ ewk xB4 ) ( LAQ rgk Wgk ( IAQ rgk 8hw ) ) ) 8wk ) ) $=
  ( pyQ egk wx4 HwQ SgE rQk WQk 8Rw KwQ 4g WxI 8gk Tg 5Q IgQ 6g 0CQ wgE aBI mAE
  ) ABCZDEFZDGZHIHJFKZIGZLUDUFMNGUCUEUGUEUCUEOUEUCPDEQRABSTUDUFUAUB $. $}
