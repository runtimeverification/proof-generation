$c rwg 0wM LAQ IAQ #Symbol #Variable #SetVariable 5x4 ) jww #ElementVariable mwg rgk pgg xQg #Pattern ( $.
$v 7Ag CQ qwg DQ Bw oAg Cw 6Ag 2gg $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Cg $f #Pattern Cw $.
DA $f #Pattern DQ $.
0gM $a #Pattern ( 0wM Bw CQ Cw DQ ) $.
HwQ $a #Pattern ( IAQ Bw CQ ) $.
KwQ $a #Pattern ( LAQ Bw CQ Cw ) $.
mgg $a #Pattern mwg $.
nwg $f #Pattern oAg $.
pQg $a #Pattern pgg $.
qgg $f #Pattern qwg $.
rgg $a #Pattern ( rwg oAg qwg ) $.
xAg $a #Pattern xQg $.
2Qg $f #ElementVariable 2gg $.
5wg $f #ElementVariable 6Ag $.
6wg $f #ElementVariable 7Ag $.
rQk $a #Pattern rgk $.
jgw $a #Pattern ( jww oAg ) $.
5h4 $a #Pattern 5x4 $.
Wh8 $a #Pattern 2gg $.
-CA $a #Pattern 7Ag $.
BCE $a #Pattern 6Ag $.
${ 2DI $p #Pattern ( 0wM mwg 2gg 6Ag ( rwg ( jww ( rwg ( LAQ rgk pgg ( IAQ rgk 5x4 ) ) xQg ) ) 7Ag ) ) $=
  ( mgg Wh8 BCE rQk pQg 5h4 HwQ KwQ xAg rgg jgw -CA 0gM ) DAEBFGHGIJKLMNCOMP $. $}
