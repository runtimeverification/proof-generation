$c 2R4 Tw #Symbol zw YQk JAQ pgg rgk #Pattern ( LAQ ewk IAQ #Variable SwE #SetVariable 4w #ElementVariable IQE 8hw ) cBQ $.
$v CQ qwg Bw oAg Cw 2gg pxw $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Cg $f #Pattern Cw $.
4g $a #Pattern ( 4w Bw CQ ) $.
SgE $a #Pattern ( SwE Bw CQ ) $.
${ lgE $e zw ( Tw Bw CQ ) $.
   lwE $e zw ( Tw CQ Cw ) $.
   mAE $a zw ( Tw Bw Cw ) $. $}
${ wAE $e zw ( Tw Bw CQ ) $.
   wQE $e zw ( Tw Bw Cw ) $.
   wgE $a zw ( Tw Bw ( 4w CQ Cw ) ) $. $}
HwQ $a #Pattern ( IAQ Bw CQ ) $.
KwQ $a #Pattern ( LAQ Bw CQ Cw ) $.
nwg $f #Pattern oAg $.
pQg $a #Pattern pgg $.
qgg $f #Pattern qwg $.
2Qg $f #ElementVariable 2gg $.
YAk $a #Pattern YQk $.
egk $a #Pattern ewk $.
rQk $a #Pattern rgk $.
bxQ $a #Pattern ( cBQ oAg qwg ) $.
fBQ $a zw ( Tw ( 4w ( SwE oAg pgg ) ( SwE qwg pgg ) ) ( SwE ( cBQ oAg qwg ) YQk ) ) $.
phw $f #ElementVariable pxw $.
8Rw $a #Pattern 8hw $.
2B4 $a #Pattern 2R4 $.
xSY $a #Pattern ( 4w ( JAQ 2gg ) ( 4w ( SwE pxw YQk ) IQE ) ) $.
ziY $a zw ( Tw ( 4w ( JAQ 2gg ) ( 4w ( SwE pxw YQk ) IQE ) ) ( SwE ( LAQ ewk pgg ( IAQ ewk 2R4 ) ) pgg ) ) $.
0CY $a zw ( Tw ( 4w ( JAQ 2gg ) ( 4w ( SwE pxw YQk ) IQE ) ) ( SwE ( LAQ rgk pgg ( IAQ rgk 8hw ) ) pgg ) ) $.
${ 0SY $p zw ( Tw ( 4w ( JAQ 2gg ) ( 4w ( SwE pxw YQk ) IQE ) ) ( SwE ( cBQ ( LAQ ewk pgg ( IAQ ewk 2R4 ) ) ( LAQ rgk pgg ( IAQ rgk 8hw ) ) ) YQk ) ) $=
  ( xSY egk pQg 2B4 HwQ KwQ SgE rQk 8Rw 4g bxQ YAk ziY 0CY wgE fBQ mAE ) ABCZDE
  DFGHZEIZJEJKGHZEIZLUAUCMNITUBUDABOABPQUAUCRS $. $}
