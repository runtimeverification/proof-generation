$c #SetVariable iA ) #ElementVariable #Symbol #Variable mwg #Pattern ( $.
$v Ow CQ xX Bw Kw ph0 nR4 3Ag $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Kg $f #ElementVariable Kw $.
Og $f #Variable Ow $.
SA $a #Variable Kw $.
${ $d xX ph0 $.
   IQI $a iA Bw Bw CQ Ow $. $}
mgg $a #Pattern mwg $.
2wg $f #ElementVariable 3Ag $.
nB4 $f #ElementVariable nR4 $.
6h8 $a #Pattern nR4 $.
${ -CQ $p iA mwg mwg nR4 3Ag $=
  ( mgg 6h8 SA IQI ) CBDAEF $. $}
