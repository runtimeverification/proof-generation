$c #Symbol #Variable #SetVariable iA 4w JAQ #ElementVariable IQE #Pattern ) ( $.
$v Ow CQ DQ Bw Kw Cw 0R8 6xw Dw $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Cg $f #Pattern Cw $.
DA $f #Pattern DQ $.
Dg $f #Pattern Dw $.
Kg $f #ElementVariable Kw $.
Og $f #Variable Ow $.
SA $a #Variable Kw $.
IAE $a #Pattern IQE $.
${ KAI $e iA CQ DQ Bw Ow $.
   KQI $e iA Cw Dw Bw Ow $.
   KgI $a iA ( 4w CQ Cw ) ( 4w DQ Dw ) Bw Ow $. $}
IwQ $a #Pattern ( JAQ Bw ) $.
6hw $f #ElementVariable 6xw $.
dB8 $a #Pattern 6xw $.
0B8 $f #ElementVariable 0R8 $.
1h8 $a #Pattern 0R8 $.
3R8 $a iA ( JAQ 0R8 ) ( JAQ 6xw ) 0R8 6xw $.
3h8 $a iA IQE IQE 0R8 6xw $.
${ 3x8 $p iA ( 4w ( JAQ 0R8 ) IQE ) ( 4w ( JAQ 6xw ) IQE ) 0R8 6xw $=
  ( 1h8 IwQ IAE dB8 SA 3R8 3h8 KgI ) BCZKDEAFDEAGABHABIJ $. $}
