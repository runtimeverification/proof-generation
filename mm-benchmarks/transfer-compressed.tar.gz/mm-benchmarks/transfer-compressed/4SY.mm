$c 4B4 Ngk Lwk #Symbol 7h4 DBE GBY 8Q4 zw YQk xwM pgg vA4 #Pattern 0Q4 rwg Ex0 xB4 tQM Wgk 0h4 #Variable SwE 0hU PQk #SetVariable vR4 4w #ElementVariable IQE qxs mwg xQg 8hw cBQ kBM 2R4 zBA XBI 1wk RAk Tw wQM -g4 zBI 5x4 rgk ( twM LAQ ewk yx4 IAQ 9R4 Hg8 3BA Kw8 7Ak 7BI ) $.
$v CQ qwg Bw oAg Cw GQ sgg $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Cg $f #Pattern Cw $.
GA $f #Pattern GQ $.
4g $a #Pattern ( 4w Bw CQ ) $.
IAE $a #Pattern IQE $.
SgE $a #Pattern ( SwE Bw CQ ) $.
${ lgE $e zw ( Tw Bw CQ ) $.
   lwE $e zw ( Tw CQ Cw ) $.
   mAE $a zw ( Tw Bw Cw ) $. $}
${ wAE $e zw ( Tw Bw CQ ) $.
   wQE $e zw ( Tw Bw Cw ) $.
   wgE $a zw ( Tw Bw ( 4w CQ Cw ) ) $. $}
uwM $a #Pattern ( twM Bw ) $.
wAM $a #Pattern ( wQM Bw CQ Cw ) $.
HwQ $a #Pattern ( IAQ Bw CQ ) $.
KwQ $a #Pattern ( LAQ Bw CQ Cw ) $.
JwU $a zw ( Tw ( 4w ( SwE CQ Bw ) ( SwE Cw Bw ) ) ( SwE ( wQM Bw CQ Cw ) Bw ) ) $.
${ sgU $e zw ( Tw GQ ( SwE CQ Bw ) ) $.
   swU $a zw ( Tw GQ ( tQM Bw ( xwM Bw CQ CQ ) ) ) $. $}
mgg $a #Pattern mwg $.
nwg $f #Pattern oAg $.
pQg $a #Pattern pgg $.
qgg $f #Pattern qwg $.
rgg $a #Pattern ( rwg oAg qwg ) $.
sQg $f #Pattern sgg $.
xAg $a #Pattern xQg $.
Lgk $a #Pattern Lwk $.
NQk $a #Pattern Ngk $.
PAk $a #Pattern PQk $.
Qwk $a #Pattern RAk $.
WQk $a #Pattern Wgk $.
YAk $a #Pattern YQk $.
egk $a #Pattern ewk $.
rQk $a #Pattern rgk $.
1gk $a #Pattern 1wk $.
6wk $a #Pattern 7Ak $.
uw4 $a #Pattern vA4 $.
0A4 $a #Pattern ( 0Q4 oAg qwg ) $.
3Q4 $a zw ( Tw ( 4w ( SwE oAg Lwk ) ( SwE qwg PQk ) ) ( SwE ( 0Q4 oAg qwg ) 7Ak ) ) $.
8A4 $a #Pattern ( 8Q4 oAg ) $.
-Q4 $a #Pattern ( -g4 oAg qwg ) $.
Cg8 $a zw ( Tw ( 4w ( SwE oAg 7Ak ) ( SwE qwg RAk ) ) ( SwE ( -g4 oAg qwg ) Ngk ) ) $.
HQ8 $a #Pattern ( Hg8 oAg ) $.
Jw8 $a zw ( Tw ( SwE oAg mwg ) ( SwE ( Hg8 oAg ) Lwk ) ) $.
Kg8 $a #Pattern ( Kw8 oAg ) $.
NA8 $a zw ( Tw ( SwE oAg YQk ) ( SwE ( Kw8 oAg ) PQk ) ) $.
yxA $a #Pattern ( zBA oAg qwg ) $.
2xA $a #Pattern ( 3BA oAg qwg ) $.
CxE $a #Pattern ( DBE oAg qwg ) $.
WxI $a #Pattern ( XBI oAg qwg ) $.
yxI $a #Pattern ( zBI oAg qwg ) $.
6xI $a #Pattern ( 7BI oAg qwg ) $.
.BI $a zw ( Tw ( 4w ( SwE oAg YQk ) ( SwE qwg YQk ) ) ( SwE ( 7BI oAg qwg ) YQk ) ) $.
jxM $a #Pattern ( kBM oAg qwg ) $.
bxQ $a #Pattern ( cBQ oAg qwg ) $.
0RU $a #Pattern ( 0hU oAg qwg sgg ) $.
FxY $a #Pattern ( GBY oAg qwg ) $.
qhs $a #Pattern ( qxs oAg ) $.
8Rw $a #Pattern 8hw $.
Eh0 $a #Pattern Ex0 $.
vB4 $a #Pattern vR4 $.
wx4 $a #Pattern xB4 $.
yh4 $a #Pattern yx4 $.
0R4 $a #Pattern 0h4 $.
2B4 $a #Pattern 2R4 $.
3x4 $a #Pattern 4B4 $.
5h4 $a #Pattern 5x4 $.
7R4 $a #Pattern 7h4 $.
9B4 $a #Pattern 9R4 $.
.R4 $a zw ( Tw IQE ( SwE ( twM Ngk ) Ngk ) ) $.
KB8 $a zw ( Tw IQE ( SwE ( cBQ ( LAQ ewk pgg ( IAQ ewk 9R4 ) ) ( LAQ rgk pgg ( IAQ rgk 8hw ) ) ) YQk ) ) $.
Kx8 $a zw ( Tw IQE ( SwE ( 8Q4 ( IAQ rgk 8hw ) ) RAk ) ) $.
Lh8 $a zw ( Tw IQE ( SwE ( cBQ ( LAQ ewk pgg ( IAQ ewk 2R4 ) ) ( LAQ rgk pgg ( IAQ rgk 8hw ) ) ) YQk ) ) $.
Lx8 $a zw ( Tw IQE ( SwE ( rwg ( LAQ 1wk pgg ( GBY ( 3BA ( IAQ ewk 7h4 ) ( 3BA ( IAQ ewk xB4 ) vA4 ) ) ( kBM ( kBM ( kBM ( kBM ( XBI ( IAQ ewk 9R4 ) ( LAQ rgk Wgk ( IAQ rgk yx4 ) ) ) ( XBI ( IAQ ewk 2R4 ) ( LAQ rgk Wgk ( IAQ rgk 0h4 ) ) ) ) ( XBI ( IAQ ewk vR4 ) ( LAQ rgk Wgk ( IAQ rgk 5x4 ) ) ) ) ( XBI ( IAQ ewk 7h4 ) ( LAQ rgk Wgk ( IAQ rgk 4B4 ) ) ) ) ( 0hU ( zBI ( LAQ ewk Wgk ( IAQ ewk 2R4 ) ) ( LAQ ewk Wgk ( IAQ ewk vR4 ) ) ) ( qxs ( XBI ( IAQ ewk xB4 ) ( LAQ rgk Wgk ( IAQ rgk 8hw ) ) ) ) ( qxs ( kBM ( kBM ( XBI ( IAQ ewk vR4 ) ( DBE ( LAQ ewk Wgk ( IAQ ewk vR4 ) ) ( LAQ ewk Wgk ( IAQ ewk 2R4 ) ) ) ) ( XBI ( IAQ ewk 7h4 ) ( zBA ( LAQ ewk Wgk ( IAQ ewk 7h4 ) ) ( LAQ ewk Wgk ( IAQ ewk 2R4 ) ) ) ) ) ( XBI ( IAQ ewk xB4 ) ( LAQ rgk Wgk ( IAQ rgk Ex0 ) ) ) ) ) ) ) ) ) xQg ) mwg ) ) $.
MR8 $a zw ( Tw IQE ( SwE ( cBQ ( LAQ ewk pgg ( IAQ ewk vR4 ) ) ( LAQ rgk pgg ( IAQ rgk 8hw ) ) ) YQk ) ) $.
${ 4SY $p zw ( Tw IQE ( tQM Ngk ( xwM Ngk ( wQM Ngk ( wQM Ngk ( twM Ngk ) ( twM Ngk ) ) ( -g4 ( 0Q4 ( Hg8 ( rwg ( LAQ 1wk pgg ( GBY ( 3BA ( IAQ ewk 7h4 ) ( 3BA ( IAQ ewk xB4 ) vA4 ) ) ( kBM ( kBM ( kBM ( kBM ( XBI ( IAQ ewk 9R4 ) ( LAQ rgk Wgk ( IAQ rgk yx4 ) ) ) ( XBI ( IAQ ewk 2R4 ) ( LAQ rgk Wgk ( IAQ rgk 0h4 ) ) ) ) ( XBI ( IAQ ewk vR4 ) ( LAQ rgk Wgk ( IAQ rgk 5x4 ) ) ) ) ( XBI ( IAQ ewk 7h4 ) ( LAQ rgk Wgk ( IAQ rgk 4B4 ) ) ) ) ( 0hU ( zBI ( LAQ ewk Wgk ( IAQ ewk 2R4 ) ) ( LAQ ewk Wgk ( IAQ ewk vR4 ) ) ) ( qxs ( XBI ( IAQ ewk xB4 ) ( LAQ rgk Wgk ( IAQ rgk 8hw ) ) ) ) ( qxs ( kBM ( kBM ( XBI ( IAQ ewk vR4 ) ( DBE ( LAQ ewk Wgk ( IAQ ewk vR4 ) ) ( LAQ ewk Wgk ( IAQ ewk 2R4 ) ) ) ) ( XBI ( IAQ ewk 7h4 ) ( zBA ( LAQ ewk Wgk ( IAQ ewk 7h4 ) ) ( LAQ ewk Wgk ( IAQ ewk 2R4 ) ) ) ) ) ( XBI ( IAQ ewk xB4 ) ( LAQ rgk Wgk ( IAQ rgk Ex0 ) ) ) ) ) ) ) ) ) xQg ) ) ( Kw8 ( 7BI ( 7BI ( cBQ ( LAQ ewk pgg ( IAQ ewk 9R4 ) ) ( LAQ rgk pgg ( IAQ rgk 8hw ) ) ) ( cBQ ( LAQ ewk pgg ( IAQ ewk 2R4 ) ) ( LAQ rgk pgg ( IAQ rgk 8hw ) ) ) ) ( cBQ ( LAQ ewk pgg ( IAQ ewk vR4 ) ) ( LAQ rgk pgg ( IAQ rgk 8hw ) ) ) ) ) ) ( 8Q4 ( IAQ rgk 8hw ) ) ) ) ( wQM Ngk ( wQM Ngk ( twM Ngk ) ( twM Ngk ) ) ( -g4 ( 0Q4 ( Hg8 ( rwg ( LAQ 1wk pgg ( GBY ( 3BA ( IAQ ewk 7h4 ) ( 3BA ( IAQ ewk xB4 ) vA4 ) ) ( kBM ( kBM ( kBM ( kBM ( XBI ( IAQ ewk 9R4 ) ( LAQ rgk Wgk ( IAQ rgk yx4 ) ) ) ( XBI ( IAQ ewk 2R4 ) ( LAQ rgk Wgk ( IAQ rgk 0h4 ) ) ) ) ( XBI ( IAQ ewk vR4 ) ( LAQ rgk Wgk ( IAQ rgk 5x4 ) ) ) ) ( XBI ( IAQ ewk 7h4 ) ( LAQ rgk Wgk ( IAQ rgk 4B4 ) ) ) ) ( 0hU ( zBI ( LAQ ewk Wgk ( IAQ ewk 2R4 ) ) ( LAQ ewk Wgk ( IAQ ewk vR4 ) ) ) ( qxs ( XBI ( IAQ ewk xB4 ) ( LAQ rgk Wgk ( IAQ rgk 8hw ) ) ) ) ( qxs ( kBM ( kBM ( XBI ( IAQ ewk vR4 ) ( DBE ( LAQ ewk Wgk ( IAQ ewk vR4 ) ) ( LAQ ewk Wgk ( IAQ ewk 2R4 ) ) ) ) ( XBI ( IAQ ewk 7h4 ) ( zBA ( LAQ ewk Wgk ( IAQ ewk 7h4 ) ) ( LAQ ewk Wgk ( IAQ ewk 2R4 ) ) ) ) ) ( XBI ( IAQ ewk xB4 ) ( LAQ rgk Wgk ( IAQ rgk Ex0 ) ) ) ) ) ) ) ) ) xQg ) ) ( Kw8 ( 7BI ( 7BI ( cBQ ( LAQ ewk pgg ( IAQ ewk 9R4 ) ) ( LAQ rgk pgg ( IAQ rgk 8hw ) ) ) ( cBQ ( LAQ ewk pgg ( IAQ ewk 2R4 ) ) ( LAQ rgk pgg ( IAQ rgk 8hw ) ) ) ) ( cBQ ( LAQ ewk pgg ( IAQ ewk vR4 ) ) ( LAQ rgk pgg ( IAQ rgk 8hw ) ) ) ) ) ) ( 8Q4 ( IAQ rgk 8hw ) ) ) ) ) ) ) $=
  ( NQk wAM pQg egk HwQ 2xA rQk WQk KwQ WxI jxM qhs bxQ 6xI IAE SgE wgE mAE YAk
  4g uwM 1gk 7R4 wx4 uw4 9B4 yh4 2B4 0R4 vB4 5h4 3x4 yxI 8Rw CxE yxA Eh0 0RU
  FxY xAg rgg HQ8 Kg8 0A4 8A4 -Q4 .R4 JwU 6wk Qwk Lgk PAk mgg Lx8 Jw8 KB8 Lh8
  .BI MR8 NA8 3Q4 Kx8 Cg8 swU ) AAAAUAZWEBZUBCDUCEZDUDEZUEFFDUFEZGHGUGEIJDUHEZG
  HGUIEIJKDUJEZGHGUKEIJKWGGHGULEIJKDHWJIZDHWKIZUMWHGHGUNEZIJLWKWMWLUOJWGDHWGIWL
  UPJKWHGHGUQEIJKLURKUSIUTVAZVBZDCWIIGCWNIZMZDCWJIWQMZNZDCWKIWQMZNZVCZVDZWNVEZV
  FZBZOOWFAPZXFAPZTXGAPOXHXIOWEAPZXJTXHOXJXJVGVGQAWEWEVHROXDVIPZXEVJPZTXIOXKXLO
  WPVKPZXCVLPZTXKOXMXNOWOVMPXMVNWOVOROXBSPZXNOWTSPZXASPZTXOOXPXQOWRSPZWSSPZTXPO
  XRXSVPVQQWRWSVRRVSQWTXAVRRXBVTRQWPXCWARWBQXDXEWCRQAWFXFVHRWD $. $}
