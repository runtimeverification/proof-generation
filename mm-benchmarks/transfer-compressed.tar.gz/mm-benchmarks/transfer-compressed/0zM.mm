$c lSA Tw #Symbol zw YQk pgg rgk #Pattern ( LAQ ewk IAQ #Variable SwE #SetVariable vR4 4w #ElementVariable IQE ) cBQ $.
$v CQ qwg Bw oAg 5Qg Cw $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Cg $f #Pattern Cw $.
4g $a #Pattern ( 4w Bw CQ ) $.
IAE $a #Pattern IQE $.
SgE $a #Pattern ( SwE Bw CQ ) $.
${ lgE $e zw ( Tw Bw CQ ) $.
   lwE $e zw ( Tw CQ Cw ) $.
   mAE $a zw ( Tw Bw Cw ) $. $}
${ wAE $e zw ( Tw Bw CQ ) $.
   wQE $e zw ( Tw Bw Cw ) $.
   wgE $a zw ( Tw Bw ( 4w CQ Cw ) ) $. $}
HwQ $a #Pattern ( IAQ Bw CQ ) $.
KwQ $a #Pattern ( LAQ Bw CQ Cw ) $.
nwg $f #Pattern oAg $.
pQg $a #Pattern pgg $.
qgg $f #Pattern qwg $.
5Ag $f #ElementVariable 5Qg $.
YAk $a #Pattern YQk $.
egk $a #Pattern ewk $.
rQk $a #Pattern rgk $.
bxQ $a #Pattern ( cBQ oAg qwg ) $.
fBQ $a zw ( Tw ( 4w ( SwE oAg pgg ) ( SwE qwg pgg ) ) ( SwE ( cBQ oAg qwg ) YQk ) ) $.
vB4 $a #Pattern vR4 $.
lCA $a #Pattern lSA $.
YCU $a #Pattern 5Qg $.
6jE $a zw ( Tw ( 4w ( SwE 5Qg ewk ) IQE ) ( SwE ( LAQ ewk pgg ( IAQ ewk vR4 ) ) pgg ) ) $.
0jM $a zw ( Tw ( 4w ( SwE 5Qg ewk ) IQE ) ( SwE ( LAQ rgk pgg ( IAQ rgk lSA ) ) pgg ) ) $.
${ 0zM $p zw ( Tw ( 4w ( SwE 5Qg ewk ) IQE ) ( SwE ( cBQ ( LAQ ewk pgg ( IAQ ewk vR4 ) ) ( LAQ rgk pgg ( IAQ rgk lSA ) ) ) YQk ) ) $=
  ( YCU egk SgE IAE 4g pQg vB4 HwQ KwQ rQk lCA bxQ YAk 6jE 0jM wgE fBQ mAE ) AB
  CDEFZCGCHIJZGDZKGKLIJZGDZFUAUCMNDTUBUDAOAPQUAUCRS $. $}
