$c 0wM 2R4 ewk IAQ #Symbol #Variable #SetVariable iA #ElementVariable #Pattern ) ( $.
$v 7Rw Ow CQ Fw DQ Bw Cw 0R8 EQ Dw FQ xX Ew Kw ph0 6xw $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Cg $f #Pattern Cw $.
DA $f #Pattern DQ $.
Dg $f #Pattern Dw $.
EA $f #Pattern EQ $.
Eg $f #Pattern Ew $.
FA $f #Pattern FQ $.
Fg $f #Pattern Fw $.
Kg $f #ElementVariable Kw $.
Og $f #Variable Ow $.
SA $a #Variable Kw $.
jg $a iA Bw Ow Bw Ow $.
${ $d xX ph0 $.
   IQI $a iA Bw Bw CQ Ow $. $}
HwQ $a #Pattern ( IAQ Bw CQ ) $.
${ XgQ $e iA Bw Dw Fw Ow $.
   XwQ $e iA CQ EQ Fw Ow $.
   YAQ $e iA Cw Ew Fw Ow $.
   YQQ $e iA DQ FQ Fw Ow $.
   YgQ $a iA ( 0wM Bw CQ Cw DQ ) ( 0wM Dw EQ Ew FQ ) Fw Ow $. $}
egk $a #Pattern ewk $.
6hw $f #ElementVariable 6xw $.
7Bw $f #ElementVariable 7Rw $.
2B4 $a #Pattern 2R4 $.
dB8 $a #Pattern 6xw $.
0B8 $f #ElementVariable 0R8 $.
1B8 $a #Pattern 7Rw $.
1h8 $a #Pattern 0R8 $.
4B8 $a iA ewk ewk 0R8 6xw $.
4R8 $a iA 7Rw 7Rw 0R8 6xw $.
${ 4h8 $p iA ( 0wM ewk 0R8 7Rw ( IAQ ewk 2R4 ) ) ( 0wM ewk 6xw 7Rw ( IAQ ewk 2R4 ) ) 0R8 6xw $=
  ( egk 1h8 1B8 2B4 HwQ dB8 SA 4B8 jg 4R8 IQI YgQ ) DCEZBFZDGHZDAIQRPAJZACKPSLA
  BCMRPSNO $. $}
