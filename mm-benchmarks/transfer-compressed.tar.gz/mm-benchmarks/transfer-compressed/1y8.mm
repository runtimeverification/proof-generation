$c LAQ #Symbol #Variable 0hU #SetVariable iA #ElementVariable 8wk pgg #Pattern ) ( $.
$v Ow CQ DQ Ew Bw Kw 5Qg MB0 Cw nR4 EQ Dw 4Ag $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Cg $f #Pattern Cw $.
DA $f #Pattern DQ $.
Dg $f #Pattern Dw $.
EA $f #Pattern EQ $.
Eg $f #Pattern Ew $.
Kg $f #ElementVariable Kw $.
Og $f #Variable Ow $.
SA $a #Variable Kw $.
${ lAQ $e iA Bw DQ Ew Ow $.
   lQQ $e iA CQ Dw Ew Ow $.
   lgQ $e iA Cw EQ Ew Ow $.
   lwQ $a iA ( LAQ Bw CQ Cw ) ( LAQ DQ Dw EQ ) Ew Ow $. $}
pQg $a #Pattern pgg $.
3wg $f #ElementVariable 4Ag $.
5Ag $f #ElementVariable 5Qg $.
8gk $a #Pattern 8wk $.
Lx0 $f #ElementVariable MB0 $.
nB4 $f #ElementVariable nR4 $.
6h8 $a #Pattern nR4 $.
niQ $a iA pgg pgg nR4 4Ag $.
pSo $a iA 8wk 8wk nR4 4Ag $.
wS8 $a #Pattern ( 0hU 5Qg 4Ag MB0 ) $.
0i8 $a #Pattern ( 0hU 5Qg nR4 MB0 ) $.
1i8 $a iA ( 0hU 5Qg nR4 MB0 ) ( 0hU 5Qg 4Ag MB0 ) nR4 4Ag $.
${ 1y8 $p iA ( LAQ 8wk pgg ( 0hU 5Qg nR4 MB0 ) ) ( LAQ 8wk pgg ( 0hU 5Qg 4Ag MB0 ) ) nR4 4Ag $=
  ( 8gk pQg 0i8 wS8 6h8 SA pSo niQ 1i8 lwQ ) EFBCDGEFABCHDIAJADKADLABCDMN $. $}
