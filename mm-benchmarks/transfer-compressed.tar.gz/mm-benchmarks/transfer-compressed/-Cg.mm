$c ewk Wgk Tw #Symbol #Variable SwE #SetVariable zw 4w YQk JAQ #ElementVariable IQE rgk pgg #Pattern ) ( $.
$v 4wg CQ 3gg -Bw Bw 5Qg Cw $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Cg $f #Pattern Cw $.
Tg $a #Pattern ( Tw Bw CQ ) $.
4g $a #Pattern ( 4w Bw CQ ) $.
5Q $a zw ( Tw Bw ( Tw CQ Bw ) ) $.
${ 6A $e zw ( Tw Bw CQ ) $.
   6Q $e zw Bw $.
   6g $a zw CQ $. $}
SgE $a #Pattern ( SwE Bw CQ ) $.
${ wAE $e zw ( Tw Bw CQ ) $.
   wQE $e zw ( Tw Bw Cw ) $.
   wgE $a zw ( Tw Bw ( 4w CQ Cw ) ) $. $}
IwQ $a #Pattern ( JAQ Bw ) $.
3Qg $f #ElementVariable 3gg $.
4gg $f #ElementVariable 4wg $.
5Ag $f #ElementVariable 5Qg $.
WQk $a #Pattern Wgk $.
XQk $a zw ( JAQ Wgk ) $.
egk $a #Pattern ewk $.
rQk $a #Pattern rgk $.
sQk $a zw ( JAQ rgk ) $.
.xw $f #ElementVariable -Bw $.
XiU $a #Pattern 3gg $.
XyU $a #Pattern 4wg $.
zCg $a #Pattern ( 4w ( SwE 5Qg pgg ) ( 4w ( SwE -Bw YQk ) IQE ) ) $.
${ -Cg $p zw ( Tw ( 4w ( SwE 3gg rgk ) ( 4w ( SwE 4wg ewk ) ( 4w ( SwE 5Qg pgg ) ( 4w ( SwE -Bw YQk ) IQE ) ) ) ) ( 4w ( JAQ rgk ) ( JAQ Wgk ) ) ) $=
  ( XiU rQk SgE XyU egk zCg 4g IwQ WQk Tg 5Q sQk 6g XQk wgE ) AEFGBHIGCDJKKZFLZ
  MLZUATUANUATOPQUBTUBNUBTORQS $. $}
