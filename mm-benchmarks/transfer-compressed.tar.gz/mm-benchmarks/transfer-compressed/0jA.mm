$c Uw PgE Tw #Symbol zw JAQ pwk .gk #Pattern ( 0wM LAQ tQM #Variable SwE #SetVariable iA 4w #ElementVariable IQE ) $.
$v th1 CQ Bw Cw 2gg z ph2 ph0 x Lw 6xw LQ Ow DQ ph1 y th2 mh4 Dw HQ Gw th0 Hw lB4 lh4 Kw GQ $.
$d z y $.
$d z x $.
$d y x $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Cg $f #Pattern Cw $.
DA $f #Pattern DQ $.
Dg $f #Pattern Dw $.
GA $f #Pattern GQ $.
Gg $f #Pattern Gw $.
HA $f #Pattern HQ $.
Hg $f #Pattern Hw $.
Kg $f #ElementVariable Kw $.
LA $f #ElementVariable LQ $.
Lg $f #ElementVariable Lw $.
Og $f #Variable Ow $.
SA $a #Variable Kw $.
Tg $a #Pattern ( Tw Bw CQ ) $.
${ kg $e iA CQ DQ Bw Ow $.
   kw $e iA Cw Dw Bw Ow $.
   lA $a iA ( Tw CQ Cw ) ( Tw DQ Dw ) Bw Ow $. $}
4g $a #Pattern ( 4w Bw CQ ) $.
5Q $a zw ( Tw Bw ( Tw CQ Bw ) ) $.
${ 6A $e zw ( Tw Bw CQ ) $.
   6Q $e zw Bw $.
   6g $a zw CQ $. $}
IAE $a #Pattern IQE $.
lQE $a zw ( Tw Bw Bw ) $.
${ lgE $e zw ( Tw Bw CQ ) $.
   lwE $e zw ( Tw CQ Cw ) $.
   mAE $a zw ( Tw Bw Cw ) $. $}
nAE $a zw IQE $.
ugE $a zw ( Tw ( 4w Bw CQ ) Bw ) $.
${ wAE $e zw ( Tw Bw CQ ) $.
   wQE $e zw ( Tw Bw Cw ) $.
   wgE $a zw ( Tw Bw ( 4w CQ Cw ) ) $. $}
${ NwM $e zw CQ $.
   OAM $a zw ( Tw Bw CQ ) $. $}
tAM $a #Pattern ( tQM Bw CQ ) $.
0gM $a #Pattern ( 0wM Bw CQ Cw DQ ) $.
IwQ $a #Pattern ( JAQ Bw ) $.
KwQ $a #Pattern ( LAQ Bw CQ Cw ) $.
${ QAQ $e iA Bw Cw Dw Ow $.
   QQQ $e iA CQ DQ Dw Ow $.
   QgQ $a iA ( tQM Bw CQ ) ( tQM Cw DQ ) Dw Ow $. $}
${ $d z ph0 $.
   $d z ph1 $.
   $d z ph2 $.
   $d z y $.
   $d z x $.
   $d z th1 $.
   $d z th2 $.
   $d x ph0 $.
   $d y th0 $.
   lAY $e zw ( Tw GQ ( Uw Kw ( PgE Kw Bw ) ) ) $.
   lQY $e zw ( Tw ( 4w GQ Gw ) CQ ) $.
   lgY $e iA ( Tw HQ Cw ) ( Tw Gw CQ ) Bw LQ $.
   lwY $e iA ( Tw Hw DQ ) ( Tw Gw CQ ) Lw LQ $.
   mAY $a zw ( Tw ( 4w GQ HQ ) Cw ) $. $}
2Qg $f #ElementVariable 2gg $.
pgk $a #Pattern pwk $.
qgk $a zw ( JAQ pwk ) $.
.Qk $a #Pattern .gk $.
6hw $f #ElementVariable 6xw $.
kx4 $f #ElementVariable lB4 $.
lR4 $f #ElementVariable lh4 $.
mR4 $f #ElementVariable mh4 $.
Wh8 $a #Pattern 2gg $.
Wx8 $a #Pattern lh4 $.
XB8 $a #Pattern lB4 $.
YR8 $a #Pattern mh4 $.
dB8 $a #Pattern 6xw $.
sB8 $a iA ( 4w ( JAQ 6xw ) IQE ) ( 4w ( JAQ lh4 ) IQE ) 6xw lh4 $.
sR8 $a iA 2gg 2gg 6xw lh4 $.
cTA $a #Pattern ( LAQ .gk lh4 mh4 ) $.
cjA $a #Pattern ( LAQ .gk lB4 mh4 ) $.
gDA $a #Pattern ( 4w ( JAQ lB4 ) ( 4w ( SwE mh4 .gk ) IQE ) ) $.
kDA $a zw ( Tw ( 4w ( 4w ( JAQ 2gg ) ( 4w ( JAQ lB4 ) ( 4w ( SwE mh4 .gk ) IQE ) ) ) ( 4w ( JAQ lh4 ) IQE ) ) ( tQM 2gg ( 0wM lB4 2gg ( LAQ lh4 lB4 ( LAQ .gk lh4 mh4 ) ) ( LAQ .gk lB4 mh4 ) ) ) ) $.
kTA $a #Pattern ( LAQ .gk 6xw mh4 ) $.
mDA $a iA ( 0wM lB4 2gg ( LAQ 6xw lB4 ( LAQ .gk 6xw mh4 ) ) ( LAQ .gk lB4 mh4 ) ) ( 0wM lB4 2gg ( LAQ lh4 lB4 ( LAQ .gk lh4 mh4 ) ) ( LAQ .gk lB4 mh4 ) ) 6xw lh4 $.
mjA $a zw ( Tw ( 4w ( JAQ 2gg ) ( 4w ( JAQ lB4 ) ( 4w ( SwE mh4 .gk ) IQE ) ) ) ( 4w ( JAQ lB4 ) ( 4w ( SwE mh4 .gk ) IQE ) ) ) $.
yjA $a zw ( Tw ( 4w ( JAQ 2gg ) ( 4w ( JAQ lB4 ) ( 4w ( SwE mh4 .gk ) IQE ) ) ) ( Uw Kw ( PgE Kw pwk ) ) ) $.
yzA $a iA ( 4w ( JAQ pwk ) IQE ) ( 4w ( JAQ lh4 ) IQE ) pwk lh4 $.
zDA $a iA 2gg 2gg pwk lh4 $.
0TA $a iA ( 0wM lB4 2gg ( LAQ pwk lB4 ( LAQ .gk pwk mh4 ) ) ( LAQ .gk lB4 mh4 ) ) ( 0wM lB4 2gg ( LAQ lh4 lB4 ( LAQ .gk lh4 mh4 ) ) ( LAQ .gk lB4 mh4 ) ) pwk lh4 $.
${ 0jA $p zw ( Tw ( 4w ( JAQ 2gg ) ( 4w ( JAQ lB4 ) ( 4w ( SwE mh4 .gk ) IQE ) ) ) ( tQM 2gg ( 0wM lB4 2gg ( LAQ pwk lB4 ( LAQ .gk pwk mh4 ) ) ( LAQ .gk lB4 mh4 ) ) ) ) $=
  ( lR4 6hw Kg Wh8 IwQ gDA 4g pgk IAE XB8 KwQ 0gM tAM mAE wgE QgQ lA .Qk YR8 Tg
  cjA ugE lQE mjA 5Q qgk 6g nAE OAM Wx8 cTA dB8 kTA yjA kDA yzA zDA 0TA sB8 sR8
  SA mDA mAY ) AGZHZBCIZJZVJKHZLJZJVGBMZVGKVMUAKCUBNNBCUDZOZPZVJVJVLVJVHVIVJVHV
  HVHVIUEVHUFQABCUGRVJVKLVKVJVKUCVKVJUHUIUJVJLUKULRRKVGVMVGDUMZVMDCUNNVNOZPZVPV
  GVMVGEUOZVMECUPNVNOZPZVJVQHLJZVLVTHLJZFDEFABCUQABDCURKVLVPWCVSDVDZDUSVGVOVGVR
  KWEADUTABDCVASTVTWDWBWCVSWEEDVBVGWAVGVRVTWEAEDVCAEBDCVESTVFQ $. $}
