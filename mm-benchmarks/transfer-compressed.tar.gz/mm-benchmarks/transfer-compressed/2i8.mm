$c rwg LAQ 0Q4 Hg8 #Symbol #Variable 0hU #SetVariable iA #ElementVariable 8wk pgg #Pattern ) ( $.
$v 4wg ngg CQ qwg 3gg Bw Kw oAg 5Qg MB0 Cw nR4 sgg tAg tgg 4Ag $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Cg $f #Pattern Cw $.
Kg $f #ElementVariable Kw $.
SA $a #Variable Kw $.
KwQ $a #Pattern ( LAQ Bw CQ Cw ) $.
nQg $f #Variable ngg $.
nwg $f #Pattern oAg $.
pQg $a #Pattern pgg $.
qgg $f #Pattern qwg $.
rgg $a #Pattern ( rwg oAg qwg ) $.
sQg $f #Pattern sgg $.
swg $f #Pattern tAg $.
tQg $f #Pattern tgg $.
3Qg $f #ElementVariable 3gg $.
3wg $f #ElementVariable 4Ag $.
4gg $f #ElementVariable 4wg $.
5Ag $f #ElementVariable 5Qg $.
8gk $a #Pattern 8wk $.
${ 1Q4 $e iA qwg tAg oAg ngg $.
   1g4 $e iA sgg tgg oAg ngg $.
   1w4 $a iA ( 0Q4 qwg sgg ) ( 0Q4 tAg tgg ) oAg ngg $. $}
HQ8 $a #Pattern ( Hg8 oAg ) $.
Lx0 $f #ElementVariable MB0 $.
nB4 $f #ElementVariable nR4 $.
6h8 $a #Pattern nR4 $.
XiU $a #Pattern 3gg $.
XyU $a #Pattern 4wg $.
iic $a iA 4wg 4wg nR4 4Ag $.
wS8 $a #Pattern ( 0hU 5Qg 4Ag MB0 ) $.
0i8 $a #Pattern ( 0hU 5Qg nR4 MB0 ) $.
2S8 $a iA ( Hg8 ( rwg ( LAQ 8wk pgg ( 0hU 5Qg nR4 MB0 ) ) 3gg ) ) ( Hg8 ( rwg ( LAQ 8wk pgg ( 0hU 5Qg 4Ag MB0 ) ) 3gg ) ) nR4 4Ag $.
${ 2i8 $p iA ( 0Q4 ( Hg8 ( rwg ( LAQ 8wk pgg ( 0hU 5Qg nR4 MB0 ) ) 3gg ) ) 4wg ) ( 0Q4 ( Hg8 ( rwg ( LAQ 8wk pgg ( 0hU 5Qg 4Ag MB0 ) ) 3gg ) ) 4wg ) nR4 4Ag $=
  ( SA 6h8 8gk pQg 0i8 KwQ XiU rgg HQ8 XyU wS8 2S8 iic 1w4 ) BGFHIJDEFKLAMZNOCP
  ZIJBDEQLUANOUBABDEFRBCFST $. $}
