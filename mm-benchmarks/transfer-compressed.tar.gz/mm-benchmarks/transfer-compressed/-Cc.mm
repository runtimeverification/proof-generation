$c #Symbol #Variable SwE PQk #SetVariable iA #ElementVariable #Pattern ) ( $.
$v 4wg Ow CQ DQ Bw Kw Cw nR4 Dw $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Cg $f #Pattern Cw $.
DA $f #Pattern DQ $.
Dg $f #Pattern Dw $.
Kg $f #ElementVariable Kw $.
Og $f #Variable Ow $.
SA $a #Variable Kw $.
jg $a iA Bw Ow Bw Ow $.
${ OgI $e iA CQ DQ Bw Ow $.
   OwI $e iA Cw Dw Bw Ow $.
   PAI $a iA ( SwE CQ Cw ) ( SwE DQ Dw ) Bw Ow $. $}
4gg $f #ElementVariable 4wg $.
PAk $a #Pattern PQk $.
nB4 $f #ElementVariable nR4 $.
6h8 $a #Pattern nR4 $.
XyU $a #Pattern 4wg $.
.yc $a iA PQk PQk nR4 4wg $.
${ -Cc $p iA ( SwE nR4 PQk ) ( SwE 4wg PQk ) nR4 4wg $=
  ( 6h8 PAk XyU SA jg .yc PAI ) BCZJDAEDAFZJKGABHI $. $}
