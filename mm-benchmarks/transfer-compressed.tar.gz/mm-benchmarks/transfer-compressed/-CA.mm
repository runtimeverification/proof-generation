$c #SetVariable ) #ElementVariable #Symbol #Variable #Pattern ( $.
$v 7Ag Ow Kw $.
Kg $f #ElementVariable Kw $.
Og $f #Variable Ow $.
SA $a #Variable Kw $.
Sg $a #Pattern Ow $.
6wg $f #ElementVariable 7Ag $.
${ -CA $p #Pattern 7Ag $=
  ( SA Sg ) ABC $. $}
