$c 4B4 Tw #Symbol wQM cwE zw JAQ .gk xwM rgk pgg 3gk #Pattern ( rwg 0wM twM LAQ tQM IAQ 1gM #Variable 5xw SwE #SetVariable iA 4w #ElementVariable IQE mwg xQg ) Vhc $.
$v Fw Ow CQ qwg DQ Bw Cw 2gg EQ sgg Dw Pw tAg ngg FQ xX Ew Kw ph0 oAg GQ nR4 tgg $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Cg $f #Pattern Cw $.
DA $f #Pattern DQ $.
Dg $f #Pattern Dw $.
EA $f #Pattern EQ $.
Eg $f #Pattern Ew $.
FA $f #Pattern FQ $.
Fg $f #Pattern Fw $.
GA $f #Pattern GQ $.
Kg $f #ElementVariable Kw $.
Og $f #Variable Ow $.
Pg $f #Symbol Pw $.
SA $a #Variable Kw $.
Sw $a #Pattern Pw $.
jg $a iA Bw Ow Bw Ow $.
4g $a #Pattern ( 4w Bw CQ ) $.
IAE $a #Pattern IQE $.
cgE $a #Symbol cwE $.
lQE $a zw ( Tw Bw Bw ) $.
${ lgE $e zw ( Tw Bw CQ ) $.
   lwE $e zw ( Tw CQ Cw ) $.
   mAE $a zw ( Tw Bw Cw ) $. $}
nAE $a zw IQE $.
ugE $a zw ( Tw ( 4w Bw CQ ) Bw ) $.
${ wAE $e zw ( Tw Bw CQ ) $.
   wQE $e zw ( Tw Bw Cw ) $.
   wgE $a zw ( Tw Bw ( 4w CQ Cw ) ) $. $}
${ $d xX ph0 $.
   IQI $a iA Bw Bw CQ Ow $. $}
${ NwM $e zw CQ $.
   OAM $a zw ( Tw Bw CQ ) $. $}
tAM $a #Pattern ( tQM Bw CQ ) $.
uwM $a #Pattern ( twM Bw ) $.
wAM $a #Pattern ( wQM Bw CQ Cw ) $.
xgM $a #Pattern ( xwM Bw CQ Cw ) $.
0gM $a #Pattern ( 0wM Bw CQ Cw DQ ) $.
1QM $a #Pattern ( 1gM Bw CQ Cw DQ ) $.
HwQ $a #Pattern ( IAQ Bw CQ ) $.
IwQ $a #Pattern ( JAQ Bw ) $.
KwQ $a #Pattern ( LAQ Bw CQ Cw ) $.
${ QAQ $e iA Bw Cw Dw Ow $.
   QQQ $e iA CQ DQ Dw Ow $.
   QgQ $a iA ( tQM Bw CQ ) ( tQM Cw DQ ) Dw Ow $. $}
${ SgQ $e iA Bw DQ Ew Ow $.
   SwQ $e iA CQ Dw Ew Ow $.
   TAQ $e iA Cw EQ Ew Ow $.
   TQQ $a iA ( wQM Bw CQ Cw ) ( wQM DQ Dw EQ ) Ew Ow $. $}
${ UgQ $e iA Bw DQ Ew Ow $.
   UwQ $e iA CQ Dw Ew Ow $.
   VAQ $e iA Cw EQ Ew Ow $.
   VQQ $a iA ( xwM Bw CQ Cw ) ( xwM DQ Dw EQ ) Ew Ow $. $}
${ YwQ $e iA Bw Dw Fw Ow $.
   ZAQ $e iA CQ EQ Fw Ow $.
   ZQQ $e iA Cw Ew Fw Ow $.
   ZgQ $e iA DQ FQ Fw Ow $.
   ZwQ $a iA ( 1gM Bw CQ Cw DQ ) ( 1gM Dw EQ Ew FQ ) Fw Ow $. $}
${ swY $e zw ( Tw GQ ( SwE CQ Bw ) ) $.
   tAY $e zw ( Tw GQ ( SwE Cw Bw ) ) $.
   tQY $e zw ( Tw GQ ( tQM cwE ( 0wM Bw cwE CQ Cw ) ) ) $.
   tgY $e zw ( Tw GQ ( tQM Ew DQ ) ) $.
   twY $e iA ( tQM Ew DQ ) Dw CQ Kw $.
   uAY $e iA ( tQM FQ EQ ) Dw Cw Kw $.
   uQY $a zw ( Tw GQ ( tQM FQ EQ ) ) $. $}
mgg $a #Pattern mwg $.
nQg $f #Variable ngg $.
nwg $f #Pattern oAg $.
pQg $a #Pattern pgg $.
qgg $f #Pattern qwg $.
rgg $a #Pattern ( rwg oAg qwg ) $.
sQg $f #Pattern sgg $.
swg $f #Pattern tAg $.
tQg $f #Pattern tgg $.
${ uQg $e iA qwg tAg oAg ngg $.
   ugg $e iA sgg tgg oAg ngg $.
   uwg $a iA ( rwg qwg sgg ) ( rwg tAg tgg ) oAg ngg $. $}
xAg $a #Pattern xQg $.
2Qg $f #ElementVariable 2gg $.
rQk $a #Pattern rgk $.
3Qk $a #Pattern 3gk $.
.Qk $a #Pattern .gk $.
VRc $a #Pattern ( Vhc oAg ) $.
5hw $a #Pattern 5xw $.
nB4 $f #ElementVariable nR4 $.
3x4 $a #Pattern 4B4 $.
Wh8 $a #Pattern 2gg $.
6h8 $a #Pattern nR4 $.
9h8 $a zw ( Tw ( 4w ( JAQ 2gg ) IQE ) ( 4w ( JAQ 2gg ) IQE ) ) $.
0DQ $a zw ( Tw ( 4w ( JAQ 2gg ) IQE ) ( tQM 2gg ( xwM 2gg ( wQM 2gg ( twM 2gg ) ( wQM 2gg ( 1gM mwg 2gg ( rwg ( LAQ rgk pgg ( IAQ rgk 4B4 ) ) xQg ) ( rwg ( LAQ 3gk pgg ( LAQ rgk 3gk ( IAQ rgk 4B4 ) ) ) xQg ) ) ( twM 2gg ) ) ) ( wQM 2gg ( 0wM .gk 2gg ( Vhc ( rwg ( LAQ rgk pgg ( IAQ rgk 4B4 ) ) xQg ) ) ( IAQ .gk 5xw ) ) ( twM 2gg ) ) ) ) ) $.
0jQ $a zw ( Tw IQE ( tQM cwE ( 0wM pgg cwE ( LAQ 3gk pgg ( LAQ rgk 3gk ( IAQ rgk 4B4 ) ) ) ( LAQ rgk pgg ( IAQ rgk 4B4 ) ) ) ) ) $.
1DQ $a zw ( Tw ( 4w ( 4w ( JAQ 2gg ) IQE ) ( 4w ( 4w ( JAQ 2gg ) IQE ) IQE ) ) ( SwE ( LAQ 3gk pgg ( LAQ rgk 3gk ( IAQ rgk 4B4 ) ) ) pgg ) ) $.
1TQ $a zw ( Tw ( 4w ( 4w ( JAQ 2gg ) IQE ) ( 4w ( 4w ( JAQ 2gg ) IQE ) IQE ) ) ( SwE ( LAQ rgk pgg ( IAQ rgk 4B4 ) ) pgg ) ) $.
${ 1jQ $p zw ( Tw ( 4w ( JAQ 2gg ) IQE ) ( tQM 2gg ( xwM 2gg ( wQM 2gg ( twM 2gg ) ( wQM 2gg ( 1gM mwg 2gg ( rwg ( LAQ rgk pgg ( IAQ rgk 4B4 ) ) xQg ) ( rwg ( LAQ rgk pgg ( IAQ rgk 4B4 ) ) xQg ) ) ( twM 2gg ) ) ) ( wQM 2gg ( 0wM .gk 2gg ( Vhc ( rwg ( LAQ rgk pgg ( IAQ rgk 4B4 ) ) xQg ) ) ( IAQ .gk 5xw ) ) ( twM 2gg ) ) ) ) ) $=
  ( nB4 IAE 4g mgg rQk pQg HwQ KwQ xAg rgg 1QM wAM .Qk xgM tAM wgE mAE IQI TQQ
  Wh8 IwQ uwM 3x4 VRc 5hw 0gM 9h8 nAE OAM 3Qk 6h8 1DQ 1TQ cgE Sw 0jQ ugE lQE SA
  0DQ jg uwg ZwQ VQQ QgQ uQY ) AUAZUBZCDZVJVJCDZDZVHVHVHVHUCZVHEVHFGFUDHZIZJKZV
  PLZVMMZMZVHNVHVPUENUFHUGVMMZOZPVJVJVKAUHZVJVJCWBVJCUIUJQQGUKGFUKVNIIZVOVHVHVM
  VHEVHVPWCJKZLZVMMZMZVTOZVHVHVHVMVHEVHVPBULZJKZLZVMMZMZVTOZPWAVHVHVLBAUMAUNVLC
  UOUPZGWOWCVOUGPVLCUIUJZUQRVLVJVHWHPVLVICVLVJVIVJVKURVJVIVIVICURVIUSRRWPQAVARV
  HWHVHWNWCBUTZVHWCWQSZVHWGVTVHWMVTWCWQWRVHVMWFVHVMWLWCWQWRVMWCWQSZVHWEVMVHWKVM
  WCWQWREVHVPWDEVHVPWJWCWQEWCWQSWRVPWCWQSWQWCWCJWIJWCWQVBJWCWQSVCVDWSTTVTWCWQSV
  EVFVHWAVHWNVOWQVHVOWQSZVHVSVTVHWMVTVOWQWTVHVMVRVHVMWLVOWQWTVMVOWQSZVHVQVMVHWK
  VMVOWQWTEVHVPVPEVHVPWJVOWQEVOWQSWTVPVOWQSWQVOVOJWIJVOWQVBJVOWQSVCVDXATTVTVOWQ
  SVEVFVGR $. $}
