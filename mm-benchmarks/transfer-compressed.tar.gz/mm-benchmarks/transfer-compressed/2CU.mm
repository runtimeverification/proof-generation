$c 2R4 Tw #Symbol -gg DBE zw #Pattern ( LAQ ewk IAQ Wgk #Variable SwE #SetVariable vR4 4w #ElementVariable IQE ) $.
$v CQ qwg Bw oAg 5Qg Cw $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Cg $f #Pattern Cw $.
4g $a #Pattern ( 4w Bw CQ ) $.
IAE $a #Pattern IQE $.
SgE $a #Pattern ( SwE Bw CQ ) $.
${ lgE $e zw ( Tw Bw CQ ) $.
   lwE $e zw ( Tw CQ Cw ) $.
   mAE $a zw ( Tw Bw Cw ) $. $}
${ wAE $e zw ( Tw Bw CQ ) $.
   wQE $e zw ( Tw Bw Cw ) $.
   wgE $a zw ( Tw Bw ( 4w CQ Cw ) ) $. $}
HwQ $a #Pattern ( IAQ Bw CQ ) $.
KwQ $a #Pattern ( LAQ Bw CQ Cw ) $.
nwg $f #Pattern oAg $.
qgg $f #Pattern qwg $.
5Ag $f #ElementVariable 5Qg $.
-Qg $a #Pattern -gg $.
WQk $a #Pattern Wgk $.
egk $a #Pattern ewk $.
CxE $a #Pattern ( DBE oAg qwg ) $.
GBE $a zw ( Tw ( 4w ( SwE oAg Wgk ) ( SwE qwg Wgk ) ) ( SwE ( DBE oAg qwg ) Wgk ) ) $.
vB4 $a #Pattern vR4 $.
2B4 $a #Pattern 2R4 $.
YCU $a #Pattern 5Qg $.
ziU $a zw ( Tw ( 4w ( SwE 5Qg -gg ) IQE ) ( SwE ( LAQ ewk Wgk ( IAQ ewk 2R4 ) ) Wgk ) ) $.
0CU $a zw ( Tw ( 4w ( SwE 5Qg -gg ) IQE ) ( SwE ( LAQ ewk Wgk ( IAQ ewk vR4 ) ) Wgk ) ) $.
${ 2CU $p zw ( Tw ( 4w ( SwE 5Qg -gg ) IQE ) ( SwE ( DBE ( LAQ ewk Wgk ( IAQ ewk vR4 ) ) ( LAQ ewk Wgk ( IAQ ewk 2R4 ) ) ) Wgk ) ) $=
  ( YCU -Qg SgE IAE 4g egk WQk vB4 HwQ KwQ 2B4 CxE 0CU ziU wgE GBE mAE ) ABCDEF
  ZGHGIJKZHDZGHGLJKZHDZFTUBMHDSUAUCANAOPTUBQR $. $}
