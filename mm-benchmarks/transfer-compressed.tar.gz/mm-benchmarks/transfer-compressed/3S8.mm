$c Wgk Tw #Symbol #Variable SwE PQk #SetVariable hgk zw 4w pwk JAQ #ElementVariable IQE mwg rgk pgg #Pattern ) ( $.
$v 4wg CQ 3gg -Bw Bw 5Qg MB0 Cw $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Cg $f #Pattern Cw $.
Tg $a #Pattern ( Tw Bw CQ ) $.
4g $a #Pattern ( 4w Bw CQ ) $.
5Q $a zw ( Tw Bw ( Tw CQ Bw ) ) $.
${ 6A $e zw ( Tw Bw CQ ) $.
   6Q $e zw Bw $.
   6g $a zw CQ $. $}
SgE $a #Pattern ( SwE Bw CQ ) $.
${ wAE $e zw ( Tw Bw CQ ) $.
   wQE $e zw ( Tw Bw Cw ) $.
   wgE $a zw ( Tw Bw ( 4w CQ Cw ) ) $. $}
IwQ $a #Pattern ( JAQ Bw ) $.
mgg $a #Pattern mwg $.
3Qg $f #ElementVariable 3gg $.
4gg $f #ElementVariable 4wg $.
5Ag $f #ElementVariable 5Qg $.
PAk $a #Pattern PQk $.
WQk $a #Pattern Wgk $.
XQk $a zw ( JAQ Wgk ) $.
pgk $a #Pattern pwk $.
rQk $a #Pattern rgk $.
sQk $a zw ( JAQ rgk ) $.
.xw $f #ElementVariable -Bw $.
Lx0 $f #ElementVariable MB0 $.
XiU $a #Pattern 3gg $.
XyU $a #Pattern 4wg $.
YCU $a #Pattern 5Qg $.
rC8 $a #Pattern ( 4w ( SwE -Bw pgg ) ( 4w ( SwE MB0 hgk ) IQE ) ) $.
${ 3S8 $p zw ( Tw ( 4w ( SwE 3gg mwg ) ( 4w ( SwE 4wg PQk ) ( 4w ( SwE 5Qg pwk ) ( 4w ( SwE -Bw pgg ) ( 4w ( SwE MB0 hgk ) IQE ) ) ) ) ) ( 4w ( JAQ rgk ) ( JAQ Wgk ) ) ) $=
  ( XiU mgg SgE XyU PAk YCU pgk rC8 4g rQk IwQ WQk Tg 5Q 6g sQk XQk wgE ) AFGHB
  IJHCKLHDEMNNNZOPZQPZUEUDUERUEUDSUATUFUDUFRUFUDSUBTUC $. $}
