$c #Symbol cwE #Variable #SetVariable iA JAQ #ElementVariable #Pattern ) ( $.
$v Ow CQ xX ph2 Bw Kw ph1 ph0 Cw x 6xw Pw $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Cg $f #Pattern Cw $.
Kg $f #ElementVariable Kw $.
Og $f #Variable Ow $.
Pg $f #Symbol Pw $.
SA $a #Variable Kw $.
Sw $a #Pattern Pw $.
jg $a iA Bw Ow Bw Ow $.
cgE $a #Symbol cwE $.
${ $d x ph0 $.
   $d x ph1 $.
   $d x ph2 $.
   $d x xX $.
   mAQ $e iA Bw CQ Cw Ow $.
   mQQ $a iA ( JAQ Bw ) ( JAQ CQ ) Cw Ow $. $}
6hw $f #ElementVariable 6xw $.
dB8 $a #Pattern 6xw $.
${ 1x8 $p iA ( JAQ cwE ) ( JAQ 6xw ) cwE 6xw $=
  ( cgE Sw dB8 SA jg mQQ ) BCZADHAEZHIFG $. $}
