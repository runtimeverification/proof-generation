$c 4B4 Ngk Lwk #Symbol 7h4 8Q4 zw xwM pgg #Pattern 0Q4 rwg Ex0 0wM xB4 tQM Wgk 0h4 5xw #Variable SwE PQk #SetVariable vR4 4w #ElementVariable IQE mwg 8hw xQg cBQ zBA 2R4 lSA XBI RAk Tw wQM -g4 .gk rgk ( twM LAQ ewk yx4 IAQ 9R4 Hg8 Kw8 8wk 7Ak 7BI ) $.
$v CQ qwg DQ Bw oAg Cw GQ Dw $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Cg $f #Pattern Cw $.
DA $f #Pattern DQ $.
Dg $f #Pattern Dw $.
GA $f #Pattern GQ $.
Tg $a #Pattern ( Tw Bw CQ ) $.
4g $a #Pattern ( 4w Bw CQ ) $.
5Q $a zw ( Tw Bw ( Tw CQ Bw ) ) $.
${ 6A $e zw ( Tw Bw CQ ) $.
   6Q $e zw Bw $.
   6g $a zw CQ $. $}
IAE $a #Pattern IQE $.
SgE $a #Pattern ( SwE Bw CQ ) $.
${ lgE $e zw ( Tw Bw CQ ) $.
   lwE $e zw ( Tw CQ Cw ) $.
   mAE $a zw ( Tw Bw Cw ) $. $}
${ wAE $e zw ( Tw Bw CQ ) $.
   wQE $e zw ( Tw Bw Cw ) $.
   wgE $a zw ( Tw Bw ( 4w CQ Cw ) ) $. $}
${ NwM $e zw CQ $.
   OAM $a zw ( Tw Bw CQ ) $. $}
tAM $a #Pattern ( tQM Bw CQ ) $.
uwM $a #Pattern ( twM Bw ) $.
wAM $a #Pattern ( wQM Bw CQ Cw ) $.
0gM $a #Pattern ( 0wM Bw CQ Cw DQ ) $.
HwQ $a #Pattern ( IAQ Bw CQ ) $.
KwQ $a #Pattern ( LAQ Bw CQ Cw ) $.
JwU $a zw ( Tw ( 4w ( SwE CQ Bw ) ( SwE Cw Bw ) ) ( SwE ( wQM Bw CQ Cw ) Bw ) ) $.
LAU $a zw ( SwE ( 0wM Bw CQ Cw DQ ) CQ ) $.
${ VwU $e zw ( Tw GQ ( tQM Bw Cw ) ) $.
   WAU $a zw ( Tw GQ ( tQM Bw ( xwM Bw CQ Cw ) ) ) $. $}
${ sgU $e zw ( Tw GQ ( SwE CQ Bw ) ) $.
   swU $a zw ( Tw GQ ( tQM Bw ( xwM Bw CQ CQ ) ) ) $. $}
${ AgY $e zw ( Tw GQ ( SwE CQ Bw ) ) $.
   AwY $e zw ( Tw GQ ( SwE Cw Bw ) ) $.
   BAY $e zw ( Tw GQ ( SwE Dw Bw ) ) $.
   BQY $e zw ( Tw GQ ( tQM Bw ( xwM Bw CQ Cw ) ) ) $.
   BgY $e zw ( Tw GQ ( tQM Bw ( xwM Bw DQ ( wQM Bw CQ Dw ) ) ) ) $.
   BwY $a zw ( Tw GQ ( tQM Bw ( xwM Bw DQ ( wQM Bw Cw Dw ) ) ) ) $. $}
uwY $a zw ( tQM Bw ( 0wM CQ Bw Cw Cw ) ) $.
mgg $a #Pattern mwg $.
nwg $f #Pattern oAg $.
pQg $a #Pattern pgg $.
qgg $f #Pattern qwg $.
rgg $a #Pattern ( rwg oAg qwg ) $.
xAg $a #Pattern xQg $.
Lgk $a #Pattern Lwk $.
NQk $a #Pattern Ngk $.
PAk $a #Pattern PQk $.
Qwk $a #Pattern RAk $.
WQk $a #Pattern Wgk $.
egk $a #Pattern ewk $.
rQk $a #Pattern rgk $.
6wk $a #Pattern 7Ak $.
8gk $a #Pattern 8wk $.
.Qk $a #Pattern .gk $.
0A4 $a #Pattern ( 0Q4 oAg qwg ) $.
3Q4 $a zw ( Tw ( 4w ( SwE oAg Lwk ) ( SwE qwg PQk ) ) ( SwE ( 0Q4 oAg qwg ) 7Ak ) ) $.
8A4 $a #Pattern ( 8Q4 oAg ) $.
-Q4 $a #Pattern ( -g4 oAg qwg ) $.
Cg8 $a zw ( Tw ( 4w ( SwE oAg 7Ak ) ( SwE qwg RAk ) ) ( SwE ( -g4 oAg qwg ) Ngk ) ) $.
HQ8 $a #Pattern ( Hg8 oAg ) $.
Jw8 $a zw ( Tw ( SwE oAg mwg ) ( SwE ( Hg8 oAg ) Lwk ) ) $.
Kg8 $a #Pattern ( Kw8 oAg ) $.
yxA $a #Pattern ( zBA oAg qwg ) $.
WxI $a #Pattern ( XBI oAg qwg ) $.
6xI $a #Pattern ( 7BI oAg qwg ) $.
bxQ $a #Pattern ( cBQ oAg qwg ) $.
5hw $a #Pattern 5xw $.
8Rw $a #Pattern 8hw $.
Eh0 $a #Pattern Ex0 $.
vB4 $a #Pattern vR4 $.
wx4 $a #Pattern xB4 $.
yh4 $a #Pattern yx4 $.
0R4 $a #Pattern 0h4 $.
2B4 $a #Pattern 2R4 $.
3x4 $a #Pattern 4B4 $.
7R4 $a #Pattern 7h4 $.
9B4 $a #Pattern 9R4 $.
.R4 $a zw ( Tw IQE ( SwE ( twM Ngk ) Ngk ) ) $.
Kx8 $a zw ( Tw IQE ( SwE ( 8Q4 ( IAQ rgk 8hw ) ) RAk ) ) $.
dyA $a zw ( Tw IQE ( SwE ( rwg ( LAQ 8wk pgg ( XBI ( IAQ ewk 7h4 ) ( zBA ( LAQ ewk Wgk ( IAQ ewk 7h4 ) ) ( LAQ ewk Wgk ( IAQ ewk 2R4 ) ) ) ) ) ( rwg ( LAQ 8wk pgg ( XBI ( IAQ ewk xB4 ) ( LAQ rgk Wgk ( IAQ rgk Ex0 ) ) ) ) xQg ) ) mwg ) ) $.
lCA $a #Pattern lSA $.
qSA $a zw ( Tw IQE ( SwE ( Kw8 ( 7BI ( cBQ ( LAQ ewk pgg ( IAQ ewk xB4 ) ) ( LAQ rgk pgg ( IAQ rgk 8hw ) ) ) ( 7BI ( cBQ ( LAQ ewk pgg ( IAQ ewk vR4 ) ) ( LAQ rgk pgg ( IAQ rgk lSA ) ) ) ( 7BI ( cBQ ( LAQ ewk pgg ( IAQ ewk 9R4 ) ) ( LAQ rgk pgg ( IAQ rgk yx4 ) ) ) ( 7BI ( cBQ ( LAQ ewk pgg ( IAQ ewk 7h4 ) ) ( LAQ rgk pgg ( IAQ rgk 4B4 ) ) ) ( cBQ ( LAQ ewk pgg ( IAQ ewk 2R4 ) ) ( LAQ rgk pgg ( IAQ rgk 0h4 ) ) ) ) ) ) ) ) PQk ) ) $.
${ -TM $p zw ( Tw IQE ( tQM Ngk ( xwM Ngk ( wQM Ngk ( wQM Ngk ( twM Ngk ) ( twM Ngk ) ) ( -g4 ( 0Q4 ( Hg8 ( rwg ( LAQ 8wk pgg ( XBI ( IAQ ewk 7h4 ) ( zBA ( LAQ ewk Wgk ( IAQ ewk 7h4 ) ) ( LAQ ewk Wgk ( IAQ ewk 2R4 ) ) ) ) ) ( rwg ( LAQ 8wk pgg ( XBI ( IAQ ewk xB4 ) ( LAQ rgk Wgk ( IAQ rgk Ex0 ) ) ) ) xQg ) ) ) ( Kw8 ( 7BI ( cBQ ( LAQ ewk pgg ( IAQ ewk xB4 ) ) ( LAQ rgk pgg ( IAQ rgk 8hw ) ) ) ( 7BI ( cBQ ( LAQ ewk pgg ( IAQ ewk vR4 ) ) ( LAQ rgk pgg ( IAQ rgk lSA ) ) ) ( 7BI ( cBQ ( LAQ ewk pgg ( IAQ ewk 9R4 ) ) ( LAQ rgk pgg ( IAQ rgk yx4 ) ) ) ( 7BI ( cBQ ( LAQ ewk pgg ( IAQ ewk 7h4 ) ) ( LAQ rgk pgg ( IAQ rgk 4B4 ) ) ) ( cBQ ( LAQ ewk pgg ( IAQ ewk 2R4 ) ) ( LAQ rgk pgg ( IAQ rgk 0h4 ) ) ) ) ) ) ) ) ) ( 8Q4 ( IAQ rgk 8hw ) ) ) ) ( wQM Ngk ( 0wM .gk Ngk ( IAQ .gk 5xw ) ( IAQ .gk 5xw ) ) ( -g4 ( 0Q4 ( Hg8 ( rwg ( LAQ 8wk pgg ( XBI ( IAQ ewk 7h4 ) ( zBA ( LAQ ewk Wgk ( IAQ ewk 7h4 ) ) ( LAQ ewk Wgk ( IAQ ewk 2R4 ) ) ) ) ) ( rwg ( LAQ 8wk pgg ( XBI ( IAQ ewk xB4 ) ( LAQ rgk Wgk ( IAQ rgk Ex0 ) ) ) ) xQg ) ) ) ( Kw8 ( 7BI ( cBQ ( LAQ ewk pgg ( IAQ ewk xB4 ) ) ( LAQ rgk pgg ( IAQ rgk 8hw ) ) ) ( 7BI ( cBQ ( LAQ ewk pgg ( IAQ ewk vR4 ) ) ( LAQ rgk pgg ( IAQ rgk lSA ) ) ) ( 7BI ( cBQ ( LAQ ewk pgg ( IAQ ewk 9R4 ) ) ( LAQ rgk pgg ( IAQ rgk yx4 ) ) ) ( 7BI ( cBQ ( LAQ ewk pgg ( IAQ ewk 7h4 ) ) ( LAQ rgk pgg ( IAQ rgk 4B4 ) ) ) ( cBQ ( LAQ ewk pgg ( IAQ ewk 2R4 ) ) ( LAQ rgk pgg ( IAQ rgk 0h4 ) ) ) ) ) ) ) ) ) ( 8Q4 ( IAQ rgk 8hw ) ) ) ) ) ) ) $=
  ( NQk wAM .Qk HwQ 8gk pQg egk WQk KwQ WxI rQk rgg bxQ 6xI IAE SgE .R4 wgE mAE
  4g uwM 5hw 0gM 7R4 2B4 yxA wx4 Eh0 xAg HQ8 8Rw vB4 lCA 9B4 yh4 3x4 0R4 Kg8 Tg
  0A4 8A4 -Q4 JwU 5Q LAU 6g 6wk Qwk Lgk PAk mgg dyA Jw8 qSA 3Q4 Kx8 Cg8 tAM uwY
  OAM WAU swU BwY ) AAAUAZWDBZCACUBDZWFUCZAWEEFGUDDZGHWHIGHGUEDZIUFJIEFGUGDZKHK
  UHDIJIUILLZUJZGFWJIKFKUKDZIMGFGULDIKFKUMDIMGFGUNDIKFKUODIMGFWHIKFKUPDIMGFWIIK
  FKUQDIMNNNNURZUTZWMVAZVBZBZWQOOWDAPZWSTWEAPZOWSWSQQRAWDWDVCSZWGAPZOXBUSXBOVDC
  AWFWFVEVFOWOVGPZWPVHPZTWQAPZOXCXDOWLVIPZWNVJPZTXCOXFXGOWKVKPXFVLWKVMSVNRWLWNV
  OSVPRWOWPVQSZAWEWGOOAWGVRACWFVSVTWAAWROOWTXETWRAPOWTXEXAXHRAWEWQVCSWBWC $. $}
