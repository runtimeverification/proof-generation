$c 2R4 Tw #Symbol DBE zw pgg #Pattern ( LAQ ewk IAQ Wgk #Variable SwE PQk #SetVariable vR4 4w #ElementVariable IQE ) $.
$v 4wg CQ qwg -Bw Bw oAg 5Qg Cw $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Cg $f #Pattern Cw $.
4g $a #Pattern ( 4w Bw CQ ) $.
SgE $a #Pattern ( SwE Bw CQ ) $.
${ lgE $e zw ( Tw Bw CQ ) $.
   lwE $e zw ( Tw CQ Cw ) $.
   mAE $a zw ( Tw Bw Cw ) $. $}
${ wAE $e zw ( Tw Bw CQ ) $.
   wQE $e zw ( Tw Bw Cw ) $.
   wgE $a zw ( Tw Bw ( 4w CQ Cw ) ) $. $}
HwQ $a #Pattern ( IAQ Bw CQ ) $.
KwQ $a #Pattern ( LAQ Bw CQ Cw ) $.
nwg $f #Pattern oAg $.
qgg $f #Pattern qwg $.
4gg $f #ElementVariable 4wg $.
5Ag $f #ElementVariable 5Qg $.
PAk $a #Pattern PQk $.
WQk $a #Pattern Wgk $.
egk $a #Pattern ewk $.
CxE $a #Pattern ( DBE oAg qwg ) $.
GBE $a zw ( Tw ( 4w ( SwE oAg Wgk ) ( SwE qwg Wgk ) ) ( SwE ( DBE oAg qwg ) Wgk ) ) $.
.xw $f #ElementVariable -Bw $.
vB4 $a #Pattern vR4 $.
2B4 $a #Pattern 2R4 $.
XyU $a #Pattern 4wg $.
pC0 $a #Pattern ( 4w ( SwE 5Qg Wgk ) ( 4w ( SwE -Bw pgg ) IQE ) ) $.
0i0 $a zw ( Tw ( 4w ( SwE 4wg PQk ) ( 4w ( SwE 5Qg Wgk ) ( 4w ( SwE -Bw pgg ) IQE ) ) ) ( SwE ( LAQ ewk Wgk ( IAQ ewk vR4 ) ) Wgk ) ) $.
0y0 $a zw ( Tw ( 4w ( SwE 4wg PQk ) ( 4w ( SwE 5Qg Wgk ) ( 4w ( SwE -Bw pgg ) IQE ) ) ) ( SwE ( LAQ ewk Wgk ( IAQ ewk 2R4 ) ) Wgk ) ) $.
${ 1C0 $p zw ( Tw ( 4w ( SwE 4wg PQk ) ( 4w ( SwE 5Qg Wgk ) ( 4w ( SwE -Bw pgg ) IQE ) ) ) ( SwE ( DBE ( LAQ ewk Wgk ( IAQ ewk vR4 ) ) ( LAQ ewk Wgk ( IAQ ewk 2R4 ) ) ) Wgk ) ) $=
  ( XyU PAk SgE pC0 4g egk WQk vB4 HwQ KwQ 2B4 CxE 0i0 0y0 wgE GBE mAE ) ADEFBC
  GHZIJIKLMZJFZIJINLMZJFZHUBUDOJFUAUCUEABCPABCQRUBUDST $. $}
