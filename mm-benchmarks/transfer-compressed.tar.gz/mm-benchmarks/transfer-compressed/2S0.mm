$c XBI Tw #Symbol zw pgg rgk #Pattern ( Ex0 LAQ ewk xB4 IAQ Wgk #Variable SwE PQk #SetVariable 4w #ElementVariable IQE 8wk ) $.
$v 4wg CQ qwg -Bw Bw oAg 5Qg Cw $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Cg $f #Pattern Cw $.
Tg $a #Pattern ( Tw Bw CQ ) $.
4g $a #Pattern ( 4w Bw CQ ) $.
5Q $a zw ( Tw Bw ( Tw CQ Bw ) ) $.
${ 6A $e zw ( Tw Bw CQ ) $.
   6Q $e zw Bw $.
   6g $a zw CQ $. $}
SgE $a #Pattern ( SwE Bw CQ ) $.
${ lgE $e zw ( Tw Bw CQ ) $.
   lwE $e zw ( Tw CQ Cw ) $.
   mAE $a zw ( Tw Bw Cw ) $. $}
${ wAE $e zw ( Tw Bw CQ ) $.
   wQE $e zw ( Tw Bw Cw ) $.
   wgE $a zw ( Tw Bw ( 4w CQ Cw ) ) $. $}
HwQ $a #Pattern ( IAQ Bw CQ ) $.
IgQ $a zw ( SwE ( IAQ Bw CQ ) Bw ) $.
KwQ $a #Pattern ( LAQ Bw CQ Cw ) $.
nwg $f #Pattern oAg $.
qgg $f #Pattern qwg $.
4gg $f #ElementVariable 4wg $.
5Ag $f #ElementVariable 5Qg $.
PAk $a #Pattern PQk $.
WQk $a #Pattern Wgk $.
egk $a #Pattern ewk $.
rQk $a #Pattern rgk $.
8gk $a #Pattern 8wk $.
WxI $a #Pattern ( XBI oAg qwg ) $.
aBI $a zw ( Tw ( 4w ( SwE oAg ewk ) ( SwE qwg Wgk ) ) ( SwE ( XBI oAg qwg ) 8wk ) ) $.
.xw $f #ElementVariable -Bw $.
Eh0 $a #Pattern Ex0 $.
wx4 $a #Pattern xB4 $.
XyU $a #Pattern 4wg $.
pC0 $a #Pattern ( 4w ( SwE 5Qg Wgk ) ( 4w ( SwE -Bw pgg ) IQE ) ) $.
2C0 $a zw ( Tw ( 4w ( SwE 4wg PQk ) ( 4w ( SwE 5Qg Wgk ) ( 4w ( SwE -Bw pgg ) IQE ) ) ) ( SwE ( LAQ rgk Wgk ( IAQ rgk Ex0 ) ) Wgk ) ) $.
${ 2S0 $p zw ( Tw ( 4w ( SwE 4wg PQk ) ( 4w ( SwE 5Qg Wgk ) ( 4w ( SwE -Bw pgg ) IQE ) ) ) ( SwE ( XBI ( IAQ ewk xB4 ) ( LAQ rgk Wgk ( IAQ rgk Ex0 ) ) ) 8wk ) ) $=
  ( XyU PAk SgE pC0 4g egk wx4 HwQ rQk WQk Eh0 KwQ WxI 8gk Tg 5Q IgQ 6g 2C0 wgE
  aBI mAE ) ADEFBCGHZIJKZIFZLMLNKOZMFZHUGUIPQFUFUHUJUHUFUHRUHUFSIJTUAABCUBUCUGU
  IUDUE $. $}
