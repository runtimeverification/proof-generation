$c IAQ 0h4 Tw #Symbol #Variable SwE pgg #SetVariable zw 4w JAQ #ElementVariable IQE rgk #Pattern ) ( $.
$v Cw 2gg CQ Bw $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Cg $f #Pattern Cw $.
4g $a #Pattern ( 4w Bw CQ ) $.
IAE $a #Pattern IQE $.
SgE $a #Pattern ( SwE Bw CQ ) $.
${ wAE $e zw ( Tw Bw CQ ) $.
   wQE $e zw ( Tw Bw Cw ) $.
   wgE $a zw ( Tw Bw ( 4w CQ Cw ) ) $. $}
HwQ $a #Pattern ( IAQ Bw CQ ) $.
IwQ $a #Pattern ( JAQ Bw ) $.
pQg $a #Pattern pgg $.
2Qg $f #ElementVariable 2gg $.
rQk $a #Pattern rgk $.
0R4 $a #Pattern 0h4 $.
Wh8 $a #Pattern 2gg $.
XiA $a zw ( Tw ( 4w ( JAQ 2gg ) IQE ) ( SwE ( IAQ rgk 0h4 ) rgk ) ) $.
WSY $a zw ( Tw ( 4w ( JAQ 2gg ) IQE ) ( 4w ( JAQ rgk ) ( JAQ pgg ) ) ) $.
${ 1Sk $p zw ( Tw ( 4w ( JAQ 2gg ) IQE ) ( 4w ( 4w ( JAQ rgk ) ( JAQ pgg ) ) ( SwE ( IAQ rgk 0h4 ) rgk ) ) ) $=
  ( Wh8 IwQ IAE 4g rQk pQg 0R4 HwQ SgE WSY XiA wgE ) ABCDEFCGCEFHIFJAKALM $. $}
