$c Tw #Symbol 5x4 zw JAQ rgk pgg #Pattern ( rwg LAQ IAQ #Variable SwE #SetVariable 4w #ElementVariable IQE mwg xQg ) $.
$v CQ qwg Bw oAg Cw 2gg $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Cg $f #Pattern Cw $.
4g $a #Pattern ( 4w Bw CQ ) $.
IAE $a #Pattern IQE $.
SgE $a #Pattern ( SwE Bw CQ ) $.
nAE $a zw IQE $.
${ wAE $e zw ( Tw Bw CQ ) $.
   wQE $e zw ( Tw Bw Cw ) $.
   wgE $a zw ( Tw Bw ( 4w CQ Cw ) ) $. $}
${ NwM $e zw CQ $.
   OAM $a zw ( Tw Bw CQ ) $. $}
HwQ $a #Pattern ( IAQ Bw CQ ) $.
IwQ $a #Pattern ( JAQ Bw ) $.
KwQ $a #Pattern ( LAQ Bw CQ Cw ) $.
mgg $a #Pattern mwg $.
nwg $f #Pattern oAg $.
pQg $a #Pattern pgg $.
qgg $f #Pattern qwg $.
rgg $a #Pattern ( rwg oAg qwg ) $.
xAg $a #Pattern xQg $.
2Qg $f #ElementVariable 2gg $.
rQk $a #Pattern rgk $.
5h4 $a #Pattern 5x4 $.
Wh8 $a #Pattern 2gg $.
0jI $a zw ( Tw ( 4w ( JAQ 2gg ) IQE ) ( SwE ( rwg ( LAQ rgk pgg ( IAQ rgk 5x4 ) ) xQg ) mwg ) ) $.
${ 0zI $p zw ( Tw ( 4w ( JAQ 2gg ) IQE ) ( 4w ( SwE ( rwg ( LAQ rgk pgg ( IAQ rgk 5x4 ) ) xQg ) mwg ) IQE ) ) $=
  ( Wh8 IwQ IAE 4g rQk pQg 5h4 HwQ KwQ xAg rgg mgg SgE 0jI nAE OAM wgE ) ABCDEZ
  FGFHIJKLMNDAOSDPQR $. $}
