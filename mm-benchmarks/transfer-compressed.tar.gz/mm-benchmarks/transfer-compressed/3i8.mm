$c Tw #Symbol zw pwk JAQ rgk pgg #Pattern ( IAQ Wgk #Variable SwE PQk #SetVariable hgk 4w #ElementVariable IQE mwg 8hw ) $.
$v 4wg CQ 3gg -Bw Bw 5Qg MB0 Cw $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Cg $f #Pattern Cw $.
Tg $a #Pattern ( Tw Bw CQ ) $.
4g $a #Pattern ( 4w Bw CQ ) $.
5Q $a zw ( Tw Bw ( Tw CQ Bw ) ) $.
${ 6A $e zw ( Tw Bw CQ ) $.
   6Q $e zw Bw $.
   6g $a zw CQ $. $}
SgE $a #Pattern ( SwE Bw CQ ) $.
${ wAE $e zw ( Tw Bw CQ ) $.
   wQE $e zw ( Tw Bw Cw ) $.
   wgE $a zw ( Tw Bw ( 4w CQ Cw ) ) $. $}
HwQ $a #Pattern ( IAQ Bw CQ ) $.
IgQ $a zw ( SwE ( IAQ Bw CQ ) Bw ) $.
IwQ $a #Pattern ( JAQ Bw ) $.
mgg $a #Pattern mwg $.
3Qg $f #ElementVariable 3gg $.
4gg $f #ElementVariable 4wg $.
5Ag $f #ElementVariable 5Qg $.
PAk $a #Pattern PQk $.
WQk $a #Pattern Wgk $.
pgk $a #Pattern pwk $.
rQk $a #Pattern rgk $.
8Rw $a #Pattern 8hw $.
.xw $f #ElementVariable -Bw $.
Lx0 $f #ElementVariable MB0 $.
XiU $a #Pattern 3gg $.
XyU $a #Pattern 4wg $.
YCU $a #Pattern 5Qg $.
rC8 $a #Pattern ( 4w ( SwE -Bw pgg ) ( 4w ( SwE MB0 hgk ) IQE ) ) $.
3S8 $a zw ( Tw ( 4w ( SwE 3gg mwg ) ( 4w ( SwE 4wg PQk ) ( 4w ( SwE 5Qg pwk ) ( 4w ( SwE -Bw pgg ) ( 4w ( SwE MB0 hgk ) IQE ) ) ) ) ) ( 4w ( JAQ rgk ) ( JAQ Wgk ) ) ) $.
${ 3i8 $p zw ( Tw ( 4w ( SwE 3gg mwg ) ( 4w ( SwE 4wg PQk ) ( 4w ( SwE 5Qg pwk ) ( 4w ( SwE -Bw pgg ) ( 4w ( SwE MB0 hgk ) IQE ) ) ) ) ) ( 4w ( 4w ( JAQ rgk ) ( JAQ Wgk ) ) ( SwE ( IAQ rgk 8hw ) rgk ) ) ) $=
  ( XiU mgg SgE XyU PAk YCU pgk rC8 4g rQk IwQ WQk 8Rw HwQ 3S8 Tg 5Q IgQ 6g wgE
  ) AFGHBIJHCKLHDEMNNNZOPQPNORSOHZABCDETUGUFUGUAUGUFUBORUCUDUE $. $}
