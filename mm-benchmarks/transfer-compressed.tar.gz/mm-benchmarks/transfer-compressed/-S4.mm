$c IAQ Wgk Tw #Symbol #Variable SwE pgg #SetVariable 5x4 zw 4w JAQ #ElementVariable IQE rgk #Pattern ) ( $.
$v Cw CQ -Bw Bw $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Cg $f #Pattern Cw $.
4g $a #Pattern ( 4w Bw CQ ) $.
IAE $a #Pattern IQE $.
SgE $a #Pattern ( SwE Bw CQ ) $.
${ wAE $e zw ( Tw Bw CQ ) $.
   wQE $e zw ( Tw Bw Cw ) $.
   wgE $a zw ( Tw Bw ( 4w CQ Cw ) ) $. $}
HwQ $a #Pattern ( IAQ Bw CQ ) $.
IwQ $a #Pattern ( JAQ Bw ) $.
pQg $a #Pattern pgg $.
WQk $a #Pattern Wgk $.
rQk $a #Pattern rgk $.
.xw $f #ElementVariable -Bw $.
5h4 $a #Pattern 5x4 $.
yyg $a #Pattern -Bw $.
9S0 $a zw ( Tw ( 4w ( SwE -Bw pgg ) IQE ) ( 4w ( JAQ rgk ) ( JAQ Wgk ) ) ) $.
-C4 $a zw ( Tw ( 4w ( SwE -Bw pgg ) IQE ) ( SwE ( IAQ rgk 5x4 ) rgk ) ) $.
${ -S4 $p zw ( Tw ( 4w ( SwE -Bw pgg ) IQE ) ( 4w ( 4w ( JAQ rgk ) ( JAQ Wgk ) ) ( SwE ( IAQ rgk 5x4 ) rgk ) ) ) $=
  ( yyg pQg SgE IAE 4g rQk IwQ WQk 5h4 HwQ 9S0 -C4 wgE ) ABCDEFGHIHFGJKGDALAMN
  $. $}
