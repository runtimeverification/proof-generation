$c Uw PgE Tw #Symbol 7h4 -gg zw JAQ vA4 #Pattern ( 0wM ewk xB4 tQM IAQ 3BA #Variable SwE #SetVariable iA vR4 4w rwM #ElementVariable IQE ) $.
$v th1 yhs Fw CQ Bw Cw 2gg sgg ngg FQ z ph2 Ew ph0 x Lw LQ Ow ph6 qwg DQ XRw ph1 EQ y th2 Dw tAg HQ xX Gw th0 Hw Kw oAg GQ nR4 tgg $.
$d z y $.
$d z x $.
$d y x $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Cg $f #Pattern Cw $.
DA $f #Pattern DQ $.
Dg $f #Pattern Dw $.
EA $f #Pattern EQ $.
Eg $f #Pattern Ew $.
FA $f #Pattern FQ $.
Fg $f #Pattern Fw $.
GA $f #Pattern GQ $.
Gg $f #Pattern Gw $.
HA $f #Pattern HQ $.
Hg $f #Pattern Hw $.
Kg $f #ElementVariable Kw $.
LA $f #ElementVariable LQ $.
Lg $f #ElementVariable Lw $.
Og $f #Variable Ow $.
SA $a #Variable Kw $.
jg $a iA Bw Ow Bw Ow $.
${ kg $e iA CQ DQ Bw Ow $.
   kw $e iA Cw Dw Bw Ow $.
   lA $a iA ( Tw CQ Cw ) ( Tw DQ Dw ) Bw Ow $. $}
4g $a #Pattern ( 4w Bw CQ ) $.
IAE $a #Pattern IQE $.
SgE $a #Pattern ( SwE Bw CQ ) $.
${ lgE $e zw ( Tw Bw CQ ) $.
   lwE $e zw ( Tw CQ Cw ) $.
   mAE $a zw ( Tw Bw Cw ) $. $}
${ wAE $e zw ( Tw Bw CQ ) $.
   wQE $e zw ( Tw Bw Cw ) $.
   wgE $a zw ( Tw Bw ( 4w CQ Cw ) ) $. $}
${ $d xX ph0 $.
   IQI $a iA Bw Bw CQ Ow $. $}
${ KAI $e iA CQ DQ Bw Ow $.
   KQI $e iA Cw Dw Bw Ow $.
   KgI $a iA ( 4w CQ Cw ) ( 4w DQ Dw ) Bw Ow $. $}
${ OgI $e iA CQ DQ Bw Ow $.
   OwI $e iA Cw Dw Bw Ow $.
   PAI $a iA ( SwE CQ Cw ) ( SwE DQ Dw ) Bw Ow $. $}
rgM $a #Pattern ( rwM Bw CQ Kw Cw ) $.
tAM $a #Pattern ( tQM Bw CQ ) $.
0gM $a #Pattern ( 0wM Bw CQ Cw DQ ) $.
HwQ $a #Pattern ( IAQ Bw CQ ) $.
IwQ $a #Pattern ( JAQ Bw ) $.
${ $d xX y $.
   $d y ph6 $.
   OAQ $e iA Bw DQ Ew Ow $.
   OQQ $e iA CQ Dw Ew Ow $.
   OgQ $e iA Cw EQ Ew Ow $.
   OwQ $a iA ( rwM Bw CQ LQ Cw ) ( rwM DQ Dw LQ EQ ) Ew Ow $. $}
${ QAQ $e iA Bw Cw Dw Ow $.
   QQQ $e iA CQ DQ Dw Ow $.
   QgQ $a iA ( tQM Bw CQ ) ( tQM Cw DQ ) Dw Ow $. $}
${ XgQ $e iA Bw Dw Fw Ow $.
   XwQ $e iA CQ EQ Fw Ow $.
   YAQ $e iA Cw Ew Fw Ow $.
   YQQ $e iA DQ FQ Fw Ow $.
   YgQ $a iA ( 0wM Bw CQ Cw DQ ) ( 0wM Dw EQ Ew FQ ) Fw Ow $. $}
${ $d z ph0 $.
   $d z ph1 $.
   $d z ph2 $.
   $d z y $.
   $d z x $.
   $d z th1 $.
   $d z th2 $.
   $d x ph0 $.
   $d y th0 $.
   lAY $e zw ( Tw GQ ( Uw Kw ( PgE Kw Bw ) ) ) $.
   lQY $e zw ( Tw ( 4w GQ Gw ) CQ ) $.
   lgY $e iA ( Tw HQ Cw ) ( Tw Gw CQ ) Bw LQ $.
   lwY $e iA ( Tw Hw DQ ) ( Tw Gw CQ ) Lw LQ $.
   mAY $a zw ( Tw ( 4w GQ HQ ) Cw ) $. $}
nQg $f #Variable ngg $.
nwg $f #Pattern oAg $.
qgg $f #Pattern qwg $.
sQg $f #Pattern sgg $.
swg $f #Pattern tAg $.
tQg $f #Pattern tgg $.
2Qg $f #ElementVariable 2gg $.
-Qg $a #Pattern -gg $.
egk $a #Pattern ewk $.
uw4 $a #Pattern vA4 $.
2xA $a #Pattern ( 3BA oAg qwg ) $.
${ 4BA $e iA qwg tAg oAg ngg $.
   4RA $e iA sgg tgg oAg ngg $.
   4hA $a iA ( 3BA qwg sgg ) ( 3BA tAg tgg ) oAg ngg $. $}
yRs $f #ElementVariable yhs $.
XBw $f #ElementVariable XRw $.
nB4 $f #ElementVariable nR4 $.
vB4 $a #Pattern vR4 $.
wx4 $a #Pattern xB4 $.
7R4 $a #Pattern 7h4 $.
Wh8 $a #Pattern 2gg $.
6h8 $a #Pattern nR4 $.
9h8 $a zw ( Tw ( 4w ( JAQ 2gg ) IQE ) ( 4w ( JAQ 2gg ) IQE ) ) $.
7SA $a #Pattern yhs $.
QCE $a #Pattern XRw $.
iCE $a #Pattern ( 0wM -gg 2gg yhs ( 3BA ( IAQ ewk vR4 ) XRw ) ) $.
uiE $a iA -gg -gg nR4 XRw $.
vSE $a iA ( 4w ( SwE nR4 -gg ) IQE ) ( 4w ( SwE XRw -gg ) IQE ) nR4 XRw $.
viE $a iA 2gg 2gg nR4 XRw $.
1iE $a zw ( Tw ( 4w ( JAQ 2gg ) IQE ) ( Uw yhs ( PgE yhs ( 3BA ( IAQ ewk 7h4 ) ( 3BA ( IAQ ewk xB4 ) vA4 ) ) ) ) ) $.
1yE $a zw ( Tw ( 4w ( 4w ( JAQ 2gg ) IQE ) ( 4w ( SwE XRw -gg ) IQE ) ) ( tQM 2gg ( rwM -gg 2gg yhs ( 0wM -gg 2gg yhs ( 3BA ( IAQ ewk vR4 ) XRw ) ) ) ) ) $.
2CE $a #Pattern ( 0wM -gg 2gg yhs ( 3BA ( IAQ ewk vR4 ) nR4 ) ) $.
2SE $a iA ( 0wM -gg 2gg yhs ( 3BA ( IAQ ewk vR4 ) nR4 ) ) ( 0wM -gg 2gg yhs ( 3BA ( IAQ ewk vR4 ) XRw ) ) nR4 XRw $.
3CE $a zw ( Tw ( 4w ( JAQ 2gg ) IQE ) ( 4w ( SwE ( 3BA ( IAQ ewk 7h4 ) ( 3BA ( IAQ ewk xB4 ) vA4 ) ) -gg ) IQE ) ) $.
${ 3SE $p zw ( Tw ( 4w ( JAQ 2gg ) IQE ) ( tQM 2gg ( rwM -gg 2gg yhs ( 0wM -gg 2gg yhs ( 3BA ( IAQ ewk vR4 ) ( 3BA ( IAQ ewk 7h4 ) ( 3BA ( IAQ ewk xB4 ) vA4 ) ) ) ) ) ) ) $=
  ( XBw nB4 Wh8 IwQ IAE 4g egk 7R4 HwQ 2xA -Qg SgE rgM tAM IQI OwQ QgQ lA SA jg
  wx4 uw4 7SA vB4 0gM 9h8 3CE wgE iCE 2CE QCE 6h8 1iE 1yE PAI KgI 4hA YgQ vSE
  viE uiE 2SE mAY mAE ) AEZFGHZVHIJKIUCKUDLLZMNZGHZHVGMVGMVGBUEZIUFKZVILZUGZBOZ
  PZVHVHVKAUHAUIUJVIVGMVGABCUKZBOZPZVQVGMVGABDULZBOZPZVHCUMZMNZGHZVKDUNZMNGHZBC
  DABUOABCUPVIVKVQWFVTCUAZVIVJGWEGWIVIVIMWDMWIVIWIUBZMVIWIQZUQGVIWIQURVGVPVGVSV
  IWIVGVIWIQZMVGVOMVGVRVIBWIWKWLMVGVLVNMVGVLVMWDLVIWIWKWLVLVIWIQWIVIVMVIVMWDVMV
  IWIQWJUSUTRSTWGWHWCWFVTWICDVAVGWBVGVSWGWIACDVBZMVGWAMVGVRWGBWICDVCWMABCDVDRST
  VEVF $. $}
