$c #Symbol cwE #Variable #SetVariable iA 4w JAQ #ElementVariable IQE #Pattern ) ( $.
$v Ow CQ DQ Bw Kw Cw 2gg Dw Pw $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Cg $f #Pattern Cw $.
DA $f #Pattern DQ $.
Dg $f #Pattern Dw $.
Kg $f #ElementVariable Kw $.
Og $f #Variable Ow $.
Pg $f #Symbol Pw $.
SA $a #Variable Kw $.
Sw $a #Pattern Pw $.
IAE $a #Pattern IQE $.
cgE $a #Symbol cwE $.
${ KAI $e iA CQ DQ Bw Ow $.
   KQI $e iA Cw Dw Bw Ow $.
   KgI $a iA ( 4w CQ Cw ) ( 4w DQ Dw ) Bw Ow $. $}
IwQ $a #Pattern ( JAQ Bw ) $.
2Qg $f #ElementVariable 2gg $.
Wh8 $a #Pattern 2gg $.
.x8 $a iA ( JAQ cwE ) ( JAQ 2gg ) cwE 2gg $.
-B8 $a iA IQE IQE cwE 2gg $.
${ -R8 $p iA ( 4w ( JAQ cwE ) IQE ) ( 4w ( JAQ 2gg ) IQE ) cwE 2gg $=
  ( cgE Sw IwQ IAE Wh8 SA .x8 -B8 KgI ) BCZKDEAFDEAGAHAIJ $. $}
