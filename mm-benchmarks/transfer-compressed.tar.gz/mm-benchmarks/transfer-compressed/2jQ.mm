$c 4B4 Tw #Symbol wQM zw JAQ pgg rgk #Pattern ( rwg twM LAQ tQM IAQ 1gM #Variable SwE #SetVariable 4w #ElementVariable IQE mwg xQg ) $.
$v CQ qwg DQ Bw oAg Cw 2gg GQ $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Cg $f #Pattern Cw $.
DA $f #Pattern DQ $.
GA $f #Pattern GQ $.
Tg $a #Pattern ( Tw Bw CQ ) $.
4g $a #Pattern ( 4w Bw CQ ) $.
5Q $a zw ( Tw Bw ( Tw CQ Bw ) ) $.
${ 6A $e zw ( Tw Bw CQ ) $.
   6Q $e zw Bw $.
   6g $a zw CQ $. $}
IAE $a #Pattern IQE $.
SgE $a #Pattern ( SwE Bw CQ ) $.
lQE $a zw ( Tw Bw Bw ) $.
${ lgE $e zw ( Tw Bw CQ ) $.
   lwE $e zw ( Tw CQ Cw ) $.
   mAE $a zw ( Tw Bw Cw ) $. $}
nAE $a zw IQE $.
ugE $a zw ( Tw ( 4w Bw CQ ) Bw ) $.
${ wAE $e zw ( Tw Bw CQ ) $.
   wQE $e zw ( Tw Bw Cw ) $.
   wgE $a zw ( Tw Bw ( 4w CQ Cw ) ) $. $}
${ NwM $e zw CQ $.
   OAM $a zw ( Tw Bw CQ ) $. $}
tAM $a #Pattern ( tQM Bw CQ ) $.
uwM $a #Pattern ( twM Bw ) $.
wAM $a #Pattern ( wQM Bw CQ Cw ) $.
1QM $a #Pattern ( 1gM Bw CQ Cw DQ ) $.
HwQ $a #Pattern ( IAQ Bw CQ ) $.
IwQ $a #Pattern ( JAQ Bw ) $.
KwQ $a #Pattern ( LAQ Bw CQ Cw ) $.
IAU $a zw ( SwE ( twM Bw ) Bw ) $.
PwU $a zw ( SwE ( 1gM Bw CQ Cw DQ ) CQ ) $.
SwU $a zw ( tQM Bw ( twM Bw ) ) $.
${ hwU $e zw ( Tw GQ ( SwE CQ Bw ) ) $.
   iAU $e zw ( Tw GQ ( SwE Cw Bw ) ) $.
   iQU $e zw ( Tw GQ ( tQM Bw CQ ) ) $.
   igU $e zw ( Tw GQ ( tQM Bw Cw ) ) $.
   iwU $a zw ( Tw GQ ( tQM Bw ( wQM Bw CQ Cw ) ) ) $. $}
mgg $a #Pattern mwg $.
nwg $f #Pattern oAg $.
pQg $a #Pattern pgg $.
qgg $f #Pattern qwg $.
rgg $a #Pattern ( rwg oAg qwg ) $.
xAg $a #Pattern xQg $.
2Qg $f #ElementVariable 2gg $.
rQk $a #Pattern rgk $.
3x4 $a #Pattern 4B4 $.
Wh8 $a #Pattern 2gg $.
9h8 $a zw ( Tw ( 4w ( JAQ 2gg ) IQE ) ( 4w ( JAQ 2gg ) IQE ) ) $.
2TQ $a zw ( Tw ( 4w ( JAQ 2gg ) IQE ) ( tQM 2gg ( 1gM mwg 2gg ( rwg ( LAQ rgk pgg ( IAQ rgk 4B4 ) ) xQg ) ( rwg ( LAQ rgk pgg ( IAQ rgk 4B4 ) ) xQg ) ) ) ) $.
${ 2jQ $p zw ( Tw ( 4w ( JAQ 2gg ) IQE ) ( tQM 2gg ( wQM 2gg ( 1gM mwg 2gg ( rwg ( LAQ rgk pgg ( IAQ rgk 4B4 ) ) xQg ) ( rwg ( LAQ rgk pgg ( IAQ rgk 4B4 ) ) xQg ) ) ( twM 2gg ) ) ) ) $=
  ( Wh8 IwQ IAE 4g mgg rQk pQg 3x4 HwQ tAM nAE OAM wgE SgE Tg 5Q 6g ugE mAE KwQ
  xAg rgg 1QM uwM wAM 9h8 PwU IAU lQE 2TQ SwU iwU ) ABZCZDEZUPUPUPDEZEZEZUNUNFU
  NGHGIJUAUBUCZUTUDZUNUEZUFKUPUPURAUGZUPUPUQVCUPUPDVCUPDLMNNNUNVAVBUSVAUNOZUSVD
  PVDUSQFUNUTUTUHRVBUNOZUSVEPVEUSQUNUIRUSUPUNVAKUSUODUSUPUOUPURSZUPUOUOUODSUOUJ
  TTUSDLMNAUKTUSUPUNVBKZVFUPVGUNULMTUMT $. $}
