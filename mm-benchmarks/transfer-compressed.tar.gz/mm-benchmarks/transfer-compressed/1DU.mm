$c Uw PgE Tw #Symbol 1CA cwE zw JAQ pgg rgk 3gk #Pattern ( rwg 0wM LAQ tQM IAQ #Variable SwE #SetVariable 4w rwM #ElementVariable IQE mwg xQg ) $.
$v CQ qwg Bw Kw ph1 oAg Cw 6Ag 2gg ph0 GQ x 4Ag $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Cg $f #Pattern Cw $.
GA $f #Pattern GQ $.
Kg $f #ElementVariable Kw $.
Ug $a #Pattern ( Uw Kw Bw ) $.
IAE $a #Pattern IQE $.
PQE $a #Pattern ( PgE Bw CQ ) $.
${ lgE $e zw ( Tw Bw CQ ) $.
   lwE $e zw ( Tw CQ Cw ) $.
   mAE $a zw ( Tw Bw Cw ) $. $}
nAE $a zw IQE $.
${ NwM $e zw CQ $.
   OAM $a zw ( Tw Bw CQ ) $. $}
HwQ $a #Pattern ( IAQ Bw CQ ) $.
KwQ $a #Pattern ( LAQ Bw CQ Cw ) $.
${ $d x ph0 $.
   $d x ph1 $.
   vwY $e zw ( Tw GQ ( SwE CQ Bw ) ) $.
   wAY $e zw ( Tw GQ ( tQM cwE ( rwM Bw cwE Kw ( 0wM Bw cwE Kw CQ ) ) ) ) $.
   wQY $a zw ( Tw GQ ( Uw Kw ( PgE Kw CQ ) ) ) $. $}
mgg $a #Pattern mwg $.
nwg $f #Pattern oAg $.
pQg $a #Pattern pgg $.
qgg $f #Pattern qwg $.
rgg $a #Pattern ( rwg oAg qwg ) $.
xAg $a #Pattern xQg $.
2Qg $f #ElementVariable 2gg $.
3wg $f #ElementVariable 4Ag $.
5wg $f #ElementVariable 6Ag $.
rQk $a #Pattern rgk $.
0yA $a #Pattern 1CA $.
BCE $a #Pattern 6Ag $.
DC4 $a #Pattern ( 4w ( JAQ 2gg ) ( 4w ( SwE 4Ag 3gk ) IQE ) ) $.
0jU $a zw ( Tw IQE ( tQM cwE ( rwM mwg cwE 6Ag ( 0wM mwg cwE 6Ag ( rwg ( LAQ rgk pgg ( IAQ rgk 1CA ) ) xQg ) ) ) ) ) $.
0zU $a zw ( Tw IQE ( SwE ( rwg ( LAQ rgk pgg ( IAQ rgk 1CA ) ) xQg ) mwg ) ) $.
${ 1DU $p zw ( Tw ( 4w ( JAQ 2gg ) ( 4w ( SwE 4Ag 3gk ) IQE ) ) ( Uw 6Ag ( PgE 6Ag ( rwg ( LAQ rgk pgg ( IAQ rgk 1CA ) ) xQg ) ) ) ) $=
  ( DC4 IAE BCE rQk pQg 0yA HwQ KwQ xAg rgg PQE Ug nAE OAM mgg 0zU 0jU wQY mAE
  ) ABDZECFGHGIJKLMZNCOUCEPQRUDECSCTUAUB $. $}
