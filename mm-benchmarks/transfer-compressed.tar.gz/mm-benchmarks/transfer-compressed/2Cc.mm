$c 0wM LAQ ewk xB4 cBQ IAQ #Symbol #Variable #SetVariable ) YQk #ElementVariable pgg #Pattern ( $.
$v yhs CQ qwg DQ Bw XRw oAg Cw 2gg $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Cg $f #Pattern Cw $.
DA $f #Pattern DQ $.
0gM $a #Pattern ( 0wM Bw CQ Cw DQ ) $.
HwQ $a #Pattern ( IAQ Bw CQ ) $.
KwQ $a #Pattern ( LAQ Bw CQ Cw ) $.
nwg $f #Pattern oAg $.
pQg $a #Pattern pgg $.
qgg $f #Pattern qwg $.
2Qg $f #ElementVariable 2gg $.
YAk $a #Pattern YQk $.
egk $a #Pattern ewk $.
bxQ $a #Pattern ( cBQ oAg qwg ) $.
yRs $f #ElementVariable yhs $.
XBw $f #ElementVariable XRw $.
wx4 $a #Pattern xB4 $.
Wh8 $a #Pattern 2gg $.
7SA $a #Pattern yhs $.
QCE $a #Pattern XRw $.
${ 2Cc $p #Pattern ( 0wM YQk 2gg yhs ( cBQ ( LAQ ewk pgg ( IAQ ewk xB4 ) ) XRw ) ) $=
  ( YAk Wh8 7SA egk pQg wx4 HwQ KwQ QCE bxQ 0gM ) DAEBFGHGIJKCLMN $. $}
