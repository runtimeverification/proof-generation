$c Tw #Symbol 5x4 zw JAQ pgg rgk #Pattern ( rwg LAQ IAQ #Variable SwE #SetVariable 4w #ElementVariable IQE mwg xQg ) $.
$v CQ qwg Bw oAg Cw 2gg $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Cg $f #Pattern Cw $.
4g $a #Pattern ( 4w Bw CQ ) $.
IAE $a #Pattern IQE $.
SgE $a #Pattern ( SwE Bw CQ ) $.
${ lgE $e zw ( Tw Bw CQ ) $.
   lwE $e zw ( Tw CQ Cw ) $.
   mAE $a zw ( Tw Bw Cw ) $. $}
HwQ $a #Pattern ( IAQ Bw CQ ) $.
IwQ $a #Pattern ( JAQ Bw ) $.
KwQ $a #Pattern ( LAQ Bw CQ Cw ) $.
mgg $a #Pattern mwg $.
nwg $f #Pattern oAg $.
pQg $a #Pattern pgg $.
qgg $f #Pattern qwg $.
rgg $a #Pattern ( rwg oAg qwg ) $.
wQg $a zw ( Tw ( 4w ( SwE oAg pgg ) ( SwE qwg mwg ) ) ( SwE ( rwg oAg qwg ) mwg ) ) $.
xAg $a #Pattern xQg $.
2Qg $f #ElementVariable 2gg $.
rQk $a #Pattern rgk $.
5h4 $a #Pattern 5x4 $.
Wh8 $a #Pattern 2gg $.
0TI $a zw ( Tw ( 4w ( JAQ 2gg ) IQE ) ( 4w ( SwE ( LAQ rgk pgg ( IAQ rgk 5x4 ) ) pgg ) ( SwE xQg mwg ) ) ) $.
${ 0jI $p zw ( Tw ( 4w ( JAQ 2gg ) IQE ) ( SwE ( rwg ( LAQ rgk pgg ( IAQ rgk 5x4 ) ) xQg ) mwg ) ) $=
  ( Wh8 IwQ IAE 4g rQk pQg 5h4 HwQ KwQ SgE xAg mgg rgg 0TI wQg mAE ) ABCDEFGFHI
  JZGKLMKERLNMKAORLPQ $. $}
