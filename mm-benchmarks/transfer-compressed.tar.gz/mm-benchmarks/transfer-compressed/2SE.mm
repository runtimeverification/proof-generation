$c 0wM ewk IAQ 3BA #Symbol #Variable -gg #SetVariable iA vR4 #ElementVariable #Pattern ) ( $.
$v yhs Fw Ow CQ qwg DQ Bw XRw Cw 2gg EQ sgg tAg Dw ngg FQ xX Ew Kw ph0 oAg nR4 tgg $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Cg $f #Pattern Cw $.
DA $f #Pattern DQ $.
Dg $f #Pattern Dw $.
EA $f #Pattern EQ $.
Eg $f #Pattern Ew $.
FA $f #Pattern FQ $.
Fg $f #Pattern Fw $.
Kg $f #ElementVariable Kw $.
Og $f #Variable Ow $.
SA $a #Variable Kw $.
jg $a iA Bw Ow Bw Ow $.
${ $d xX ph0 $.
   IQI $a iA Bw Bw CQ Ow $. $}
HwQ $a #Pattern ( IAQ Bw CQ ) $.
${ XgQ $e iA Bw Dw Fw Ow $.
   XwQ $e iA CQ EQ Fw Ow $.
   YAQ $e iA Cw Ew Fw Ow $.
   YQQ $e iA DQ FQ Fw Ow $.
   YgQ $a iA ( 0wM Bw CQ Cw DQ ) ( 0wM Dw EQ Ew FQ ) Fw Ow $. $}
nQg $f #Variable ngg $.
nwg $f #Pattern oAg $.
qgg $f #Pattern qwg $.
sQg $f #Pattern sgg $.
swg $f #Pattern tAg $.
tQg $f #Pattern tgg $.
2Qg $f #ElementVariable 2gg $.
-Qg $a #Pattern -gg $.
egk $a #Pattern ewk $.
2xA $a #Pattern ( 3BA oAg qwg ) $.
${ 4BA $e iA qwg tAg oAg ngg $.
   4RA $e iA sgg tgg oAg ngg $.
   4hA $a iA ( 3BA qwg sgg ) ( 3BA tAg tgg ) oAg ngg $. $}
yRs $f #ElementVariable yhs $.
XBw $f #ElementVariable XRw $.
nB4 $f #ElementVariable nR4 $.
vB4 $a #Pattern vR4 $.
Wh8 $a #Pattern 2gg $.
6h8 $a #Pattern nR4 $.
7SA $a #Pattern yhs $.
QCE $a #Pattern XRw $.
uiE $a iA -gg -gg nR4 XRw $.
viE $a iA 2gg 2gg nR4 XRw $.
vyE $a iA yhs yhs nR4 XRw $.
${ 2SE $p iA ( 0wM -gg 2gg yhs ( 3BA ( IAQ ewk vR4 ) nR4 ) ) ( 0wM -gg 2gg yhs ( 3BA ( IAQ ewk vR4 ) XRw ) ) nR4 XRw $=
  ( -Qg Wh8 7SA egk vB4 HwQ 6h8 2xA QCE SA uiE viE vyE IQI jg 4hA YgQ ) EAFZBGZ
  HIJZDKZLEUBUCUDCMZLUECNZCDOACDPBCDQUGUEUDUEUDUFUDUEUGRUEUGSTUA $. $}
