$c #SetVariable iA ) #ElementVariable #Symbol #Variable #Pattern ( $.
$v Ow CQ xX Bw Kw ph0 2gg nR4 pxw $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Kg $f #ElementVariable Kw $.
Og $f #Variable Ow $.
SA $a #Variable Kw $.
${ $d xX ph0 $.
   IQI $a iA Bw Bw CQ Ow $. $}
2Qg $f #ElementVariable 2gg $.
phw $f #ElementVariable pxw $.
nB4 $f #ElementVariable nR4 $.
Wh8 $a #Pattern 2gg $.
6h8 $a #Pattern nR4 $.
${ 3CY $p iA 2gg 2gg nR4 pxw $=
  ( Wh8 6h8 SA IQI ) ADCEBFG $. $}
