$c #Symbol cwE #Variable #SetVariable iA 4w JAQ #ElementVariable IQE #Pattern ) ( $.
$v Ow CQ DQ Bw Kw Cw 6xw Dw Pw $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Cg $f #Pattern Cw $.
DA $f #Pattern DQ $.
Dg $f #Pattern Dw $.
Kg $f #ElementVariable Kw $.
Og $f #Variable Ow $.
Pg $f #Symbol Pw $.
SA $a #Variable Kw $.
Sw $a #Pattern Pw $.
IAE $a #Pattern IQE $.
cgE $a #Symbol cwE $.
${ KAI $e iA CQ DQ Bw Ow $.
   KQI $e iA Cw Dw Bw Ow $.
   KgI $a iA ( 4w CQ Cw ) ( 4w DQ Dw ) Bw Ow $. $}
IwQ $a #Pattern ( JAQ Bw ) $.
6hw $f #ElementVariable 6xw $.
dB8 $a #Pattern 6xw $.
1x8 $a iA ( JAQ cwE ) ( JAQ 6xw ) cwE 6xw $.
2B8 $a iA IQE IQE cwE 6xw $.
${ 2R8 $p iA ( 4w ( JAQ cwE ) IQE ) ( 4w ( JAQ 6xw ) IQE ) cwE 6xw $=
  ( cgE Sw IwQ IAE dB8 SA 1x8 2B8 KgI ) BCZKDEAFDEAGAHAIJ $. $}
