$c 2R4 Tw #Symbol wQM zw JAQ .gk Px0 pgg #Pattern ( rwg 0wM twM LAQ ewk tQM IAQ #Variable SwE #SetVariable 4w #ElementVariable IQE xQg ) Vhc $.
$v CQ qwg DQ Bw oAg Cw 2gg GQ $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Cg $f #Pattern Cw $.
DA $f #Pattern DQ $.
GA $f #Pattern GQ $.
Tg $a #Pattern ( Tw Bw CQ ) $.
4g $a #Pattern ( 4w Bw CQ ) $.
5Q $a zw ( Tw Bw ( Tw CQ Bw ) ) $.
${ 6A $e zw ( Tw Bw CQ ) $.
   6Q $e zw Bw $.
   6g $a zw CQ $. $}
IAE $a #Pattern IQE $.
SgE $a #Pattern ( SwE Bw CQ ) $.
lQE $a zw ( Tw Bw Bw ) $.
${ lgE $e zw ( Tw Bw CQ ) $.
   lwE $e zw ( Tw CQ Cw ) $.
   mAE $a zw ( Tw Bw Cw ) $. $}
nAE $a zw IQE $.
ugE $a zw ( Tw ( 4w Bw CQ ) Bw ) $.
${ wAE $e zw ( Tw Bw CQ ) $.
   wQE $e zw ( Tw Bw Cw ) $.
   wgE $a zw ( Tw Bw ( 4w CQ Cw ) ) $. $}
${ NwM $e zw CQ $.
   OAM $a zw ( Tw Bw CQ ) $. $}
tAM $a #Pattern ( tQM Bw CQ ) $.
uwM $a #Pattern ( twM Bw ) $.
wAM $a #Pattern ( wQM Bw CQ Cw ) $.
0gM $a #Pattern ( 0wM Bw CQ Cw DQ ) $.
HwQ $a #Pattern ( IAQ Bw CQ ) $.
IwQ $a #Pattern ( JAQ Bw ) $.
KwQ $a #Pattern ( LAQ Bw CQ Cw ) $.
LAU $a zw ( SwE ( 0wM Bw CQ Cw DQ ) CQ ) $.
${ -wU $e zw ( Tw GQ ( SwE CQ Bw ) ) $.
   AAY $e zw ( Tw GQ ( tQM Bw ( wQM Bw CQ ( twM Bw ) ) ) ) $.
   AQY $a zw ( Tw GQ ( tQM Bw CQ ) ) $. $}
nwg $f #Pattern oAg $.
pQg $a #Pattern pgg $.
qgg $f #Pattern qwg $.
rgg $a #Pattern ( rwg oAg qwg ) $.
xAg $a #Pattern xQg $.
2Qg $f #ElementVariable 2gg $.
egk $a #Pattern ewk $.
.Qk $a #Pattern .gk $.
VRc $a #Pattern ( Vhc oAg ) $.
Ph0 $a #Pattern Px0 $.
2B4 $a #Pattern 2R4 $.
Wh8 $a #Pattern 2gg $.
9h8 $a zw ( Tw ( 4w ( JAQ 2gg ) IQE ) ( 4w ( JAQ 2gg ) IQE ) ) $.
zyw $a zw ( Tw ( 4w ( JAQ 2gg ) IQE ) ( tQM 2gg ( wQM 2gg ( 0wM .gk 2gg ( Vhc ( rwg ( LAQ ewk pgg ( IAQ ewk 2R4 ) ) xQg ) ) ( IAQ .gk Px0 ) ) ( twM 2gg ) ) ) ) $.
${ 0Cw $p zw ( Tw ( 4w ( JAQ 2gg ) IQE ) ( tQM 2gg ( 0wM .gk 2gg ( Vhc ( rwg ( LAQ ewk pgg ( IAQ ewk 2R4 ) ) xQg ) ) ( IAQ .gk Px0 ) ) ) ) $=
  ( Wh8 IwQ IAE 4g .Qk egk pQg 2B4 HwQ KwQ xAg rgg VRc tAM nAE OAM wgE ugE mAE
  Ph0 0gM 9h8 SgE Tg 5Q LAU 6g uwM wAM lQE zyw AQY ) ABZCZDEZUPUPDEZEZUNFUNGHGI
  JKLMNZFUAJZUBZOUPUPUQAUCZUPUPDVBUPDPQRRUNVAURVAUNUDZURVCUEVCURUFFUNUSUTUGUHUR
  UPUNUNVAUNUIUJOURUODURUPUOUPUQSUPUOUOUODSUOUKTTURDPQRAULTUMT $. $}
