$c ewk Tw #Symbol #Variable SwE #SetVariable zw 4w YQk #ElementVariable IQE mwg rgk pgg #Pattern ) ( $.
$v 4wg CQ 3gg -Bw Bw 5Qg Cw 4Ag $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Cg $f #Pattern Cw $.
4g $a #Pattern ( 4w Bw CQ ) $.
IAE $a #Pattern IQE $.
SgE $a #Pattern ( SwE Bw CQ ) $.
${ wAE $e zw ( Tw Bw CQ ) $.
   wQE $e zw ( Tw Bw Cw ) $.
   wgE $a zw ( Tw Bw ( 4w CQ Cw ) ) $. $}
mgg $a #Pattern mwg $.
pQg $a #Pattern pgg $.
3Qg $f #ElementVariable 3gg $.
3wg $f #ElementVariable 4Ag $.
4gg $f #ElementVariable 4wg $.
5Ag $f #ElementVariable 5Qg $.
YAk $a #Pattern YQk $.
egk $a #Pattern ewk $.
rQk $a #Pattern rgk $.
.xw $f #ElementVariable -Bw $.
BCQ $a #Pattern 4Ag $.
XiU $a #Pattern 3gg $.
XyU $a #Pattern 4wg $.
YCU $a #Pattern 5Qg $.
yyg $a #Pattern -Bw $.
zCg $a #Pattern ( 4w ( SwE 5Qg pgg ) ( 4w ( SwE -Bw YQk ) IQE ) ) $.
0Sg $a zw ( Tw ( 4w ( SwE 4Ag mwg ) ( 4w ( SwE 3gg rgk ) ( 4w ( SwE 4wg ewk ) ( 4w ( SwE 5Qg pgg ) ( 4w ( SwE -Bw YQk ) IQE ) ) ) ) ) ( SwE 5Qg pgg ) ) $.
3ig $a zw ( Tw ( 4w ( SwE 4Ag mwg ) ( 4w ( SwE 3gg rgk ) ( 4w ( SwE 4wg ewk ) ( 4w ( SwE 5Qg pgg ) ( 4w ( SwE -Bw YQk ) IQE ) ) ) ) ) ( 4w ( SwE -Bw YQk ) IQE ) ) $.
${ 3yg $p zw ( Tw ( 4w ( SwE 4Ag mwg ) ( 4w ( SwE 3gg rgk ) ( 4w ( SwE 4wg ewk ) ( 4w ( SwE 5Qg pgg ) ( 4w ( SwE -Bw YQk ) IQE ) ) ) ) ) ( 4w ( SwE 5Qg pgg ) ( 4w ( SwE -Bw YQk ) IQE ) ) ) $=
  ( BCQ mgg SgE XiU rQk XyU egk zCg 4g YCU pQg yyg YAk IAE 0Sg 3ig wgE ) BFGHAI
  JHCKLHDEMNNNDOPHEQRHSNABCDETABCDEUAUB $. $}
