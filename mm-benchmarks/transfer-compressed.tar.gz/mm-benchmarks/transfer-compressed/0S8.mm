$c rwg LAQ XBI ewk xB4 IAQ Wgk #Symbol #Variable 0hU #SetVariable ) #ElementVariable qxs 8wk rgk pgg 8hw #Pattern ( $.
$v CQ qwg 3gg Bw oAg 5Qg MB0 Cw sgg $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Cg $f #Pattern Cw $.
HwQ $a #Pattern ( IAQ Bw CQ ) $.
KwQ $a #Pattern ( LAQ Bw CQ Cw ) $.
nwg $f #Pattern oAg $.
pQg $a #Pattern pgg $.
qgg $f #Pattern qwg $.
rgg $a #Pattern ( rwg oAg qwg ) $.
sQg $f #Pattern sgg $.
3Qg $f #ElementVariable 3gg $.
5Ag $f #ElementVariable 5Qg $.
WQk $a #Pattern Wgk $.
egk $a #Pattern ewk $.
rQk $a #Pattern rgk $.
8gk $a #Pattern 8wk $.
WxI $a #Pattern ( XBI oAg qwg ) $.
0RU $a #Pattern ( 0hU oAg qwg sgg ) $.
qhs $a #Pattern ( qxs oAg ) $.
8Rw $a #Pattern 8hw $.
Lx0 $f #ElementVariable MB0 $.
wx4 $a #Pattern xB4 $.
XiU $a #Pattern 3gg $.
YCU $a #Pattern 5Qg $.
qy8 $a #Pattern MB0 $.
${ 0S8 $p #Pattern ( rwg ( LAQ 8wk pgg ( 0hU 5Qg ( qxs ( XBI ( IAQ ewk xB4 ) ( LAQ rgk Wgk ( IAQ rgk 8hw ) ) ) ) MB0 ) ) 3gg ) $=
  ( 8gk pQg YCU egk wx4 HwQ rQk WQk 8Rw KwQ WxI qhs qy8 0RU XiU rgg ) DEBFGHIJK
  JLIMNOCPQMARS $. $}
