$c 2R4 Tw #Symbol zw JAQ #Pattern ( 0wM LAQ ewk tQM IAQ Wgk #Variable #SetVariable 4w rwM #ElementVariable IQE ) $.
$v yhs CQ DQ Bw Kw Cw 2gg $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Cg $f #Pattern Cw $.
DA $f #Pattern DQ $.
Kg $f #ElementVariable Kw $.
4g $a #Pattern ( 4w Bw CQ ) $.
IAE $a #Pattern IQE $.
${ lgE $e zw ( Tw Bw CQ ) $.
   lwE $e zw ( Tw CQ Cw ) $.
   mAE $a zw ( Tw Bw Cw ) $. $}
nAE $a zw IQE $.
${ wAE $e zw ( Tw Bw CQ ) $.
   wQE $e zw ( Tw Bw Cw ) $.
   wgE $a zw ( Tw Bw ( 4w CQ Cw ) ) $. $}
${ NwM $e zw CQ $.
   OAM $a zw ( Tw Bw CQ ) $. $}
rgM $a #Pattern ( rwM Bw CQ Kw Cw ) $.
tAM $a #Pattern ( tQM Bw CQ ) $.
0gM $a #Pattern ( 0wM Bw CQ Cw DQ ) $.
HwQ $a #Pattern ( IAQ Bw CQ ) $.
IwQ $a #Pattern ( JAQ Bw ) $.
KwQ $a #Pattern ( LAQ Bw CQ Cw ) $.
2Qg $f #ElementVariable 2gg $.
WQk $a #Pattern Wgk $.
egk $a #Pattern ewk $.
yRs $f #ElementVariable yhs $.
2B4 $a #Pattern 2R4 $.
Wh8 $a #Pattern 2gg $.
.h8 $a zw ( Tw ( 4w IQE ( 4w ( JAQ 2gg ) IQE ) ) ( JAQ 2gg ) ) $.
7SA $a #Pattern yhs $.
1iI $a zw ( Tw ( 4w ( JAQ 2gg ) IQE ) ( tQM 2gg ( rwM Wgk 2gg yhs ( 0wM Wgk 2gg yhs ( LAQ ewk Wgk ( IAQ ewk 2R4 ) ) ) ) ) ) $.
${ 1yI $p zw ( Tw ( 4w IQE ( 4w ( JAQ 2gg ) IQE ) ) ( tQM 2gg ( rwM Wgk 2gg yhs ( 0wM Wgk 2gg yhs ( LAQ ewk Wgk ( IAQ ewk 2R4 ) ) ) ) ) ) $=
  ( IAE Wh8 IwQ 4g WQk 7SA egk 2B4 HwQ KwQ 0gM rgM tAM .h8 nAE OAM wgE 1iI mAE
  ) CADZEZCFZFZUDUBGUBGUBBHIGIJKLMBNOUEUCCAPUECQRSABTUA $. $}
