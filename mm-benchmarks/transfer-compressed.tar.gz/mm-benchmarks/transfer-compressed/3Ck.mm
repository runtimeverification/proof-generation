$c Uw 2R4 PgE Tw #Symbol 7h4 zw YQk JAQ rgk pgg #Pattern ( 0wM LAQ ewk tQM IAQ 0h4 #Variable SwE #SetVariable iA 4w rwM #ElementVariable IQE 7BI 8hw ) cBQ $.
$v th1 yhs Fw CQ Bw Cw 2gg sgg ngg FQ z ph2 Ew ph0 x Lw LQ 7Ag Ow ph6 qwg DQ ph1 EQ y th2 tAg Dw HQ xX Gw th0 Hw Kw oAg 6Ag GQ nR4 tgg $.
$d z y $.
$d z x $.
$d y x $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Cg $f #Pattern Cw $.
DA $f #Pattern DQ $.
Dg $f #Pattern Dw $.
EA $f #Pattern EQ $.
Eg $f #Pattern Ew $.
FA $f #Pattern FQ $.
Fg $f #Pattern Fw $.
GA $f #Pattern GQ $.
Gg $f #Pattern Gw $.
HA $f #Pattern HQ $.
Hg $f #Pattern Hw $.
Kg $f #ElementVariable Kw $.
LA $f #ElementVariable LQ $.
Lg $f #ElementVariable Lw $.
Og $f #Variable Ow $.
SA $a #Variable Kw $.
jg $a iA Bw Ow Bw Ow $.
${ kg $e iA CQ DQ Bw Ow $.
   kw $e iA Cw Dw Bw Ow $.
   lA $a iA ( Tw CQ Cw ) ( Tw DQ Dw ) Bw Ow $. $}
4g $a #Pattern ( 4w Bw CQ ) $.
IAE $a #Pattern IQE $.
SgE $a #Pattern ( SwE Bw CQ ) $.
${ lgE $e zw ( Tw Bw CQ ) $.
   lwE $e zw ( Tw CQ Cw ) $.
   mAE $a zw ( Tw Bw Cw ) $. $}
nAE $a zw IQE $.
${ wAE $e zw ( Tw Bw CQ ) $.
   wQE $e zw ( Tw Bw Cw ) $.
   wgE $a zw ( Tw Bw ( 4w CQ Cw ) ) $. $}
${ $d xX ph0 $.
   IQI $a iA Bw Bw CQ Ow $. $}
${ KAI $e iA CQ DQ Bw Ow $.
   KQI $e iA Cw Dw Bw Ow $.
   KgI $a iA ( 4w CQ Cw ) ( 4w DQ Dw ) Bw Ow $. $}
${ OgI $e iA CQ DQ Bw Ow $.
   OwI $e iA Cw Dw Bw Ow $.
   PAI $a iA ( SwE CQ Cw ) ( SwE DQ Dw ) Bw Ow $. $}
${ NwM $e zw CQ $.
   OAM $a zw ( Tw Bw CQ ) $. $}
rgM $a #Pattern ( rwM Bw CQ Kw Cw ) $.
tAM $a #Pattern ( tQM Bw CQ ) $.
0gM $a #Pattern ( 0wM Bw CQ Cw DQ ) $.
HwQ $a #Pattern ( IAQ Bw CQ ) $.
IwQ $a #Pattern ( JAQ Bw ) $.
KwQ $a #Pattern ( LAQ Bw CQ Cw ) $.
${ $d xX y $.
   $d y ph6 $.
   OAQ $e iA Bw DQ Ew Ow $.
   OQQ $e iA CQ Dw Ew Ow $.
   OgQ $e iA Cw EQ Ew Ow $.
   OwQ $a iA ( rwM Bw CQ LQ Cw ) ( rwM DQ Dw LQ EQ ) Ew Ow $. $}
${ QAQ $e iA Bw Cw Dw Ow $.
   QQQ $e iA CQ DQ Dw Ow $.
   QgQ $a iA ( tQM Bw CQ ) ( tQM Cw DQ ) Dw Ow $. $}
${ XgQ $e iA Bw Dw Fw Ow $.
   XwQ $e iA CQ EQ Fw Ow $.
   YAQ $e iA Cw Ew Fw Ow $.
   YQQ $e iA DQ FQ Fw Ow $.
   YgQ $a iA ( 0wM Bw CQ Cw DQ ) ( 0wM Dw EQ Ew FQ ) Fw Ow $. $}
${ $d z ph0 $.
   $d z ph1 $.
   $d z ph2 $.
   $d z y $.
   $d z x $.
   $d z th1 $.
   $d z th2 $.
   $d x ph0 $.
   $d y th0 $.
   lAY $e zw ( Tw GQ ( Uw Kw ( PgE Kw Bw ) ) ) $.
   lQY $e zw ( Tw ( 4w GQ Gw ) CQ ) $.
   lgY $e iA ( Tw HQ Cw ) ( Tw Gw CQ ) Bw LQ $.
   lwY $e iA ( Tw Hw DQ ) ( Tw Gw CQ ) Lw LQ $.
   mAY $a zw ( Tw ( 4w GQ HQ ) Cw ) $. $}
nQg $f #Variable ngg $.
nwg $f #Pattern oAg $.
pQg $a #Pattern pgg $.
qgg $f #Pattern qwg $.
sQg $f #Pattern sgg $.
swg $f #Pattern tAg $.
tQg $f #Pattern tgg $.
2Qg $f #ElementVariable 2gg $.
5wg $f #ElementVariable 6Ag $.
6wg $f #ElementVariable 7Ag $.
YAk $a #Pattern YQk $.
egk $a #Pattern ewk $.
rQk $a #Pattern rgk $.
6xI $a #Pattern ( 7BI oAg qwg ) $.
${ 8BI $e iA qwg tAg oAg ngg $.
   8RI $e iA sgg tgg oAg ngg $.
   8hI $a iA ( 7BI qwg sgg ) ( 7BI tAg tgg ) oAg ngg $. $}
bxQ $a #Pattern ( cBQ oAg qwg ) $.
yRs $f #ElementVariable yhs $.
8Rw $a #Pattern 8hw $.
nB4 $f #ElementVariable nR4 $.
0R4 $a #Pattern 0h4 $.
2B4 $a #Pattern 2R4 $.
7R4 $a #Pattern 7h4 $.
Wh8 $a #Pattern 2gg $.
6h8 $a #Pattern nR4 $.
9h8 $a zw ( Tw ( 4w ( JAQ 2gg ) IQE ) ( 4w ( JAQ 2gg ) IQE ) ) $.
-CA $a #Pattern 7Ag $.
BCE $a #Pattern 6Ag $.
8yM $a iA YQk YQk nR4 7Ag $.
9iM $a iA ( 4w ( SwE nR4 YQk ) IQE ) ( 4w ( SwE 7Ag YQk ) IQE ) nR4 7Ag $.
9yM $a iA 2gg 2gg nR4 7Ag $.
.CM $a iA 6Ag 6Ag nR4 7Ag $.
Nic $a zw ( Tw ( 4w ( 4w ( JAQ 2gg ) IQE ) ( 4w ( SwE 7Ag YQk ) IQE ) ) ( tQM 2gg ( rwM YQk 2gg 6Ag ( 0wM YQk 2gg 6Ag ( 7BI ( cBQ ( LAQ ewk pgg ( IAQ ewk 7h4 ) ) ( LAQ rgk pgg ( IAQ rgk 8hw ) ) ) 7Ag ) ) ) ) ) $.
2ik $a zw ( Tw ( 4w ( JAQ 2gg ) IQE ) ( Uw yhs ( PgE yhs ( cBQ ( LAQ ewk pgg ( IAQ ewk 2R4 ) ) ( LAQ rgk pgg ( IAQ rgk 0h4 ) ) ) ) ) ) $.
2yk $a zw ( Tw ( 4w ( JAQ 2gg ) IQE ) ( SwE ( cBQ ( LAQ ewk pgg ( IAQ ewk 2R4 ) ) ( LAQ rgk pgg ( IAQ rgk 0h4 ) ) ) YQk ) ) $.
${ 3Ck $p zw ( Tw ( 4w ( JAQ 2gg ) IQE ) ( tQM 2gg ( rwM YQk 2gg 6Ag ( 0wM YQk 2gg 6Ag ( 7BI ( cBQ ( LAQ ewk pgg ( IAQ ewk 7h4 ) ) ( LAQ rgk pgg ( IAQ rgk 8hw ) ) ) ( cBQ ( LAQ ewk pgg ( IAQ ewk 2R4 ) ) ( LAQ rgk pgg ( IAQ rgk 0h4 ) ) ) ) ) ) ) ) $=
  ( 6wg nB4 yRs IAE 4g egk pQg HwQ KwQ rQk bxQ YAk SgE 6xI 0gM rgM tAM IQI Wh8
  IwQ 2B4 0R4 BCE 7R4 8Rw 9h8 2yk nAE OAM wgE -CA 6h8 2ik Nic SA jg PAI KgI 8hI
  YgQ OwQ QgQ lA 9iM 9yM 8yM .CM mAY mAE ) AUAZUBFGZVMHIHUCJKLILUDJKMZNOZFGZGVL
  NVLNVLBUEZHIHUFJKLILUGJKMZVNPZQZBRZSZVMVMVPAUHVMVOFAUIVMFUJUKULULVNVLNVLNVLVQ
  VRCUMZPZQZBRZSZWBVLNVLNVLVQVRDUNZPZQZBRZSZVMWCNOZFGZVPWHNOFGZECDAEUOABCUPVNVP
  WBWNWGCUQZVNVOFWMFWPVNVNNWCNWPVNWPURZNVNWPTZUSFVNWPTUTVLWAVLWFVNWPVLVNWPTZNVL
  VTNVLWEVNBWPWRWSNVLVQVSNVLVQWDVNWPWRWSVQVNWPTWPVNVRVNVRWCVRVNWPTWQVAVBVCVDVEW
  HWOWLWNWGWPCDVFVLWKVLWFWHWPACDVGZNVLWJNVLWEWHBWPCDVHZWTNVLVQWINVLVQWDWHWPXAWT
  BCDVIWPWHVRWHVRWCVRWHWPTWHWPURVAVBVCVDVEVJVK $. $}
