$c Uw xAM zBA 2R4 PgE vgM Tw #Symbol 7h4 wQM cwE zw JAQ mwg .gk xwM Px0 pgg #Pattern ( 3gk rwg 0wM twM LAQ ewk tQM IAQ Wgk 1gM #Variable SwE #SetVariable iA 4w rwM #ElementVariable IQE uQM xQg ) Vhc $.
$v th1 Fw CQ Bw Cw 2gg sgg ngg FQ z ph2 3gg Ew ph0 x Lw LQ Ow ph6 qwg DQ ph1 EQ y th2 3Ag Dw HQ xX Gw th0 Hw Kw oAg 6Ag GQ nR4 4Ag $.
$d z y $.
$d z x $.
$d y x $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Cg $f #Pattern Cw $.
DA $f #Pattern DQ $.
Dg $f #Pattern Dw $.
EA $f #Pattern EQ $.
Eg $f #Pattern Ew $.
FA $f #Pattern FQ $.
Fg $f #Pattern Fw $.
GA $f #Pattern GQ $.
Gg $f #Pattern Gw $.
HA $f #Pattern HQ $.
Hg $f #Pattern Hw $.
Kg $f #ElementVariable Kw $.
LA $f #ElementVariable LQ $.
Lg $f #ElementVariable Lw $.
Og $f #Variable Ow $.
SA $a #Variable Kw $.
Ug $a #Pattern ( Uw Kw Bw ) $.
jg $a iA Bw Ow Bw Ow $.
${ kg $e iA CQ DQ Bw Ow $.
   kw $e iA Cw Dw Bw Ow $.
   lA $a iA ( Tw CQ Cw ) ( Tw DQ Dw ) Bw Ow $. $}
4g $a #Pattern ( 4w Bw CQ ) $.
IAE $a #Pattern IQE $.
PQE $a #Pattern ( PgE Bw CQ ) $.
SgE $a #Pattern ( SwE Bw CQ ) $.
${ lgE $e zw ( Tw Bw CQ ) $.
   lwE $e zw ( Tw CQ Cw ) $.
   mAE $a zw ( Tw Bw Cw ) $. $}
nAE $a zw IQE $.
ugE $a zw ( Tw ( 4w Bw CQ ) Bw ) $.
${ wAE $e zw ( Tw Bw CQ ) $.
   wQE $e zw ( Tw Bw Cw ) $.
   wgE $a zw ( Tw Bw ( 4w CQ Cw ) ) $. $}
${ $d xX ph0 $.
   IQI $a iA Bw Bw CQ Ow $. $}
${ KAI $e iA CQ DQ Bw Ow $.
   KQI $e iA Cw Dw Bw Ow $.
   KgI $a iA ( 4w CQ Cw ) ( 4w DQ Dw ) Bw Ow $. $}
${ OgI $e iA CQ DQ Bw Ow $.
   OwI $e iA Cw Dw Bw Ow $.
   PAI $a iA ( SwE CQ Cw ) ( SwE DQ Dw ) Bw Ow $. $}
${ NwM $e zw CQ $.
   OAM $a zw ( Tw Bw CQ ) $. $}
rgM $a #Pattern ( rwM Bw CQ Kw Cw ) $.
tAM $a #Pattern ( tQM Bw CQ ) $.
uAM $a #Pattern ( uQM Bw ) $.
uwM $a #Pattern ( twM Bw ) $.
vQM $a #Pattern ( vgM Bw CQ ) $.
wAM $a #Pattern ( wQM Bw CQ Cw ) $.
wwM $a #Pattern ( xAM Bw CQ Cw ) $.
xgM $a #Pattern ( xwM Bw CQ Cw ) $.
0gM $a #Pattern ( 0wM Bw CQ Cw DQ ) $.
1QM $a #Pattern ( 1gM Bw CQ Cw DQ ) $.
HwQ $a #Pattern ( IAQ Bw CQ ) $.
IwQ $a #Pattern ( JAQ Bw ) $.
KwQ $a #Pattern ( LAQ Bw CQ Cw ) $.
${ $d xX y $.
   $d y ph6 $.
   OAQ $e iA Bw DQ Ew Ow $.
   OQQ $e iA CQ Dw Ew Ow $.
   OgQ $e iA Cw EQ Ew Ow $.
   OwQ $a iA ( rwM Bw CQ LQ Cw ) ( rwM DQ Dw LQ EQ ) Ew Ow $. $}
${ QAQ $e iA Bw Cw Dw Ow $.
   QQQ $e iA CQ DQ Dw Ow $.
   QgQ $a iA ( tQM Bw CQ ) ( tQM Cw DQ ) Dw Ow $. $}
${ RwQ $e iA Bw Cw Dw Ow $.
   SAQ $e iA CQ DQ Dw Ow $.
   SQQ $a iA ( vgM Bw CQ ) ( vgM Cw DQ ) Dw Ow $. $}
${ SgQ $e iA Bw DQ Ew Ow $.
   SwQ $e iA CQ Dw Ew Ow $.
   TAQ $e iA Cw EQ Ew Ow $.
   TQQ $a iA ( wQM Bw CQ Cw ) ( wQM DQ Dw EQ ) Ew Ow $. $}
${ TgQ $e iA Bw DQ Ew Ow $.
   TwQ $e iA CQ Dw Ew Ow $.
   UAQ $e iA Cw EQ Ew Ow $.
   UQQ $a iA ( xAM Bw CQ Cw ) ( xAM DQ Dw EQ ) Ew Ow $. $}
${ UgQ $e iA Bw DQ Ew Ow $.
   UwQ $e iA CQ Dw Ew Ow $.
   VAQ $e iA Cw EQ Ew Ow $.
   VQQ $a iA ( xwM Bw CQ Cw ) ( xwM DQ Dw EQ ) Ew Ow $. $}
${ XgQ $e iA Bw Dw Fw Ow $.
   XwQ $e iA CQ EQ Fw Ow $.
   YAQ $e iA Cw Ew Fw Ow $.
   YQQ $e iA DQ FQ Fw Ow $.
   YgQ $a iA ( 0wM Bw CQ Cw DQ ) ( 0wM Dw EQ Ew FQ ) Fw Ow $. $}
${ YwQ $e iA Bw Dw Fw Ow $.
   ZAQ $e iA CQ EQ Fw Ow $.
   ZQQ $e iA Cw Ew Fw Ow $.
   ZgQ $e iA DQ FQ Fw Ow $.
   ZwQ $a iA ( 1gM Bw CQ Cw DQ ) ( 1gM Dw EQ Ew FQ ) Fw Ow $. $}
${ $d z ph0 $.
   $d z ph1 $.
   $d z ph2 $.
   $d z y $.
   $d z x $.
   $d z th1 $.
   $d z th2 $.
   $d x ph0 $.
   $d y th0 $.
   lAY $e zw ( Tw GQ ( Uw Kw ( PgE Kw Bw ) ) ) $.
   lQY $e zw ( Tw ( 4w GQ Gw ) CQ ) $.
   lgY $e iA ( Tw HQ Cw ) ( Tw Gw CQ ) Bw LQ $.
   lwY $e iA ( Tw Hw DQ ) ( Tw Gw CQ ) Lw LQ $.
   mAY $a zw ( Tw ( 4w GQ HQ ) Cw ) $. $}
${ $d x ph0 $.
   $d x ph1 $.
   vwY $e zw ( Tw GQ ( SwE CQ Bw ) ) $.
   wAY $e zw ( Tw GQ ( tQM cwE ( rwM Bw cwE Kw ( 0wM Bw cwE Kw CQ ) ) ) ) $.
   wQY $a zw ( Tw GQ ( Uw Kw ( PgE Kw CQ ) ) ) $. $}
mgg $a #Pattern mwg $.
nQg $f #Variable ngg $.
nwg $f #Pattern oAg $.
pQg $a #Pattern pgg $.
qgg $f #Pattern qwg $.
rgg $a #Pattern ( rwg oAg qwg ) $.
sQg $f #Pattern sgg $.
wQg $a zw ( Tw ( 4w ( SwE oAg pgg ) ( SwE qwg mwg ) ) ( SwE ( rwg oAg qwg ) mwg ) ) $.
xAg $a #Pattern xQg $.
2Qg $f #ElementVariable 2gg $.
2wg $f #ElementVariable 3Ag $.
3Qg $f #ElementVariable 3gg $.
3wg $f #ElementVariable 4Ag $.
5wg $f #ElementVariable 6Ag $.
WQk $a #Pattern Wgk $.
egk $a #Pattern ewk $.
3Qk $a #Pattern 3gk $.
.Qk $a #Pattern .gk $.
yxA $a #Pattern ( zBA oAg qwg ) $.
VRc $a #Pattern ( Vhc oAg ) $.
${ Whc $e iA qwg sgg oAg ngg $.
   Wxc $a iA ( Vhc qwg ) ( Vhc sgg ) oAg ngg $. $}
Ph0 $a #Pattern Px0 $.
Px4 $a zw ( Tw ( 4w ( JAQ 2gg ) ( 4w ( SwE 3Ag mwg ) ( 4w ( SwE 4Ag mwg ) IQE ) ) ) ( tQM 2gg ( xwM 2gg ( wQM 2gg ( vgM 2gg ( xAM 2gg ( rwM 3gk 2gg 3gg ( wQM 2gg ( twM 2gg ) ( wQM 2gg ( 1gM mwg 2gg 3Ag ( rwg ( LAQ 3gk pgg 3gg ) xQg ) ) ( twM 2gg ) ) ) ) ( uQM 2gg ) ) ) ( wQM 2gg ( twM 2gg ) ( wQM 2gg ( 1gM mwg 2gg 3Ag 4Ag ) ( twM 2gg ) ) ) ) ( wQM 2gg ( 0wM .gk 2gg ( Vhc 3Ag ) ( IAQ .gk Px0 ) ) ( twM 2gg ) ) ) ) ) $.
nB4 $f #ElementVariable nR4 $.
2B4 $a #Pattern 2R4 $.
7R4 $a #Pattern 7h4 $.
Wh8 $a #Pattern 2gg $.
6h8 $a #Pattern nR4 $.
BCE $a #Pattern 6Ag $.
BCQ $a #Pattern 4Ag $.
ByQ $a #Pattern 3Ag $.
FSQ $a iA 2gg 2gg nR4 3Ag $.
FiQ $a iA ( twM 2gg ) ( twM 2gg ) nR4 3Ag $.
-iQ $a iA ( 4w ( SwE nR4 mwg ) IQE ) ( 4w ( SwE 3Ag mwg ) IQE ) nR4 3Ag $.
XiU $a #Pattern 3gg $.
MSs $a #Pattern ( 4w ( JAQ 2gg ) ( 4w ( SwE 4Ag mwg ) IQE ) ) $.
Mis $a zw ( Tw ( 4w ( JAQ 2gg ) ( 4w ( SwE 4Ag mwg ) IQE ) ) ( JAQ 2gg ) ) $.
NCs $a zw ( Tw ( 4w ( 4w ( JAQ 2gg ) ( 4w ( SwE 4Ag mwg ) IQE ) ) ( 4w ( SwE 3Ag mwg ) IQE ) ) ( 4w ( SwE 3Ag mwg ) ( 4w ( SwE 4Ag mwg ) IQE ) ) ) $.
NSs $a #Pattern ( 4w ( JAQ 2gg ) ( 4w ( SwE 3Ag mwg ) ( 4w ( SwE 4Ag mwg ) IQE ) ) ) $.
Nis $a #Pattern ( 1gM mwg 2gg 3Ag ( rwg ( LAQ 3gk pgg 3gg ) xQg ) ) $.
Nys $a #Pattern ( 1gM mwg 2gg 3Ag 4Ag ) $.
OCs $a #Pattern ( 1gM mwg 2gg nR4 ( rwg ( LAQ 3gk pgg 3gg ) xQg ) ) $.
OSs $a #Pattern ( 1gM mwg 2gg nR4 4Ag ) $.
Ois $a iA 3gk 3gk nR4 3Ag $.
Oys $a iA ( 1gM mwg 2gg nR4 ( rwg ( LAQ 3gk pgg 3gg ) xQg ) ) ( 1gM mwg 2gg 3Ag ( rwg ( LAQ 3gk pgg 3gg ) xQg ) ) nR4 3Ag $.
PCs $a iA ( uQM 2gg ) ( uQM 2gg ) nR4 3Ag $.
Pys $a iA ( wQM 2gg ( twM 2gg ) ( wQM 2gg ( 1gM mwg 2gg nR4 4Ag ) ( twM 2gg ) ) ) ( wQM 2gg ( twM 2gg ) ( wQM 2gg ( 1gM mwg 2gg 3Ag 4Ag ) ( twM 2gg ) ) ) nR4 3Ag $.
Qys $a iA ( wQM 2gg ( 0wM .gk 2gg ( Vhc nR4 ) ( IAQ .gk Px0 ) ) ( twM 2gg ) ) ( wQM 2gg ( 0wM .gk 2gg ( Vhc 3Ag ) ( IAQ .gk Px0 ) ) ( twM 2gg ) ) nR4 3Ag $.
RCs $a zw ( Tw ( 4w ( JAQ 2gg ) ( 4w ( SwE 4Ag mwg ) IQE ) ) ( 4w ( JAQ 2gg ) ( 4w ( SwE 4Ag mwg ) IQE ) ) ) $.
2jM $a zw ( Tw IQE ( tQM cwE ( rwM mwg cwE 6Ag ( 0wM mwg cwE 6Ag ( rwg ( LAQ Wgk pgg ( zBA ( LAQ ewk Wgk ( IAQ ewk 7h4 ) ) ( LAQ ewk Wgk ( IAQ ewk 2R4 ) ) ) ) xQg ) ) ) ) ) $.
2zM $a zw ( Tw IQE ( SwE ( rwg ( LAQ Wgk pgg ( zBA ( LAQ ewk Wgk ( IAQ ewk 7h4 ) ) ( LAQ ewk Wgk ( IAQ ewk 2R4 ) ) ) ) xQg ) mwg ) ) $.
3jM $a zw ( Tw ( 4w ( JAQ 2gg ) ( 4w ( SwE 4Ag mwg ) IQE ) ) ( 4w ( SwE ( LAQ Wgk pgg ( zBA ( LAQ ewk Wgk ( IAQ ewk 7h4 ) ) ( LAQ ewk Wgk ( IAQ ewk 2R4 ) ) ) ) pgg ) ( SwE xQg mwg ) ) ) $.
${ 3zM $p zw ( Tw ( 4w ( JAQ 2gg ) ( 4w ( SwE 4Ag mwg ) IQE ) ) ( tQM 2gg ( xwM 2gg ( wQM 2gg ( vgM 2gg ( xAM 2gg ( rwM 3gk 2gg 3gg ( wQM 2gg ( twM 2gg ) ( wQM 2gg ( 1gM mwg 2gg ( rwg ( LAQ Wgk pgg ( zBA ( LAQ ewk Wgk ( IAQ ewk 7h4 ) ) ( LAQ ewk Wgk ( IAQ ewk 2R4 ) ) ) ) xQg ) ( rwg ( LAQ 3gk pgg 3gg ) xQg ) ) ( twM 2gg ) ) ) ) ( uQM 2gg ) ) ) ( wQM 2gg ( twM 2gg ) ( wQM 2gg ( 1gM mwg 2gg ( rwg ( LAQ Wgk pgg ( zBA ( LAQ ewk Wgk ( IAQ ewk 7h4 ) ) ( LAQ ewk Wgk ( IAQ ewk 2R4 ) ) ) ) xQg ) 4Ag ) ( twM 2gg ) ) ) ) ( wQM 2gg ( 0wM .gk 2gg ( Vhc ( rwg ( LAQ Wgk pgg ( zBA ( LAQ ewk Wgk ( IAQ ewk 7h4 ) ) ( LAQ ewk Wgk ( IAQ ewk 2R4 ) ) ) ) xQg ) ) ( IAQ .gk Px0 ) ) ( twM 2gg ) ) ) ) ) $=
  ( 2wg nB4 5wg WQk egk KwQ xAg mgg SgE IAE 4g 3Qk wAM .Qk mAE IQI TQQ Ug SA jg
  MSs pQg 7R4 HwQ 2B4 yxA rgg Wh8 uwM XiU 1QM rgM uAM wwM vQM BCQ VRc Ph0 0gM
  xgM tAM RCs 3jM wQg nAE OAM wgE Nis Nys ByQ OCs OSs 6h8 BCE PQE 2zM 2jM wQY
  NSs IwQ ugE Mis NCs Px4 PAI KgI ZwQ OwQ UQQ SQQ Wxc YgQ VQQ QgQ -iQ FSQ Ois
  lA FiQ Oys PCs Pys Qys mAY ) ACUDZXHGUEHGHUFUGIHGHUHUGIUIIZJUJZKLZMNZNAUKZXMX
  MXMXMOXMXMXMULZXMKXMXJOUEBUMIJUJZUNZXNPZPZBUOZXMUPZUQZURZXMXNXMKXMXJCUSZUNZXN
  PZPZPZXMQXMXJUTZQVAUGZVBZXNPZVCZVDZXHXHXLACVEXHXKMXHXIUELJKLNXKACVFXIJVGRXHMV
  HVIZVJVJXJXMXMXMXMXMOXMXMXNXMADBVKZXNPZPZBUOZXTUQZURZXMXNXMADCVLZXNPZPZPZXMQX
  MDVMZUTZYIVBZXNPZVCZVDZYMXMXMXMXMXMOXMXMXNXMABEVNZXNPZPZBUOZXTUQZURZXMXNXMACE
  VOXNPPZPZXMQXMEVPZUTYIVBXNPZVCZVDZXHUUEKLZMNZXLUUSKLMNZFDEXHMFVQXJVRFUAYNKXJM
  FVSFVTWARXHUVDNZADCWBUUJUVFXMWCZUVCYCKLMNNUVFXHUVGXHUVDWDACWERADCWFVJADBCWGRX
  JXLYMUVDUUJDUBZXJXKMUVCMUVHXJXJKUUEKUVHXJUVHUCZKXJUVHSZWHMXJUVHSWIXMYLXMUUIXJ
  UVHXMXJUVHSZXMYGYKXMUUDUUHXJUVHUVKXMYBYFXMYTUUCXJUVHUVKXMYAXMYSXJUVHUVKXMXSXT
  XMYRXTXJUVHUVKOXMXROXMYQXJBUVHOXJUVHSUVKXMXNXQXMXNYPXJUVHUVKXNXJUVHSZXMXPXNXM
  YOXNXJUVHUVKKXMXJXOKXMUUEXOXJUVHUVJUVKUVIXOXJUVHSWJUVLTTWKXTXJUVHSWLWMXMXNYEX
  MXNUUBXJUVHUVKUVLXMYDXNXMUUAXNXJUVHUVKKXMXJYCKXMUUEYCXJUVHUVJUVKUVIYCXJUVHSWJ
  UVLTTTXMYJXNXMUUGXNXJUVHUVKQXMYHYIQXMUUFYIXJUVHQXJUVHSUVKUVHXJXJUUEUVIWNYIXJU
  VHSWOUVLTWPWQXAUUSUVEUVBUVDUUJUVHDEWRXMUVAXMUUIUUSUVHADEWSZXMUURUUTXMUUDUUHUU
  SUVHUVMXMUUPUUQXMYTUUCUUSUVHUVMXMUUOXMYSUUSUVHUVMXMUUNXTXMYRXTUUSUVHUVMOXMUUM
  OXMYQUUSBUVHDEWTUVMXMXNUULXMXNYPUUSUVHUVMADEXBZXMUUKXNXMYOXNUUSUVHUVMADBEXCUV
  NTTWKADEXDWLWMADCEXETADEXFWPWQXAXGR $. $}
