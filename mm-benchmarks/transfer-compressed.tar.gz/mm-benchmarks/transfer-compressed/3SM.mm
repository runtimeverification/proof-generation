$c 2R4 Tw #Symbol 7h4 -gg zw JAQ vA4 #Pattern ( ewk xB4 IAQ 9R4 3BA #Variable SwE #SetVariable vR4 4w #ElementVariable IQE ) $.
$v CQ qwg Bw oAg Cw 2gg $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Cg $f #Pattern Cw $.
4g $a #Pattern ( 4w Bw CQ ) $.
IAE $a #Pattern IQE $.
SgE $a #Pattern ( SwE Bw CQ ) $.
${ lgE $e zw ( Tw Bw CQ ) $.
   lwE $e zw ( Tw CQ Cw ) $.
   mAE $a zw ( Tw Bw Cw ) $. $}
${ wAE $e zw ( Tw Bw CQ ) $.
   wQE $e zw ( Tw Bw Cw ) $.
   wgE $a zw ( Tw Bw ( 4w CQ Cw ) ) $. $}
HwQ $a #Pattern ( IAQ Bw CQ ) $.
IwQ $a #Pattern ( JAQ Bw ) $.
nwg $f #Pattern oAg $.
qgg $f #Pattern qwg $.
2Qg $f #ElementVariable 2gg $.
-Qg $a #Pattern -gg $.
egk $a #Pattern ewk $.
uw4 $a #Pattern vA4 $.
2xA $a #Pattern ( 3BA oAg qwg ) $.
6BA $a zw ( Tw ( 4w ( SwE oAg ewk ) ( SwE qwg -gg ) ) ( SwE ( 3BA oAg qwg ) -gg ) ) $.
vB4 $a #Pattern vR4 $.
wx4 $a #Pattern xB4 $.
2B4 $a #Pattern 2R4 $.
7R4 $a #Pattern 7h4 $.
9B4 $a #Pattern 9R4 $.
Wh8 $a #Pattern 2gg $.
7CE $a zw ( Tw ( 4w ( JAQ 2gg ) IQE ) ( SwE ( 3BA ( IAQ ewk 2R4 ) ( 3BA ( IAQ ewk vR4 ) ( 3BA ( IAQ ewk 7h4 ) ( 3BA ( IAQ ewk xB4 ) vA4 ) ) ) ) -gg ) ) $.
yCM $a zw ( Tw ( 4w ( JAQ 2gg ) IQE ) ( SwE ( IAQ ewk 9R4 ) ewk ) ) $.
${ 3SM $p zw ( Tw ( 4w ( JAQ 2gg ) IQE ) ( SwE ( 3BA ( IAQ ewk 9R4 ) ( 3BA ( IAQ ewk 2R4 ) ( 3BA ( IAQ ewk vR4 ) ( 3BA ( IAQ ewk 7h4 ) ( 3BA ( IAQ ewk xB4 ) vA4 ) ) ) ) ) -gg ) ) $=
  ( Wh8 IwQ IAE 4g egk 9B4 HwQ SgE 2B4 vB4 7R4 wx4 uw4 2xA -Qg yCM 7CE wgE 6BA
  mAE ) ABCDEZFGHZFIZFJHFKHFLHFMHNOOOOZPIZEUCUEOPIUBUDUFAQARSUCUETUA $. $}
