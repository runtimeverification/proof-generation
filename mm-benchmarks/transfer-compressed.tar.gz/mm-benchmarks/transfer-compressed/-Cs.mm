$c #Symbol -g4 zBI 8Q4 pwk rgk pgg #Pattern 0Q4 ( rwg LAQ ewk IAQ Wgk Hg8 #Variable #SetVariable iA vR4 #ElementVariable 8hw ) $.
$v Ow CQ qwg Bw Cw sgg tAg 4wg ngg xX 3gg Kw ph0 oAg 5Qg tgg 4Ag $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Cg $f #Pattern Cw $.
Kg $f #ElementVariable Kw $.
Og $f #Variable Ow $.
SA $a #Variable Kw $.
${ $d xX ph0 $.
   IQI $a iA Bw Bw CQ Ow $. $}
HwQ $a #Pattern ( IAQ Bw CQ ) $.
KwQ $a #Pattern ( LAQ Bw CQ Cw ) $.
nQg $f #Variable ngg $.
nwg $f #Pattern oAg $.
pQg $a #Pattern pgg $.
qgg $f #Pattern qwg $.
rgg $a #Pattern ( rwg oAg qwg ) $.
sQg $f #Pattern sgg $.
swg $f #Pattern tAg $.
tQg $f #Pattern tgg $.
3Qg $f #ElementVariable 3gg $.
3wg $f #ElementVariable 4Ag $.
4gg $f #ElementVariable 4wg $.
5Ag $f #ElementVariable 5Qg $.
WQk $a #Pattern Wgk $.
egk $a #Pattern ewk $.
pgk $a #Pattern pwk $.
rQk $a #Pattern rgk $.
${ 1Q4 $e iA qwg tAg oAg ngg $.
   1g4 $e iA sgg tgg oAg ngg $.
   1w4 $a iA ( 0Q4 qwg sgg ) ( 0Q4 tAg tgg ) oAg ngg $. $}
8A4 $a #Pattern ( 8Q4 oAg ) $.
${ Ag8 $e iA qwg tAg oAg ngg $.
   Aw8 $e iA sgg tgg oAg ngg $.
   BA8 $a iA ( -g4 qwg sgg ) ( -g4 tAg tgg ) oAg ngg $. $}
HQ8 $a #Pattern ( Hg8 oAg ) $.
yxI $a #Pattern ( zBI oAg qwg ) $.
8Rw $a #Pattern 8hw $.
vB4 $a #Pattern vR4 $.
XiU $a #Pattern 3gg $.
XyU $a #Pattern 4wg $.
YCU $a #Pattern 5Qg $.
6is $a #Pattern ( zBI 5Qg 4Ag ) $.
6ys $a #Pattern ( 0Q4 ( Hg8 ( rwg ( LAQ pwk pgg ( zBI 5Qg 4Ag ) ) 3gg ) ) 4wg ) $.
9ys $a #Pattern ( 0Q4 ( Hg8 ( rwg ( LAQ pwk pgg ( zBI 5Qg ( LAQ ewk Wgk ( IAQ ewk vR4 ) ) ) ) 3gg ) ) 4wg ) $.
.ys $a iA ( Hg8 ( rwg ( LAQ pwk pgg ( zBI 5Qg ( LAQ ewk Wgk ( IAQ ewk vR4 ) ) ) ) 3gg ) ) ( Hg8 ( rwg ( LAQ pwk pgg ( zBI 5Qg 4Ag ) ) 3gg ) ) ( LAQ ewk Wgk ( IAQ ewk vR4 ) ) 4Ag $.
${ -Cs $p iA ( -g4 ( 0Q4 ( Hg8 ( rwg ( LAQ pwk pgg ( zBI 5Qg ( LAQ ewk Wgk ( IAQ ewk vR4 ) ) ) ) 3gg ) ) 4wg ) ( 8Q4 ( IAQ rgk 8hw ) ) ) ( -g4 ( 0Q4 ( Hg8 ( rwg ( LAQ pwk pgg ( zBI 5Qg 4Ag ) ) 3gg ) ) 4wg ) ( 8Q4 ( IAQ rgk 8hw ) ) ) ( LAQ ewk Wgk ( IAQ ewk vR4 ) ) 4Ag $=
  ( SA egk WQk vB4 HwQ KwQ 9ys rQk 8Rw 8A4 6ys pgk pQg rgg HQ8 IQI YCU yxI XiU
  XyU 6is .ys 1w4 BA8 ) BEZFGFHIJZACDKLMINZABCDOUKUIUJPQDUAUJUBJAUCZRSCUDZPQBDU
  EJULRSUMABDUFUMUJUITUGUKUJUITUH $. $}
