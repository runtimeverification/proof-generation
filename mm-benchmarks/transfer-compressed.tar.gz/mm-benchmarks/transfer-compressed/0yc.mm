$c ewk xB4 IAQ Tw #Symbol #Variable SwE #SetVariable zw 4w JAQ #ElementVariable IQE #Pattern ) ( $.
$v Cw 2gg CQ Bw $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Cg $f #Pattern Cw $.
4g $a #Pattern ( 4w Bw CQ ) $.
IAE $a #Pattern IQE $.
SgE $a #Pattern ( SwE Bw CQ ) $.
nAE $a zw IQE $.
${ wAE $e zw ( Tw Bw CQ ) $.
   wQE $e zw ( Tw Bw Cw ) $.
   wgE $a zw ( Tw Bw ( 4w CQ Cw ) ) $. $}
${ NwM $e zw CQ $.
   OAM $a zw ( Tw Bw CQ ) $. $}
HwQ $a #Pattern ( IAQ Bw CQ ) $.
IwQ $a #Pattern ( JAQ Bw ) $.
2Qg $f #ElementVariable 2gg $.
egk $a #Pattern ewk $.
wx4 $a #Pattern xB4 $.
Wh8 $a #Pattern 2gg $.
zyE $a zw ( Tw ( 4w ( JAQ 2gg ) IQE ) ( SwE ( IAQ ewk xB4 ) ewk ) ) $.
${ 0yc $p zw ( Tw ( 4w ( JAQ 2gg ) IQE ) ( 4w ( SwE ( IAQ ewk xB4 ) ewk ) IQE ) ) $=
  ( Wh8 IwQ IAE 4g egk wx4 HwQ SgE zyE nAE OAM wgE ) ABCDEZFGHFIDAJNDKLM $. $}
