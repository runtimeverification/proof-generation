$c 0wM ww4 #Symbol #Variable #SetVariable iA rwM YQk #ElementVariable 7BI #Pattern ) ( $.
$v 7Ag Ow ph6 CQ xX DQ Ew Bw Kw Cw 6Ag 2gg nR4 EQ y Dw LQ $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Cg $f #Pattern Cw $.
DA $f #Pattern DQ $.
Dg $f #Pattern Dw $.
EA $f #Pattern EQ $.
Eg $f #Pattern Ew $.
Kg $f #ElementVariable Kw $.
LA $f #ElementVariable LQ $.
Og $f #Variable Ow $.
SA $a #Variable Kw $.
${ $d xX y $.
   $d y ph6 $.
   OAQ $e iA Bw DQ Ew Ow $.
   OQQ $e iA CQ Dw Ew Ow $.
   OgQ $e iA Cw EQ Ew Ow $.
   OwQ $a iA ( rwM Bw CQ LQ Cw ) ( rwM DQ Dw LQ EQ ) Ew Ow $. $}
2Qg $f #ElementVariable 2gg $.
5wg $f #ElementVariable 6Ag $.
6wg $f #ElementVariable 7Ag $.
YAk $a #Pattern YQk $.
nB4 $f #ElementVariable nR4 $.
Wh8 $a #Pattern 2gg $.
6h8 $a #Pattern nR4 $.
CCE $a #Pattern ( 0wM YQk 2gg 6Ag ( 7BI ww4 7Ag ) ) $.
8iM $a #Pattern ( 0wM YQk 2gg 6Ag ( 7BI ww4 nR4 ) ) $.
8yM $a iA YQk YQk nR4 7Ag $.
9yM $a iA 2gg 2gg nR4 7Ag $.
.yM $a iA ( 0wM YQk 2gg 6Ag ( 7BI ww4 nR4 ) ) ( 0wM YQk 2gg 6Ag ( 7BI ww4 7Ag ) ) nR4 7Ag $.
${ -CM $p iA ( rwM YQk 2gg 6Ag ( 0wM YQk 2gg 6Ag ( 7BI ww4 nR4 ) ) ) ( rwM YQk 2gg 6Ag ( 0wM YQk 2gg 6Ag ( 7BI ww4 7Ag ) ) ) nR4 7Ag $=
  ( YAk Wh8 8iM CCE 6h8 SA 8yM 9yM .yM OwQ ) EAFZABDGEOABCHDIBCJCDKACDLABCDMN
  $. $}
