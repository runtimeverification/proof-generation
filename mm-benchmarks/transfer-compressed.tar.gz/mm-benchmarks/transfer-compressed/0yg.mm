$c #Symbol Tw #Variable SwE #SetVariable zw 4w YQk #ElementVariable IQE pgg #Pattern ) ( $.
$v 5Qg Cw CQ -Bw Bw $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Cg $f #Pattern Cw $.
4g $a #Pattern ( 4w Bw CQ ) $.
IAE $a #Pattern IQE $.
SgE $a #Pattern ( SwE Bw CQ ) $.
lQE $a zw ( Tw Bw Bw ) $.
${ lgE $e zw ( Tw Bw CQ ) $.
   lwE $e zw ( Tw CQ Cw ) $.
   mAE $a zw ( Tw Bw Cw ) $. $}
ugE $a zw ( Tw ( 4w Bw CQ ) Bw ) $.
uwE $a zw ( Tw ( 4w Bw CQ ) CQ ) $.
pQg $a #Pattern pgg $.
5Ag $f #ElementVariable 5Qg $.
YAk $a #Pattern YQk $.
.xw $f #ElementVariable -Bw $.
YCU $a #Pattern 5Qg $.
yyg $a #Pattern -Bw $.
zCg $a #Pattern ( 4w ( SwE 5Qg pgg ) ( 4w ( SwE -Bw YQk ) IQE ) ) $.
${ 0yg $p zw ( Tw ( 4w ( SwE 5Qg pgg ) ( 4w ( SwE -Bw YQk ) IQE ) ) ( SwE -Bw YQk ) ) $=
  ( zCg yyg YAk SgE IAE 4g YCU pQg uwE ugE lQE mAE ) ABCBDEFZGHZOAIJFPKPOOOGLOM
  NN $. $}
