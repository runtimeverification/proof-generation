$c Uw zBA PgE 2R4 Tw #Symbol 7h4 cwE zw JAQ pgg #Pattern ( rwg 0wM LAQ ewk tQM IAQ Wgk #Variable SwE #SetVariable 4w rwM #ElementVariable IQE mwg xQg ) $.
$v CQ qwg Bw Kw ph1 oAg Cw 6Ag 2gg ph0 GQ x $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Cg $f #Pattern Cw $.
GA $f #Pattern GQ $.
Kg $f #ElementVariable Kw $.
Ug $a #Pattern ( Uw Kw Bw ) $.
4g $a #Pattern ( 4w Bw CQ ) $.
IAE $a #Pattern IQE $.
PQE $a #Pattern ( PgE Bw CQ ) $.
${ lgE $e zw ( Tw Bw CQ ) $.
   lwE $e zw ( Tw CQ Cw ) $.
   mAE $a zw ( Tw Bw Cw ) $. $}
nAE $a zw IQE $.
${ NwM $e zw CQ $.
   OAM $a zw ( Tw Bw CQ ) $. $}
HwQ $a #Pattern ( IAQ Bw CQ ) $.
IwQ $a #Pattern ( JAQ Bw ) $.
KwQ $a #Pattern ( LAQ Bw CQ Cw ) $.
${ $d x ph0 $.
   $d x ph1 $.
   vwY $e zw ( Tw GQ ( SwE CQ Bw ) ) $.
   wAY $e zw ( Tw GQ ( tQM cwE ( rwM Bw cwE Kw ( 0wM Bw cwE Kw CQ ) ) ) ) $.
   wQY $a zw ( Tw GQ ( Uw Kw ( PgE Kw CQ ) ) ) $. $}
mgg $a #Pattern mwg $.
nwg $f #Pattern oAg $.
pQg $a #Pattern pgg $.
qgg $f #Pattern qwg $.
rgg $a #Pattern ( rwg oAg qwg ) $.
xAg $a #Pattern xQg $.
2Qg $f #ElementVariable 2gg $.
5wg $f #ElementVariable 6Ag $.
WQk $a #Pattern Wgk $.
egk $a #Pattern ewk $.
yxA $a #Pattern ( zBA oAg qwg ) $.
2B4 $a #Pattern 2R4 $.
7R4 $a #Pattern 7h4 $.
Wh8 $a #Pattern 2gg $.
BCE $a #Pattern 6Ag $.
2jM $a zw ( Tw IQE ( tQM cwE ( rwM mwg cwE 6Ag ( 0wM mwg cwE 6Ag ( rwg ( LAQ Wgk pgg ( zBA ( LAQ ewk Wgk ( IAQ ewk 7h4 ) ) ( LAQ ewk Wgk ( IAQ ewk 2R4 ) ) ) ) xQg ) ) ) ) ) $.
2zM $a zw ( Tw IQE ( SwE ( rwg ( LAQ Wgk pgg ( zBA ( LAQ ewk Wgk ( IAQ ewk 7h4 ) ) ( LAQ ewk Wgk ( IAQ ewk 2R4 ) ) ) ) xQg ) mwg ) ) $.
${ 4DM $p zw ( Tw ( 4w ( JAQ 2gg ) IQE ) ( Uw 6Ag ( PgE 6Ag ( rwg ( LAQ Wgk pgg ( zBA ( LAQ ewk Wgk ( IAQ ewk 7h4 ) ) ( LAQ ewk Wgk ( IAQ ewk 2R4 ) ) ) ) xQg ) ) ) ) $=
  ( Wh8 IwQ IAE 4g BCE WQk pQg egk 7R4 HwQ KwQ 2B4 yxA xAg rgg PQE Ug nAE OAM
  mgg 2zM 2jM wQY mAE ) ACDEFZEBGHIJHJKLMJHJNLMOMPQZRBSUGETUAUBUHEBUCBUDUEUF $. $}
