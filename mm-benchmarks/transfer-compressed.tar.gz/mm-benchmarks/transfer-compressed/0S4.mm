$c Uw PgE Tw #Symbol zw JAQ rgk pgg #Pattern ( rwg 0wM LAQ tQM IAQ 0h4 #Variable SwE #SetVariable iA OA0 4w rwM #ElementVariable IQE mwg xQg ) $.
$v th1 yhs Fw CQ Bw Cw 2gg sgg ngg FQ z ph2 Ew ph0 x Lw LQ 7Ag Ow ph6 qwg DQ ph1 EQ y th2 Dw tAg HQ xX Gw th0 Hw Kw oAg 6Ag GQ 6gg nR4 tgg $.
$d z y $.
$d z x $.
$d y x $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Cg $f #Pattern Cw $.
DA $f #Pattern DQ $.
Dg $f #Pattern Dw $.
EA $f #Pattern EQ $.
Eg $f #Pattern Ew $.
FA $f #Pattern FQ $.
Fg $f #Pattern Fw $.
GA $f #Pattern GQ $.
Gg $f #Pattern Gw $.
HA $f #Pattern HQ $.
Hg $f #Pattern Hw $.
Kg $f #ElementVariable Kw $.
LA $f #ElementVariable LQ $.
Lg $f #ElementVariable Lw $.
Og $f #Variable Ow $.
SA $a #Variable Kw $.
jg $a iA Bw Ow Bw Ow $.
${ kg $e iA CQ DQ Bw Ow $.
   kw $e iA Cw Dw Bw Ow $.
   lA $a iA ( Tw CQ Cw ) ( Tw DQ Dw ) Bw Ow $. $}
4g $a #Pattern ( 4w Bw CQ ) $.
IAE $a #Pattern IQE $.
SgE $a #Pattern ( SwE Bw CQ ) $.
${ lgE $e zw ( Tw Bw CQ ) $.
   lwE $e zw ( Tw CQ Cw ) $.
   mAE $a zw ( Tw Bw Cw ) $. $}
nAE $a zw IQE $.
${ wAE $e zw ( Tw Bw CQ ) $.
   wQE $e zw ( Tw Bw Cw ) $.
   wgE $a zw ( Tw Bw ( 4w CQ Cw ) ) $. $}
${ $d xX ph0 $.
   IQI $a iA Bw Bw CQ Ow $. $}
${ KAI $e iA CQ DQ Bw Ow $.
   KQI $e iA Cw Dw Bw Ow $.
   KgI $a iA ( 4w CQ Cw ) ( 4w DQ Dw ) Bw Ow $. $}
${ OgI $e iA CQ DQ Bw Ow $.
   OwI $e iA Cw Dw Bw Ow $.
   PAI $a iA ( SwE CQ Cw ) ( SwE DQ Dw ) Bw Ow $. $}
${ NwM $e zw CQ $.
   OAM $a zw ( Tw Bw CQ ) $. $}
rgM $a #Pattern ( rwM Bw CQ Kw Cw ) $.
tAM $a #Pattern ( tQM Bw CQ ) $.
HwQ $a #Pattern ( IAQ Bw CQ ) $.
KwQ $a #Pattern ( LAQ Bw CQ Cw ) $.
${ $d xX y $.
   $d y ph6 $.
   OAQ $e iA Bw DQ Ew Ow $.
   OQQ $e iA CQ Dw Ew Ow $.
   OgQ $e iA Cw EQ Ew Ow $.
   OwQ $a iA ( rwM Bw CQ LQ Cw ) ( rwM DQ Dw LQ EQ ) Ew Ow $. $}
${ QAQ $e iA Bw Cw Dw Ow $.
   QQQ $e iA CQ DQ Dw Ow $.
   QgQ $a iA ( tQM Bw CQ ) ( tQM Cw DQ ) Dw Ow $. $}
${ XgQ $e iA Bw Dw Fw Ow $.
   XwQ $e iA CQ EQ Fw Ow $.
   YAQ $e iA Cw Ew Fw Ow $.
   YQQ $e iA DQ FQ Fw Ow $.
   YgQ $a iA ( 0wM Bw CQ Cw DQ ) ( 0wM Dw EQ Ew FQ ) Fw Ow $. $}
${ $d z ph0 $.
   $d z ph1 $.
   $d z ph2 $.
   $d z y $.
   $d z x $.
   $d z th1 $.
   $d z th2 $.
   $d x ph0 $.
   $d y th0 $.
   lAY $e zw ( Tw GQ ( Uw Kw ( PgE Kw Bw ) ) ) $.
   lQY $e zw ( Tw ( 4w GQ Gw ) CQ ) $.
   lgY $e iA ( Tw HQ Cw ) ( Tw Gw CQ ) Bw LQ $.
   lwY $e iA ( Tw Hw DQ ) ( Tw Gw CQ ) Lw LQ $.
   mAY $a zw ( Tw ( 4w GQ HQ ) Cw ) $. $}
mgg $a #Pattern mwg $.
nQg $f #Variable ngg $.
nwg $f #Pattern oAg $.
pQg $a #Pattern pgg $.
qgg $f #Pattern qwg $.
rgg $a #Pattern ( rwg oAg qwg ) $.
sQg $f #Pattern sgg $.
swg $f #Pattern tAg $.
tQg $f #Pattern tgg $.
${ uQg $e iA qwg tAg oAg ngg $.
   ugg $e iA sgg tgg oAg ngg $.
   uwg $a iA ( rwg qwg sgg ) ( rwg tAg tgg ) oAg ngg $. $}
xAg $a #Pattern xQg $.
2Qg $f #ElementVariable 2gg $.
5wg $f #ElementVariable 6Ag $.
6Qg $f #ElementVariable 6gg $.
6wg $f #ElementVariable 7Ag $.
rQk $a #Pattern rgk $.
Nw0 $a #Pattern ( OA0 oAg ) $.
QQ0 $a zw ( Tw ( SwE oAg mwg ) ( SwE ( OA0 oAg ) pgg ) ) $.
yRs $f #ElementVariable yhs $.
nB4 $f #ElementVariable nR4 $.
0R4 $a #Pattern 0h4 $.
Wh8 $a #Pattern 2gg $.
6h8 $a #Pattern nR4 $.
-CA $a #Pattern 7Ag $.
-yA $a #Pattern 6gg $.
BCE $a #Pattern 6Ag $.
pyQ $a #Pattern ( 4w ( JAQ 2gg ) ( 4w ( SwE 7Ag mwg ) IQE ) ) $.
riQ $a #Pattern ( rwg 6gg 7Ag ) $.
ryQ $a #Pattern ( 0wM mwg 2gg 6Ag ( rwg 6gg 7Ag ) ) $.
sCQ $a zw ( Tw ( 4w ( 4w ( JAQ 2gg ) ( 4w ( SwE 7Ag mwg ) IQE ) ) ( 4w ( SwE 6gg pgg ) IQE ) ) ( tQM 2gg ( rwM mwg 2gg 6Ag ( 0wM mwg 2gg 6Ag ( rwg 6gg 7Ag ) ) ) ) ) $.
siQ $a #Pattern ( 0wM mwg 2gg 6Ag ( rwg nR4 7Ag ) ) $.
tSQ $a iA ( 4w ( SwE nR4 pgg ) IQE ) ( 4w ( SwE 6gg pgg ) IQE ) nR4 6gg $.
uiQ $a iA ( tQM 2gg ( rwM mwg 2gg 6Ag ( 0wM mwg 2gg 6Ag ( rwg nR4 7Ag ) ) ) ) ( tQM 2gg ( rwM mwg 2gg 6Ag ( 0wM mwg 2gg 6Ag ( rwg 6gg 7Ag ) ) ) ) nR4 6gg $.
uyQ $a zw ( Tw ( 4w ( JAQ 2gg ) ( 4w ( SwE 7Ag mwg ) IQE ) ) ( 4w ( JAQ 2gg ) ( 4w ( SwE 7Ag mwg ) IQE ) ) ) $.
zi4 $a zw ( Tw ( 4w ( JAQ 2gg ) ( 4w ( SwE 7Ag mwg ) IQE ) ) ( Uw yhs ( PgE yhs ( OA0 ( rwg ( LAQ rgk pgg ( IAQ rgk 0h4 ) ) xQg ) ) ) ) ) $.
zy4 $a #Pattern ( 0wM mwg 2gg 6Ag ( rwg ( OA0 ( rwg ( LAQ rgk pgg ( IAQ rgk 0h4 ) ) xQg ) ) 7Ag ) ) $.
0C4 $a zw ( Tw ( 4w ( JAQ 2gg ) ( 4w ( SwE 7Ag mwg ) IQE ) ) ( SwE ( rwg ( LAQ rgk pgg ( IAQ rgk 0h4 ) ) xQg ) mwg ) ) $.
${ 0S4 $p zw ( Tw ( 4w ( JAQ 2gg ) ( 4w ( SwE 7Ag mwg ) IQE ) ) ( tQM 2gg ( rwM mwg 2gg 6Ag ( 0wM mwg 2gg 6Ag ( rwg ( OA0 ( rwg ( LAQ rgk pgg ( IAQ rgk 0h4 ) ) xQg ) ) 7Ag ) ) ) ) ) $=
  ( 6Qg nB4 yRs pyQ rQk pQg rgg SgE IAE 4g mgg rgM tAM mAE wgE IQI lA 0R4 SA jg
  HwQ KwQ xAg Nw0 Wh8 zy4 uyQ 0C4 QQ0 nAE OAM ryQ siQ -yA 6h8 zi4 sCQ PAI KgI
  BCE -CA riQ uwg YgQ OwQ QgQ tSQ uiQ mAY ) ACGZVMHIHUAUDUEUFJZUGZIKZLMZMAUHZNV
  RABCUIZBOZPZVMVMVQACUJVMVPLVMVNNKVPACUKVNULQVMLUMUNRRVOVRNVRABDCUOZBOZPZWAVRN
  VRABCEUPBOPZVMDUQZIKZLMZVQEURZIKLMZFDEACFUSABDCUTVOVQWAWHWDDUBZVOVPLWGLWKVOVO
  IWFIWKVOWKUCZIVOWKSVALVOWKSVBVRVTVRWCVOWKVRVOWKSZNVRVSNVRWBVOBWKNVOWKSZWMNVRB
  VCZVOCVDZJNVRWODCVEVOWKWNWMWOVOWKSWKVOVOWPWFWPWLWPVOWKSVFVGVHVITWIWJWEWHWDWKD
  EVJABDCEVKTVLQ $. $}
