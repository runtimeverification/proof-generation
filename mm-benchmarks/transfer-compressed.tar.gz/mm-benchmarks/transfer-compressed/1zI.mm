$c Uw PgE Tw #Symbol cwE 5x4 zw jww JAQ rgk pgg #Pattern ( rwg 0wM LAQ tQM IAQ #Variable SwE #SetVariable 4w rwM #ElementVariable IQE mwg xQg ) $.
$v 7Ag yhs CQ qwg Bw Kw ph1 oAg Cw 2gg ph0 GQ x $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Cg $f #Pattern Cw $.
GA $f #Pattern GQ $.
Kg $f #ElementVariable Kw $.
Ug $a #Pattern ( Uw Kw Bw ) $.
IAE $a #Pattern IQE $.
PQE $a #Pattern ( PgE Bw CQ ) $.
${ lgE $e zw ( Tw Bw CQ ) $.
   lwE $e zw ( Tw CQ Cw ) $.
   mAE $a zw ( Tw Bw Cw ) $. $}
nAE $a zw IQE $.
${ NwM $e zw CQ $.
   OAM $a zw ( Tw Bw CQ ) $. $}
HwQ $a #Pattern ( IAQ Bw CQ ) $.
KwQ $a #Pattern ( LAQ Bw CQ Cw ) $.
${ $d x ph0 $.
   $d x ph1 $.
   vwY $e zw ( Tw GQ ( SwE CQ Bw ) ) $.
   wAY $e zw ( Tw GQ ( tQM cwE ( rwM Bw cwE Kw ( 0wM Bw cwE Kw CQ ) ) ) ) $.
   wQY $a zw ( Tw GQ ( Uw Kw ( PgE Kw CQ ) ) ) $. $}
nwg $f #Pattern oAg $.
pQg $a #Pattern pgg $.
qgg $f #Pattern qwg $.
rgg $a #Pattern ( rwg oAg qwg ) $.
xAg $a #Pattern xQg $.
2Qg $f #ElementVariable 2gg $.
6wg $f #ElementVariable 7Ag $.
rQk $a #Pattern rgk $.
jgw $a #Pattern ( jww oAg ) $.
yRs $f #ElementVariable yhs $.
5h4 $a #Pattern 5x4 $.
jCA $a zw ( Tw IQE ( SwE ( jww ( rwg ( LAQ rgk pgg ( IAQ rgk 5x4 ) ) xQg ) ) pgg ) ) $.
7SA $a #Pattern yhs $.
pyQ $a #Pattern ( 4w ( JAQ 2gg ) ( 4w ( SwE 7Ag mwg ) IQE ) ) $.
1jI $a zw ( Tw IQE ( tQM cwE ( rwM pgg cwE yhs ( 0wM pgg cwE yhs ( jww ( rwg ( LAQ rgk pgg ( IAQ rgk 5x4 ) ) xQg ) ) ) ) ) ) $.
${ 1zI $p zw ( Tw ( 4w ( JAQ 2gg ) ( 4w ( SwE 7Ag mwg ) IQE ) ) ( Uw yhs ( PgE yhs ( jww ( rwg ( LAQ rgk pgg ( IAQ rgk 5x4 ) ) xQg ) ) ) ) ) $=
  ( pyQ IAE 7SA rQk pQg 5h4 HwQ KwQ xAg rgg jgw PQE Ug nAE OAM jCA 1jI wQY mAE
  ) ABDZECFGHGIJKLMNZOCPUCEQRHUDECSCTUAUB $. $}
