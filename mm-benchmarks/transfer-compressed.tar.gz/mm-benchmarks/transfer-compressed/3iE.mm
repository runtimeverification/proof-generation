$c Tw #Symbol 7h4 -gg zw JAQ vA4 #Pattern ( 0wM ewk xB4 tQM IAQ 3BA #Variable #SetVariable vR4 4w rwM #ElementVariable IQE ) $.
$v yhs CQ qwg DQ Bw Kw oAg Cw 2gg $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Cg $f #Pattern Cw $.
DA $f #Pattern DQ $.
Kg $f #ElementVariable Kw $.
4g $a #Pattern ( 4w Bw CQ ) $.
IAE $a #Pattern IQE $.
${ lgE $e zw ( Tw Bw CQ ) $.
   lwE $e zw ( Tw CQ Cw ) $.
   mAE $a zw ( Tw Bw Cw ) $. $}
nAE $a zw IQE $.
${ wAE $e zw ( Tw Bw CQ ) $.
   wQE $e zw ( Tw Bw Cw ) $.
   wgE $a zw ( Tw Bw ( 4w CQ Cw ) ) $. $}
${ NwM $e zw CQ $.
   OAM $a zw ( Tw Bw CQ ) $. $}
rgM $a #Pattern ( rwM Bw CQ Kw Cw ) $.
tAM $a #Pattern ( tQM Bw CQ ) $.
0gM $a #Pattern ( 0wM Bw CQ Cw DQ ) $.
HwQ $a #Pattern ( IAQ Bw CQ ) $.
IwQ $a #Pattern ( JAQ Bw ) $.
nwg $f #Pattern oAg $.
qgg $f #Pattern qwg $.
2Qg $f #ElementVariable 2gg $.
-Qg $a #Pattern -gg $.
egk $a #Pattern ewk $.
uw4 $a #Pattern vA4 $.
2xA $a #Pattern ( 3BA oAg qwg ) $.
yRs $f #ElementVariable yhs $.
vB4 $a #Pattern vR4 $.
wx4 $a #Pattern xB4 $.
7R4 $a #Pattern 7h4 $.
Wh8 $a #Pattern 2gg $.
.h8 $a zw ( Tw ( 4w IQE ( 4w ( JAQ 2gg ) IQE ) ) ( JAQ 2gg ) ) $.
7SA $a #Pattern yhs $.
3SE $a zw ( Tw ( 4w ( JAQ 2gg ) IQE ) ( tQM 2gg ( rwM -gg 2gg yhs ( 0wM -gg 2gg yhs ( 3BA ( IAQ ewk vR4 ) ( 3BA ( IAQ ewk 7h4 ) ( 3BA ( IAQ ewk xB4 ) vA4 ) ) ) ) ) ) ) $.
${ 3iE $p zw ( Tw ( 4w IQE ( 4w ( JAQ 2gg ) IQE ) ) ( tQM 2gg ( rwM -gg 2gg yhs ( 0wM -gg 2gg yhs ( 3BA ( IAQ ewk vR4 ) ( 3BA ( IAQ ewk 7h4 ) ( 3BA ( IAQ ewk xB4 ) vA4 ) ) ) ) ) ) ) $=
  ( IAE Wh8 IwQ 4g -Qg 7SA egk vB4 HwQ 7R4 wx4 uw4 2xA 0gM rgM tAM .h8 nAE OAM
  wgE 3SE mAE ) CADZEZCFZFZUGUEGUEGUEBHIJKILKIMKNOOOPBQRUHUFCASUHCTUAUBABUCUD
  $. $}
