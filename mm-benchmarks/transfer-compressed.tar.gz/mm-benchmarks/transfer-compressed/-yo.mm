$c #Symbol #Variable SwE #SetVariable iA pwk #ElementVariable #Pattern ) ( $.
$v Ow CQ DQ Bw Kw 5Qg Cw nR4 Dw $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Cg $f #Pattern Cw $.
DA $f #Pattern DQ $.
Dg $f #Pattern Dw $.
Kg $f #ElementVariable Kw $.
Og $f #Variable Ow $.
SA $a #Variable Kw $.
jg $a iA Bw Ow Bw Ow $.
${ OgI $e iA CQ DQ Bw Ow $.
   OwI $e iA Cw Dw Bw Ow $.
   PAI $a iA ( SwE CQ Cw ) ( SwE DQ Dw ) Bw Ow $. $}
5Ag $f #ElementVariable 5Qg $.
pgk $a #Pattern pwk $.
nB4 $f #ElementVariable nR4 $.
6h8 $a #Pattern nR4 $.
YCU $a #Pattern 5Qg $.
-io $a iA pwk pwk nR4 5Qg $.
${ -yo $p iA ( SwE nR4 pwk ) ( SwE 5Qg pwk ) nR4 5Qg $=
  ( 6h8 pgk YCU SA jg -io PAI ) BCZJDAEDAFZJKGABHI $. $}
