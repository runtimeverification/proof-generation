$c #SetVariable iA ) #ElementVariable IQE #Symbol #Variable #Pattern ( $.
$v Ow CQ xX Bw Kw ph0 nR4 pxw $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Kg $f #ElementVariable Kw $.
Og $f #Variable Ow $.
SA $a #Variable Kw $.
IAE $a #Pattern IQE $.
${ $d xX ph0 $.
   IQI $a iA Bw Bw CQ Ow $. $}
phw $f #ElementVariable pxw $.
nB4 $f #ElementVariable nR4 $.
6h8 $a #Pattern nR4 $.
${ 2iY $p iA IQE IQE nR4 pxw $=
  ( IAE 6h8 SA IQI ) CBDAEF $. $}
