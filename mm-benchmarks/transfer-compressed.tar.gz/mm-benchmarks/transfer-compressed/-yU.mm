$c 0wM ww4 tQM #Symbol #Variable #SetVariable iA YQk #ElementVariable 7BI #Pattern ) ( $.
$v Ow CQ qwg qxw DQ Bw Kw oAg Cw 2gg nR4 Dw $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Cg $f #Pattern Cw $.
DA $f #Pattern DQ $.
Dg $f #Pattern Dw $.
Kg $f #ElementVariable Kw $.
Og $f #Variable Ow $.
SA $a #Variable Kw $.
0gM $a #Pattern ( 0wM Bw CQ Cw DQ ) $.
${ QAQ $e iA Bw Cw Dw Ow $.
   QQQ $e iA CQ DQ Dw Ow $.
   QgQ $a iA ( tQM Bw CQ ) ( tQM Cw DQ ) Dw Ow $. $}
nwg $f #Pattern oAg $.
qgg $f #Pattern qwg $.
2Qg $f #ElementVariable 2gg $.
YAk $a #Pattern YQk $.
wg4 $a #Pattern ww4 $.
6xI $a #Pattern ( 7BI oAg qwg ) $.
qhw $f #ElementVariable qxw $.
nB4 $f #ElementVariable nR4 $.
Wh8 $a #Pattern 2gg $.
6h8 $a #Pattern nR4 $.
7iU $a #Pattern qxw $.
.yU $a iA 2gg 2gg nR4 qxw $.
-iU $a iA ( 0wM YQk 2gg ( 7BI nR4 ww4 ) nR4 ) ( 0wM YQk 2gg ( 7BI qxw ww4 ) qxw ) nR4 qxw $.
${ -yU $p iA ( tQM 2gg ( 0wM YQk 2gg ( 7BI nR4 ww4 ) nR4 ) ) ( tQM 2gg ( 0wM YQk 2gg ( 7BI qxw ww4 ) qxw ) ) nR4 qxw $=
  ( Wh8 YAk 6h8 wg4 6xI 0gM 7iU SA .yU -iU QgQ ) ADZEOCFZGHPIOEOBJZGHQIPBKABCLA
  BCMN $. $}
