$c Ex0 LAQ IAQ Wgk Tw #Symbol #Variable SwE -gg #SetVariable zw 4w JAQ #ElementVariable IQE rgk #Pattern ) ( $.
$v CQ qwg Bw oAg 5Qg Cw sgg $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Cg $f #Pattern Cw $.
4g $a #Pattern ( 4w Bw CQ ) $.
IAE $a #Pattern IQE $.
SgE $a #Pattern ( SwE Bw CQ ) $.
${ lgE $e zw ( Tw Bw CQ ) $.
   lwE $e zw ( Tw CQ Cw ) $.
   mAE $a zw ( Tw Bw Cw ) $. $}
HwQ $a #Pattern ( IAQ Bw CQ ) $.
IwQ $a #Pattern ( JAQ Bw ) $.
KwQ $a #Pattern ( LAQ Bw CQ Cw ) $.
nwg $f #Pattern oAg $.
qgg $f #Pattern qwg $.
sQg $f #Pattern sgg $.
5Ag $f #ElementVariable 5Qg $.
.gg $a zw ( Tw ( 4w ( 4w ( JAQ oAg ) ( JAQ qwg ) ) ( SwE sgg oAg ) ) ( SwE ( LAQ oAg qwg sgg ) qwg ) ) $.
-Qg $a #Pattern -gg $.
WQk $a #Pattern Wgk $.
rQk $a #Pattern rgk $.
Eh0 $a #Pattern Ex0 $.
YCU $a #Pattern 5Qg $.
3yU $a zw ( Tw ( 4w ( SwE 5Qg -gg ) IQE ) ( 4w ( 4w ( JAQ rgk ) ( JAQ Wgk ) ) ( SwE ( IAQ rgk Ex0 ) rgk ) ) ) $.
${ 4CU $p zw ( Tw ( 4w ( SwE 5Qg -gg ) IQE ) ( SwE ( LAQ rgk Wgk ( IAQ rgk Ex0 ) ) Wgk ) ) $=
  ( YCU -Qg SgE IAE 4g rQk IwQ WQk Eh0 HwQ KwQ 3yU .gg mAE ) ABCDEFGHIHFGJKZGDF
  GIPLIDAMGIPNO $. $}
