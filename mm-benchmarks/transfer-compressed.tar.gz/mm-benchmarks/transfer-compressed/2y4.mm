$c Tw #Symbol 5x4 zw YQk JAQ pgg rgk #Pattern ( LAQ ewk IAQ #Variable SwE #SetVariable 4w #ElementVariable IQE ) $.
$v CQ qwg -Bw Bw oAg 5Qg Cw sgg $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Cg $f #Pattern Cw $.
4g $a #Pattern ( 4w Bw CQ ) $.
IAE $a #Pattern IQE $.
SgE $a #Pattern ( SwE Bw CQ ) $.
${ lgE $e zw ( Tw Bw CQ ) $.
   lwE $e zw ( Tw CQ Cw ) $.
   mAE $a zw ( Tw Bw Cw ) $. $}
nAE $a zw IQE $.
${ wAE $e zw ( Tw Bw CQ ) $.
   wQE $e zw ( Tw Bw Cw ) $.
   wgE $a zw ( Tw Bw ( 4w CQ Cw ) ) $. $}
${ NwM $e zw CQ $.
   OAM $a zw ( Tw Bw CQ ) $. $}
HwQ $a #Pattern ( IAQ Bw CQ ) $.
IwQ $a #Pattern ( JAQ Bw ) $.
KwQ $a #Pattern ( LAQ Bw CQ Cw ) $.
nwg $f #Pattern oAg $.
pQg $a #Pattern pgg $.
qgg $f #Pattern qwg $.
sQg $f #Pattern sgg $.
5Ag $f #ElementVariable 5Qg $.
.gg $a zw ( Tw ( 4w ( 4w ( JAQ oAg ) ( JAQ qwg ) ) ( SwE sgg oAg ) ) ( SwE ( LAQ oAg qwg sgg ) qwg ) ) $.
rQk $a #Pattern rgk $.
.xw $f #ElementVariable -Bw $.
5h4 $a #Pattern 5x4 $.
2yw $a #Pattern ( 4w ( SwE 5Qg ewk ) ( 4w ( SwE -Bw YQk ) IQE ) ) $.
2i4 $a zw ( Tw ( 4w ( SwE 5Qg ewk ) ( 4w ( SwE -Bw YQk ) IQE ) ) ( 4w ( 4w ( JAQ rgk ) ( JAQ pgg ) ) ( SwE ( IAQ rgk 5x4 ) rgk ) ) ) $.
${ 2y4 $p zw ( Tw ( 4w ( SwE 5Qg ewk ) ( 4w ( SwE -Bw YQk ) IQE ) ) ( 4w ( SwE ( LAQ rgk pgg ( IAQ rgk 5x4 ) ) pgg ) IQE ) ) $=
  ( 2yw rQk pQg 5h4 HwQ KwQ SgE IAE IwQ 4g 2i4 .gg mAE nAE OAM wgE ) ABCZDEDFGZ
  HEIZJSDKEKLTDILUAABMDETNOSJPQR $. $}
