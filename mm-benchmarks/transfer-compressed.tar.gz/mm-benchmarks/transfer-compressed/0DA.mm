$c LAQ #Symbol #Variable #SetVariable iA pwk #ElementVariable .gk #Pattern ) ( $.
$v Ow CQ DQ Ew Bw lh4 lB4 Kw Cw EQ mh4 Dw $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Cg $f #Pattern Cw $.
DA $f #Pattern DQ $.
Dg $f #Pattern Dw $.
EA $f #Pattern EQ $.
Eg $f #Pattern Ew $.
Kg $f #ElementVariable Kw $.
Og $f #Variable Ow $.
SA $a #Variable Kw $.
jg $a iA Bw Ow Bw Ow $.
KwQ $a #Pattern ( LAQ Bw CQ Cw ) $.
${ lAQ $e iA Bw DQ Ew Ow $.
   lQQ $e iA CQ Dw Ew Ow $.
   lgQ $e iA Cw EQ Ew Ow $.
   lwQ $a iA ( LAQ Bw CQ Cw ) ( LAQ DQ Dw EQ ) Ew Ow $. $}
pgk $a #Pattern pwk $.
.Qk $a #Pattern .gk $.
kx4 $f #ElementVariable lB4 $.
lR4 $f #ElementVariable lh4 $.
mR4 $f #ElementVariable mh4 $.
Wx8 $a #Pattern lh4 $.
XB8 $a #Pattern lB4 $.
YR8 $a #Pattern mh4 $.
cTA $a #Pattern ( LAQ .gk lh4 mh4 ) $.
zTA $a iA lB4 lB4 pwk lh4 $.
zzA $a iA ( LAQ .gk pwk mh4 ) ( LAQ .gk lh4 mh4 ) pwk lh4 $.
${ 0DA $p iA ( LAQ pwk lB4 ( LAQ .gk pwk mh4 ) ) ( LAQ lh4 lB4 ( LAQ .gk lh4 mh4 ) ) pwk lh4 $=
  ( pgk XB8 .Qk YR8 KwQ Wx8 cTA SA jg zTA zzA lwQ ) DAEZFDCGHBIPBCJDBKZDQLABMBC
  NO $. $}
