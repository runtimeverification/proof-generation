$c Uw 2R4 PgE Tw #Symbol cwE zw JAQ .gk Px0 pgg #Pattern ( rwg 0wM LAQ ewk tQM IAQ #Variable #SetVariable iA 4w #ElementVariable IQE xQg ) Vhc $.
$v th1 Fw CQ Bw Cw 2gg Pw FQ z ph2 Ew ph0 x Lw 6xw LQ Ow qwg DQ ph1 EQ y th2 Dw HQ xX Gw th0 Hw Kw oAg GQ $.
$d z y $.
$d z x $.
$d y x $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Cg $f #Pattern Cw $.
DA $f #Pattern DQ $.
Dg $f #Pattern Dw $.
EA $f #Pattern EQ $.
Eg $f #Pattern Ew $.
FA $f #Pattern FQ $.
Fg $f #Pattern Fw $.
GA $f #Pattern GQ $.
Gg $f #Pattern Gw $.
HA $f #Pattern HQ $.
Hg $f #Pattern Hw $.
Kg $f #ElementVariable Kw $.
LA $f #ElementVariable LQ $.
Lg $f #ElementVariable Lw $.
Og $f #Variable Ow $.
Pg $f #Symbol Pw $.
SA $a #Variable Kw $.
Sw $a #Pattern Pw $.
Ug $a #Pattern ( Uw Kw Bw ) $.
jg $a iA Bw Ow Bw Ow $.
${ kg $e iA CQ DQ Bw Ow $.
   kw $e iA Cw Dw Bw Ow $.
   lA $a iA ( Tw CQ Cw ) ( Tw DQ Dw ) Bw Ow $. $}
4g $a #Pattern ( 4w Bw CQ ) $.
IAE $a #Pattern IQE $.
cgE $a #Symbol cwE $.
${ lgE $e zw ( Tw Bw CQ ) $.
   lwE $e zw ( Tw CQ Cw ) $.
   mAE $a zw ( Tw Bw Cw ) $. $}
nAE $a zw IQE $.
${ wAE $e zw ( Tw Bw CQ ) $.
   wQE $e zw ( Tw Bw Cw ) $.
   wgE $a zw ( Tw Bw ( 4w CQ Cw ) ) $. $}
${ $d xX ph0 $.
   IQI $a iA Bw Bw CQ Ow $. $}
${ NwM $e zw CQ $.
   OAM $a zw ( Tw Bw CQ ) $. $}
tAM $a #Pattern ( tQM Bw CQ ) $.
0gM $a #Pattern ( 0wM Bw CQ Cw DQ ) $.
HwQ $a #Pattern ( IAQ Bw CQ ) $.
IwQ $a #Pattern ( JAQ Bw ) $.
KwQ $a #Pattern ( LAQ Bw CQ Cw ) $.
${ QAQ $e iA Bw Cw Dw Ow $.
   QQQ $e iA CQ DQ Dw Ow $.
   QgQ $a iA ( tQM Bw CQ ) ( tQM Cw DQ ) Dw Ow $. $}
${ XgQ $e iA Bw Dw Fw Ow $.
   XwQ $e iA CQ EQ Fw Ow $.
   YAQ $e iA Cw Ew Fw Ow $.
   YQQ $e iA DQ FQ Fw Ow $.
   YgQ $a iA ( 0wM Bw CQ Cw DQ ) ( 0wM Dw EQ Ew FQ ) Fw Ow $. $}
iwY $a zw ( Uw Kw ( PgE Kw cwE ) ) $.
${ $d z ph0 $.
   $d z ph1 $.
   $d z ph2 $.
   $d z y $.
   $d z x $.
   $d z th1 $.
   $d z th2 $.
   $d x ph0 $.
   $d y th0 $.
   lAY $e zw ( Tw GQ ( Uw Kw ( PgE Kw Bw ) ) ) $.
   lQY $e zw ( Tw ( 4w GQ Gw ) CQ ) $.
   lgY $e iA ( Tw HQ Cw ) ( Tw Gw CQ ) Bw LQ $.
   lwY $e iA ( Tw Hw DQ ) ( Tw Gw CQ ) Lw LQ $.
   mAY $a zw ( Tw ( 4w GQ HQ ) Cw ) $. $}
nwg $f #Pattern oAg $.
pQg $a #Pattern pgg $.
qgg $f #Pattern qwg $.
rgg $a #Pattern ( rwg oAg qwg ) $.
xAg $a #Pattern xQg $.
2Qg $f #ElementVariable 2gg $.
egk $a #Pattern ewk $.
.Qk $a #Pattern .gk $.
VRc $a #Pattern ( Vhc oAg ) $.
6hw $f #ElementVariable 6xw $.
Ph0 $a #Pattern Px0 $.
2B4 $a #Pattern 2R4 $.
Wh8 $a #Pattern 2gg $.
dB8 $a #Pattern 6xw $.
0h8 $a #Pattern ( PgE Kw cwE ) $.
5B8 $a zw ( Tw IQE ( 4w ( JAQ cwE ) IQE ) ) $.
-R8 $a iA ( 4w ( JAQ cwE ) IQE ) ( 4w ( JAQ 2gg ) IQE ) cwE 2gg $.
ASA $a iA ( 4w ( JAQ 6xw ) IQE ) ( 4w ( JAQ 2gg ) IQE ) 6xw 2gg $.
bCA $a iA .gk .gk cwE 2gg $.
bSA $a iA .gk .gk 6xw 2gg $.
0Sw $a zw ( Tw ( 4w IQE ( 4w ( JAQ 2gg ) IQE ) ) ( tQM 2gg ( 0wM .gk 2gg ( Vhc ( rwg ( LAQ ewk pgg ( IAQ ewk 2R4 ) ) xQg ) ) ( IAQ .gk Px0 ) ) ) ) $.
${ 0iw $p zw ( Tw IQE ( tQM cwE ( 0wM .gk cwE ( Vhc ( rwg ( LAQ ewk pgg ( IAQ ewk 2R4 ) ) xQg ) ) ( IAQ .gk Px0 ) ) ) ) $=
  ( 2Qg 6hw Kg IAE cgE Sw IwQ 4g .Qk egk pQg HwQ 0gM tAM OAM jg IQI YgQ QgQ lA
  2B4 KwQ xAg rgg VRc Ph0 nAE 5B8 wgE Wh8 dB8 0h8 Ug iwY 0Sw SA -R8 bCA ASA bSA
  mAY mAE ) DDEFZGDHZHVCIVCJKJUALUBUCUDUEZIUFLZMZNZDDVDDDUGOUHUIVCAUJZIVIVEVFMZ
  NZVHBUKZIVLVEVFMZNZDVIGDHZVDVLGDHZCABDCULCUMCUNOAUOVCVDVHVOVKAUPZAUQVCVGVIVJV
  CVQVCVQPZIVCVEVFIVIVEVFVCVQAURVRVEVCVQQVFVCVQQRSTVLVPVNVOVKVQABUSVLVMVIVJVLVQ
  VLVQPZIVLVEVFIVIVEVFVLVQABUTVSVEVLVQQVFVLVQQRSTVAVB $. $}
