$c 0wM #Symbol #Variable #SetVariable iA #ElementVariable mwg #Pattern xQg ) ( $.
$v Fw Ow CQ FQ DQ Ew Bw Kw Cw 6Ag 2gg EQ 6xw Dw $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Cg $f #Pattern Cw $.
DA $f #Pattern DQ $.
Dg $f #Pattern Dw $.
EA $f #Pattern EQ $.
Eg $f #Pattern Ew $.
FA $f #Pattern FQ $.
Fg $f #Pattern Fw $.
Kg $f #ElementVariable Kw $.
Og $f #Variable Ow $.
SA $a #Variable Kw $.
jg $a iA Bw Ow Bw Ow $.
${ XgQ $e iA Bw Dw Fw Ow $.
   XwQ $e iA CQ EQ Fw Ow $.
   YAQ $e iA Cw Ew Fw Ow $.
   YQQ $e iA DQ FQ Fw Ow $.
   YgQ $a iA ( 0wM Bw CQ Cw DQ ) ( 0wM Dw EQ Ew FQ ) Fw Ow $. $}
mgg $a #Pattern mwg $.
xAg $a #Pattern xQg $.
2Qg $f #ElementVariable 2gg $.
5wg $f #ElementVariable 6Ag $.
6hw $f #ElementVariable 6xw $.
Wh8 $a #Pattern 2gg $.
dB8 $a #Pattern 6xw $.
BCE $a #Pattern 6Ag $.
AyQ $a iA 6Ag 6Ag 6xw 2gg $.
3yQ $a iA mwg mwg 6xw 2gg $.
4CQ $a iA xQg xQg 6xw 2gg $.
${ 4SQ $p iA ( 0wM mwg 6xw 6Ag xQg ) ( 0wM mwg 2gg 6Ag xQg ) 6xw 2gg $=
  ( mgg dB8 BCE xAg Wh8 SA 3yQ jg AyQ 4CQ YgQ ) DCEZBFZGDAHPGOAIZACJOQKABCLACMN
  $. $}
