$c Uw Ngk #Symbol 7h4 DBE 8Q4 BA0 zw pgg #Pattern 0Q4 rwg 0wM oBM Ex0 xB4 tQM Wgk 5xw #Variable SwE PQk #SetVariable iA vR4 4w rwM #ElementVariable IQE 8hw xQg Vhc 2R4 zBA PgE XBI Tw cwE wQM -g4 .gk rgk ( twM .gM LAQ ewk IAQ Hg8 lhg 8wk ) $.
$v th1 yhs Fw CQ Bw Cw sgg ngg FQ z ph2 3gg Ew ph0 5Qg x Lw LQ Ow qwg DQ ph1 EQ y th2 tAg Dw HQ 4wg xX Gw th0 Hw Kw oAg GQ nR4 tgg $.
$d z y $.
$d z x $.
$d y x $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Cg $f #Pattern Cw $.
DA $f #Pattern DQ $.
Dg $f #Pattern Dw $.
EA $f #Pattern EQ $.
Eg $f #Pattern Ew $.
FA $f #Pattern FQ $.
Fg $f #Pattern Fw $.
GA $f #Pattern GQ $.
Gg $f #Pattern Gw $.
HA $f #Pattern HQ $.
Hg $f #Pattern Hw $.
Kg $f #ElementVariable Kw $.
LA $f #ElementVariable LQ $.
Lg $f #ElementVariable Lw $.
Og $f #Variable Ow $.
SA $a #Variable Kw $.
Ug $a #Pattern ( Uw Kw Bw ) $.
jg $a iA Bw Ow Bw Ow $.
${ kg $e iA CQ DQ Bw Ow $.
   kw $e iA Cw Dw Bw Ow $.
   lA $a iA ( Tw CQ Cw ) ( Tw DQ Dw ) Bw Ow $. $}
4g $a #Pattern ( 4w Bw CQ ) $.
IAE $a #Pattern IQE $.
PQE $a #Pattern ( PgE Bw CQ ) $.
SgE $a #Pattern ( SwE Bw CQ ) $.
lQE $a zw ( Tw Bw Bw ) $.
${ lgE $e zw ( Tw Bw CQ ) $.
   lwE $e zw ( Tw CQ Cw ) $.
   mAE $a zw ( Tw Bw Cw ) $. $}
nAE $a zw IQE $.
ugE $a zw ( Tw ( 4w Bw CQ ) Bw ) $.
uwE $a zw ( Tw ( 4w Bw CQ ) CQ ) $.
${ wAE $e zw ( Tw Bw CQ ) $.
   wQE $e zw ( Tw Bw Cw ) $.
   wgE $a zw ( Tw Bw ( 4w CQ Cw ) ) $. $}
${ $d xX ph0 $.
   IQI $a iA Bw Bw CQ Ow $. $}
${ KAI $e iA CQ DQ Bw Ow $.
   KQI $e iA Cw Dw Bw Ow $.
   KgI $a iA ( 4w CQ Cw ) ( 4w DQ Dw ) Bw Ow $. $}
${ OgI $e iA CQ DQ Bw Ow $.
   OwI $e iA Cw Dw Bw Ow $.
   PAI $a iA ( SwE CQ Cw ) ( SwE DQ Dw ) Bw Ow $. $}
${ NwM $e zw CQ $.
   OAM $a zw ( Tw Bw CQ ) $. $}
tAM $a #Pattern ( tQM Bw CQ ) $.
uwM $a #Pattern ( twM Bw ) $.
wAM $a #Pattern ( wQM Bw CQ Cw ) $.
0gM $a #Pattern ( 0wM Bw CQ Cw DQ ) $.
.QM $a #Pattern ( .gM Bw CQ Cw ) $.
HwQ $a #Pattern ( IAQ Bw CQ ) $.
KwQ $a #Pattern ( LAQ Bw CQ Cw ) $.
${ QAQ $e iA Bw Cw Dw Ow $.
   QQQ $e iA CQ DQ Dw Ow $.
   QgQ $a iA ( tQM Bw CQ ) ( tQM Cw DQ ) Dw Ow $. $}
${ SgQ $e iA Bw DQ Ew Ow $.
   SwQ $e iA CQ Dw Ew Ow $.
   TAQ $e iA Cw EQ Ew Ow $.
   TQQ $a iA ( wQM Bw CQ Cw ) ( wQM DQ Dw EQ ) Ew Ow $. $}
${ XgQ $e iA Bw Dw Fw Ow $.
   XwQ $e iA CQ EQ Fw Ow $.
   YAQ $e iA Cw Ew Fw Ow $.
   YQQ $e iA DQ FQ Fw Ow $.
   YgQ $a iA ( 0wM Bw CQ Cw DQ ) ( 0wM Dw EQ Ew FQ ) Fw Ow $. $}
${ awQ $e iA Bw DQ Ew Ow $.
   bAQ $e iA CQ Dw Ew Ow $.
   bQQ $e iA Cw EQ Ew Ow $.
   bgQ $a iA ( .gM Bw CQ Cw ) ( .gM DQ Dw EQ ) Ew Ow $. $}
${ lAQ $e iA Bw DQ Ew Ow $.
   lQQ $e iA CQ Dw Ew Ow $.
   lgQ $e iA Cw EQ Ew Ow $.
   lwQ $a iA ( LAQ Bw CQ Cw ) ( LAQ DQ Dw EQ ) Ew Ow $. $}
${ $d z ph0 $.
   $d z ph1 $.
   $d z ph2 $.
   $d z y $.
   $d z x $.
   $d z th1 $.
   $d z th2 $.
   $d x ph0 $.
   $d y th0 $.
   lAY $e zw ( Tw GQ ( Uw Kw ( PgE Kw Bw ) ) ) $.
   lQY $e zw ( Tw ( 4w GQ Gw ) CQ ) $.
   lgY $e iA ( Tw HQ Cw ) ( Tw Gw CQ ) Bw LQ $.
   lwY $e iA ( Tw Hw DQ ) ( Tw Gw CQ ) Lw LQ $.
   mAY $a zw ( Tw ( 4w GQ HQ ) Cw ) $. $}
${ $d x ph0 $.
   $d x ph1 $.
   vwY $e zw ( Tw GQ ( SwE CQ Bw ) ) $.
   wAY $e zw ( Tw GQ ( tQM cwE ( rwM Bw cwE Kw ( 0wM Bw cwE Kw CQ ) ) ) ) $.
   wQY $a zw ( Tw GQ ( Uw Kw ( PgE Kw CQ ) ) ) $. $}
nQg $f #Variable ngg $.
nwg $f #Pattern oAg $.
pQg $a #Pattern pgg $.
qgg $f #Pattern qwg $.
rgg $a #Pattern ( rwg oAg qwg ) $.
sQg $f #Pattern sgg $.
swg $f #Pattern tAg $.
tQg $f #Pattern tgg $.
${ uQg $e iA qwg tAg oAg ngg $.
   ugg $e iA sgg tgg oAg ngg $.
   uwg $a iA ( rwg qwg sgg ) ( rwg tAg tgg ) oAg ngg $. $}
xAg $a #Pattern xQg $.
3Qg $f #ElementVariable 3gg $.
4gg $f #ElementVariable 4wg $.
5Ag $f #ElementVariable 5Qg $.
NQk $a #Pattern Ngk $.
WQk $a #Pattern Wgk $.
egk $a #Pattern ewk $.
rQk $a #Pattern rgk $.
8gk $a #Pattern 8wk $.
.Qk $a #Pattern .gk $.
Aw0 $a #Pattern ( BA0 oAg ) $.
0A4 $a #Pattern ( 0Q4 oAg qwg ) $.
${ 1Q4 $e iA qwg tAg oAg ngg $.
   1g4 $e iA sgg tgg oAg ngg $.
   1w4 $a iA ( 0Q4 qwg sgg ) ( 0Q4 tAg tgg ) oAg ngg $. $}
8A4 $a #Pattern ( 8Q4 oAg ) $.
-Q4 $a #Pattern ( -g4 oAg qwg ) $.
${ Ag8 $e iA qwg tAg oAg ngg $.
   Aw8 $e iA sgg tgg oAg ngg $.
   BA8 $a iA ( -g4 qwg sgg ) ( -g4 tAg tgg ) oAg ngg $. $}
HQ8 $a #Pattern ( Hg8 oAg ) $.
${ Ig8 $e iA qwg sgg oAg ngg $.
   Iw8 $a iA ( Hg8 qwg ) ( Hg8 sgg ) oAg ngg $. $}
yxA $a #Pattern ( zBA oAg qwg ) $.
CxE $a #Pattern ( DBE oAg qwg ) $.
GBE $a zw ( Tw ( 4w ( SwE oAg Wgk ) ( SwE qwg Wgk ) ) ( SwE ( DBE oAg qwg ) Wgk ) ) $.
WxI $a #Pattern ( XBI oAg qwg ) $.
${ YBI $e iA qwg tAg oAg ngg $.
   YRI $e iA sgg tgg oAg ngg $.
   YhI $a iA ( XBI qwg sgg ) ( XBI tAg tgg ) oAg ngg $. $}
nxM $a #Pattern ( oBM oAg qwg ) $.
${ pBM $e iA qwg tAg oAg ngg $.
   pRM $e iA sgg tgg oAg ngg $.
   phM $a iA ( oBM qwg sgg ) ( oBM tAg tgg ) oAg ngg $. $}
VRc $a #Pattern ( Vhc oAg ) $.
${ Whc $e iA qwg sgg oAg ngg $.
   Wxc $a iA ( Vhc qwg ) ( Vhc sgg ) oAg ngg $. $}
lRg $a #Pattern ( lhg oAg ) $.
${ mhg $e iA qwg sgg oAg ngg $.
   mxg $a iA ( lhg qwg ) ( lhg sgg ) oAg ngg $. $}
yRs $f #ElementVariable yhs $.
5hw $a #Pattern 5xw $.
8Rw $a #Pattern 8hw $.
Eh0 $a #Pattern Ex0 $.
nB4 $f #ElementVariable nR4 $.
vB4 $a #Pattern vR4 $.
wx4 $a #Pattern xB4 $.
2B4 $a #Pattern 2R4 $.
7R4 $a #Pattern 7h4 $.
HR8 $a zw ( Tw IQE ( SwE ( DBE ( LAQ ewk Wgk ( IAQ ewk vR4 ) ) ( LAQ ewk Wgk ( IAQ ewk 2R4 ) ) ) Wgk ) ) $.
6h8 $a #Pattern nR4 $.
7SA $a #Pattern yhs $.
bSM $a zw ( Tw IQE ( tQM cwE ( rwM Wgk cwE yhs ( 0wM Wgk cwE yhs ( DBE ( LAQ ewk Wgk ( IAQ ewk vR4 ) ) ( LAQ ewk Wgk ( IAQ ewk 2R4 ) ) ) ) ) ) ) $.
XiU $a #Pattern 3gg $.
XyU $a #Pattern 4wg $.
YCU $a #Pattern 5Qg $.
kSU $a iA Ngk Ngk nR4 3gg $.
liU $a iA 4wg 4wg nR4 3gg $.
ljE $a #Pattern ( 4w ( SwE 4wg PQk ) ( 4w ( SwE 5Qg ewk ) IQE ) ) $.
oDE $a #Pattern ( XBI 5Qg 3gg ) $.
zDE $a zw ( Tw ( 4w ( SwE 3gg Wgk ) ( 4w ( SwE 4wg PQk ) ( 4w ( SwE 5Qg ewk ) IQE ) ) ) ( tQM Ngk ( .gM Ngk ( wQM Ngk ( 0wM .gk Ngk ( oBM ( IAQ .gk 5xw ) ( lhg ( Vhc ( rwg ( LAQ Wgk pgg 3gg ) xQg ) ) ) ) ( IAQ .gk 5xw ) ) ( -g4 ( 0Q4 ( Hg8 ( rwg ( LAQ 8wk pgg ( XBI 5Qg 3gg ) ) ( rwg ( LAQ 8wk pgg ( XBI ( IAQ ewk 7h4 ) ( zBA ( LAQ ewk Wgk ( IAQ ewk 7h4 ) ) ( LAQ ewk Wgk ( IAQ ewk 2R4 ) ) ) ) ) ( rwg ( LAQ 8wk pgg ( XBI ( IAQ ewk xB4 ) ( LAQ rgk Wgk ( IAQ rgk Ex0 ) ) ) ) xQg ) ) ) ) 4wg ) ( 8Q4 ( IAQ rgk 8hw ) ) ) ) ( wQM Ngk ( twM Ngk ) ( -g4 ( 0Q4 ( Hg8 ( rwg ( LAQ Wgk pgg 3gg ) ( rwg ( BA0 ( rwg ( LAQ ewk pgg 5Qg ) xQg ) ) ( rwg ( LAQ 8wk pgg ( XBI ( IAQ ewk 7h4 ) ( zBA ( LAQ ewk Wgk ( IAQ ewk 7h4 ) ) ( LAQ ewk Wgk ( IAQ ewk 2R4 ) ) ) ) ) ( rwg ( LAQ 8wk pgg ( XBI ( IAQ ewk xB4 ) ( LAQ rgk Wgk ( IAQ rgk Ex0 ) ) ) ) xQg ) ) ) ) ) 4wg ) ( 8Q4 ( IAQ rgk 8hw ) ) ) ) ) ) ) $.
zTE $a zw ( Tw ( 4w ( 4w ( SwE 4wg PQk ) ( 4w ( SwE 5Qg ewk ) IQE ) ) ( 4w ( SwE 3gg Wgk ) IQE ) ) ( 4w ( SwE 4wg PQk ) ( 4w ( SwE 5Qg ewk ) IQE ) ) ) $.
zjE $a #Pattern ( XBI 5Qg nR4 ) $.
0DE $a iA ( 4w ( SwE nR4 Wgk ) IQE ) ( 4w ( SwE 3gg Wgk ) IQE ) nR4 3gg $.
0TE $a iA .gk .gk nR4 3gg $.
0jE $a iA ( LAQ Wgk pgg nR4 ) ( LAQ Wgk pgg 3gg ) nR4 3gg $.
1DE $a iA ( lhg ( Vhc ( rwg ( LAQ Wgk pgg nR4 ) xQg ) ) ) ( lhg ( Vhc ( rwg ( LAQ Wgk pgg 3gg ) xQg ) ) ) nR4 3gg $.
1jE $a iA ( LAQ 8wk pgg ( XBI 5Qg nR4 ) ) ( LAQ 8wk pgg ( XBI 5Qg 3gg ) ) nR4 3gg $.
1zE $a zw ( Tw ( 4w ( SwE 4wg PQk ) ( 4w ( SwE 5Qg ewk ) IQE ) ) ( 4w ( SwE 4wg PQk ) ( 4w ( SwE 5Qg ewk ) IQE ) ) ) $.
2jE $a zw ( Tw ( 4w ( SwE 4wg PQk ) ( 4w ( SwE 5Qg ewk ) IQE ) ) ( 4w ( SwE ( LAQ ewk Wgk ( IAQ ewk vR4 ) ) Wgk ) ( SwE ( LAQ ewk Wgk ( IAQ ewk 2R4 ) ) Wgk ) ) ) $.
${ 2zE $p zw ( Tw ( 4w ( SwE 4wg PQk ) ( 4w ( SwE 5Qg ewk ) IQE ) ) ( tQM Ngk ( .gM Ngk ( wQM Ngk ( 0wM .gk Ngk ( oBM ( IAQ .gk 5xw ) ( lhg ( Vhc ( rwg ( LAQ Wgk pgg ( DBE ( LAQ ewk Wgk ( IAQ ewk vR4 ) ) ( LAQ ewk Wgk ( IAQ ewk 2R4 ) ) ) ) xQg ) ) ) ) ( IAQ .gk 5xw ) ) ( -g4 ( 0Q4 ( Hg8 ( rwg ( LAQ 8wk pgg ( XBI 5Qg ( DBE ( LAQ ewk Wgk ( IAQ ewk vR4 ) ) ( LAQ ewk Wgk ( IAQ ewk 2R4 ) ) ) ) ) ( rwg ( LAQ 8wk pgg ( XBI ( IAQ ewk 7h4 ) ( zBA ( LAQ ewk Wgk ( IAQ ewk 7h4 ) ) ( LAQ ewk Wgk ( IAQ ewk 2R4 ) ) ) ) ) ( rwg ( LAQ 8wk pgg ( XBI ( IAQ ewk xB4 ) ( LAQ rgk Wgk ( IAQ rgk Ex0 ) ) ) ) xQg ) ) ) ) 4wg ) ( 8Q4 ( IAQ rgk 8hw ) ) ) ) ( wQM Ngk ( twM Ngk ) ( -g4 ( 0Q4 ( Hg8 ( rwg ( LAQ Wgk pgg ( DBE ( LAQ ewk Wgk ( IAQ ewk vR4 ) ) ( LAQ ewk Wgk ( IAQ ewk 2R4 ) ) ) ) ( rwg ( BA0 ( rwg ( LAQ ewk pgg 5Qg ) xQg ) ) ( rwg ( LAQ 8wk pgg ( XBI ( IAQ ewk 7h4 ) ( zBA ( LAQ ewk Wgk ( IAQ ewk 7h4 ) ) ( LAQ ewk Wgk ( IAQ ewk 2R4 ) ) ) ) ) ( rwg ( LAQ 8wk pgg ( XBI ( IAQ ewk xB4 ) ( LAQ rgk Wgk ( IAQ rgk Ex0 ) ) ) ) xQg ) ) ) ) ) 4wg ) ( 8Q4 ( IAQ rgk 8hw ) ) ) ) ) ) ) $=
  ( 3Qg nB4 egk WQk HwQ KwQ IAE 4g NQk .Qk pQg xAg rgg 8gk HQ8 0A4 -Q4 IQI yRs
  ljE vB4 2B4 CxE SgE 5hw VRc lRg nxM 0gM YCU WxI 7R4 yxA wx4 rQk Eh0 XyU Ug SA
  8Rw 8A4 wAM uwM Aw0 .QM tAM 1zE 2jE GBE mAE nAE OAM wgE XiU oDE 6h8 zjE jg lA
  7SA PQE HR8 bSM wQY uwE ugE lQE zTE zDE PAI KgI lwQ uwg Wxc mxg phM YgQ YhI
  Iw8 1w4 BA8 TQQ bgQ QgQ 0DE kSU 0TE 1DE 1jE liU 0jE mAY ) ABUBZXOEFEUCGHZEFEU
  DGHZUEZFUFZIJZJKKKLKLUGGZFMXRHZNOZUHZUIZUJZYAUKZPMBULZXRUMZHZPMEUNGZEFYKHXQUO
  UMHPMEUPGUQFUQURGHUMHNOOZOZQZAUSZRZUQVBGVCZSZVDZKKVEZYBEMYHHNOVFYLOZOZQZYORZY
  QSZVDZVGZVHZXOXOXTABVIXOXSIXOXPFUFXQFUFJXSABVJXPXQVKVLXOIVMVNZVOVOXRKKKLKYAFM
  CVPZHZNOZUHZUIZUJZYAUKZPMCBVQZHZYLOZQZYORZYQSZVDZKYTUUKUUAOZQZYORZYQSZVDZVGZV
  HZUUHKKKLKYAFMDVRZHZNOUHUIZUJZYAUKZPMBDVSHZYLOZQZYORZYQSZVDZKYTUVLUUAOZQZYORZ
  YQSZVDZVGZVHZXOUUJFUFZIJZXTUVKFUFIJZUACDXOIUAWBXRWCUAUTUUIFXRIUAWDUAWEWFVLXOU
  WJJZUWIXOJUVJUWLUWIXOUWLUWJUWIXOUWJWGUWJUWIUWIUWIIWHUWIWIVLVLCABWJVOCABWKVLXR
  XTUUHUWJUVJCVAZXRXSIUWIIUWMXRXRFUUJFUWMXRUWMVTZFXRUWMTZWLIXRUWMTWMKUUGKUVIXRU
  WMKXRUWMTZKYSUUFKUVCUVHXRUWMUWPKYGYRKUUPUVBXRUWMUWPLKYFYALKUUOYAXRUWMLXRUWMTU
  WPUWMXRYAYEYAUUNYAXRUWMTZUWMXRYDUUMUWMXRYCUULUWMXRYBNUUKNFMXRFMUUJXRUWMUWOMXR
  UWMTZUWNWNZNXRUWMTWOWPWQWRUWQWSUWMXRYPYQUVAYQUWMXRYNYOUUTYOUWMXRYMUUSUWMXRYJY
  LUURYLPMYIPMUUQXRUWMPXRUWMTUWRUWMXRYHXRYHUUJYHXRUWMTUWNWTWNYLXRUWMTWOXAYOXRUW
  MTZXBYQXRUWMTZXCXDKYTUUEKYTUVGXRUWMUWPYTXRUWMTUWMXRUUDYQUVFYQUWMXRUUCYOUVEYOU
  WMXRUUBUVDUWMXRYBUUAUUKUUAUWSUUAXRUWMTWOXAUWTXBUXAXCXDXEXFWAUVKUWKUWHUWJUVJUW
  MCDXGKUWGKUVIUVKUWMCDXHZKUWAUWFKUVCUVHUVKUWMUXBKUVOUVTKUUPUVBUVKUWMUXBLKUVNYA
  LKUUOYAUVKUWMCDXIUXBUWMUVKYAUVMYAUUNYAUVKUWMTZCDXJWRUXCWSUWMUVKUVSYQUVAYQUWMU
  VKUVRYOUUTYOUWMUVKUVQUUSUWMUVKUVPYLUURYLCBDXKYLUVKUWMTWOXACADXLZXBYQUVKUWMTZX
  CXDKYTUWEKYTUVGUVKUWMUXBYTUVKUWMTUWMUVKUWDYQUVFYQUWMUVKUWCYOUVEYOUWMUVKUWBUVD
  UWMUVKUVLUUAUUKUUACDXMUUAUVKUWMTWOXAUXDXBUXEXCXDXEXFWAXNVL $. $}
