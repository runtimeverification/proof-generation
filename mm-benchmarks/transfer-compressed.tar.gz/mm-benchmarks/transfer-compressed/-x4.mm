$c ewk xB4 IAQ #Symbol Tw #Variable SwE #SetVariable zw #ElementVariable IQE #Pattern ) ( $.
$v CQ Bw $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Tg $a #Pattern ( Tw Bw CQ ) $.
5Q $a zw ( Tw Bw ( Tw CQ Bw ) ) $.
${ 6A $e zw ( Tw Bw CQ ) $.
   6Q $e zw Bw $.
   6g $a zw CQ $. $}
IAE $a #Pattern IQE $.
SgE $a #Pattern ( SwE Bw CQ ) $.
HwQ $a #Pattern ( IAQ Bw CQ ) $.
IgQ $a zw ( SwE ( IAQ Bw CQ ) Bw ) $.
egk $a #Pattern ewk $.
wx4 $a #Pattern xB4 $.
${ -x4 $p zw ( Tw IQE ( SwE ( IAQ ewk xB4 ) ewk ) ) $=
  ( egk wx4 HwQ SgE IAE Tg 5Q IgQ 6g ) ABCADZEJFJEGABHI $. $}
