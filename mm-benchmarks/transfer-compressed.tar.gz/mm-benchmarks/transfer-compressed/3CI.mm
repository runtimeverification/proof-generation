$c #SetVariable zBI ) #ElementVariable #Symbol #Variable #Pattern ( $.
$v -Rs oAg XRw qwg $.
nwg $f #Pattern oAg $.
qgg $f #Pattern qwg $.
yxI $a #Pattern ( zBI oAg qwg ) $.
-Bs $f #ElementVariable -Rs $.
XBw $f #ElementVariable XRw $.
QCE $a #Pattern XRw $.
QyE $a #Pattern -Rs $.
${ 3CI $p #Pattern ( zBI -Rs XRw ) $=
  ( QyE QCE yxI ) ACBDE $. $}
