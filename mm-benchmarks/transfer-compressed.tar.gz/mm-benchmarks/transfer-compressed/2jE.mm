$c 2R4 Tw #Symbol zw JAQ #Pattern ( LAQ ewk IAQ Wgk #Variable SwE PQk #SetVariable vR4 4w #ElementVariable IQE ) $.
$v 4wg CQ qwg Bw oAg 5Qg Cw sgg $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Cg $f #Pattern Cw $.
4g $a #Pattern ( 4w Bw CQ ) $.
SgE $a #Pattern ( SwE Bw CQ ) $.
${ lgE $e zw ( Tw Bw CQ ) $.
   lwE $e zw ( Tw CQ Cw ) $.
   mAE $a zw ( Tw Bw Cw ) $. $}
${ wAE $e zw ( Tw Bw CQ ) $.
   wQE $e zw ( Tw Bw Cw ) $.
   wgE $a zw ( Tw Bw ( 4w CQ Cw ) ) $. $}
HwQ $a #Pattern ( IAQ Bw CQ ) $.
IwQ $a #Pattern ( JAQ Bw ) $.
KwQ $a #Pattern ( LAQ Bw CQ Cw ) $.
nwg $f #Pattern oAg $.
qgg $f #Pattern qwg $.
sQg $f #Pattern sgg $.
4gg $f #ElementVariable 4wg $.
5Ag $f #ElementVariable 5Qg $.
.gg $a zw ( Tw ( 4w ( 4w ( JAQ oAg ) ( JAQ qwg ) ) ( SwE sgg oAg ) ) ( SwE ( LAQ oAg qwg sgg ) qwg ) ) $.
WQk $a #Pattern Wgk $.
egk $a #Pattern ewk $.
vB4 $a #Pattern vR4 $.
2B4 $a #Pattern 2R4 $.
ljE $a #Pattern ( 4w ( SwE 4wg PQk ) ( 4w ( SwE 5Qg ewk ) IQE ) ) $.
2DE $a zw ( Tw ( 4w ( SwE 4wg PQk ) ( 4w ( SwE 5Qg ewk ) IQE ) ) ( 4w ( 4w ( JAQ ewk ) ( JAQ Wgk ) ) ( SwE ( IAQ ewk vR4 ) ewk ) ) ) $.
2TE $a zw ( Tw ( 4w ( SwE 4wg PQk ) ( 4w ( SwE 5Qg ewk ) IQE ) ) ( 4w ( 4w ( JAQ ewk ) ( JAQ Wgk ) ) ( SwE ( IAQ ewk 2R4 ) ewk ) ) ) $.
${ 2jE $p zw ( Tw ( 4w ( SwE 4wg PQk ) ( 4w ( SwE 5Qg ewk ) IQE ) ) ( 4w ( SwE ( LAQ ewk Wgk ( IAQ ewk vR4 ) ) Wgk ) ( SwE ( LAQ ewk Wgk ( IAQ ewk 2R4 ) ) Wgk ) ) ) $=
  ( ljE egk WQk vB4 HwQ KwQ SgE 2B4 IwQ 4g 2DE .gg mAE 2TE wgE ) ABCZDEDFGZHEIZ
  DEDJGZHEIZRDKEKLZSDILTABMDESNORUCUADILUBABPDEUANOQ $. $}
