$c #SetVariable iA ) JAQ #ElementVariable #Symbol #Variable #Pattern ( $.
$v Ow CQ xX ph2 Bw Kw ph1 ph0 Cw 2gg x 6xw $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Cg $f #Pattern Cw $.
Kg $f #ElementVariable Kw $.
Og $f #Variable Ow $.
SA $a #Variable Kw $.
jg $a iA Bw Ow Bw Ow $.
${ $d x ph0 $.
   $d x ph1 $.
   $d x ph2 $.
   $d x xX $.
   mAQ $e iA Bw CQ Cw Ow $.
   mQQ $a iA ( JAQ Bw ) ( JAQ CQ ) Cw Ow $. $}
2Qg $f #ElementVariable 2gg $.
6hw $f #ElementVariable 6xw $.
Wh8 $a #Pattern 2gg $.
dB8 $a #Pattern 6xw $.
${ -x8 $p iA ( JAQ 6xw ) ( JAQ 2gg ) 6xw 2gg $=
  ( dB8 Wh8 SA jg mQQ ) BCZADHAEZHIFG $. $}
