$c #Symbol Tw #Variable #SetVariable zw 4w JAQ #ElementVariable IQE #Pattern ) ( $.
$v Cw CQ 6xw Bw $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Cg $f #Pattern Cw $.
4g $a #Pattern ( 4w Bw CQ ) $.
IAE $a #Pattern IQE $.
lQE $a zw ( Tw Bw Bw ) $.
${ lgE $e zw ( Tw Bw CQ ) $.
   lwE $e zw ( Tw CQ Cw ) $.
   mAE $a zw ( Tw Bw Cw ) $. $}
ugE $a zw ( Tw ( 4w Bw CQ ) Bw ) $.
uwE $a zw ( Tw ( 4w Bw CQ ) CQ ) $.
IwQ $a #Pattern ( JAQ Bw ) $.
6hw $f #ElementVariable 6xw $.
dB8 $a #Pattern 6xw $.
${ 0x8 $p zw ( Tw ( 4w IQE ( 4w ( JAQ 6xw ) IQE ) ) ( JAQ 6xw ) ) $=
  ( IAE dB8 IwQ 4g uwE ugE lQE mAE ) BACDZBEZEKJBKFKJJJBGJHII $. $}
