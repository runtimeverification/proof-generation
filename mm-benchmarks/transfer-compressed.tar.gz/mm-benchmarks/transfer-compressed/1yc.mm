$c Uw PgE Tw #Symbol cwE zw JAQ pgg #Pattern ( 0wM LAQ ewk xB4 tQM IAQ #Variable SwE #SetVariable 4w rwM #ElementVariable IQE ) $.
$v yhs CQ Bw XRw Kw ph1 Cw 2gg ph0 GQ x $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Cg $f #Pattern Cw $.
GA $f #Pattern GQ $.
Kg $f #ElementVariable Kw $.
Ug $a #Pattern ( Uw Kw Bw ) $.
IAE $a #Pattern IQE $.
PQE $a #Pattern ( PgE Bw CQ ) $.
${ lgE $e zw ( Tw Bw CQ ) $.
   lwE $e zw ( Tw CQ Cw ) $.
   mAE $a zw ( Tw Bw Cw ) $. $}
nAE $a zw IQE $.
${ NwM $e zw CQ $.
   OAM $a zw ( Tw Bw CQ ) $. $}
HwQ $a #Pattern ( IAQ Bw CQ ) $.
KwQ $a #Pattern ( LAQ Bw CQ Cw ) $.
${ $d x ph0 $.
   $d x ph1 $.
   vwY $e zw ( Tw GQ ( SwE CQ Bw ) ) $.
   wAY $e zw ( Tw GQ ( tQM cwE ( rwM Bw cwE Kw ( 0wM Bw cwE Kw CQ ) ) ) ) $.
   wQY $a zw ( Tw GQ ( Uw Kw ( PgE Kw CQ ) ) ) $. $}
pQg $a #Pattern pgg $.
2Qg $f #ElementVariable 2gg $.
egk $a #Pattern ewk $.
yRs $f #ElementVariable yhs $.
XBw $f #ElementVariable XRw $.
wx4 $a #Pattern xB4 $.
Nh8 $a zw ( Tw IQE ( SwE ( LAQ ewk pgg ( IAQ ewk xB4 ) ) pgg ) ) $.
7SA $a #Pattern yhs $.
QSE $a #Pattern ( 4w ( JAQ 2gg ) ( 4w ( SwE XRw pgg ) IQE ) ) $.
1ic $a zw ( Tw IQE ( tQM cwE ( rwM pgg cwE yhs ( 0wM pgg cwE yhs ( LAQ ewk pgg ( IAQ ewk xB4 ) ) ) ) ) ) $.
${ 1yc $p zw ( Tw ( 4w ( JAQ 2gg ) ( 4w ( SwE XRw pgg ) IQE ) ) ( Uw yhs ( PgE yhs ( LAQ ewk pgg ( IAQ ewk xB4 ) ) ) ) ) $=
  ( QSE IAE 7SA egk pQg wx4 HwQ KwQ PQE Ug nAE OAM Nh8 1ic wQY mAE ) ACDZEBFGHG
  IJKZLBMTENOHUAEBPBQRS $. $}
