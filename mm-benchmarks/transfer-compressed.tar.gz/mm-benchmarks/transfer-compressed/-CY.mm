$c Uw Ngk #Symbol GBY 8Q4 zw YQk pgg #Pattern 0Q4 rwg 0wM tQM #Variable SwE #SetVariable iA vR4 4w rwM #ElementVariable IQE 8hw xQg cBQ ww4 2R4 PgE 1wk Tw cwE wQM -gg -g4 rgk ( twM .gM LAQ ewk IAQ 9R4 Hg8 3BA Kw8 8wk 7BI ) $.
$v th1 CQ Bw Cw sgg ngg z ph2 3gg Ew ph0 5Qg x Lw LQ Ow qwg DQ ph1 EQ y th2 tAg Dw HQ 4wg xX Gw th0 Hw Kw oAg 6Ag GQ nR4 tgg 4Ag $.
$d z y $.
$d z x $.
$d y x $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Cg $f #Pattern Cw $.
DA $f #Pattern DQ $.
Dg $f #Pattern Dw $.
EA $f #Pattern EQ $.
Eg $f #Pattern Ew $.
GA $f #Pattern GQ $.
Gg $f #Pattern Gw $.
HA $f #Pattern HQ $.
Hg $f #Pattern Hw $.
Kg $f #ElementVariable Kw $.
LA $f #ElementVariable LQ $.
Lg $f #ElementVariable Lw $.
Og $f #Variable Ow $.
SA $a #Variable Kw $.
Ug $a #Pattern ( Uw Kw Bw ) $.
jg $a iA Bw Ow Bw Ow $.
${ kg $e iA CQ DQ Bw Ow $.
   kw $e iA Cw Dw Bw Ow $.
   lA $a iA ( Tw CQ Cw ) ( Tw DQ Dw ) Bw Ow $. $}
4g $a #Pattern ( 4w Bw CQ ) $.
IAE $a #Pattern IQE $.
PQE $a #Pattern ( PgE Bw CQ ) $.
SgE $a #Pattern ( SwE Bw CQ ) $.
lQE $a zw ( Tw Bw Bw ) $.
${ lgE $e zw ( Tw Bw CQ ) $.
   lwE $e zw ( Tw CQ Cw ) $.
   mAE $a zw ( Tw Bw Cw ) $. $}
nAE $a zw IQE $.
ugE $a zw ( Tw ( 4w Bw CQ ) Bw ) $.
uwE $a zw ( Tw ( 4w Bw CQ ) CQ ) $.
${ wAE $e zw ( Tw Bw CQ ) $.
   wQE $e zw ( Tw Bw Cw ) $.
   wgE $a zw ( Tw Bw ( 4w CQ Cw ) ) $. $}
${ $d xX ph0 $.
   IQI $a iA Bw Bw CQ Ow $. $}
${ KAI $e iA CQ DQ Bw Ow $.
   KQI $e iA Cw Dw Bw Ow $.
   KgI $a iA ( 4w CQ Cw ) ( 4w DQ Dw ) Bw Ow $. $}
${ OgI $e iA CQ DQ Bw Ow $.
   OwI $e iA Cw Dw Bw Ow $.
   PAI $a iA ( SwE CQ Cw ) ( SwE DQ Dw ) Bw Ow $. $}
${ NwM $e zw CQ $.
   OAM $a zw ( Tw Bw CQ ) $. $}
tAM $a #Pattern ( tQM Bw CQ ) $.
uwM $a #Pattern ( twM Bw ) $.
wAM $a #Pattern ( wQM Bw CQ Cw ) $.
.QM $a #Pattern ( .gM Bw CQ Cw ) $.
HwQ $a #Pattern ( IAQ Bw CQ ) $.
KwQ $a #Pattern ( LAQ Bw CQ Cw ) $.
${ QAQ $e iA Bw Cw Dw Ow $.
   QQQ $e iA CQ DQ Dw Ow $.
   QgQ $a iA ( tQM Bw CQ ) ( tQM Cw DQ ) Dw Ow $. $}
${ SgQ $e iA Bw DQ Ew Ow $.
   SwQ $e iA CQ Dw Ew Ow $.
   TAQ $e iA Cw EQ Ew Ow $.
   TQQ $a iA ( wQM Bw CQ Cw ) ( wQM DQ Dw EQ ) Ew Ow $. $}
${ awQ $e iA Bw DQ Ew Ow $.
   bAQ $e iA CQ Dw Ew Ow $.
   bQQ $e iA Cw EQ Ew Ow $.
   bgQ $a iA ( .gM Bw CQ Cw ) ( .gM DQ Dw EQ ) Ew Ow $. $}
${ $d z ph0 $.
   $d z ph1 $.
   $d z ph2 $.
   $d z y $.
   $d z x $.
   $d z th1 $.
   $d z th2 $.
   $d x ph0 $.
   $d y th0 $.
   lAY $e zw ( Tw GQ ( Uw Kw ( PgE Kw Bw ) ) ) $.
   lQY $e zw ( Tw ( 4w GQ Gw ) CQ ) $.
   lgY $e iA ( Tw HQ Cw ) ( Tw Gw CQ ) Bw LQ $.
   lwY $e iA ( Tw Hw DQ ) ( Tw Gw CQ ) Lw LQ $.
   mAY $a zw ( Tw ( 4w GQ HQ ) Cw ) $. $}
${ $d x ph0 $.
   $d x ph1 $.
   vwY $e zw ( Tw GQ ( SwE CQ Bw ) ) $.
   wAY $e zw ( Tw GQ ( tQM cwE ( rwM Bw cwE Kw ( 0wM Bw cwE Kw CQ ) ) ) ) $.
   wQY $a zw ( Tw GQ ( Uw Kw ( PgE Kw CQ ) ) ) $. $}
nQg $f #Variable ngg $.
nwg $f #Pattern oAg $.
pQg $a #Pattern pgg $.
qgg $f #Pattern qwg $.
rgg $a #Pattern ( rwg oAg qwg ) $.
sQg $f #Pattern sgg $.
swg $f #Pattern tAg $.
tQg $f #Pattern tgg $.
xAg $a #Pattern xQg $.
3Qg $f #ElementVariable 3gg $.
3wg $f #ElementVariable 4Ag $.
4gg $f #ElementVariable 4wg $.
5Ag $f #ElementVariable 5Qg $.
5wg $f #ElementVariable 6Ag $.
NQk $a #Pattern Ngk $.
YAk $a #Pattern YQk $.
egk $a #Pattern ewk $.
rQk $a #Pattern rgk $.
1gk $a #Pattern 1wk $.
wg4 $a #Pattern ww4 $.
0A4 $a #Pattern ( 0Q4 oAg qwg ) $.
${ 1Q4 $e iA qwg tAg oAg ngg $.
   1g4 $e iA sgg tgg oAg ngg $.
   1w4 $a iA ( 0Q4 qwg sgg ) ( 0Q4 tAg tgg ) oAg ngg $. $}
8A4 $a #Pattern ( 8Q4 oAg ) $.
-Q4 $a #Pattern ( -g4 oAg qwg ) $.
${ Ag8 $e iA qwg tAg oAg ngg $.
   Aw8 $e iA sgg tgg oAg ngg $.
   BA8 $a iA ( -g4 qwg sgg ) ( -g4 tAg tgg ) oAg ngg $. $}
HQ8 $a #Pattern ( Hg8 oAg ) $.
Kg8 $a #Pattern ( Kw8 oAg ) $.
${ Lw8 $e iA qwg sgg oAg ngg $.
   MA8 $a iA ( Kw8 qwg ) ( Kw8 sgg ) oAg ngg $. $}
6xI $a #Pattern ( 7BI oAg qwg ) $.
${ 8BI $e iA qwg tAg oAg ngg $.
   8RI $e iA sgg tgg oAg ngg $.
   8hI $a iA ( 7BI qwg sgg ) ( 7BI tAg tgg ) oAg ngg $. $}
.BI $a zw ( Tw ( 4w ( SwE oAg YQk ) ( SwE qwg YQk ) ) ( SwE ( 7BI oAg qwg ) YQk ) ) $.
bxQ $a #Pattern ( cBQ oAg qwg ) $.
FxY $a #Pattern ( GBY oAg qwg ) $.
8Rw $a #Pattern 8hw $.
nB4 $f #ElementVariable nR4 $.
vB4 $a #Pattern vR4 $.
2B4 $a #Pattern 2R4 $.
9B4 $a #Pattern 9R4 $.
KB8 $a zw ( Tw IQE ( SwE ( cBQ ( LAQ ewk pgg ( IAQ ewk 9R4 ) ) ( LAQ rgk pgg ( IAQ rgk 8hw ) ) ) YQk ) ) $.
Lh8 $a zw ( Tw IQE ( SwE ( cBQ ( LAQ ewk pgg ( IAQ ewk 2R4 ) ) ( LAQ rgk pgg ( IAQ rgk 8hw ) ) ) YQk ) ) $.
MR8 $a zw ( Tw IQE ( SwE ( cBQ ( LAQ ewk pgg ( IAQ ewk vR4 ) ) ( LAQ rgk pgg ( IAQ rgk 8hw ) ) ) YQk ) ) $.
6h8 $a #Pattern nR4 $.
BCE $a #Pattern 6Ag $.
BCQ $a #Pattern 4Ag $.
RCQ $a iA ( 4w ( SwE nR4 YQk ) IQE ) ( 4w ( SwE 4Ag YQk ) IQE ) nR4 4Ag $.
RyQ $a iA Ngk Ngk nR4 4Ag $.
XiU $a #Pattern 3gg $.
XyU $a #Pattern 4wg $.
YSU $a #Pattern ( 4w ( SwE 4wg 8wk ) ( 4w ( SwE 5Qg -gg ) IQE ) ) $.
ayU $a #Pattern ( 3BA 3gg 5Qg ) $.
bCU $a #Pattern ( 0Q4 ( Hg8 ( rwg ( LAQ 1wk pgg ( GBY ( 3BA 3gg 5Qg ) 4wg ) ) xQg ) ) ( Kw8 ( 7BI 4Ag ww4 ) ) ) $.
bSU $a #Pattern ( GBY 5Qg 4wg ) $.
diU $a zw ( Tw ( 4w ( SwE 4Ag YQk ) ( 4w ( SwE 3gg ewk ) ( 4w ( SwE 4wg 8wk ) ( 4w ( SwE 5Qg -gg ) IQE ) ) ) ) ( tQM Ngk ( .gM Ngk ( wQM Ngk ( twM Ngk ) ( -g4 ( 0Q4 ( Hg8 ( rwg ( LAQ 1wk pgg ( GBY ( 3BA 3gg 5Qg ) 4wg ) ) xQg ) ) ( Kw8 ( 7BI 4Ag ww4 ) ) ) ( 8Q4 ( IAQ rgk 8hw ) ) ) ) ( wQM Ngk ( twM Ngk ) ( -g4 ( 0Q4 ( Hg8 ( rwg ( LAQ 1wk pgg ( GBY 5Qg 4wg ) ) xQg ) ) ( Kw8 ( 7BI 4Ag ( cBQ ( LAQ ewk pgg 3gg ) ( LAQ rgk pgg ( IAQ rgk 8hw ) ) ) ) ) ) ( 8Q4 ( IAQ rgk 8hw ) ) ) ) ) ) ) $.
eyU $a zw ( Tw ( 4w ( 4w ( SwE 3gg ewk ) ( 4w ( SwE 4wg 8wk ) ( 4w ( SwE 5Qg -gg ) IQE ) ) ) ( 4w ( SwE 4Ag YQk ) IQE ) ) ( 4w ( SwE 4wg 8wk ) ( 4w ( SwE 5Qg -gg ) IQE ) ) ) $.
fCU $a #Pattern ( 0Q4 ( Hg8 ( rwg ( LAQ 1wk pgg ( GBY ( 3BA 3gg 5Qg ) 4wg ) ) xQg ) ) ( Kw8 ( 7BI nR4 ww4 ) ) ) $.
gCU $a iA ( Kw8 ( 7BI nR4 ww4 ) ) ( Kw8 ( 7BI 4Ag ww4 ) ) nR4 4Ag $.
giU $a zw ( Tw ( 4w ( SwE 3gg ewk ) ( 4w ( SwE 4wg 8wk ) ( 4w ( SwE 5Qg -gg ) IQE ) ) ) ( 4w ( SwE 4wg 8wk ) ( 4w ( SwE 5Qg -gg ) IQE ) ) ) $.
YyY $a zw ( Tw ( 4w ( SwE 3gg ewk ) ( 4w ( SwE 4wg 8wk ) ( 4w ( SwE 5Qg -gg ) IQE ) ) ) ( SwE ( cBQ ( LAQ ewk pgg ( IAQ ewk 9R4 ) ) ( LAQ rgk pgg ( IAQ rgk 8hw ) ) ) YQk ) ) $.
nyY $a zw ( Tw ( 4w ( SwE 3gg ewk ) ( 4w ( SwE 4wg 8wk ) ( 4w ( SwE 5Qg -gg ) IQE ) ) ) ( SwE ( cBQ ( LAQ ewk pgg ( IAQ ewk 2R4 ) ) ( LAQ rgk pgg ( IAQ rgk 8hw ) ) ) YQk ) ) $.
.CY $a zw ( Tw IQE ( tQM cwE ( rwM YQk cwE 6Ag ( 0wM YQk cwE 6Ag ( 7BI ( cBQ ( LAQ ewk pgg ( IAQ ewk vR4 ) ) ( LAQ rgk pgg ( IAQ rgk 8hw ) ) ) ( 7BI ( cBQ ( LAQ ewk pgg ( IAQ ewk 9R4 ) ) ( LAQ rgk pgg ( IAQ rgk 8hw ) ) ) ( cBQ ( LAQ ewk pgg ( IAQ ewk 2R4 ) ) ( LAQ rgk pgg ( IAQ rgk 8hw ) ) ) ) ) ) ) ) ) $.
.yY $a zw ( Tw ( 4w ( SwE 3gg ewk ) ( 4w ( SwE 4wg 8wk ) ( 4w ( SwE 5Qg -gg ) IQE ) ) ) ( SwE ( cBQ ( LAQ ewk pgg ( IAQ ewk vR4 ) ) ( LAQ rgk pgg ( IAQ rgk 8hw ) ) ) YQk ) ) $.
${ -CY $p zw ( Tw ( 4w ( SwE 3gg ewk ) ( 4w ( SwE 4wg 8wk ) ( 4w ( SwE 5Qg -gg ) IQE ) ) ) ( tQM Ngk ( .gM Ngk ( wQM Ngk ( twM Ngk ) ( -g4 ( 0Q4 ( Hg8 ( rwg ( LAQ 1wk pgg ( GBY ( 3BA 3gg 5Qg ) 4wg ) ) xQg ) ) ( Kw8 ( 7BI ( 7BI ( cBQ ( LAQ ewk pgg ( IAQ ewk vR4 ) ) ( LAQ rgk pgg ( IAQ rgk 8hw ) ) ) ( 7BI ( cBQ ( LAQ ewk pgg ( IAQ ewk 9R4 ) ) ( LAQ rgk pgg ( IAQ rgk 8hw ) ) ) ( cBQ ( LAQ ewk pgg ( IAQ ewk 2R4 ) ) ( LAQ rgk pgg ( IAQ rgk 8hw ) ) ) ) ) ww4 ) ) ) ( 8Q4 ( IAQ rgk 8hw ) ) ) ) ( wQM Ngk ( twM Ngk ) ( -g4 ( 0Q4 ( Hg8 ( rwg ( LAQ 1wk pgg ( GBY 5Qg 4wg ) ) xQg ) ) ( Kw8 ( 7BI ( 7BI ( cBQ ( LAQ ewk pgg ( IAQ ewk vR4 ) ) ( LAQ rgk pgg ( IAQ rgk 8hw ) ) ) ( 7BI ( cBQ ( LAQ ewk pgg ( IAQ ewk 9R4 ) ) ( LAQ rgk pgg ( IAQ rgk 8hw ) ) ) ( cBQ ( LAQ ewk pgg ( IAQ ewk 2R4 ) ) ( LAQ rgk pgg ( IAQ rgk 8hw ) ) ) ) ) ( cBQ ( LAQ ewk pgg 3gg ) ( LAQ rgk pgg ( IAQ rgk 8hw ) ) ) ) ) ) ( 8Q4 ( IAQ rgk 8hw ) ) ) ) ) ) ) $=
  ( 3wg nB4 egk SgE 4g pQg KwQ 6xI YAk IAE NQk wg4 Kg8 -Q4 mAE wgE IQI Ug SA jg
  5wg XiU YSU vB4 HwQ rQk 8Rw bxQ 9B4 2B4 uwM 1gk ayU XyU FxY xAg rgg HQ8 0A4
  8A4 wAM bSU .QM tAM ugE lQE giU .yY YyY nyY .BI nAE OAM bCU BCQ fCU 6h8 BCE
  PQE MR8 KB8 Lh8 .CY wQY uwE eyU diU PAI KgI 8hI MA8 1w4 BA8 TQQ bgQ QgQ RCQ
  lA RyQ gCU mAY ) AUEZFGZBCUFZHZXHFIFUGUHJUIIUIUJUHZJZUKZFIFULUHJXJUKZFIFUMUHJ
  XJUKZKZKZLGZMHZHNNNNUNZUOIACUPBUQURJUSUTVAZXOOKZPZVBZXIVCZQZVDZNXRUOIBCVEJUSU
  TVAZXOFIXEJXJUKZKZPZVBZYCQZVDZVFZVGZXHXHXQXHXFXGXHXFXFXFXGVHZXFVIRABCVJSXHXPM
  XHXKLGZXNLGZHZXPXHYPYQABCVKXHXLLGZXMLGZHZYQXHYSYTABCVLABCVMSXLXMVNZRSXKXNVNZR
  XHMVOVPZSSXONNNXRADBCVQZYCQZVDZNXRYFDVRZYGKZPZVBZYCQZVDZVFZVGZYNNNNXRABCEVSZY
  CQZVDZNXRYFEVTZYGKZPZVBZYCQZVDZVFZVGZXHUUHLGZMHZXQUUSLGMHZUDDEXHMUDWAXOWBUDUA
  UUDLXOMUDMYRXPMYPYQWCMUUAYQMYSYTWDWESUUBRSUUCRUDWFWGRXHUVHHZUVGXHHUUOUVJUVGXH
  UVJUVHUVGXHUVHWHUVHUVGUVGUVGMVHUVGVIRRUVJXFXGUVJXHXFXHUVHVHYORADBCWISSADBCWJR
  XOXQYNUVHUUODUBZXOXPMUVGMUVKXOXOLUUHLUVKXOUVKUCZLXOUVKTWKMXOUVKTWLNYMNUUNXOUV
  KNXOUVKTZNYEYLNUUGUUMXOUVKUVMNXRYDNXRUUFXOUVKUVMXRXOUVKTZUVKXOYBYCUUEYCUVKXOX
  SYAXSUUHOKZPZXSXOUVKTUVKXOXTUVOUVKXOXOOUUHOUVLOXOUVKTWMWNWOYCXOUVKTZWPWQNXRYK
  NXRUULXOUVKUVMUVNUVKXOYJYCUUKYCUVKXOYFYIYFUUJYFXOUVKTUVKXOYHUUIUVKXOXOYGUUHYG
  UVLYGXOUVKTWMWNWOUVQWPWQWRWSXAUUSUVIUVFUVHUUOUVKDEWTNUVENUUNUUSUVKDEXBZNUURUV
  DNUUGUUMUUSUVKUVRNXRUUQNXRUUFUUSUVKUVRXRUUSUVKTZUVKUUSUUPYCUUEYCUVKUUSXSUUSOK
  PXSUVPXSUUSUVKTDEXCWOYCUUSUVKTZWPWQNXRUVCNXRUULUUSUVKUVRUVSUVKUUSUVBYCUUKYCUV
  KUUSYFUVAYFUUJYFUUSUVKTUVKUUSUUTUUIUVKUUSUUSYGUUHYGUUSUVKUCYGUUSUVKTWMWNWOUVT
  WPWQWRWSXAXDR $. $}
