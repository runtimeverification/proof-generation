$c LAQ XBI #Symbol #Variable #SetVariable iA #ElementVariable 8wk pgg #Pattern ) ( $.
$v Ow CQ 3gg DQ Ew Bw Kw 5Qg Cw nR4 EQ Dw $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Cg $f #Pattern Cw $.
DA $f #Pattern DQ $.
Dg $f #Pattern Dw $.
EA $f #Pattern EQ $.
Eg $f #Pattern Ew $.
Kg $f #ElementVariable Kw $.
Og $f #Variable Ow $.
SA $a #Variable Kw $.
${ lAQ $e iA Bw DQ Ew Ow $.
   lQQ $e iA CQ Dw Ew Ow $.
   lgQ $e iA Cw EQ Ew Ow $.
   lwQ $a iA ( LAQ Bw CQ Cw ) ( LAQ DQ Dw EQ ) Ew Ow $. $}
pQg $a #Pattern pgg $.
3Qg $f #ElementVariable 3gg $.
5Ag $f #ElementVariable 5Qg $.
8gk $a #Pattern 8wk $.
nB4 $f #ElementVariable nR4 $.
6h8 $a #Pattern nR4 $.
kyU $a iA pgg pgg nR4 3gg $.
kyc $a iA 8wk 8wk nR4 3gg $.
oDE $a #Pattern ( XBI 5Qg 3gg ) $.
zjE $a #Pattern ( XBI 5Qg nR4 ) $.
1TE $a iA ( XBI 5Qg nR4 ) ( XBI 5Qg 3gg ) nR4 3gg $.
${ 1jE $p iA ( LAQ 8wk pgg ( XBI 5Qg nR4 ) ) ( LAQ 8wk pgg ( XBI 5Qg 3gg ) ) nR4 3gg $=
  ( 8gk pQg zjE oDE 6h8 SA kyc kyU 1TE lwQ ) DEBCFDEABGCHAIACJACKABCLM $. $}
