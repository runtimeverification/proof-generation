$c rwg LAQ 1wk 1gM #Symbol #Variable pgg #SetVariable iA #ElementVariable mwg #Pattern xQg ) ( $.
$v Fw Ow CQ qwg DQ Bw Cw 2gg EQ 3Ag Dw FQ xX Ew Kw ph0 oAg nR4 4Ag $.
Bg $f #Pattern Bw $.
CA $f #Pattern CQ $.
Cg $f #Pattern Cw $.
DA $f #Pattern DQ $.
Dg $f #Pattern Dw $.
EA $f #Pattern EQ $.
Eg $f #Pattern Ew $.
FA $f #Pattern FQ $.
Fg $f #Pattern Fw $.
Kg $f #ElementVariable Kw $.
Og $f #Variable Ow $.
SA $a #Variable Kw $.
jg $a iA Bw Ow Bw Ow $.
${ $d xX ph0 $.
   IQI $a iA Bw Bw CQ Ow $. $}
KwQ $a #Pattern ( LAQ Bw CQ Cw ) $.
${ YwQ $e iA Bw Dw Fw Ow $.
   ZAQ $e iA CQ EQ Fw Ow $.
   ZQQ $e iA Cw Ew Fw Ow $.
   ZgQ $e iA DQ FQ Fw Ow $.
   ZwQ $a iA ( 1gM Bw CQ Cw DQ ) ( 1gM Dw EQ Ew FQ ) Fw Ow $. $}
mgg $a #Pattern mwg $.
nwg $f #Pattern oAg $.
pQg $a #Pattern pgg $.
qgg $f #Pattern qwg $.
rgg $a #Pattern ( rwg oAg qwg ) $.
xAg $a #Pattern xQg $.
2Qg $f #ElementVariable 2gg $.
2wg $f #ElementVariable 3Ag $.
3wg $f #ElementVariable 4Ag $.
1gk $a #Pattern 1wk $.
nB4 $f #ElementVariable nR4 $.
Wh8 $a #Pattern 2gg $.
6h8 $a #Pattern nR4 $.
BCQ $a #Pattern 4Ag $.
ByQ $a #Pattern 3Ag $.
FSQ $a iA 2gg 2gg nR4 3Ag $.
-CQ $a iA mwg mwg nR4 3Ag $.
${ -yQ $p iA ( 1gM mwg 2gg nR4 ( rwg ( LAQ 1wk pgg 4Ag ) xQg ) ) ( 1gM mwg 2gg 3Ag ( rwg ( LAQ 1wk pgg 4Ag ) xQg ) ) nR4 3Ag $=
  ( mgg Wh8 6h8 1gk pQg BCQ KwQ xAg rgg ByQ SA -CQ FSQ jg IQI ZwQ ) EAFZDGZHICJ
  KLMZEUABNUCUBBOZBDPABDQUBUDRUCUBUDST $. $}
