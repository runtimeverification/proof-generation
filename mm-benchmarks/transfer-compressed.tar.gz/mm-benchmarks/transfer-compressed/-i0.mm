$c rwg #Symbol #Variable #SetVariable iA #ElementVariable #Pattern xQg ) ( $.
$v ngg Ow qwg -Bw Bw Kw oAg nR4 sgg tAg tgg $.
Bg $f #Pattern Bw $.
Kg $f #ElementVariable Kw $.
Og $f #Variable Ow $.
SA $a #Variable Kw $.
jg $a iA Bw Ow Bw Ow $.
nQg $f #Variable ngg $.
nwg $f #Pattern oAg $.
qgg $f #Pattern qwg $.
sQg $f #Pattern sgg $.
swg $f #Pattern tAg $.
tQg $f #Pattern tgg $.
${ uQg $e iA qwg tAg oAg ngg $.
   ugg $e iA sgg tgg oAg ngg $.
   uwg $a iA ( rwg qwg sgg ) ( rwg tAg tgg ) oAg ngg $. $}
xAg $a #Pattern xQg $.
.xw $f #ElementVariable -Bw $.
nB4 $f #ElementVariable nR4 $.
6h8 $a #Pattern nR4 $.
yyg $a #Pattern -Bw $.
Fys $a iA xQg xQg nR4 -Bw $.
${ -i0 $p iA ( rwg nR4 xQg ) ( rwg -Bw xQg ) nR4 -Bw $=
  ( SA 6h8 xAg yyg jg Fys uwg ) ACZBDZKEAFEKJGABHI $. $}
